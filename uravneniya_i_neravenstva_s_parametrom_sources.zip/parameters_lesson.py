from pathlib import Path
import math
import json

import numpy as np
from manim import Axes, Create, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Уравнения и неравенства с параметром"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



def graph(kind):
    if kind is None:
        return VGroup(),VGroup()
    xrange={
        "line":(-2.3,3.2),"circle":(-2.7,2.7),"segment":(-2.7,2.7),
        "levels":(-.55,2.65),"abs_sum":(-3.6,4.5),"root":(-.8,2.9),
    }[kind]
    yrange={
        "line":(-1.35,5.5),"circle":(-2.7,2.7),"segment":(-.5,4.4),
        "levels":(-1.35,3.25),"abs_sum":(-.3,6.1),"root":(-1.25,4.6),
    }[kind]
    axes=Axes(x_range=[*xrange,1],y_range=[*yrange,1],x_length=5.25,y_length=3.73,
              axis_config={"include_ticks":False,"color":MUTED,"stroke_width":1.65}).move_to([-3.62,-.22,0])
    if kind=="circle":
        curves=VGroup(*[axes.plot(fn,x_range=[-2,2,.015],color=CYAN,stroke_width=3.0)
                        for fn in (lambda x:math.sqrt(max(0,4-x*x)),lambda x:-math.sqrt(max(0,4-x*x)))],
                      Line(axes.c2p(-2.5,1),axes.c2p(2.47,1),color=GOLD,stroke_width=2.7))
        return VGroup(axes),curves
    if kind=="segment":
        high,low=axes.c2p(2,3),axes.c2p(-2,1)
        return VGroup(axes),VGroup(Line(high,low,color=CYAN,stroke_width=3.0),
                                   *[Dot(p,color=GOLD,radius=.065) for p in (high,low)])
    if kind=="abs_sum":
        fx=lambda x:abs(x-2)+abs(x+1)
        return VGroup(axes),VGroup(axes.plot(fx,x_range=[-2.5,3.5,.02],color=CYAN,stroke_width=3.0),
                                   Line(axes.c2p(-3.3,4.8),axes.c2p(4.25,4.8),color=GOLD,stroke_width=2.5))
    curves={
        "line":[(lambda x:x*x,(-2.2,2.2),CYAN),(lambda x:x+1,(-2.2,3.1),GOLD),
                (lambda x:-x+1,(-2.25,2.29),LAVENDER)],
        "levels":[(lambda x:x*x-2*x,(-.53,2.62),CYAN),(lambda x:1.,(-.48,2.54),GOLD)],
        "root":[(lambda x:x*x-x,(0,2.68),CYAN),(lambda x:-.16,(0,2.68),GOLD)],
    }[kind]
    return VGroup(axes),VGroup(*[axes.plot(f,x_range=[lo,hi,.04],color=c,stroke_width=3.2)
                               for f,(lo,hi),c in curves])


class ParametersLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind in ("abs_sum",) else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
