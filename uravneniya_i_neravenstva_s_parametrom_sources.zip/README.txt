Установите Python, системные зависимости Manim, шрифт DejaVu Sans и FFmpeg. Из распакованной папки последовательно выполните команды.

python -m pip install manim==0.20.1 matplotlib
python -m manim --disable_caching --media_dir media/01_01 -o part.mp4 parameters_lesson.py ParametersLesson
python assemble.py 1-1
