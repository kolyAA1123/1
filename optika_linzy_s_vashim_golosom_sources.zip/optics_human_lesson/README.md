# Оптика и линзы — монтаж с авторской озвучкой

Исходные анимации и сценарий опубликованы в `optika_linzy_sources.zip`
и `optika_linzy_tekst.txt`. Этот проект использует опубликованный
`optika_linzy_1080p60.mp4` и запись `compress.mp3`. В итоговой версии
17 глав, 114 реплик и 57 действий на экране.

`boundaries.json` содержит границы пауз в записи в секундах.
Реплики сопоставлены со сценарием по распознанному тексту. Границы
проверены по сигналу и по распознаванию коротких фрагментов с обеих
сторон каждого перехода. Пауза перед объяснением закона отражения
уточнена по сигналу около 43 с. Перед результатом обратного хода
наклонного пучка сохранено тихое начало фразы около 1546,6 с.
`edit.json` описывает соответствие кадров и аудиоотсчётов,
`timeline.txt` содержит сценарий с обновлёнными таймкодами.

## Повторная сборка

Распакуйте архив. Запустите команды из папки `optics_human_lesson`
в Python 3.11+ с NumPy и FFmpeg с libx264.

```sh
python build_edit.py /path/to/optika_linzy_1080p60.mp4 /path/to/compress.mp3
bash render_audited.sh /path/to/optika_linzy_1080p60.mp4 optika_linzy_s_vashim_golosom_1080p60.mp4
mv source-audited.gray source.gray
python check_holds.py source.gray
ffmpeg -v error -xerror -threads 2 -i optika_linzy_s_vashim_golosom_1080p60.mp4 \
  -map 0:v:0 -vf scale=160:90,format=gray -filter_threads 1 -f rawvideo delivered.gray \
  -map 0:a:0 -f s16le audio_decode.s16
python verify_edit.py optika_linzy_s_vashim_golosom_1080p60.mp4
```

Монтаж меняет длительность статичных кадров между анимациями и паузы
между репликами. Внутри реплик отсчёты идут непрерывно с исходным темпом
и высотой. Для выпуска запись сведена в моно и закодирована в AAC.

Исходная запись используется локально. В архив включены сценарий, план,
монтажные решения и результаты проверок.
