#!/usr/bin/env bash
set -euo pipefail
film=$1
output=$2
python - <<'PY'
from pathlib import Path
edit = Path('edit/video.filter').read_text().strip()
Path('render.filter').write_text(
    '[0:v:0]split=2[audit][video];'
    '[audit]scale=160:90,format=gray[source];'
    f'[video]{edit}[edited]\n'
)
PY
ffmpeg -nostdin -hide_banner -n -xerror -threads 2 -i "$film" -i edit/narration.wav \
  -f ffmetadata -i edit/chapters.ffmeta -filter_complex_threads 1 -filter_complex_script render.filter \
  -map '[edited]' -map 1:a:0 -map_metadata 2 -map_chapters 2 \
  -c:v libx264 -threads:v 2 -preset superfast -crf 23 -g 480 -pix_fmt yuv420p \
  -c:a aac -b:a 80k -metadata:s:a:0 language=rus -movflags +faststart "$output" \
  -map '[source]' -c:v rawvideo -threads:v 1 -f rawvideo source-audited.gray
