"""Verify the measured 100-cue own-voice edition against its source assets.

This validates actual delivery media, exact PCM placement, and frame partitions.
ASR is an alignment aid; this report does not certify pronunciation or perform
human listening. Source held frames are decoded over their complete intervals.
"""
from __future__ import annotations
from dataclasses import asdict
from fractions import Fraction
import argparse,hashlib,json,subprocess,wave
from pathlib import Path
import numpy as np
from retime_video import build_segments,input_at_frame

ROOT=Path(__file__).resolve().parent
ORIGINAL_SOURCE=ROOT.parent/'magnetism_lesson'
SOURCE=ROOT/'visual_source' if (ROOT/'visual_source').exists() else ORIGINAL_SOURCE
PREFIX='magnetizm_magnitnyy_potok_s_vashim_golosom'
FPS=60;RATE=48000
CHAPTER_COUNT=19;CUE_COUNT=120;BEAT_COUNT=60;SOURCE_SECONDS=3517

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def verify_original_integrity():
    baseline=read(ROOT/'original_source_manifest.json')
    assert len(baseline['chapters'])==CHAPTER_COUNT
    assert len(baseline['source_files'])==27 and len(baseline['reports'])==76
    for group in ('chapters','source_files','reports'):
        for item in baseline[group]:
            assert digest(ORIGINAL_SOURCE/item['file'])==item['sha256'],('Original asset modified',item['file'])
    movie=baseline['published_movie']
    assert digest(ROOT.parent/movie['file'])==movie['sha256'],'Original silent film modified'
    return {'chapters':len(baseline['chapters']),'source_files':len(baseline['source_files']),
            'reports':len(baseline['reports']),'published_silent_movie':True,'unchanged':True}

def probe(p):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-show_chapters','-of','json',str(p)]))
def wav(p,rate=RATE):
    with wave.open(str(p)) as w:
        assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,rate),p
        return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy()
def video_info(p,frames,audio):
    d=probe(p);vs=[s for s in d['streams'] if s['codec_type']=='video'];ads=[s for s in d['streams'] if s['codec_type']=='audio']
    assert len(vs)==1 and len(ads)==int(audio),p
    v=vs[0];assert (v['width'],v['height'],Fraction(v['avg_frame_rate']))==(1920,1080,FPS),p
    assert int(v['nb_frames'])==frames,(p,v['nb_frames'],frames)
    assert abs(float(d['format']['duration'])-frames/FPS)<.06,p
    if audio:
        a=ads[0];assert (a['codec_name'],int(a['sample_rate']),a['channels'])==('aac',RATE,1),p
        assert abs(float(a['duration'])-frames/FPS)<.06,p
    return d

def interval_frames(p,a,b,width=160,height=90):
    inputs,first=input_at_frame(p,a)
    raw=subprocess.check_output(['ffmpeg','-v','error','-filter_threads','1',*inputs,'-an',
       '-vf',f'trim=start_frame={first}:end_frame={first+b-a},scale={width}:{height},format=rgb24',
       '-frames:v',str(b-a),'-f','rawvideo','pipe:1'])
    frames=np.frombuffer(raw,dtype=np.uint8).reshape(-1,height,width,3)
    assert len(frames)==b-a,(p,a,b,len(frames))
    return frames

def static_limits(p,item,source_sha):
    limits={'mean_limit':.15,'channel_limit':8}
    exceptions=ROOT/'static_exceptions.json'
    if exceptions.exists():
        for exception in read(exceptions)['exceptions']:
            if (source_sha,item['old_start_frame'],item['old_end_frame'])!=(exception['source_sha256'],exception['start_frame'],exception['end_frame']):continue
            if exception.get('require_frozen_wait'):
                chapters=read(ROOT/'output/source_timeline.json')['chapters']
                chapter=next(ch for ch in chapters if Path(ch['source']).name==p.name)
                assert any(e['kind']=='wait' and e['frozen_wait'] and
                    (e['source_start_frame'],e['source_end_frame'])==(exception['start_frame'],exception['end_frame'])
                    for e in chapter['events']),exception
            limits={k:exception[k] for k in ('mean_limit','channel_limit','reason')}
    return limits

def verify_static(p,item,source_sha):
    a,b=item['old_start_frame'],item['old_end_frame']
    frames=interval_frames(p,a,b)
    diff=np.abs(frames.astype(np.int16)-frames[len(frames)//2].astype(np.int16))
    means=diff.mean(axis=(1,2,3));maximum=int(diff.max())
    limits=static_limits(p,item,source_sha)
    assert float(means.max())<limits['mean_limit'] and maximum<=limits['channel_limit'],(p,item['label'],float(means.max()),maximum)
    return {'label':item['label'],'start_frame':a,'end_frame':b,'decoded_frames':len(frames),
            'max_frame_mean_abs_rgb_difference':round(float(means.max()),6),'max_channel_difference':maximum,
            'accepted_limits':limits}

def cached_static(p,item,source_sha):
    """Reuse only complete decoded checks of the identical source/interval."""
    cache_path=ROOT/'output/source_static_validation.json'
    cache=read(cache_path) if cache_path.exists() else {'schema':1,'checks':{}}
    key=f"{source_sha}:{item['old_start_frame']}:{item['old_end_frame']}"
    check=cache['checks'].get(key)
    if check is None:
        check=verify_static(p,item,source_sha);cache['checks'][key]=check
        temporary=cache_path.with_suffix('.tmp.json')
        temporary.write_text(json.dumps(cache,ensure_ascii=False,indent=2)+'\n');temporary.replace(cache_path)
    limits=static_limits(p,item,source_sha)
    assert check['max_frame_mean_abs_rgb_difference']<limits['mean_limit'] and check['max_channel_difference']<=limits['channel_limit']
    return {**check,'label':item['label'],'source_sha256':source_sha}

def boundary_checks(cuts,guide,edits):
    assert len(cuts)==len(edits)==CUE_COUNT
    assert cuts[0]['source_start']==0
    assert abs(cuts[-1]['source_end']-len(guide)/16000)<=1/16000
    checks=[]
    for a,b in zip(cuts,cuts[1:]):
        assert abs(a['source_end']-b['source_start'])<1e-6
        t=a['source_end'];window=guide[max(0,round((t-.02)*16000)):round((t+.02)*16000)].astype(float)/32768
        rms=float(np.sqrt(np.mean(window**2)))
        assert rms<.01,(a['key'],b['key'],t,rms)
        checks.append({'after':a['key'],'time':t,'boundary_40ms_rms_dbfs':round(20*np.log10(max(rms,1e-9)),3)})
    # Removed content must be quiet edge pauses, never a recognized word range.
    for c,e in zip(cuts,edits):
        assert c['key']==e['key']
        for lo,hi in ((c['source_start'],e['retained_source_start']),(e['retained_source_end'],c['source_end'])):
            g=guide[round(lo*16000):round(hi*16000)].astype(float)/32768
            n=len(g)//160
            if n:
                rms=np.sqrt((g[:n*160].reshape(n,160)**2).mean(axis=1))
                assert float(rms.max())<.008,(c['key'],lo,hi,float(rms.max()))
    return checks

def mapped_frame(point,replacements):
    delta=0
    for item in replacements:
        if point>=item['old_end_frame']:
            delta+=item['new_frame_count']-(item['old_end_frame']-item['old_start_frame'])
        elif point>item['old_start_frame']:
            raise AssertionError(('Audio anchor inside replaced interval',point,item))
    return point+delta

def verify_reading_phases(ch,old,mp,source_windows,timeline):
    """Check the measured speech against exact source reading/action intervals."""
    windows={w['key']:w for w in source_windows['windows']}
    cues={c['key']:c for c in ch['cues']}
    expected=[f"{ch['id']:02d}_{i+1:02d}_{phase}"
              for i in range(len(old['beats'])) for phase in ('intro','result')]
    assert set(windows)==set(cues)==set(expected),(ch['id'],'Reading window coverage')
    main={r['label']:r for r in mp['replacements'] if r['label']!='tail_padding'}
    assert set(main)==set(expected),(ch['id'],'Unexpected replacement of a non-reading interval')
    results=[]
    for key in expected:
        w,c,r=windows[key],cues[key],main[key]
        assert (r['old_start_frame'],r['old_end_frame'])==(w['old_start_frame'],w['old_end_frame'])
        assert c['speech_source_start_frame']==w['old_start_frame']
        assert c['phase']==w['phase'] and c['beat']==w['beat']
        assert c['key']==f"{ch['id']:02d}_{c['beat']:02d}_{c['phase']}"
        assert abs(c['at']*FPS-r['new_start_frame'])<1e-7
        assert c['at']+c['speech_duration']<=(r['new_start_frame']+r['new_frame_count'])/FPS+1/RATE
        ready=w.get('ready_event_frame',w['old_start_frame'])
        assert ready<=w['old_start_frame'],(key,'Speech before source state was ready')
        assert mapped_frame(ready,mp['replacements'])/FPS<=c['at']+1/FPS,(key,'Speech before mapped state readiness')
    actions=timeline.get('actions',source_windows.get('actions',[]))
    assert len(actions)==len(old['beats']),(ch['id'],'Missing exact source actions')
    for i,(beat,action) in enumerate(zip(old['beats'],actions),1):
        intro=windows[f"{ch['id']:02d}_{i:02d}_intro"]
        result=windows[f"{ch['id']:02d}_{i:02d}_result"]
        a,b=action['old_start_frame'],action['old_end_frame']
        assert intro['old_end_frame']<=a<b<=result['old_start_frame'],(ch['id'],i,'Intro/action/result order')
        assert b-a==round(beat['action_seconds']*FPS),(ch['id'],i,'Original action length')
        for r in main.values():
            assert r['old_end_frame']<=a or r['old_start_frame']>=b,(ch['id'],i,'Action frame replaced')
        new_a=mapped_frame(a,mp['replacements']);new_b=mapped_frame(b,mp['replacements'])
        assert new_b-new_a==b-a,(ch['id'],i,'Action speed/order changed')
        ci=cues[intro['key']];cr=cues[result['key']]
        assert ci['at']+ci['speech_duration']<=new_a/FPS+1/RATE
        assert cr['at']>=new_b/FPS-1/RATE
        results.append({'beat':i,'source_start_frame':a,'source_end_frame':b,
                        'new_start_frame':new_a,'new_end_frame':new_b,
                        'all_action_frames_preserved':True,
                        'intro_to_action_guard_seconds':round(new_a/FPS-ci['at']-ci['speech_duration'],6),
                        'action_to_result_guard_seconds':round(cr['at']-new_b/FPS,6)})
    return results

def verify_preassembly():
    integrity=verify_original_integrity()
    out=ROOT/'output';plan=read(ROOT/'plan.json');mapping=read(ROOT/'frame_map.json')
    original=read(SOURCE/'plan.json')
    source_windows={c['id']:c for c in read(ROOT/'source_windows.json')['chapters']}
    timeline={c['id']:c for c in read(out/'source_timeline.json')['chapters']}
    assert len(plan['chapters'])==len(mapping['chapters'])==CHAPTER_COUNT
    cuts=read(ROOT/'cuts.json')['cues'];edits=read(out/'edit_decisions.json')
    guide=wav(ROOT/'materials/recording_16k.wav',16000)
    boundaries=boundary_checks(cuts,guide,edits)
    processed=wav(ROOT/'materials/recording_processed.wav')
    for cut,edit in zip(cuts,edits):
        a=round(cut['source_start']*RATE)
        lo=round((edit['retained_source_start']-cut['source_start'])*RATE)
        hi=round((edit['retained_source_end']-cut['source_start'])*RATE)
        expected=processed[a+lo:a+hi].copy();ramp=min(240,len(expected)//2)
        expected[:ramp]=(expected[:ramp]*np.linspace(0,1,ramp)).astype('<i2')
        expected[-ramp:]=(expected[-ramp:]*np.linspace(1,0,ramp)).astype('<i2')
        part=out/'audio/parts'/f"{cut['key']}.wav"
        assert len(expected)==edit['samples'] and edit['sha256']==digest(part)
        assert np.array_equal(expected,wav(part)),cut['key']
    del processed
    master=wav(out/'audio/narration.wav');assert len(master)==plan['duration']*RATE
    offset=0;keys=[];phase_checks=[]
    for ch,old,mp in zip(plan['chapters'],original['chapters'],mapping['chapters']):
        assert ch['start']==offset and ch['id']==old['id']==mp['id']
        build_segments(old['duration']*FPS,mp['replacements'],ch['duration']*FPS)
        phase_checks.extend({'chapter':ch['id'],**p} for p in verify_reading_phases(ch,old,mp,source_windows[ch['id']],timeline[ch['id']]))
        track=wav(out/'audio/chapters'/f"{ch['id']:02d}.wav")
        assert len(track)==ch['duration']*RATE
        assert np.array_equal(master[offset*RATE:(offset+ch['duration'])*RATE],track)
        cursor=0
        for cue in ch['cues']:
            pcm=wav(ROOT/cue['file']);a=round(cue['at']*RATE);b=a+len(pcm)
            assert a>=cursor and b<=len(track)
            assert not np.any(track[cursor:a]) and np.array_equal(track[a:b],pcm),cue['key']
            assert abs(cue['global_at']-offset-cue['at'])<1e-8
            assert abs(len(pcm)/RATE-cue['speech_duration'])<1/RATE
            cursor=b;keys.append(cue['key'])
        assert not np.any(track[cursor:]);offset+=ch['duration']
    assert len(keys)==len(set(keys))==CUE_COUNT and len(phase_checks)==BEAT_COUNT
    assert offset==plan['duration']
    report={'complete':True,'cues':CUE_COUNT,'beats':BEAT_COUNT,'chapters':CHAPTER_COUNT,
            'duration_seconds':offset,'frames':offset*FPS,'exact_parts_reconstruction':True,
            'exact_master_pcm_placement':True,'silent_gaps_zero':True,
            'reading_action_phase_checks':phase_checks,'acoustic_boundaries':boundaries,
            'original_integrity':integrity,
            'scope':'Preassembly exact PCM and frame-map validation; delivered AAC and full decode are separate.'}
    (out/'preassembly_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(f'PREASSEMBLY PASSED {CUE_COUNT}cues,{BEAT_COUNT}actions,{offset}s,{offset*FPS}frames',flush=True)
    return report

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--skip-decode',action='store_true',help='Diagnostic only; report is explicitly incomplete.')
    parser.add_argument('--source-only',action='store_true',help='Precheck immutable source hold intervals before final assembly.')
    parser.add_argument('--preassembly',action='store_true',help='Check exact audio parts, PCM layout and reading/action phase maps before muxing.')
    args=parser.parse_args()
    if args.preassembly:
        verify_preassembly();return
    if args.source_only:
        integrity=verify_original_integrity()
        full_timeline=ROOT/'source_windows.json'
        if full_timeline.exists():
            timeline=read(full_timeline)
        else:
            available=sorted((ROOT/'output').glob('source_timeline_chapter_*.json'))
            assert available,'No complete per-chapter source timeline is available yet'
            timeline={'chapters':[read(p)['chapters'][0] for p in available]}
        print(f"Prechecking {len(timeline['chapters'])}/{CHAPTER_COUNT} available source chapters",flush=True)
        checked=[]
        for chapter in timeline['chapters']:
            path=SOURCE/'output/chapters'/Path(chapter['source']).name;source_sha=digest(path)
            for window in chapter['windows']:
                item={'label':window['key'],
                      'old_start_frame':window['old_start_frame'],'old_end_frame':window['old_end_frame']}
                result=cached_static(path,item,source_sha)
                checked.append({'chapter':chapter['id'],'source':str(path),**result})
                print(f"Static {item['label']}: meanDifference={result['max_frame_mean_abs_rgb_difference']}; channelMax={result['max_channel_difference']}",flush=True)
        complete=len(timeline['chapters'])==CHAPTER_COUNT and len(checked)==CUE_COUNT
        report={'complete':complete,'chapters':len(timeline['chapters']),'cues':len(checked),
                'source_root':str(SOURCE),'checks':checked,'original_integrity':integrity,
                'scope':'Full decoded source reading intervals only; delivery verification is separate.'}
        (ROOT/'output/source_static_selected_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        print(f'SOURCE STATIC {len(checked)} intervals checked; complete={complete}',flush=True)
        return
    integrity=verify_original_integrity()
    out=ROOT/'output';plan=read(ROOT/'plan.json');source_plan=read(SOURCE/'plan.json');mapping=read(ROOT/'frame_map.json')
    correction_path=ROOT/'visual_corrections.json'
    corrections=read(correction_path) if correction_path.exists() else {'corrected_chapter_ids':[],'chapters':[],'only_label_positions_changed':True}
    corrected={c['id']:c for c in corrections['chapters']}
    assert set(corrected)==set(corrections['corrected_chapter_ids'])
    assert set(corrected)<=set(range(1,CHAPTER_COUNT+1)), 'Unknown corrected chapter'
    assert corrections['only_label_positions_changed']
    # Original assets/reports are checked independently against the immutable
    # baseline, whether or not the new visual source needed a correction.
    if corrected:
        assert corrections['original_sources_unchanged']
        for report in corrections.get('original_reports_before_after',[]):
            assert report['unchanged'] and report['before_sha256']==report['after_sha256']
            assert digest(ORIGINAL_SOURCE/report['relative'])==report['before_sha256'],('Original report modified',report['relative'])
    window_chapters={c['id']:c for c in read(ROOT/'source_windows.json')['chapters']}
    anchors={w['key']:w for c in window_chapters.values() for w in c['windows']}
    source_timeline={c['id']:c for c in read(ROOT/'output/source_timeline.json')['chapters']}
    assert len(plan['chapters'])==len(mapping['chapters'])==len(source_plan['chapters'])==CHAPTER_COUNT
    assert source_plan['duration']==SOURCE_SECONDS
    assert plan['voice']['synthetic_speech_used'] is False
    movie=out/f'{PREFIX}_1080p60.mp4'
    final=video_info(movie,plan['duration']*FPS,True)
    assert len(final['chapters'])==CHAPTER_COUNT
    guide=wav(ROOT/'materials/recording_16k.wav',16000)
    recording=read(ROOT/'recording_manifest.json')
    asr_recording=read(ROOT/'asr_recording_manifest.json')
    assert recording['sha256']==asr_recording['source_sha256']
    assert recording['original_bytes']==asr_recording['source_bytes']
    assert digest(ROOT/'materials/recording_16k.wav')==asr_recording['guide_sha256']
    if recording.get('processed_wav_sha256'):
        assert digest(ROOT/'materials/recording_processed.wav')==recording['processed_wav_sha256']
    edits=read(out/'edit_decisions.json');cuts=read(ROOT/'cuts.json')['cues']
    boundaries=boundary_checks(cuts,guide,edits)
    processed=wav(ROOT/'materials/recording_processed.wav')
    for cut,edit in zip(cuts,edits):
        # Reconstruct the exact segment from the levelled supplied recording,
        # including the documented5ms edge fade, rather than trusting a filename.
        a=round(cut['source_start']*RATE)
        left=round((edit['retained_source_start']-cut['source_start'])*RATE)
        right=round((edit['retained_source_end']-cut['source_start'])*RATE)
        expected=processed[a+left:a+right].copy()
        ramp=min(240,len(expected)//2)
        expected[:ramp]=(expected[:ramp]*np.linspace(0,1,ramp)).astype('<i2')
        expected[-ramp:]=(expected[-ramp:]*np.linspace(1,0,ramp)).astype('<i2')
        part=out/'audio/parts'/f"{cut['key']}.wav"
        assert edit['sha256']==digest(part)
        assert len(expected)==edit['samples'] and np.array_equal(expected,wav(part)),cut['key']
    del processed
    master=wav(out/'audio/narration.wav');assert len(master)==plan['duration']*RATE
    offset=0;all_cues=[];chapters=[];source_hashes=[];original_hashes=[]
    baseline=read(ROOT/'original_source_manifest.json')
    original_baseline={c['id']:c['sha256'] for c in baseline['chapters']}
    for item in baseline['source_files']:
        assert digest(ORIGINAL_SOURCE/item['file'])==item['sha256'],('Original source file modified',item['file'])
    original_movie=baseline['published_movie']
    assert digest(ROOT.parent/original_movie['file'])==original_movie['sha256'],'Original published silent movie modified'
    for ch,old,mp,meta in zip(plan['chapters'],source_plan['chapters'],mapping['chapters'],final['chapters']):
        assert ch['id']==old['id']==mp['id']
        assert ch['start']==offset
        assert abs(float(meta['start_time'])-offset)<.0011
        assert abs(float(meta['end_time'])-offset-ch['duration'])<.0011
        assert meta['tags']['title']==ch['title']
        name=f"{ch['id']:02d}_{ch['class']}.mp4"
        source=SOURCE/'output/chapters'/name;clip=out/'chapters'/name
        video_info(source,old['duration']*FPS,False);video_info(clip,ch['duration']*FPS,False)
        partition=build_segments(old['duration']*FPS,mp['replacements'],ch['duration']*FPS)
        report=read(out/'retime_reports'/f"{ch['id']:02d}.json")
        source_sha=digest(source);source_hashes.append({'chapter':ch['id'],'sha256':source_sha})
        original_sha=digest(ORIGINAL_SOURCE/'output/chapters'/name)
        assert original_sha==original_baseline[ch['id']],(ch['id'],'Original source modified')
        original_hashes.append({'chapter':ch['id'],'sha256':original_sha})
        if ch['id'] not in corrected:
            assert source_sha==original_sha,(ch['id'],'Unexpected visual source change')
        else:
            correction=corrected[ch['id']]
            assert source_sha!=original_sha,(ch['id'],'Corrected visual source not rendered')
            assert (source_sha,original_sha)==(correction['new_sha256'],correction['original_sha256'])
            tail=correction.get('source_tail_padding_frames',correction.get('original_tail_padding_frames',0))
            assert correction['source_frames']==old['duration']*FPS==sum(correction['partial_frame_counts'])+tail
            assert correction['same_frame_count'] and correction['partial_frame_counts_unchanged'] and correction['event_timing_unchanged']
        assert report['source_sha256']==source_sha
        assert report['sha256']==digest(clip)
        assert report['source_frames']==old['duration']*FPS and report['frames']==ch['duration']*FPS
        assert report['non_hold_frames_preserved_in_order'] is True and report['motion_speed_changed'] is False
        timestamp_repair=report.get('concat_timestamp_repair')
        if timestamp_repair:
            assert timestamp_repair['method']=='decoded_frame_order_setpts_CFR'
            assert timestamp_repair['decoded_frames']==ch['duration']*FPS
            assert timestamp_repair['output_fps']==FPS
            assert timestamp_repair['frame_interpolation_used'] is False
        assert len(partition)==len(report['segments'])
        for seg,actual in zip(partition,report['segments']):
            assert all(actual[k]==v for k,v in asdict(seg).items()),(ch['id'],seg)
        holds=[]
        for r in mp['replacements']:
            if r['label']=='tail_padding':assert r['old_end_frame']-r['old_start_frame']==1;continue
            if r['label'] in anchors:
                anchor=anchors[r['label']]
                assert (r['old_start_frame'],r['old_end_frame'])==(anchor['old_start_frame'],anchor['old_end_frame'])
            elif r['old_end_frame']-r['old_start_frame']>1:
                # Reviewed additional pauses (e.g. zero velocity at the apex)
                # must lie inside a real source Wait event, then decode static.
                waits=[e for e in source_timeline[ch['id']]['events'] if e['kind']=='wait']
                assert any(e['source_start_frame']<=r['old_start_frame']<r['old_end_frame']<=e['source_end_frame'] for e in waits),r
            else:
                # An inserted readable pause repeats one existing frame without
                # discarding or slowing any of the following movement frames.
                assert r['old_end_frame']-r['old_start_frame']==1,r
            holds.append(cached_static(source,r,source_sha))
        track=wav(out/'audio/chapters'/f"{ch['id']:02d}.wav");assert len(track)==ch['duration']*RATE
        assert np.array_equal(master[offset*RATE:(offset+ch['duration'])*RATE],track)
        cursor=0
        assert len(ch['cues'])==2*len(old['beats'])
        assert [(c['beat'],c['phase']) for c in ch['cues']]==[(i+1,phase) for i in range(len(old['beats'])) for phase in ('intro','result')]
        for cue in ch['cues']:
            assert cue['chapter']==ch['id']
            assert abs(mapped_frame(cue['speech_source_start_frame'],mp['replacements'])/FPS-cue['at'])<1e-8,cue['key']
            a=round(cue['at']*RATE);pcm=wav(ROOT/cue['file']);b=a+len(pcm)
            assert a>=cursor and b<=len(track)
            assert not np.any(track[cursor:a])
            assert np.array_equal(track[a:b],pcm),cue['key']
            assert abs(len(pcm)/RATE-cue['speech_duration'])<1/RATE
            assert abs(cue['global_at']-(offset+cue['at']))<1e-7
            r=next(r for r in mp['replacements'] if r['label']==cue['key'])
            next_transition=(r['new_start_frame']+r['new_frame_count'])/FPS
            assert cue['at']+cue['speech_duration']<=next_transition+1/RATE,(cue['key'],next_transition)
            assert cue['phase'] in ('intro','result')
            assert cue['speech_source_start_frame']==anchors[cue['key']]['old_start_frame']
            assert cue['key']==f"{ch['id']:02d}_{cue['beat']:02d}_{cue['phase']}"
            cursor=b;all_cues.append(cue)
        assert not np.any(track[cursor:])
        phase_checks=verify_reading_phases(ch,old,mp,window_chapters[ch['id']],source_timeline[ch['id']])
        fade=interval_frames(clip,ch['duration']*FPS-72,ch['duration']*FPS)
        energy=fade.mean(axis=(1,2,3))
        assert energy[-1]/max(energy[0],.001)<.08,(ch['id'],energy[0],energy[-1])
        assert float(np.diff(energy).max())<.12,(ch['id'],float(np.diff(energy).max()))
        corner=interval_frames(movie,offset*FPS+180,offset*FPS+181,160,90)[0,:2,:2]
        assert int(corner.max())<=1,(ch['id'],corner.max())
        chapters.append({'id':ch['id'],'frames':ch['duration']*FPS,'static_holds':holds,
            'reading_action_phase_checks':phase_checks,
            'source_non_hold_frames_partition_preserved':True,'fades_to_black':True,'black_corner':True,
            'concat_timestamp_repair':timestamp_repair})
        offset+=ch['duration'];print(f"Verified chapter {ch['id']:02d}:{len(ch['cues'])}cues,{len(holds)}static holds",flush=True)
    assert len(all_cues)==CUE_COUNT and offset==plan['duration']
    decoded=subprocess.check_output(['ffmpeg','-v','error','-i',str(movie),'-map','0:a:0','-f','s16le','-ac','1','-ar',str(RATE),'pipe:1'])
    actual=np.frombuffer(decoded,dtype='<i2')
    assert len(master)<=len(actual)<=len(master)+1024,(len(master),len(actual))
    actual=actual[:len(master)]
    # AAC is lossy. Exact PCM placement above is complemented by correlation
    # against actual delivered speech, so a stale/different mux fails.
    audio_checks=[]
    for cue in all_cues:
        a=round(cue['global_at']*RATE);b=a+round(cue['speech_duration']*RATE)
        expected=master[a:b].astype(float);heard=actual[a:b].astype(float)
        corr=float(np.dot(expected,heard)/max(1.,np.linalg.norm(expected)*np.linalg.norm(heard)))
        assert corr>.975,(cue['key'],corr)
        audio_checks.append({'key':cue['key'],'aac_pcm_correlation':round(corr,6)})
    decode_log=out/'decode_check.log'
    if not args.skip_decode:
        print('Decoding entire video and audio...',flush=True)
        with decode_log.open('w') as log:
            result=subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(movie),'-map','0:v:0','-map','0:a:0','-f','null','-'],stderr=log)
        assert result.returncode==0 and decode_log.stat().st_size==0,decode_log
    summary={'title':plan['title'],'duration_seconds':plan['duration'],'resolution':[1920,1080],
        'fps':FPS,'frames':plan['duration']*FPS,'audio_streams':1,'audio_format':'AAC mono48k',
        'provided_recording':True,'synthetic_speech_used':False,'speech_speed_changed':False,
        'cues':CUE_COUNT,'chapters':chapters,'source_chapter_hashes':source_hashes,'acoustic_boundaries':boundaries,
        'original_source_chapter_hashes':original_hashes,
        'original_source_files_unchanged':True,'original_published_movie_unchanged':True,
        'original_reports_unchanged':True,'original_integrity':integrity,
        'visual_corrections':corrections,
        'static_tolerance_exceptions':read(ROOT/'static_exceptions.json')['exceptions'] if (ROOT/'static_exceptions.json').exists() else [],
        'exact_parts_from_provided_processed_recording_passed':True,
        'recording_sha256':recording['sha256'],
        'exact_master_pcm_placement_passed':True,'delivered_aac_checks':audio_checks,
        'full_decode_passed':not args.skip_decode,'complete':not args.skip_decode,
        'bytes':movie.stat().st_size,'sha256':digest(movie),
        'limitations':'ASR and acoustic checks do not certify pronunciation. Motion preservation is verified structurally against explicit frame partitions and encoder reports; static source windows are decoded completely.'}
    (out/'quality_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(f"VERIFIED {movie.name}: {plan['duration']}s; {summary['bytes']} bytes; {summary['sha256']}",flush=True)

if __name__=='__main__':main()
