"""Conservative acoustic boundaries, preferring existing long-pause chunk cuts."""
from pathlib import Path
import json,wave
import numpy as np
ROOT=Path(__file__).resolve().parent

def main():
 d=json.loads((ROOT/'output/alignment_proposals.json').read_text());cues=d['cues']
 chunks={c['index']:c for c in json.loads((ROOT/'output/transcription.json').read_text())}
 with wave.open(str(ROOT/'materials/recording_16k.wav'),'rb') as w:
  a=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
 hop=160;n=len(a)//hop;r=np.sqrt((a[:n*hop].reshape(n,hop)**2).mean(1));quiet=r<10**(-43/20)
 changes=np.diff(np.r_[False,quiet,False].astype(int))
 pauses=[(int(s)/100,int(e)/100) for s,e in zip(np.flatnonzero(changes==1),np.flatnonzero(changes==-1)) if e-s>=7]
 boundaries=[0.];reviews=[]
 for prev,nxt in zip(cues,cues[1:]):
  left=max(prev['chunk_ids']);right=min(nxt['chunk_ids']);method='long_pause_chunk_boundary'
  if left<right:
   target=(chunks[left]['end']+chunks[right]['start'])/2
  elif prev['key']=='10_02_intro' and nxt['key']=='10_02_result':
   target=1039.05;method='reviewed_native_segment_acoustic_pause'
  elif prev['key']=='11_01_result' and nxt['key']=='11_02_intro':
   target=1139.71;method='reviewed_shared_segment_acoustic_pause'
  else:
   target=(prev['estimated_end']+nxt['estimated_start'])/2;method='native_segment_boundary_refined_to_pause'
  candidates=[(s,e) for s,e in pauses if (s<=target<=e or abs((s+e)/2-target)<=1.0) and (s+e)/2>boundaries[-1]+.25]
  if not candidates:raise ValueError(f'No safe pause around {prev["key"]} → {nxt["key"]}, {target}')
  # Keep full-chunk cuts if already inside a pause; they retain all unrecognized tails.
  containing=[(s,e) for s,e in candidates if s<=target<=e]
  if containing:s,e=max(containing,key=lambda p:p[1]-p[0])
  else:s,e=min(candidates,key=lambda p:abs((p[0]+p[1])/2-target)-.12*min(p[1]-p[0],1))
  cut=(s+e)/2
  assert cut>boundaries[-1]
  boundaries.append(cut)
  reviews.append({'before':prev['key'],'after':nxt['key'],'time':round(cut,4),'pause':[s,e],
                  'pause_duration':round(e-s,4),'target':round(target,4),'adjustment':round(cut-target,4),
                  'method':method,'needs_review':abs(cut-target)>.65 or e-s<.12})
 boundaries.append(len(a)/16000)
 out=[]
 for i,c in enumerate(cues):
  out.append({'key':c['key'],'source_start':round(boundaries[i],4),'source_end':round(boundaries[i+1],4),
              'expected_text':c['expected_text'],'recognized_text':c['source_text'],
              'review':'Preserve full chunk tails; trim end pauses with handles. No time stretching or TTS.'})
 (ROOT/'cuts.json').write_text(json.dumps({'source':'provided recording','cues':out},ensure_ascii=False,indent=2)+'\n')
 (ROOT/'output/boundary_review.json').write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n')
 print('Prepared',len(out),'cues;',len(reviews),'acoustic boundaries')
 for r in reviews:
  if r['needs_review'] or r['method']!='long_pause_chunk_boundary':print(r)
if __name__=='__main__':main()
