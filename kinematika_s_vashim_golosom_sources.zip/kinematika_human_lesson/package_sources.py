"""Publish reviewed montage artifacts; never bundle the private source recording."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parent
PREFIX='kinematika_s_vashim_golosom'

def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 qpath=ROOT/'output/quality_validation.json';q=json.loads(qpath.read_text())
 movie=ROOT/'output'/f'{PREFIX}_1080p60.mp4'
 assert q['full_decode_passed'] and not q['synthetic_speech_used']
 assert q['narration_parts']==120 and q['chapters']==12
 assert digest(movie)==q['sha256'] and movie.stat().st_size<100*1024**2
 for name,sha in q['input_hashes'].items():assert digest(ROOT/name)==sha,name
 assert digest(ROOT/'output/audio/narration.wav')==q['master_audio']['sha256']
 files=set()
 for pattern in ('*.py','*.json','*.md','*.txt','*.srt'):
  files.update(ROOT.glob(pattern))
 for name in ('edit_decisions.json','boundary_review.json','transcription.json','asr_chunks_plan.json',
              'alignment_proposals.json','alignment_review.md','semantic_rechecks.json',
              'recording_review.json','recording_review.md','source_hold_audit.json','quality_validation.json'):
  p=ROOT/'output'/name;assert p.is_file(),p;files.add(p)
 reports=list((ROOT/'output/retime_reports').glob('*.json'));assert len(reports)==12;files.update(reports)
 for name in ('setup_env.sh','install.sh','requirements.lock','AGENTS.md'):
  p=ROOT.parent/name;assert p.is_file();files.add(p)
 for p in files:
  assert p.is_file() and p.suffix.lower() not in ('.mp3','.wav','.mp4','.onnx','.png','.jpg','.pyc'),p
  assert 'materials' not in p.parts and 'retime_cache' not in p.parts,p
 assert qpath.stat().st_mtime>=max((ROOT/n).stat().st_mtime for n in ('plan.json','frame_map.json','narration.json','retime_video.py','verify_delivery.py'))
 shutil.copyfile(movie,ROOT.parent/movie.name)
 for source,suffix in [('tekst_ozvuchki.txt','tekst.txt'),('proverit_ozvuchku.txt','proverit.txt')]:
  text=(ROOT/source).read_text(encoding='utf-8-sig').rstrip()+'\n'
  (ROOT.parent/f'{PREFIX}_{suffix}').write_text(text,encoding='utf-8-sig',newline='\n')
 archive=ROOT.parent/f'{PREFIX}_sources.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(files):z.write(p,p.relative_to(ROOT.parent))
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 print(f'PACKAGED {movie.name}, timed text, listening notes, {len(files)} source/report files',flush=True)
if __name__=='__main__':main()
