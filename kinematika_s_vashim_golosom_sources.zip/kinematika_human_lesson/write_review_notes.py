"""Publish careful listening notes with final-film cue times."""
from pathlib import Path
import json
from prepare_human import stamp
ROOT=Path(__file__).resolve().parent

def main():
 review=json.loads((ROOT/'output/recording_review.json').read_text())
 n=json.loads((ROOT/'narration.json').read_text());cues={c['key']:c for ch in n['chapters'] for c in ch['cues']}
 lines=['МЕСТА ДЛЯ ПРОСЛУШИВАНИЯ В ЗАПИСИ','',
        'Это замечания автоматического распознавания, а не подтверждённые ошибки вашей речи.',
        'Все 120 реплик присутствуют. Запись смонтирована без замены слов и без синтетического голоса.',
        'Ниже указаны времена целых реплик в новом фильме и исходной записи.','']
 for i,item in enumerate(review['items'],1):
  c=cues[item['key']];item['film_cue_start']=c['global_at'];item['film_cue_end']=c['global_until']
  lines += [f"{i}. Фильм {stamp(c['global_at'])}–{stamp(c['global_until'])}",
            f"   Исходная запись {stamp(item['source_start'])}–{stamp(item['source_end'])}",
            item['concern'],'Правильная формулировка: '+item['intended_text'],'']
 (ROOT/'output/recording_review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'proverit_ozvuchku.txt').write_text('\n'.join(lines).rstrip()+'\n',encoding='utf-8-sig')
 print('Listening notes:',len(review['items']))
if __name__=='__main__':main()
