"""Split the previously published kinematics video at its chapter IDR frames."""
from pathlib import Path
import argparse,json,subprocess
from retime_video import probe
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--movie',type=Path,default=ROOT.parent/'kinematika_s_ozvuchkoy_1080p60.mp4');p.add_argument('--output',type=Path,default=ROOT.parent/'kinematika_voice_lesson/output/chapters');args=p.parse_args()
 plan=json.loads((ROOT/'source_plan.json').read_text());args.output.mkdir(parents=True,exist_ok=True)
 for c in plan['chapters']:
  path=args.output/f"{c['id']:02d}_{c['class']}.mp4"
  if path.exists():
   r=probe(path)
   if r['frames']==c['duration']*60 and not r['audio_streams']:continue
  tmp=path.with_name(path.stem+'.tmp.mp4')
  subprocess.run(['ffmpeg','-v','error','-y','-ss',str(c['start']),'-i',str(args.movie),'-t',str(c['duration']),'-map','0:v:0','-an','-c:v','copy','-map_metadata','-1','-map_chapters','-1',str(tmp)],check=True)
  r=probe(tmp)
  assert r['frames']==c['duration']*60 and not r['audio_streams'],(c['id'],r)
  tmp.replace(path);print(path,flush=True)
if __name__=='__main__':main()
