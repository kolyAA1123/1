"""Cut supplied recording and derive exact voice/video frame maps; no TTS."""
from pathlib import Path
import argparse,copy,hashlib,json,math,wave
import numpy as np
ROOT=Path(__file__).resolve().parent
RATE=48000;FPS=60

def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read_wav(p):
 with wave.open(str(p),'rb') as w:
  assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,RATE)
  return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy()
def save_wav(p,a):
 p.parent.mkdir(parents=True,exist_ok=True)
 with wave.open(str(p),'wb') as w:
  w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE);w.writeframes(np.asarray(a,dtype='<i2').tobytes())
def nframes(t):return math.ceil(t*FPS-1e-9)
def stamp(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
 return f'{h:02d}:{m:02d}:{s:02d}.{ms:03d}'
def trim_handles(a,guide):
 # Trim only low-energy end pauses; keep soft syllables and breath handles.
 hop=160;n=len(guide)//hop
 rms=np.sqrt(np.mean(guide[:n*hop].astype(float).reshape(n,hop)**2,axis=1))
 active=np.flatnonzero(rms>32768*10**(-45/20))
 if not len(active):raise ValueError('No audible speech in selected range')
 left=max(0,round((int(active[0])*.01-.14)*RATE));right=min(len(a),round(((int(active[-1])+1)*.01+.20)*RATE))
 out=a[left:right].copy();ramp=min(240,len(out)//2)
 out[:ramp]=(out[:ramp]*np.linspace(0,1,ramp)).astype('<i2')
 out[-ramp:]=(out[-ramp:]*np.linspace(1,0,ramp)).astype('<i2')
 return out,left/RATE,right/RATE

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--cuts',type=Path,default=ROOT/'cuts.json');parser.add_argument('--recording',type=Path,default=ROOT/'materials/recording_processed.wav');args=parser.parse_args()
 original=json.loads((ROOT/'source_plan.json').read_text())
 cuts=json.loads(args.cuts.read_text());cuts=cuts['cues'] if isinstance(cuts,dict) else cuts
 keyed={c['key']:c for c in cuts};assert len(keyed)==len(cuts)==120
 audio=read_wav(args.recording)
 with wave.open(str(ROOT/'materials/recording_16k.wav'),'rb') as w:
  assert w.getframerate()==16000 and w.getnchannels()==1
  guide=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy()
 parts={};editlog=[]
 for ch in original['chapters']:
  for b in ch['beats']:
   for part in ('intro','result'):
    key=f"{ch['id']:02d}_{b['index']+1:02d}_{part}";cut=keyed[key]
    ranges=cut.get('ranges') or [[cut['source_start'],cut['source_end']]]
    assert all(0<=s<e<=len(audio)/RATE for s,e in ranges),(key,ranges)
    joined=np.concatenate([audio[round(s*RATE):round(e*RATE)] for s,e in ranges])
    guide_joined=np.concatenate([guide[round(s*16000):round(e*16000)] for s,e in ranges])
    pcm,left,right=trim_handles(joined,guide_joined)
    path=ROOT/'output/audio/parts'/f'{key}.wav';save_wav(path,pcm)
    parts[key]={'file':str(path.relative_to(ROOT)),'duration':len(pcm)/RATE,'samples':len(pcm),'sha256':digest(path),'pcm':pcm}
    editlog.append({'key':key,'source_ranges':ranges,'trimmed_leading_seconds':left,'trimmed_joined_end':right,
                    'duration':len(pcm)/RATE,'samples':len(pcm),'sha256':digest(path),'review':cut.get('review','')})
 plan={'title':'Кинематика с предоставленной озвучкой','duration':0,'fps':FPS,
       'voice':{'type':'provided_recording','synthetic_speech_used':False,'sample_rate':RATE,
                'processing':'mono; highpass 65Hz; loudnorm -19 LUFS / -1.5 dBTP; end-pause trims with handles; 5ms edge fades',
                'processed_recording_sha256':digest(args.recording)},'chapters':[]}
 narrative={'title':plan['title'],'chapters':[]};mapping={'fps':FPS,'chapters':[]};master=[];timeline=[];offset=0
 text=['КИНЕМАТИКА — ВЕРСИЯ С ПРЕДОСТАВЛЕННОЙ ОЗВУЧКОЙ',
       'Сценарий и точные времена реплик. В записи сохранены авторские переформулировки.',
       'Синтетический голос не используется.','']
 for old in original['chapters']:
  ch=copy.deepcopy(old);ch['start']=offset;ch['audio_file']=f"output/audio/chapters/{ch['id']:02d}.wav"
  replacements=[];delta=0;cues=[]
  def shift(t):
   point=round(t*FPS);d=0
   for r in replacements:
    if point>=r['old_end_frame']:d+=r['new_frame_count']-(r['old_end_frame']-r['old_start_frame'])
    elif point>r['old_start_frame']:
     raise ValueError(f'Cannot map a point inside a replaced hold: {t}')
   return (point+d)/FPS
  for b,ob in zip(ch['beats'],old['beats']):
   for part in ('intro','result'):
    key=f"{ch['id']:02d}_{b['index']+1:02d}_{part}";p=parts[key]
    a=round(ob[f'{part}_at']*FPS);old_len=nframes(ob[f'{part}_duration']);new_len=nframes(p['duration'])
    r={'old_start_frame':a,'old_end_frame':a+old_len,'new_frame_count':new_len,
       'new_start_frame':a+delta,'label':key}
    replacements.append(r);delta+=new_len-old_len
    b[f'{part}_at']=r['new_start_frame']/FPS;b[f'{part}_duration']=p['duration'];b[f'{part}_file']=p['file']
    cue={'key':key,'chapter':ch['id'],'beat':b['index']+1,'part':part,
         'at':b[f'{part}_at'],'global_at':offset+b[f'{part}_at'],
         'speech_duration':p['duration'],'global_until':offset+b[f'{part}_at']+p['duration'],
         'file':p['file'],'sha256':p['sha256'],'text':ob[part]}
    cues.append(cue);timeline.append(cue)
   # All these phase markers lie outside speech holds and follow cumulative shifts.
   for field in ('start','action_at','result_at','end'):
    b[field]=shift(ob[field])
  raw_total=old['duration']*FPS+delta;pad=(-raw_total)%FPS
  if pad:
   last=old['duration']*FPS-1
   replacements.append({'old_start_frame':last,'old_end_frame':last+1,'new_frame_count':pad+1,
                        'new_start_frame':last+delta,'label':'tail_padding'})
  frames=raw_total+pad;ch['duration']=frames//FPS
  track=np.zeros(ch['duration']*RATE,dtype='<i2')
  for cue in cues:
   pcm=parts[cue['key']]['pcm'];at=round(cue['at']*RATE)
   assert at+len(pcm)<=len(track)
   track[at:at+len(pcm)]=pcm
  save_wav(ROOT/ch['audio_file'],track);master.append(track)
  plan['chapters'].append(ch);mapping['chapters'].append({'id':ch['id'],'class':ch['class'],'expected_frames':frames,'replacements':replacements})
  narrative['chapters'].append({'id':ch['id'],'title':ch['title'],'start':offset,'duration':ch['duration'],'cues':cues})
  text.extend([f"{ch['id']:02d}. {ch['title']} — {stamp(offset)}",''])
  for cue in cues:text.extend([f"[{stamp(cue['global_at'])}–{stamp(cue['global_until'])}] {cue['text']}",''])
  offset+=ch['duration']
 plan['duration']=offset;narrative['total_duration']=offset
 for name,data in [('plan.json',plan),('narration.json',narrative),('frame_map.json',mapping),('output/edit_decisions.json',editlog)]:
  (ROOT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'tekst_ozvuchki.txt').write_text('\n'.join(text).rstrip()+'\n',encoding='utf-8-sig')
 srt=[]
 for i,c in enumerate(timeline,1):srt.append(f"{i}\n{stamp(c['global_at']).replace('.',',')} --> {stamp(c['global_until']).replace('.',',')}\n{c['text']}\n")
 (ROOT/'subtitles.srt').write_text('\n'.join(srt),encoding='utf-8-sig')
 save_wav(ROOT/'output/audio/narration.wav',np.concatenate(master))
 print(f"Prepared 120 recorded parts; {offset}s / {offset//60}:{offset%60:02d}; {offset*FPS} frames.",flush=True)
if __name__=='__main__':main()
