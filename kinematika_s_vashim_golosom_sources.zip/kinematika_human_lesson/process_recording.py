"""Prepare ASR guide and a levelled recording while preserving timing/pitch."""
from pathlib import Path
import argparse,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('recording',type=Path);args=p.parse_args()
 with args.recording.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 material=ROOT/'materials';material.mkdir(exist_ok=True);(ROOT/'output').mkdir(exist_ok=True)
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(args.recording),'-ac','1','-ar','16000','-c:a','pcm_s16le',str(material/'recording_16k.wav')],check=True)
 with (ROOT/'output/audio_processing.log').open('w') as log:
  subprocess.run(['ffmpeg','-hide_banner','-nostats','-y','-i',str(args.recording),'-af','aformat=channel_layouts=mono,highpass=f=65,loudnorm=I=-19:TP=-1.5:LRA=11:print_format=json','-ar','48000','-ac','1','-c:a','pcm_s16le',str(material/'recording_processed.wav')],check=True,stdout=log,stderr=log)
 (ROOT/'recording_manifest.json').write_text(json.dumps({'sha256':sha,'original_bytes':args.recording.stat().st_size,'original_not_bundled':True,'processing':'mono; highpass65Hz; loudnormI=-19:TP=-1.5:LRA=11; 48kPCM16; no speed or pitch changes'},indent=2)+'\n')
if __name__=='__main__':main()
