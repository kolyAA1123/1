# Independent alignment review

All120 expected cues are represented in the recording in the correct order. No entire missing cue or repeated complete take was found in145 chunks. This is an ASR/text review, not verified subjective listening. Low scores mainly reflect homophones, merged words, grammatical endings and math-symbol normalization.

## Same-chunk boundaries

All five have suitable acoustic pauses, measured on16kHz mono PCM with5ms RMS windows at−45dBFS. These are pause ranges, not invented word timestamps.

| Chunk | Transition | Native ASR edge(s) | Quiet range(s) | Midpoint(s) |
|---|---|---:|---|---:|
|0|01_01_intro →01_01_result|8.000|8.080–8.460|8.270|
|50|05_01_intro →05_01_result|440.235|440.075–440.515|440.295|
|116|10_02_intro →10_02_result|1038.650|1038.805–1039.290|1039.0475|
|124|11_01_result →11_02_intro|shared1137.455–1140.575|1139.425–1139.975|1139.700|
|131|11_04_result →11_05_intro|1210.200|1209.890–1210.380|1210.135|

For116 the shorter1038.485–1038.600 pause is internal to speech. For124 split before «положительная ось направлена вверх»; proposal1137.455 duplicates part of the preceding question.

## Extraneous material and tail safeguards

Chunks7,18,43,77,88,144 contain only noise labels, isolated «спасибо»/«тьфу», or a truncated bracket. They are outside the aligned theory spans. No complete duplicate theoretical take was identified. Benign additions «как раз таки» in01_01_intro and «это» in01_03_intro should not be treated as retakes.

Preserve active audio to full chunk edges when native ASR drops final words. The conspicuous cases are04_02_result («производная…по времени», chunk41 ends366.065, proposal364.790) and12_01_intro («способ измерения времени», chunk133 ends1244.240, proposal1242.810).

## Semantic rechecks

Focused second-pass local ASR is complete:14 windows across floating-point and int8 models. Results: semantic_rechecks.json. Actionable review:recording_review.json/md.04_02_result final «по времени» and09_02_result multiplication by frequency are recovered with context. Four substantive possible read slips plus one ambiguous negation remain marked needs_listening; no phoneme or wording changes were made. ASR negations are not proven speaker errors.

## Per-cue review

| Key | Chunks | ASR range(s; approximate) | Finding |
|---|---|---|---|
|01_01_intro|0|0.000–8.000|Benign reordered wording + «как раз таки».|
|01_01_result|0|8.000–17.000|Present in order; text matches well.|
|01_02_intro|1|17.990–25.510|Present in order; only ordinary ASR wording/ending differences.|
|01_02_result|2|26.480–34.740|Present in order; text matches well.|
|01_03_intro|3,4|35.750–44.695|Preserve3+4: «Материальная точка» + definition.|
|01_03_result|5|45.665–54.105|Present in order; text matches well.|
|01_04_intro|6|55.745–66.825|Present in order; only ordinary ASR wording/ending differences.|
|01_04_result|8|70.245–79.245|Present in order; text matches well.|
|01_05_intro|9|80.095–87.455|Present in order; only ordinary ASR wording/ending differences.|
|01_05_result|10|88.825–98.265|Present in order; only ordinary ASR wording/ending differences.|
|02_01_intro|11,12|100.375–110.975|Present in order; only ordinary ASR wording/ending differences.|
|02_01_result|13|112.255–122.375|ASR corrupts «при криволинейном — искривлённая».|
|02_02_intro|14|124.100–133.820|Present in order; only ordinary ASR wording/ending differences.|
|02_02_result|15|135.580–144.980|Present in order; only ordinary ASR wording/ending differences.|
|02_03_intro|16|146.780–155.780|Present in order; only ordinary ASR wording/ending differences.|
|02_03_result|17|157.620–168.340|Present in order; text matches well.|
|02_04_intro|19|172.465–180.465|Present in order; only ordinary ASR wording/ending differences.|
|02_04_result|20|181.715–191.115|Present in order; only ordinary ASR wording/ending differences.|
|02_05_intro|21|192.175–200.175|ASR merges при движении по окружности, renders эр as R.|
|02_05_result|22|200.925–209.605|ASR normalizes нулю/двум пи to0/2π.|
|03_01_intro|23|210.680–218.680|Present in order; text matches well.|
|03_01_result|24|219.485–229.165|Present in order; only ordinary ASR wording/ending differences.|
|03_02_intro|25|230.235–238.115|Present in order; only ordinary ASR wording/ending differences.|
|03_02_result|26,27,28,29|239.965–255.125|Preserve26–29; four parts are one conclusion.|
|03_03_intro|30|256.965–266.885|ASR merges прямолинейное/вектора скорости.|
|03_03_result|31|267.935–279.715|Present in order; text matches well.|
|03_04_intro|32|281.305–290.305|Present in order; text matches well.|
|03_04_result|33|291.285–300.285|Present in order; text matches well.|
|03_05_intro|34|300.835–308.635|Present in order; text matches well.|
|03_05_result|35,36|308.990–320.600|Present in order; only ordinary ASR wording/ending differences.|
|04_01_intro|37|322.790–331.490|Present in order; text matches well.|
|04_01_result|38,39|331.945–344.335|Preserve38+39; division-order semantic recheck pending.|
|04_02_intro|40|346.010–353.810|Present in order; text matches well.|
|04_02_result|41|354.790–364.790|ASR omits final времени; retain active tail toward366.065.|
|04_03_intro|42|366.065–376.065|ASR splits сонаправленные to с направленной.|
|04_03_result|44|379.550–387.630|Present in order; text matches well.|
|04_04_intro|45|388.310–396.390|Present in order; only ordinary ASR wording/ending differences.|
|04_04_result|46|396.525–407.525|Present in order; text matches well.|
|04_05_intro|47|407.910–415.910|Present in order; text matches well.|
|04_05_result|48,49|418.680–432.260|Preserve48+49; bizarre ASR48 is first sentence, not a retake.|
|05_01_intro|50|432.875–440.235|Present in order; text matches well.|
|05_01_result|50|440.235–451.435|Present in order; text matches well.|
|05_02_intro|51|452.955–460.955|Present in order; text matches well.|
|05_02_result|52|462.850–475.450|Present in order; text matches well.|
|05_03_intro|53|476.275–484.815|Present in order; only ordinary ASR wording/ending differences.|
|05_03_result|54|486.080–497.640|Present in order; text matches well.|
|05_04_intro|55|498.660–506.660|Present in order; only ordinary ASR wording/ending differences.|
|05_04_result|56,57|507.490–519.985|Present in order; text matches well.|
|05_05_intro|58|521.260–530.460|Present in order; text matches well.|
|05_05_result|59|531.350–542.350|Present in order; text matches well.|
|06_01_intro|60|544.070–552.550|Present in order; only ordinary ASR wording/ending differences.|
|06_01_result|61|553.755–565.315|Recheck ненулевое vs нулевое acceleration.|
|06_02_intro|62,63|566.370–577.635|Present in order; only ordinary ASR wording/ending differences.|
|06_02_result|64,65|579.775–592.190|Preserve64+65; complete linear-change explanation.|
|06_03_intro|66|593.575–601.535|Present in order; only ordinary ASR wording/ending differences.|
|06_03_result|67,68|602.305–614.035|Preserve67+68; half-acceleration term spans pause.|
|06_04_intro|69|614.775–621.775|Present in order; text matches well.|
|06_04_result|70|623.120–633.120|Present in order; text matches well.|
|06_05_intro|71|634.355–643.355|Present in order; text matches well.|
|06_05_result|72|644.470–657.030|Present in order; text matches well.|
|07_01_intro|73|658.035–666.195|Present in order; only ordinary ASR wording/ending differences.|
|07_01_result|74,75|666.195–676.785|Present in order; text matches well.|
|07_02_intro|76|677.990–685.830|Recheck ASR extra НЕ before нулевая.|
|07_02_result|78|688.815–700.815|Present in order; only ordinary ASR wording/ending differences.|
|07_03_intro|79|703.570–713.410|Present in order; only ordinary ASR wording/ending differences.|
|07_03_result|80|715.280–724.880|Present in order; text matches well.|
|07_04_intro|81|726.555–735.155|Present in order; only ordinary ASR wording/ending differences.|
|07_04_result|82|736.680–748.120|Present in order; only ordinary ASR wording/ending differences.|
|07_05_intro|83|749.475–757.475|Present in order; text matches well.|
|07_05_result|84,85|758.830–770.830|Present in order; text matches well.|
|08_01_intro|86,87|772.355–785.745|Preserve86+87 including происходящие одновременно.|
|08_01_result|89|789.045–800.800|Recheck ASR extra НЕ before нулевое horizontal acceleration.|
|08_02_intro|90|800.800–809.800|Present in order; only ordinary ASR wording/ending differences.|
|08_02_result|91|809.920–818.920|Present in order; only ordinary ASR wording/ending differences.|
|08_03_intro|92|820.970–834.010|Present in order; text matches well.|
|08_03_result|93|835.485–846.885|Present in order; only ordinary ASR wording/ending differences.|
|08_04_intro|94,95|848.100–857.465|Present in order; only ordinary ASR wording/ending differences.|
|08_04_result|96,97|858.125–871.340|Preserve96+97 including45° condition.|
|08_05_intro|98,99|871.340–881.405|Preserve98+99; zero vertical speed spans pause.|
|08_05_result|100,101|881.405–897.040|Preserve100+101 through landing condition.|
|09_01_intro|102|899.430–907.230|Present in order; only ordinary ASR wording/ending differences.|
|09_01_result|103|907.570–916.570|Present in order; text matches well.|
|09_02_intro|104,105|917.550–926.535|Present in order; text matches well.|
|09_02_result|106|927.710–936.470|Recheck2π/T and2πν; ASR emits slash for both.|
|09_03_intro|107|937.625–945.905|Present in order; only ordinary ASR wording/ending differences.|
|09_03_result|108|947.780–958.900|Present in order; text matches well.|
|09_04_intro|109|960.190–968.470|Present in order; only ordinary ASR wording/ending differences.|
|09_04_result|110|970.140–981.220|Present in order; text matches well.|
|09_05_intro|111|982.685–991.605|Present in order; text matches well.|
|09_05_result|112|993.780–1005.700|Present in order; only ordinary ASR wording/ending differences.|
|10_01_intro|113|1007.105–1016.505|Present in order; text matches well.|
|10_01_result|114,115|1017.765–1030.285|Present in order; text matches well.|
|10_02_intro|116|1031.650–1038.650|Same116 as result; safe quiet1038.805–1039.290.|
|10_02_result|116|1038.650–1048.650|Present in order; text matches well.|
|10_03_intro|117|1050.045–1058.045|Present in order; only ordinary ASR wording/ending differences.|
|10_03_result|118|1058.805–1070.805|Present in order; only ordinary ASR wording/ending differences.|
|10_04_intro|119|1071.580–1079.580|Present in order; text matches well.|
|10_04_result|120|1082.460–1096.540|Present in order; text matches well.|
|10_05_intro|121|1097.590–1105.230|Present in order; only ordinary ASR wording/ending differences.|
|10_05_result|122|1106.425–1118.025|Present in order; only ordinary ASR wording/ending differences.|
|11_01_intro|123|1120.135–1129.495|Present in order; text matches well.|
|11_01_result|124|1130.835–1140.575|Shared124:1; finish before положительная at1139.71.|
|11_02_intro|124,125|1137.455–1150.170|Start inside124 at положительная ось; include125.|
|11_02_result|126|1150.870–1162.190|Present in order; only ordinary ASR wording/ending differences.|
|11_03_intro|127|1163.010–1172.010|Present in order; text matches well.|
|11_03_result|128|1172.235–1183.235|Present in order; only ordinary ASR wording/ending differences.|
|11_04_intro|129|1185.850–1195.370|Present in order; only ordinary ASR wording/ending differences.|
|11_04_result|130,131|1195.800–1210.200|Include130 plus first sentence131 (20m).|
|11_05_intro|131|1210.200–1218.200|Remainder131 after quiet1209.890–1210.380.|
|11_05_result|132|1220.755–1232.155|Present in order; only ordinary ASR wording/ending differences.|
|12_01_intro|133|1233.990–1242.810|ASR stops at и способ; retain active tail toward1244.240.|
|12_01_result|134|1244.240–1254.240|Present in order; text matches well.|
|12_02_intro|135|1254.790–1263.690|Present in order; only ordinary ASR wording/ending differences.|
|12_02_result|136|1264.430–1276.430|Present in order; text matches well.|
|12_03_intro|137|1276.850–1284.850|Present in order; text matches well.|
|12_03_result|138|1285.630–1297.630|Present in order; only ordinary ASR wording/ending differences.|
|12_04_intro|139|1298.210–1307.210|Present in order; text matches well.|
|12_04_result|140|1308.050–1319.810|Present in order; only ordinary ASR wording/ending differences.|
|12_05_intro|141|1320.550–1329.550|Present in order; only ordinary ASR wording/ending differences.|
|12_05_result|142,143|1329.795–1342.045|Preserve142+143, including final answer check.|
