"""Verify the recorded-voice film against exact audio slots and frame partitions.

Run only after retiming and final MP4 assembly. No speech synthesis or edits are
performed. The only output is the verification report and a decoder error log.
"""
from __future__ import annotations

from dataclasses import asdict
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import subprocess
import wave

import numpy as np

from retime_video import build_segments, speech_frames

ROOT = Path(__file__).resolve().parent
PREFIX = "kinematika_s_vashim_golosom"
FPS = 60
RATE = 48000
SAMPLE_TOLERANCE = 1 / RATE + 1e-8


def digest(path: Path) -> str:
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def probe(path: Path):
    return json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_streams", "-show_format",
        "-show_chapters", "-of", "json", str(path),
    ]))


def check_video(path: Path, expected_frames: int, *, with_audio: bool):
    report = probe(path)
    videos = [s for s in report["streams"] if s["codec_type"] == "video"]
    audios = [s for s in report["streams"] if s["codec_type"] == "audio"]
    assert len(videos) == 1 and len(audios) == int(with_audio), path
    video = videos[0]
    assert (video["width"], video["height"]) == (1920, 1080), path
    assert Fraction(video["avg_frame_rate"]) == FPS, path
    assert int(video["nb_frames"]) == expected_frames, (path, video["nb_frames"], expected_frames)
    assert abs(float(report["format"]["duration"]) - expected_frames / FPS) <= .06, path
    if with_audio:
        audio = audios[0]
        assert (audio["codec_name"], int(audio["sample_rate"]), audio["channels"]) == ("aac", RATE, 1)
        assert abs(float(audio["duration"]) - expected_frames / FPS) <= .06, path
    return report


def wav_info(path: Path):
    with wave.open(str(path), "rb") as stream:
        assert stream.getcomptype() == "NONE", path
        assert (stream.getnchannels(), stream.getsampwidth(), stream.getframerate()) == (1, 2, RATE), path
        return {"channels": 1, "sample_width": 2, "sample_rate": RATE,
                "frames": stream.getnframes(), "duration": stream.getnframes() / RATE}


def raw_frames(path: Path, start: float, duration: float, filters: str):
    return subprocess.check_output([
        "ffmpeg", "-v", "error", "-threads", "2", "-ss", str(start),
        "-t", str(duration), "-i", str(path), "-map", "0:v:0", "-an",
        "-vf", filters, "-f", "rawvideo", "pipe:1",
    ])


def mapped_frame(point: int, replacements: list[dict]) -> int:
    delta = 0
    for item in replacements:
        a, b = item["old_start_frame"], item["old_end_frame"]
        if point >= b:
            delta += item["new_frame_count"] - (b - a)
        elif point > a:
            raise AssertionError((point, "Phase marker inside replaced speech interval", item))
    return point + delta


def verify_chapter_map(chapter: dict, old: dict, mapping: dict, cues: list[dict]):
    number = chapter["id"]
    assert (mapping["id"], mapping["class"]) == (number, chapter["class"])
    expected_frames = chapter["duration"] * FPS
    source_frames = old["duration"] * FPS
    assert mapping["expected_frames"] == expected_frames
    segments = build_segments(source_frames, mapping["replacements"], expected_frames)
    report_path = ROOT / "output/retime_reports" / f"{number:02d}.json"
    report = read_json(report_path)
    assert report["chapter"] == number
    assert (report["source_frames"], report["frames"], report["fps"]) == (source_frames, expected_frames, FPS)
    assert (report["width"], report["height"], report["audio_streams"]) == (1920, 1080, 0)
    assert report["non_hold_frames_preserved_in_order"] is True
    assert report["motion_speed_changed"] is False
    assert abs(report["duration_seconds"] - expected_frames / FPS) < 1e-9
    assert len(report["segments"]) == len(segments)
    for actual, expected in zip(report["segments"], segments):
        for key, value in asdict(expected).items():
            assert actual[key] == value, (number, key, actual, expected)
        assert actual["frames"] == expected.frames
        assert actual["source_frames_per_output_frame"] == (1 if expected.kind == "keep" else 0)
    kept = sum(s.frames for s in segments if s.kind == "keep")
    replaced = sum(s.old_end_frame - s.old_start_frame for s in segments if s.kind == "freeze")
    frozen = sum(s.frames for s in segments if s.kind == "freeze")
    assert kept + replaced == source_frames and kept + frozen == expected_frames
    assert (report["kept_source_frames"], report["replaced_source_frames"], report["new_freeze_frames"]) == (kept, replaced, frozen)
    source = Path(report["source"])
    assert source.is_file() and digest(source) == report["source_sha256"], source
    source_report = check_video(source, source_frames, with_audio=False)
    clip = ROOT / "output/chapters" / f"{number:02d}_{chapter['class']}.mp4"
    check_video(clip, expected_frames, with_audio=False)
    assert digest(clip) == report["sha256"] and clip.stat().st_size == report["bytes"], clip
    assert Path(report["output"]).resolve() == clip.resolve()
    freshness = max((ROOT / name).stat().st_mtime for name in ("frame_map.json", "plan.json", "retime_video.py"))
    assert report_path.stat().st_mtime >= freshness and clip.stat().st_mtime >= freshness, number
    freezes = {s.label: s for s in segments if s.kind == "freeze"}
    assert len(freezes) == len([s for s in segments if s.kind == "freeze"]), number
    assert set(freezes) - {c["key"] for c in cues} <= {"tail_padding"}, number
    assert len([key for key in freezes if key != "tail_padding"]) == 10
    by_key = {c["key"]: c for c in cues}
    previous_end = 0
    for beat, old_beat in zip(chapter["beats"], old["beats"]):
        assert beat["index"] == old_beat["index"]
        assert beat["start"] >= previous_end - 1 / FPS
        assert beat["start"] <= beat["intro_at"]
        assert beat["intro_at"] + beat["intro_duration"] <= beat["action_at"] + SAMPLE_TOLERANCE
        assert abs(beat["action_seconds"] - old_beat["action_seconds"]) < 1e-9
        assert beat["action_at"] + beat["action_seconds"] <= beat["result_at"] + SAMPLE_TOLERANCE
        assert beat["result_at"] + beat["result_duration"] <= beat["end"] + SAMPLE_TOLERANCE
        for field in ("start", "action_at", "result_at", "end"):
            expected = mapped_frame(round(old_beat[field] * FPS), mapping["replacements"])
            assert abs(beat[field] * FPS - expected) < 1e-6, (number, beat["index"], field)
        for kind in ("intro", "result"):
            key = f"{number:02d}_{beat['index'] + 1:02d}_{kind}"
            cue, freeze = by_key[key], freezes[key]
            assert freeze.old_start_frame == round(old_beat[f"{kind}_at"] * FPS)
            assert freeze.old_end_frame - freeze.old_start_frame == speech_frames(old_beat[f"{kind}_duration"])
            assert abs(cue["at"] * FPS - freeze.new_start_frame) < 1e-6
            assert abs(cue["at"] - beat[f"{kind}_at"]) < 1e-9
            assert abs(cue["speech_duration"] - beat[f"{kind}_duration"]) <= SAMPLE_TOLERANCE
            assert cue["file"] == beat[f"{kind}_file"]
            assert freeze.frames == speech_frames(cue["speech_duration"])
            assert cue["at"] + cue["speech_duration"] <= freeze.new_end_frame / FPS + SAMPLE_TOLERANCE
        previous_end = beat["end"]
    return {"chapter": number, "frames": expected_frames, "source_frames": source_frames,
            "kept_source_frames": kept, "replaced_source_frames": replaced, "new_freeze_frames": frozen,
            "non_hold_frames_preserved_in_order": True, "motion_speed_changed": False,
            "sha256": report["sha256"], "source_sha256": report["source_sha256"],
            "retime_report_sha256": digest(report_path)}


def verify_pcm(plan: dict, narrative: dict):
    assert narrative["total_duration"] == plan["duration"]
    assert len(narrative["chapters"]) == 12
    master_path = ROOT / "output/audio/narration.wav"
    master_info = wav_info(master_path)
    assert master_info["frames"] == plan["duration"] * RATE
    slots, chapter_summaries = [], []
    with wave.open(str(master_path), "rb") as master:
        for chapter, spoken in zip(plan["chapters"], narrative["chapters"]):
            number = chapter["id"]
            assert (spoken["id"], spoken["start"], spoken["duration"]) == (number, chapter["start"], chapter["duration"])
            cues = spoken["cues"]
            assert len(cues) == 10 and len({c["key"] for c in cues}) == 10
            chapter_path = ROOT / chapter["audio_file"]
            chapter_info = wav_info(chapter_path)
            assert chapter_info["frames"] == chapter["duration"] * RATE
            with wave.open(str(chapter_path), "rb") as recording:
                pcm = recording.readframes(recording.getnframes())
                master.setpos(round(chapter["start"] * RATE))
                assert master.readframes(chapter_info["frames"]) == pcm, (number, "Master chapter differs")
            expected = np.zeros(chapter_info["frames"], dtype="<i2")
            previous_end = 0
            for cue in cues:
                assert cue["chapter"] == number and cue["part"] in ("intro", "result")
                assert cue["key"] == f"{number:02d}_{cue['beat']:02d}_{cue['part']}"
                assert abs(cue["global_at"] - chapter["start"] - cue["at"]) < 1e-7
                assert abs(cue["global_until"] - cue["global_at"] - cue["speech_duration"]) < 1e-7
                path = ROOT / cue["file"]
                info = wav_info(path)
                assert digest(path) == cue["sha256"], path
                assert abs(info["duration"] - cue["speech_duration"]) <= SAMPLE_TOLERANCE
                start = round(cue["at"] * RATE)
                end = start + info["frames"]
                assert start >= previous_end and end <= chapter_info["frames"], cue
                with wave.open(str(path), "rb") as part:
                    data = part.readframes(part.getnframes())
                samples = np.frombuffer(data, dtype="<i2")
                assert np.any(samples != 0), (cue["key"], "Silent recorded part")
                assert pcm[start * 2:end * 2] == data, (cue["key"], "Recorded speech missing from chapter")
                master.setpos(round(cue["global_at"] * RATE))
                assert master.readframes(info["frames"]) == data, (cue["key"], "Recorded speech missing from master")
                expected[start:end] = samples
                previous_end = end
                slots.append({"key": cue["key"], "start": cue["global_at"], "end": cue["global_until"],
                              "samples": info["frames"], "sha256": cue["sha256"]})
            assert expected.tobytes() == pcm, (number, "Unexpected audio outside declared recorded slots")
            assert cues[-1]["global_until"] <= chapter["start"] + chapter["duration"] - 1.2 + SAMPLE_TOLERANCE
            chapter_summaries.append({"chapter": number, "recorded_parts": 10, "sha256": digest(chapter_path)})
    assert len(slots) == len({s["key"] for s in slots}) == 120
    for left, right in zip(slots, slots[1:]):
        assert left["end"] <= right["start"] + SAMPLE_TOLERANCE, (left, right)
    return {**master_info, "sha256": digest(master_path)}, chapter_summaries, slots


def audio_statistics(movie: Path):
    process = subprocess.Popen([
        "ffmpeg", "-v", "error", "-threads", "2", "-i", str(movie), "-map", "0:a:0", "-vn",
        "-ac", "1", "-ar", str(RATE), "-c:a", "pcm_f32le", "-f", "f32le", "pipe:1",
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    count = clipped = active = blocks = 0
    squares = peak = 0.0
    while True:
        block = process.stdout.read(RATE * 4)
        if not block:
            break
        samples = np.frombuffer(block, dtype="<f4").astype(np.float64)
        assert np.isfinite(samples).all()
        count += len(samples)
        squares += float(np.sum(samples * samples))
        maximum = float(np.abs(samples).max(initial=0))
        peak = max(peak, maximum)
        clipped += int((np.abs(samples) >= .9999).sum())
        active += int(float(np.sqrt(np.mean(samples * samples))) > .003)
        blocks += 1
    errors = process.stderr.read()
    assert process.wait() == 0 and not errors, errors.decode(errors="replace")
    rms = math.sqrt(squares / max(count, 1))
    assert count > 0 and rms > .003, ("Inaudible recording", rms)
    assert peak < 1.15 and clipped / count < .001, ("Substantial clipping", peak, clipped / count)
    assert active / max(blocks, 1) > .1, "Recording absent from most of the film"
    return {"decoded_samples": count, "rms_dbfs": round(20 * math.log10(rms), 3),
            "sample_peak_dbfs": round(20 * math.log10(max(peak, 1e-12)), 3),
            "near_full_scale_fraction": round(clipped / count, 8),
            "active_one_second_blocks_fraction": round(active / blocks, 5)}


def optional_hold_audit():
    # The separate audit may still be generated after this verifier is written.
    candidates = [ROOT / "output/source_hold_audit.json", ROOT / "source_hold_audit.json"]
    path = next((p for p in candidates if p.is_file()), None)
    if path is None:
        return None
    report = read_json(path)
    if isinstance(report, dict):
        for key in ("passed", "all_passed", "all_holds_static"):
            if key in report:
                assert report[key] is True, (path, key)
        for key in ("issues", "failures", "errors"):
            if key in report:
                assert not report[key], (path, key, report[key])
        if "failed" in report:
            assert not report["failed"], path
    return {"path": str(path.relative_to(ROOT)), "sha256": digest(path), "report": report}


def main():
    plan = read_json(ROOT / "plan.json")
    narrative = read_json(ROOT / "narration.json")
    original = read_json(ROOT / "source_plan.json")
    mapping = read_json(ROOT / "frame_map.json")
    assert plan["fps"] == mapping["fps"] == FPS
    assert plan["voice"]["type"] == "provided_recording"
    assert plan["voice"]["synthetic_speech_used"] is False
    assert [c["id"] for c in plan["chapters"]] == list(range(1, 13))
    assert [c["id"] for c in original["chapters"]] == list(range(1, 13))
    assert [c["id"] for c in mapping["chapters"]] == list(range(1, 13))
    elapsed = 0
    for chapter in plan["chapters"]:
        assert chapter["start"] == elapsed and isinstance(chapter["duration"], int) and chapter["duration"] > 0
        assert [b["index"] for b in chapter["beats"]] == list(range(5))
        elapsed += chapter["duration"]
    assert elapsed == plan["duration"]
    movie = ROOT / "output" / f"{PREFIX}_1080p60.mp4"
    report = check_video(movie, elapsed * FPS, with_audio=True)
    assert len(report["chapters"]) == 12
    for actual, expected in zip(report["chapters"], plan["chapters"]):
        assert abs(float(actual["start_time"]) - expected["start"]) <= .001
        assert abs(float(actual["end_time"]) - expected["start"] - expected["duration"]) <= .001
    master, audio_chapters, slots = verify_pcm(plan, narrative)
    chapter_reports, fades = [], []
    for chapter, old, mapped, spoken in zip(plan["chapters"], original["chapters"], mapping["chapters"], narrative["chapters"]):
        number = chapter["id"]
        chapter_reports.append(verify_chapter_map(chapter, old, mapped, spoken["cues"]))
        clip = ROOT / "output/chapters" / f"{number:02d}_{chapter['class']}.mp4"
        data = raw_frames(clip, chapter["duration"] - 1.2, 1.2, "fps=10,scale=160:90,format=rgb24")
        frames = np.frombuffer(data, dtype=np.uint8).reshape(-1, 90, 160, 3)
        assert len(frames) >= 10, number
        energy = frames.mean(axis=(1, 2, 3))
        assert energy[-1] / max(energy[0], .001) < .05, (number, "Incomplete fade", energy)
        assert max(np.diff(energy)) < .05, (number, "Non-monotonic fade", energy)
        corner = raw_frames(movie, chapter["start"] + 3, .05, "crop=16:16:0:0,format=rgb24")
        assert corner and max(corner) == 0, (number, "Non-black corner")
        fades.append({"chapter": number, "end_fade_rgb_mean": [round(float(x), 4) for x in energy], "black_corner": True})
    audit = optional_hold_audit()
    print("Exact recorded PCM slots, frame partitions, chapters and fades passed. Decoding complete MP4...", flush=True)
    log = ROOT / "output/decode_check.log"
    with log.open("w", encoding="utf-8") as errors:
        result = subprocess.run([
            "ffmpeg", "-v", "error", "-threads", "2", "-i", str(movie),
            "-map", "0:v:0", "-map", "0:a:0", "-f", "null", "-",
        ], stderr=errors)
    assert result.returncode == 0 and log.stat().st_size == 0, log
    levels = audio_statistics(movie)
    summary = {"duration_seconds": elapsed, "resolution": [1920, 1080], "fps": FPS,
               "frames": elapsed * FPS, "video_streams": 1, "audio_streams": 1,
               "audio_codec": "aac", "audio_sample_rate": RATE, "audio_channels": 1,
               "chapters": 12, "narration_parts": len(slots), "recorded_parts": len(slots),
               "synthetic_speech_used": False, "bytes": movie.stat().st_size, "sha256": digest(movie),
               "full_decode_passed": True, "master_audio": master, "audio_statistics": levels,
               "recorded_audio_chapters": audio_chapters, "speech_sync_checks": slots,
               "chapter_frame_checks": chapter_reports, "chapter_fades": fades,
               "source_hold_audit": audit, "voice": plan["voice"],
               "input_hashes": {name: digest(ROOT / name) for name in ("plan.json", "narration.json", "frame_map.json", "source_plan.json")}}
    destination = ROOT / "output/quality_validation.json"
    temporary = destination.with_suffix(".tmp.json")
    temporary.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(destination)
    print(f"VERIFIED {movie.name}: {summary['bytes']} bytes, SHA256 {summary['sha256']}", flush=True)


if __name__ == "__main__":
    main()
