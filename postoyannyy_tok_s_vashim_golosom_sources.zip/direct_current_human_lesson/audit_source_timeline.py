"""Recover exact source play/wait intervals from immutable Manim chapter caches.

Instrumentation executes geometry with skipped animations; source partial clips
supply exact60fps frame counts, so quantized waits are not guessed. Existing
source files and rendered clips are never modified. New scratch cache is isolated.
"""
from __future__ import annotations
import argparse, importlib, inspect, json, subprocess, sys, os
os.environ['LESSON_LAYOUT_AUDIT']='0'
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'direct_current_lesson'
FPS=60

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames,width,height,r_frame_rate','-of','json',str(path)]))['streams'][0]

def mp4_frames(path):
    """Count encoded video samples from standard MP4 stsz, avoiding process startup.

    All sourcepartial files are silent one-track Manim clips. Fullchapter plus
    onepartial perchapter is independently checked using ffprobe.
    """
    import struct
    data=Path(path).read_bytes()
    def boxes(start,end):
        at=start
        while at+8<=end:
            size,kind=struct.unpack_from('>I4s',data,at);head=8
            if size==1:size=struct.unpack_from('>Q',data,at+8)[0];head=16
            elif size==0:size=end-at
            if size<head or at+size>end:raise ValueError(f'Invalid MP4box{kind!r} in {path}')
            yield kind,at+head,at+size
            at+=size
    def descendants(start,end,target):
        for kind,a,b in boxes(start,end):
            if kind==target:yield a,b
            if kind in (b'moov',b'trak',b'mdia',b'minf',b'stbl'):
                yield from descendants(a,b,target)
    sizes=list(descendants(0,len(data),b'stsz'))
    handlers=list(descendants(0,len(data),b'hdlr'))
    if len(sizes)!=1 or len(handlers)!=1:raise ValueError(f'Expected onevideo track:{path}')
    if data[handlers[0][0]+8:handlers[0][0]+12]!=b'vide':raise ValueError(f'Not a videot rack:{path}')
    a,b=sizes[0]
    count=struct.unpack_from('>I',data,a+8)[0]
    if count<=0:raise ValueError(f'Empty MP4:{path}')
    return count

def main():
    import hashlib,shutil
    p=argparse.ArgumentParser();p.add_argument('--chapters',type=int,nargs='*');args=p.parse_args()
    (ROOT/'output').mkdir(exist_ok=True)
    scratch=ROOT/'output/timeline_scratch';tex=scratch/'Tex';tex.mkdir(parents=True,exist_ok=True)
    for old in (SOURCE/'output/render_cache/final').glob('*/Tex/*'):
        dest=tex/old.name
        if old.is_file() and not dest.exists():shutil.copy2(old,dest)
    sys.path.insert(0,str(SOURCE));sys.path.insert(0,str(SOURCE/'scenes'))
    from manim import tempconfig,Wait
    import current_style as style
    from current_style import CurrentScene
    plan=json.loads((SOURCE/'plan.json').read_text())
    # PLAN is already loaded from the immutable source. Redirect unconditional
    # CurrentScene sync-report writes and any optional layout paths to NEW ROOT.
    style.ROOT=ROOT
    chapters=[];window_chapters=[]
    for meta in plan['chapters']:
        if args.chapters and meta['id'] not in args.chapters:continue
        ident=meta['id'];clsname=meta['class'];module=meta['module'][:-3]
        clip=SOURCE/'output/chapters'/f'{ident:02d}_{clsname}.mp4';video=probe(clip)
        assert (int(video['width']),int(video['height']),video['r_frame_rate'])==(1920,1080,'60/1')
        partial_list=SOURCE/f'output/render_cache/final/{ident:02d}/videos/{module}/1080p60/partial_movie_files/{clsname}/partial_movie_file_list.txt'
        paths=[Path(s[6:-1].removeprefix('file:')) for s in partial_list.read_text().splitlines() if s.startswith("file '")]
        counts=[mp4_frames(s) for s in paths];prefix=[0]
        for n in counts:prefix.append(prefix[-1]+n)
        assert counts[len(paths)//2]==int(probe(paths[len(paths)//2])['nb_frames'])
        events=[];beats=[];windows=[];actions=[]
        original_play=CurrentScene.play;original_beat=CurrentScene.beat
        original_intro=CurrentScene.intro;original_result=CurrentScene.result;original_act=CurrentScene.act
        def visible_texts(scene):
            values=[];seen=set()
            for obj in scene.mobjects:
                for mob in obj.get_family():
                    value=getattr(mob,'tex_string',None) or getattr(mob,'text',None)
                    if value and value not in seen:values.append(value);seen.add(value)
            return values
        def play(self,*animations,**kwargs):
            index=len(events)
            if index>=len(paths):raise ValueError(f'Unexpected play {ident}:{index}')
            start=self.time;prior=visible_texts(self)
            caller=next((f for f in inspect.stack() if str(SOURCE/'scenes') in f.filename),None)
            result=original_play(self,*animations,**kwargs)
            is_wait=len(animations)==1 and isinstance(animations[0],Wait)
            text=visible_texts(self)
            events.append({'index':index,'kind':'wait' if is_wait else 'play',
                'animation_types':[type(a).__name__ for a in animations],
                'source_start_frame':prefix[index],'source_end_frame':prefix[index+1],
                'frames':counts[index],'source_start':prefix[index]/FPS,'source_end':prefix[index+1]/FPS,
                'requested_seconds':self.time-start,
                'frozen_wait':bool(self.is_current_animation_frozen_frame()) if is_wait else False,
                'source_partial':str(paths[index]),'source_code_line':caller.lineno if caller else None,
                'visible_texts_after':text,'new_texts':[t for t in text if t not in prior]})
            self.renderer.time=prefix[index+1]/FPS
            return result
        def beat(self,index,note=None,clear=True):
            first=len(events);original_beat(self,index,note,clear)
            caption=next(e for e in reversed(events[first:]) if e['kind']=='play')
            beats.append({'index':index,'nominal_start':meta['beats'][index]['start'],
                'caption_event_index':caption['index'],'source_start_frame':caption['source_start_frame']})
        def reading(self,index,phase,method):
            first=len(events);method(self,index)
            generated=events[first:]
            if not generated or generated[-1]['kind']!='wait':raise ValueError(f'No reading Wait {ident}:{index}:{phase}')
            event=generated[-1];seconds=meta['beats'][index][phase+'_duration']
            assert event['frames']==round(seconds*FPS),(ident,index,phase,event,seconds)
            key=f'{ident:02d}_{index+1:02d}_{phase}'
            windows.append({'key':key,'chapter':ident,'beat':index+1,'phase':phase,
                'event_index':event['index'],'old_start_frame':event['source_start_frame'],
                'old_end_frame':event['source_end_frame'],'frames':event['frames'],
                'frozen_wait':event['frozen_wait'],'nominal_start':meta['beats'][index][phase+'_at'],
                'duration_seconds':seconds,'text':meta['beats'][index][phase],
                'ready_event_frame':prefix[first],
                'guard_before_reading_frames':event['source_start_frame']-prefix[first]})
        def intro(self,index):return reading(self,index,'intro',original_intro)
        def result(self,index):return reading(self,index,'result',original_result)
        def act(self,index,*animations,rate_func=None):
            first=len(events)
            kw={} if rate_func is None else {'rate_func':rate_func}
            original_act(self,index,*animations,**kw)
            event=events[-1]
            actions.append({'beat':index+1,'old_start_frame':event['source_start_frame'],
                'old_end_frame':event['source_end_frame'],'event_index':event['index'],
                'guard_start_frame':prefix[first],'animation_types':event['animation_types']})
        CurrentScene.play=play;CurrentScene.beat=beat;CurrentScene.intro=intro;CurrentScene.result=result;CurrentScene.act=act
        try:
            with tempconfig({'dry_run':True,'frame_rate':FPS,'pixel_width':1920,'pixel_height':1080,
                'media_dir':str(scratch),'tex_dir':str(tex),'text_dir':str(scratch/'texts'),
                'progress_bar':'none','verbosity':'ERROR','disable_caching':True}):
                cls=getattr(importlib.import_module(module),clsname)
                scene=cls(skip_animations=True);scene.construct()
        finally:
            CurrentScene.play=original_play;CurrentScene.beat=original_beat
            CurrentScene.intro=original_intro;CurrentScene.result=original_result;CurrentScene.act=original_act
        assert len(events)==len(paths),(ident,len(events),len(paths))
        source_frames=int(video['nb_frames'])
        assert source_frames==meta['duration']*FPS
        # The original renderer documented a final near-black clone to correct
        # Manim's one-frame short fractional clock. Every preceding source frame
        # still has its exact partial index; retain the explicit tail in the map.
        padding=source_frames-prefix[-1]
        assert 0<=padding<=5,(ident,prefix[-1],source_frames)
        tail_mean=None
        if padding:
            raw=subprocess.check_output(['ffmpeg','-v','error','-sseof','-0.05','-i',str(clip),
                '-frames:v','1','-vf','scale=160:90,format=rgb24','-f','rawvideo','pipe:1'])
            assert raw;tail_mean=sum(raw)/len(raw);assert tail_mean<.2,(ident,tail_mean)
            events.append({'index':len(events),'kind':'source_tail_padding',
                'animation_types':['SourceTailClone'],'source_start_frame':prefix[-1],
                'source_end_frame':source_frames,'frames':padding,'source_start':prefix[-1]/FPS,
                'source_end':source_frames/FPS,'frozen_wait':True,'source_partial':None,
                'reason':'Original render_current.py padded an already-black tail to the exact clock; packet-copy/reencode provenance remains in immutable output/frame_alignment reports',
                'tail_mean_rgb':tail_mean})
        assert len(windows)==2*len(meta['beats'])
        for i,(wi,wr,action) in enumerate(zip(windows[::2],windows[1::2],actions)):
            assert wi['beat']==wr['beat']==action['beat']==i+1
            assert wi['old_end_frame']<=action['old_start_frame']<action['old_end_frame']<=wr['old_start_frame']
            if i+1<len(meta['beats']):assert wr['old_end_frame']<=beats[i+1]['source_start_frame']
            beats[i].update({'beat':i+1,'intro_ready_frame':wi['ready_event_frame'],
                'action_start_frame':action['old_start_frame'],'action_end_frame':action['old_end_frame'],
                'result_ready_frame':wr['ready_event_frame']})
        item={'id':ident,'class':clsname,'source':str(clip),'source_frames':source_frames,
            'duration':source_frames/FPS,'events':events,'beats':beats,'windows':windows,'actions':actions,
            'manim_partial_frames':prefix[-1],'source_tail_padding_frames':padding}
        chapters.append(item);window_chapters.append({k:item[k] for k in ('id','class','source','source_frames','windows','beats','actions')})
        (ROOT/'output'/f'source_timeline_chapter_{ident:02d}.json').write_text(json.dumps({'fps':FPS,'chapters':[item]},ensure_ascii=False,indent=2)+'\n')
        print(f'{ident:02d} {clsname}: {len(events)}events,{len(windows)}reading holds,{source_frames}frames,tailpad{padding}',flush=True)
    if not args.chapters:
        assert len(chapters)==16 and sum(c['source_frames']for c in chapters)==175080
        assert sum(len(c['windows'])for c in chapters)==100
    result={'fps':FPS,'method':'Exact original MP4 partial sample counts indexed to dry geometry; reading-method final Wait selected; all chapter sums independently verified','chapters':chapters}
    windows_out={'fps':FPS,'chapters':window_chapters}
    suffix='' if not args.chapters else '_'+('_'.join(map(str,args.chapters)))
    (ROOT/'output'/f'source_timeline{suffix}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    (ROOT/f'source_windows{suffix}.json').write_text(json.dumps(windows_out,ensure_ascii=False,indent=2)+'\n')
    print(f'Windows:{sum(len(c["windows"])for c in chapters)}; frozen:{sum(w["frozen_wait"]for c in chapters for w in c["windows"])}',flush=True)

if __name__=='__main__':main()

