"""Recognize documented local windows to diagnose a repeated-text ASR failure.

This does not edit audio, infer word times, or replace the original chunk cache.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import json,wave,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parent
MODEL=ROOT.parent.parent/'asr_models/sherpa-onnx-whisper-small'
def initialize():
 global RECOGNIZER,AUDIO
 import sherpa_onnx
 RECOGNIZER=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(MODEL/'small-encoder.int8.onnx'),decoder=str(MODEL/'small-decoder.int8.onnx'),tokens=str(MODEL/'small-tokens.txt'),language='ru',task='transcribe',num_threads=2,provider='cpu',enable_segment_timestamps=True)
 with wave.open(str(ROOT/'materials/recording_16k.wav')) as w:AUDIO=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768

def recognize(job):
 name,start,end,level=job;data=AUDIO[round(start*16000):round(end*16000)].copy();gain=1.
 if level:
  gain=min(8.,.8/max(.000001,float(np.max(np.abs(data)))));data*=gain
 stream=RECOGNIZER.create_stream();stream.accept_waveform(16000,data);RECOGNIZER.decode_stream(stream);r=stream.result
 return {'name':name,'start':start,'end':end,'asr_input_gain':gain,'text':r.text,'segments':[{'start':round(start+float(at),4),'end':round(start+float(at)+float(dur),4),'text':text}for at,dur,text in zip(r.segment_timestamps,r.segment_durations,r.segment_texts)]}

def main():
 jobs=[('expanded',1640.95,1664.3,False),('left_half',1641.845,1653.6,False),('right_half',1652.8,1663.69,False),('same_window_levelled',1641.845,1663.69,True)]
 results=[]
 with ProcessPoolExecutor(max_workers=4,initializer=initialize) as pool:
  for future in as_completed([pool.submit(recognize,j)for j in jobs]):
   r=future.result();results.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
 with (ROOT/'materials/recording_16k.wav').open('rb')as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 (ROOT/'output/asr_interval_recovery.json').write_text(json.dumps({'source_guide_sha256':sha,'failed_original_chunk':139,'original_chunk_bounds':[1641.845,1663.69],'scope':'Local ASR recovery only; all source audio unchanged; native segment bounds are coarse.','results':sorted(results,key=lambda x:x['name'])},ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
