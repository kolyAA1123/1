"""One unquantized Whisper-small diagnosis of the existing ASR-failure slot."""
from pathlib import Path
import json,wave,hashlib
import numpy as np
import sherpa_onnx
ROOT=Path(__file__).resolve().parent;MODEL=ROOT.parent.parent/'asr_models/sherpa-onnx-whisper-small'
start,end=1641.845,1663.69
with wave.open(str(ROOT/'materials/recording_16k.wav'))as w:a=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
rec=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(MODEL/'small-encoder.onnx'),decoder=str(MODEL/'small-decoder.onnx'),tokens=str(MODEL/'small-tokens.txt'),language='ru',task='transcribe',num_threads=2,provider='cpu',enable_segment_timestamps=True)
s=rec.create_stream();s.accept_waveform(16000,a[round(start*16000):round(end*16000)]);rec.decode_stream(s);r=s.result
files={}
for name in ['small-encoder.onnx','small-decoder.onnx']:
 p=MODEL/name
 with p.open('rb')as f:files[name]={'bytes':p.stat().st_size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
report={'diagnostic_only':True,'start':start,'end':end,'model':'Whisper-small float32 ONNX','files':files,'text':r.text,'segments':[{'start':round(start+float(at),4),'end':round(start+float(at)+float(dur),4),'text':txt}for at,dur,txt in zip(r.segment_timestamps,r.segment_durations,r.segment_texts)]}
(ROOT/'output/asr_float_recovery.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False),flush=True)
