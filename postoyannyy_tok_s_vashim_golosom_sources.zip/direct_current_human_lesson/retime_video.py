"""Retime static speech windows while preserving every other source frame.

The caller supplies an explicit integer frame map, normally generated while
building the new narration plan. Audio is deliberately outside this utility.

Mapping JSON (all ends are exclusive)::

    {"fps": 60, "chapters": [{
      "id": 1, "class": "Opening", "expected_frames": 9000,
      "replacements": [{"old_start_frame": 240, "old_end_frame": 703,
                         "new_frame_count": 600, "new_start_frame": 240,
                         "label": "01_01_intro"}]
    }]}

Each replacement must describe a genuinely static source interval. Its frozen
frame defaults to the middle of that interval; override with freeze_source_frame
when needed. The complete original frame partition, retained source intervals,
new intervals, exact frame totals, and SHA256 values are written to reports.

Build a human plan by shifting every later old time by cumulative integer frame
deltas. Preserve the original guards, actions, reveals and fades. To pad a chapter
to a whole second, explicitly replace its last black frame [N-1,N) with 1+padding
frames, using label "tail_padding". No implicit padding or time scaling occurs.

Example::

    source ../setup_env.sh
    python retime_video.py --mapping frame_map.json --jobs 2

Completed pieces are cached atomically. Incomplete files are never reused.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import subprocess
from typing import Any


ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE = (ROOT / "visual_source/output/chapters" if (ROOT / "visual_source").is_dir() else ROOT.parent / "direct_current_lesson/output/chapters")
FPS = 60
CRF = 20
ENCODER_THREADS = 2
KEYINT_FRAMES = 240


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def speech_frames(seconds: float, fps: int = FPS) -> int:
    """Cover a measured speech duration without truncating its last samples."""
    if not math.isfinite(seconds) or seconds < 0:
        raise ValueError(f"Invalid speech duration: {seconds!r}")
    return math.ceil(seconds * fps - 1e-9)


def integer(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer, received {value!r}")
    return value


def probe(path: Path) -> dict[str, Any]:
    raw = subprocess.check_output([
        "ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path),
    ])
    result = json.loads(raw)
    videos = [s for s in result["streams"] if s["codec_type"] == "video"]
    if len(videos) != 1:
        raise ValueError(f"Expected one video stream in {path}")
    video = videos[0]
    if Fraction(video["avg_frame_rate"]) != FPS:
        raise ValueError(f"Expected {FPS} fps in {path}: {video['avg_frame_rate']}")
    if video.get("nb_frames", "N/A") == "N/A":
        raise ValueError(f"Missing exact frame count in {path}")
    return {
        "frames": int(video["nb_frames"]), "width": int(video["width"]),
        "height": int(video["height"]), "fps": FPS,
        "duration": float(result["format"]["duration"]),
        "codec": video["codec_name"],
        "audio_streams": sum(s["codec_type"] == "audio" for s in result["streams"]),
        "bytes": path.stat().st_size,
    }


@dataclass(frozen=True)
class Segment:
    kind: str
    old_start_frame: int
    old_end_frame: int
    new_start_frame: int
    new_end_frame: int
    label: str = ""
    freeze_source_frame: int | None = None

    @property
    def frames(self) -> int:
        return self.new_end_frame - self.new_start_frame


def build_segments(source_frames: int, replacements: list[dict[str, Any]],
                   expected_frames: int | None = None) -> list[Segment]:
    """Validate and partition a frame map without reading/encoding any video.

    The intervals cover every original frame exactly once. For a retained
    interval its frame count and order remain unchanged. No caller-supplied
    output start can silently move, overlap, or discard a non-hold frame.
    """
    source_frames = integer(source_frames, "source_frames")
    if source_frames <= 0:
        raise ValueError("Source must contain frames")
    old_cursor = new_cursor = 0
    segments: list[Segment] = []
    for index, item in enumerate(replacements):
        a = integer(item["old_start_frame"], f"replacement[{index}].old_start_frame")
        b = integer(item["old_end_frame"], f"replacement[{index}].old_end_frame")
        count = integer(item["new_frame_count"], f"replacement[{index}].new_frame_count")
        start = integer(item["new_start_frame"], f"replacement[{index}].new_start_frame")
        if not 0 <= old_cursor <= a < b <= source_frames:
            raise ValueError(f"Unsorted, overlapping, or outside-source replacement {index}: {item}")
        if count < 0:
            raise ValueError(f"Negative replacement length: {item}")
        if a > old_cursor:
            length = a - old_cursor
            segments.append(Segment("keep", old_cursor, a, new_cursor, new_cursor + length))
            new_cursor += length
        if start != new_cursor:
            raise ValueError(
                f"Replacement {index} starts at new frame {start}, but mapping requires {new_cursor}; "
                "derive later timestamps from cumulative frame deltas"
            )
        frozen = integer(item.get("freeze_source_frame", (a + b - 1) // 2),
                         f"replacement[{index}].freeze_source_frame")
        if not a <= frozen < b:
            raise ValueError(f"Frozen frame {frozen} is outside [{a},{b})")
        segments.append(Segment("freeze", a, b, new_cursor, new_cursor + count,
                                str(item.get("label", f"replacement_{index:02d}")), frozen))
        old_cursor, new_cursor = b, new_cursor + count
    if old_cursor < source_frames:
        length = source_frames - old_cursor
        segments.append(Segment("keep", old_cursor, source_frames, new_cursor, new_cursor + length))
        new_cursor += length
    if new_cursor <= 0:
        raise ValueError("Frame map removed the complete video")
    if expected_frames is not None and new_cursor != integer(expected_frames, "expected_frames"):
        raise ValueError(f"Frame map produces {new_cursor} frames; expected {expected_frames}")
    assert sum(s.old_end_frame - s.old_start_frame for s in segments) == source_frames
    assert segments[0].old_start_frame == 0 and segments[-1].old_end_frame == source_frames
    for left, right in zip(segments, segments[1:]):
        assert left.old_end_frame == right.old_start_frame
        assert left.new_end_frame == right.new_start_frame
    for segment in segments:
        if segment.kind == "keep":
            assert segment.frames == segment.old_end_frame - segment.old_start_frame
    return segments


def run(command: list[str], log: Path) -> None:
    with log.open("w", encoding="utf-8") as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}); {log}\n{log.read_text()[-5000:]}")


def checked_piece(path: Path, frames: int, width: int, height: int) -> bool:
    if not path.is_file():
        return False
    try:
        report = probe(path)
    except (ValueError, KeyError, subprocess.CalledProcessError, json.JSONDecodeError):
        return False
    return (report["frames"], report["width"], report["height"], report["audio_streams"]) == (
        frames, width, height, 0,
    ) and abs(report["duration"] - frames / FPS) < 1 / FPS


def input_at_frame(source: Path, frame: int) -> tuple[list[str], int]:
    # Seek to an earlier *whole second*, then count decoded frames. Decimal
    # seeks at n/60 can round above the desired PTS and skip one source frame.
    seek_second = max(0, frame // FPS - 1)
    return (["-threads", str(ENCODER_THREADS), "-ss", str(seek_second), "-i", str(source)],
            frame - seek_second * FPS)


def encoder_arguments() -> list[str]:
    return ["-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", str(CRF),
            "-threads", str(ENCODER_THREADS), "-profile:v", "high", "-level:v", "4.2",
            "-x264-params", f"keyint={KEYINT_FRAMES}:scenecut=0", "-pix_fmt", "yuv420p",
            "-r", str(FPS), "-fps_mode", "cfr", "-video_track_timescale", "15360"]


def encode_segment(source: Path, segment: Segment, path: Path,
                   width: int, height: int, force: bool = False) -> Path | None:
    if not segment.frames:
        return None
    if not force and checked_piece(path, segment.frames, width, height):
        return path
    command = ["ffmpeg", "-hide_banner", "-v", "error", "-y", "-filter_threads", "1"]
    if segment.kind == "keep":
        inputs, first = input_at_frame(source, segment.old_start_frame)
        filters = (f"trim=start_frame={first}:end_frame={first + segment.frames},"
                   f"setpts=N/({FPS}*TB),setsar=1,format=yuv420p")
    else:
        still = path.with_suffix(".png")
        temporary_still = path.with_name(path.stem + ".tmp.png")
        inputs, first = input_at_frame(source, segment.freeze_source_frame)
        extract = command + inputs + [
            "-an", "-vf", f"trim=start_frame={first}:end_frame={first + 1},format=rgb24",
            "-frames:v", "1", "-c:v", "png", "-compression_level", "1", "-threads", "1",
            str(temporary_still),
        ]
        run(extract, path.with_suffix(".extract.log"))
        temporary_still.replace(still)
        inputs = ["-threads", "1", "-framerate", str(FPS), "-i", str(still)]
        filters = f"tpad=stop_mode=clone:stop=-1,setpts=N/({FPS}*TB),setsar=1,format=yuv420p"
    temporary = path.with_name(path.stem + ".tmp.mp4")
    command += inputs + ["-map", "0:v:0", "-vf", filters, "-frames:v", str(segment.frames)]
    command += encoder_arguments() + [str(temporary)]
    run(command, path.with_suffix(".log"))
    if not checked_piece(temporary, segment.frames, width, height):
        raise RuntimeError(f"Encoded piece does not match its exact frame map: {temporary}")
    temporary.replace(path)
    return path


def retime_chapter(source: Path, destination: Path, replacements: list[dict[str, Any]],
                   expected_frames: int | None = None, *, chapter_id: int | None = None,
                   cache_root: Path | None = None, report_path: Path | None = None,
                   force: bool = False) -> dict[str, Any]:
    """Programmatic API; only this chapter's destination/cache/report are written."""
    source, destination = source.resolve(), destination.resolve()
    if source == destination:
        raise ValueError("Output must be separate from the source video")
    before = probe(source)
    segments = build_segments(before["frames"], replacements, expected_frames)
    count = segments[-1].new_end_frame
    source_sha = sha256(source)
    version = subprocess.check_output(["ffmpeg", "-version"], text=True).splitlines()[0]
    signature_data = {"source_sha256": source_sha, "fps": FPS, "crf": CRF, "keyint_frames": KEYINT_FRAMES,
                      "tool_sha256": sha256(Path(__file__)), "ffmpeg": version,
                      "segments": [asdict(s) for s in segments]}
    signature = hashlib.sha256(json.dumps(signature_data, sort_keys=True).encode()).hexdigest()
    cache_root = cache_root or ROOT / "output/retime_cache"
    cache = cache_root / destination.stem / signature[:20]
    cache.mkdir(parents=True, exist_ok=True)
    destination.parent.mkdir(parents=True, exist_ok=True)
    report_path = report_path or ROOT / "output/retime_reports" / (destination.stem + ".json")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    pieces, segment_reports = [], []
    for index, segment in enumerate(segments):
        path = cache / f"{index:03d}_{segment.kind}.mp4"
        result = encode_segment(source, segment, path, before["width"], before["height"], force)
        if result is not None:
            pieces.append(result)
        segment_reports.append({**asdict(segment), "frames": segment.frames,
                                "source_frames_per_output_frame": 1 if segment.kind == "keep" else 0,
                                "piece": str(result) if result else None})
    concat = cache / "concat.txt"
    concat.write_text("".join("file '" + str(p).replace("'", "'\\''") + "'\n" for p in pieces))
    temporary = destination.with_name(destination.stem + ".tmp.mp4")
    run(["ffmpeg", "-hide_banner", "-v", "error", "-y", "-f", "concat", "-safe", "0",
         "-i", str(concat), "-map", "0:v:0", "-an", "-c:v", "copy",
         "-video_track_timescale", "15360", "-movflags", "+faststart", str(temporary)],
        cache / "concat.log")
    timestamp_repair = None
    if not checked_piece(temporary, count, before["width"], before["height"]):
        raw = json.loads(subprocess.check_output([
            "ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(temporary)]))
        video = next(s for s in raw["streams"] if s["codec_type"] == "video")
        # Some concat-copy boundaries produce inconsistent frame-rate metadata
        # even when every decoded frame and presentation timestamp is correct.
        # Restore native60fps from decoded frame order, without an fps filter
        # that could drop/duplicate frames. Reject any actual count/shape error.
        if (int(video.get("nb_frames", -1)), int(video["width"]), int(video["height"])) != (
                count, before["width"], before["height"]):
            raise RuntimeError(f"Concatenated chapter does not match the complete map: {temporary}")
        if any(s["codec_type"] == "audio" for s in raw["streams"]):
            raise RuntimeError(f"Unexpected audio in silent chapter: {temporary}")
        timestamp_repair = {"method": "decoded_frame_order_setpts_CFR",
            "input_sha256": sha256(temporary), "input_avg_frame_rate": video["avg_frame_rate"],
            "decoded_frames": count, "output_fps": FPS, "crf": 16,
            "frame_interpolation_used": False}
        repaired = temporary.with_name(temporary.stem + ".cfr.mp4")
        encoder = encoder_arguments()
        encoder[encoder.index("-crf") + 1] = "16"
        run(["ffmpeg", "-hide_banner", "-v", "error", "-y", "-filter_threads", "1",
             "-threads", str(ENCODER_THREADS), "-i", str(temporary), "-map", "0:v:0",
             "-vf", f"setpts=N/({FPS}*TB),setsar=1,format=yuv420p",
             "-frames:v", str(count), *encoder, "-movflags", "+faststart", str(repaired)],
            cache / "concat_cfr_repair.log")
        if not checked_piece(repaired, count, before["width"], before["height"]):
            raise RuntimeError(f"CFR repair failed exact frame validation: {repaired}")
        repaired.replace(temporary)
    temporary.replace(destination)
    after = probe(destination)
    report = {"chapter": chapter_id, "source": str(source), "output": str(destination),
              "source_sha256": source_sha, "sha256": sha256(destination),
              "signature": signature, "ffmpeg": version, "fps": FPS,
              "source_frames": before["frames"], "frames": count,
              "duration_seconds": count / FPS, "width": after["width"], "height": after["height"],
              "bytes": after["bytes"], "audio_streams": after["audio_streams"],
              "kept_source_frames": sum(s.frames for s in segments if s.kind == "keep"),
              "replaced_source_frames": sum(s.old_end_frame - s.old_start_frame for s in segments if s.kind == "freeze"),
              "new_freeze_frames": sum(s.frames for s in segments if s.kind == "freeze"),
              "non_hold_frames_preserved_in_order": True,
              "motion_speed_changed": False, "encoding_crf": CRF, "keyint_frames": KEYINT_FRAMES, "segments": segment_reports}
    if timestamp_repair is not None:
        report["concat_timestamp_repair"] = timestamp_repair
    assert report["kept_source_frames"] + report["replaced_source_frames"] == before["frames"]
    assert report["kept_source_frames"] + report["new_freeze_frames"] == count
    temporary_report = report_path.with_suffix(".tmp.json")
    temporary_report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    temporary_report.replace(report_path)
    print(f"Retimed {destination.name}: {before['frames']} → {count} frames ({count / FPS:.3f}s)", flush=True)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--mapping", required=True, type=Path)
    parser.add_argument("--source-root", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output-root", type=Path, default=ROOT / "output/chapters")
    parser.add_argument("--report-root", type=Path, default=ROOT / "output/retime_reports")
    parser.add_argument("--cache-root", type=Path, default=ROOT / "output/retime_cache")
    parser.add_argument("--chapters", nargs="*", type=int)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    mapping = json.loads(args.mapping.read_text(encoding="utf-8"))
    if mapping.get("fps", FPS) != FPS:
        parser.error("Mapping must use 60 fps")
    chapters = mapping["chapters"]
    ids = [integer(c["id"], "chapter.id") for c in chapters]
    if len(set(ids)) != len(ids):
        parser.error("Duplicate chapter IDs")
    if args.chapters:
        if set(args.chapters) - set(ids):
            parser.error("Unknown chapter ID")
        chapters = [c for c in chapters if c["id"] in args.chapters]
    results = []
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = []
        for chapter in chapters:
            name = f"{chapter['id']:02d}_{chapter['class']}.mp4"
            if Path(name).name != name:
                parser.error("Chapter class must not contain directory components")
            futures.append(pool.submit(
                retime_chapter, args.source_root / name, args.output_root / name,
                chapter["replacements"], chapter.get("expected_frames"), chapter_id=chapter["id"],
                cache_root=args.cache_root, report_path=args.report_root / f"{chapter['id']:02d}.json",
                force=args.force,
            ))
        for future in as_completed(futures):
            results.append(future.result())
    print(f"Ready: {len(results)} silent chapters, {sum(r['frames'] for r in results)} frames, "
          f"{sum(r['bytes'] for r in results) / 1024**2:.2f} MiB.", flush=True)


if __name__ == "__main__":
    main()
