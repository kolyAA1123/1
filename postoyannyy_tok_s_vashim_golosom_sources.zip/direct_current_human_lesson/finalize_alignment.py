"""Apply documented acoustic-boundary decisions to the complete recording.

This preserves the entire source partition. ASR confidence is not pronunciation
verification; native sentence times are exposed only as broad source markers.
"""
from pathlib import Path
import argparse,hashlib,json,wave
import numpy as np

ROOT=Path(__file__).resolve().parent

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--decisions',type=Path,default=ROOT/'boundary_decisions.json')
    args=parser.parse_args()
    cuts=read(ROOT/'cuts_proposed.json')['cues']
    proposal=read(ROOT/'output/alignment_proposals.json')
    reviews=read(ROOT/'output/boundary_review.json')
    decisions=read(args.decisions) if args.decisions.exists() else {}
    # Recovery uses only genuine locally recognized words. Keep the original
    # hallucinated raw chunk intact for provenance, never expose it as a marker.
    recovery_path=ROOT/'asr_recovery_manifest.json'
    recovery=read(recovery_path) if recovery_path.exists() else None
    transcript_path=ROOT/recovery['alignment_transcription'] if recovery else ROOT/'output/transcription.json'
    transcript=read(transcript_path)
    if recovery:
        assert digest(ROOT/'output/transcription.json')==recovery['raw_transcription_sha256']
        assert digest(ROOT/'output/asr_chunks/139.json')==recovery['raw_chunk_cache_sha256']
        assert all(key in decisions for key in recovery['required_boundary_reviews'])
    assert len(cuts)==len(proposal['cues'])==100
    assert all(r['before'] in decisions for r in reviews if r['needs_review']), 'Document every flagged boundary decision before finalizing.'
    with wave.open(str(ROOT/'materials/recording_processed.wav')) as w:
        total=w.getnframes()/w.getframerate()
    cuts[0]['source_start']=0.;cuts[-1]['source_end']=total
    decisions_log=[]
    for i,(left,right) in enumerate(zip(cuts,cuts[1:])):
        if left['key'] in decisions:
            decision=decisions[left['key']]
            cut=float(decision['time'])
            assert left['source_start']<cut<right['source_end'],decision
            left['source_end']=right['source_start']=cut
            decisions_log.append({'before':left['key'],'after':right['key'],**decision})
        assert left['source_end']==right['source_start']
    assert all(0<=c['source_start']<c['source_end']<=total+1e-8 for c in cuts)
    with wave.open(str(ROOT/'materials/recording_16k.wav')) as w:
        assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,16000)
        guide=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2')
    boundary_checks=[]
    for left,right in zip(cuts,cuts[1:]):
        t=left['source_end']
        a=guide[max(0,round((t-.02)*16000)):round((t+.02)*16000)].astype(float)/32768
        rms=float(np.sqrt(np.mean(a*a)))
        assert rms<.01,(left['key'],right['key'],t,rms)
        boundary_checks.append({'before':left['key'],'after':right['key'],'time':t,
            'rms_40ms_dbfs':round(20*np.log10(max(rms,1e-9)),3)})
    recovery_check=None
    if recovery:
        cue=next(c for c in cuts if c['key']=='12_01_intro')
        lo,hi=recovery['conservative_source_chunk_bounds']
        assert cue['source_start']<=lo and cue['source_end']>=hi
        # Check the exact quiet-edge rule used by build_edit without generating
        # or altering any audio. Active source bins in the unrecognized beginning
        # must remain inside the retained intro, including its real voice onset.
        g=guide[round(cue['source_start']*16000):round(cue['source_end']*16000)]
        n=len(g)//160
        energy=np.sqrt((g[:n*160].astype(float).reshape(n,160)**2).mean(axis=1))
        active=np.flatnonzero(energy>32768*10**(-45/20))
        assert len(active)
        retained_start=cue['source_start']+max(0,round((active[0]*.01-.18)*48000))/48000
        retained_end=cue['source_start']+min(round((cue['source_end']-cue['source_start'])*48000),round(((active[-1]+1)*.01+.25)*48000))/48000
        early_lo,early_hi=recovery['unrecognized_first_half']
        early_active=[int(i) for i in active if early_lo<=cue['source_start']+(int(i)+.5)*.01<early_hi]
        assert early_active,'No active source bins detected in the unrecognized interval'
        assert all(retained_start<=cue['source_start']+i*.01 and
                   cue['source_start']+(i+1)*.01<=retained_end for i in early_active)
        recovery_check={'cue':cue['key'],'whole_original_chunk':[lo,hi],
            'unrecognized_first_half':[early_lo,early_hi],
            'active_10ms_bins_in_first_half':len(early_active),
            'predicted_quiet_edge_retained_interval':[retained_start,retained_end],
            'all_active_first_half_bins_preserved':True,
            'first_half_text_verified':False,'expected_words_inserted_into_ASR':False}
    for c in cuts:c['review']='Reviewed source partition; all source content retained. Only quiet edge handles may be trimmed later.'
    dump(ROOT/'cuts.json',{'source':read(ROOT/'asr_recording_manifest.json')['source_file'],'cues':cuts})
    markers=[]
    for c in cuts:
        native=[]
        unresolved=[]
        for chunk in transcript:
            segments=chunk.get('segments',[])
            if chunk.get('recovery'):
                segments=chunk['recovery']['local_native_segments']
                span=chunk['recovery']['unrecognized_audio_retained_interval']
                if span[1]>c['source_start'] and span[0]<c['source_end']:
                    unresolved.append({'start':max(span[0],c['source_start']),
                        'end':min(span[1],c['source_end']),
                        'reason':'Original audio retained; text not reliably recognized.'})
            for segment in segments:
                if float(segment['end'])>c['source_start'] and float(segment['start'])<c['source_end']:
                    native.append({'chunk':chunk['index'],**segment})
        markers.append({'key':c['key'],'source_start':c['source_start'],
                        'source_end':c['source_end'],'expected_text':c['expected_text'],
                        'native_segments':native,'unrecognized_source_intervals':unresolved})
    dump(ROOT/'output/cue_native_segments.json',markers)
    extras=[e for e in proposal['extras'] if len(e['text'].split())>=5]
    report={'summary':proposal['summary'],'source_partition_cues':100,
            'source_partition_end_seconds':total,'source_content_preserved':True,
            'confirmed_narrator_mistakes':None,'not_listening_verified':True,
            'boundary_decisions':decisions_log,
            'alignment_transcription':str(transcript_path.relative_to(ROOT)),
            'alignment_transcription_sha256':digest(transcript_path),
            'original_raw_ASR_unchanged':True,
            'acoustic_boundary_checks':boundary_checks,
            'loudest_boundary_40ms_dbfs':max(x['rms_40ms_dbfs'] for x in boundary_checks),
            'recovery_source_slot_check':recovery_check,
            'flagged_boundary_reviews':[{k:v for k,v in r.items() if k!='candidate_pauses'}
                                        for r in reviews if r['needs_review']],
            'recognized_extra_runs_at_least5words':extras,
            'unmatched_cue_keys':[c['key'] for c in proposal['cues'] if not c['matched_word_pairs']],
            'full_cue_omissions_detected':False if all(c['matched_word_pairs'] for c in proposal['cues']) else None,
            'limitations':'ASR phonetics/formulas may differ from the recording; recognized extras and low confidence are not verified narrator errors. First half of12_01_intro is unrecognized but its complete active audio is retained in that scene. Native segment times are not word timings. No continuous human listening is claimed.'}
    dump(ROOT/'output/alignment_review.json',report)
    print('Finalized 100 continuous cues; source end',total,flush=True)

if __name__=='__main__':main()
