"""Read-only representative and critical final-film proof at exact retimed frames.

Every sample comes from the assembled MP4, using the100-cue plan (intro/result).
Capturing creates evidence only; visual inspection must be recorded separately.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
FPS=60
DEFAULT_MOVIE=ROOT/'output/postoyannyy_tok_s_vashim_golosom_1080p60.mp4'

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def capture(movie,frame,dest):
    seek=max(0,frame//FPS-1);first=frame-seek*FPS
    subprocess.run(['ffmpeg','-v','error','-y','-threads','1','-ss',str(seek),'-i',str(movie),
        '-an','-vf',f'trim=start_frame={first}:end_frame={first+1}',
        '-frames:v','1','-threads','1','-q:v','2',str(dest)],check=True)
    with Image.open(dest) as im:assert im.size==(1920,1080),(dest,im.size)
def stamp(frame):
    seconds=frame/FPS;m,s=divmod(seconds,60);h,m=divmod(int(m),60)
    return f'{h:02d}:{m:02d}:{s:06.3f}'
def sample_plan(plan):
    cues=[cue for ch in plan['chapters'] for cue in ch['cues']]
    assert len(cues)==100 and len({c['key'] for c in cues})==100
    assert all(c['key']==f"{c['chapter']:02d}_{c['beat']:02d}_{c['phase']}" for c in cues)
    assert sum(len(ch['actions']) for ch in plan['chapters'])==50
    samples={}
    def cue(ch,c,reason):
        key=c['key']
        frame=round((c['global_at']+c['speech_duration']/2)*FPS)
        row={'key':key,'chapter':ch['id'],'beat':c['beat'],'phase':c['phase'],
             'global_frame':frame,'global_time':frame/FPS,'timecode':stamp(frame),'reason':[reason],
             'caption':c['caption']}
        if key in samples:samples[key]['reason'].append(reason)
        else:samples[key]=row
    def action(ch,a,phase,reason):
        start,end=a['new_start_frame'],a['new_end_frame']
        local={'action_start':start+1,'action_mid':(start+end)//2,'action_end':end-1}[phase]
        frame=ch['start']*FPS+local;key=f"{ch['id']:02d}_{a['beat']:02d}_{phase}"
        samples[key]={'key':key,'chapter':ch['id'],'beat':a['beat'],'phase':phase,
            'global_frame':frame,'global_time':frame/FPS,'timecode':stamp(frame),
            'reason':[reason],'caption':ch['beats'][a['beat']-1]['caption']}
    for ch in plan['chapters']:
        cue(ch,ch['cues'][0],'Representative first prepared theory state of chapter')
        cue(ch,ch['cues'][-1],'Representative final completed result of chapter')
        critical={1:'Electron drift, field and conventional current directions',
                  2:'Both complete current-time plots and charge area',
                  4:'Metal temperature and superconducting transition conditions',
                  5:'Rheostat active length',
                  6:'Voltmeter parallel and ammeter series with ideal limits',
                  7:'Complete series-resistance derivation',
                  8:'Complete parallel-resistance derivation',
                  9:'Complete source energy loop and EMF convention',
                  10:'External/internal resistance, finite short circuit and energy',
                  13:'Opposite ion lanes and unchanged steady ammeter',
                  14:'Donor carriers with electrically neutral crystal',
                  15:'Vacancy handoff with fixed atomic sites',
                  16:'Fixed diode ends during polarity reversal'}
        if ch['id'] in critical:
            for c in ch['cues']:cue(ch,c,critical[ch['id']])
            for a in ch['actions']:
                action(ch,a,'action_mid','Critical moving geometry and complete derivation')
                if ch['id'] in (1,2,4,5,6,7,8,9,10,13,14,15,16):
                    action(ch,a,'action_end','Completed path, state, graph or derivation endpoint')
    return sorted(samples.values(),key=lambda r:(r['chapter'],r['global_frame'],r['key']))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--movie',type=Path,default=DEFAULT_MOVIE)
    parser.add_argument('--preview',action='store_true');args=parser.parse_args()
    plan=json.loads((ROOT/'plan.json').read_text());samples=sample_plan(plan)
    if args.preview:
        print(json.dumps({'frames_to_capture':len(samples),'chapter_count':16,
                          'critical_chapters':[1,2,4,5,6,7,8,9,10,13,14,15,16],'samples':samples},ensure_ascii=False,indent=2));return
    movie=args.movie.resolve();assert movie.is_file(),movie
    before=sha(movie)
    info=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0',
        '-show_entries','stream=width,height,nb_frames,r_frame_rate','-of','json',str(movie)]))['streams'][0]
    assert (int(info['width']),int(info['height']),info['r_frame_rate'])==(1920,1080,'60/1')
    assert int(info['nb_frames'])==plan['duration']*FPS
    out=ROOT/'output/final_contacts';out.mkdir(parents=True,exist_ok=True)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
    for ch in plan['chapters']:
        rows=[r for r in samples if r['chapter']==ch['id']]
        columns=3;cellw,cellh=640,386
        sheet=Image.new('RGB',(columns*cellw,((len(rows)+columns-1)//columns)*cellh),'#151515')
        draw=ImageDraw.Draw(sheet)
        for i,row in enumerate(rows):
            dest=out/(row['key']+'_full.jpg');capture(movie,row['global_frame'],dest)
            row['file']=dest.name
            with Image.open(dest) as im:
                im.thumbnail((640,360));x=(i%columns)*cellw;y=(i//columns)*cellh;sheet.paste(im,(x,y))
            draw.text((x+5,y+363),f"{row['key']} / {row['timecode']} / f{row['global_frame']}",font=font,fill='white')
        sheet.save(out/f"sheet_{ch['id']:02d}.jpg",quality=96)
        print(f"Captured final chapter {ch['id']:02d}: {len(rows)} exact-frame states",flush=True)
    assert before==sha(movie),'Movie changed during proof capture'
    manifest={'scope':'Representative and critical final assembled film frames; not an all-frame inspection or full listening pass.',
        'movie':str(movie),'final_sha256':before,'fps':FPS,'final_frames':int(info['nb_frames']),
        'plan_cues':100,'plan_actions':50,'captured_frames':len(samples),'source_movie_unchanged':True,
        'visually_inspected_frames':[],'review_state':'captured_not_yet_visually_reviewed','states':samples}
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(f"COMPLETE {len(samples)} final proof states; SHA256 {before}",flush=True)

if __name__=='__main__':main()
