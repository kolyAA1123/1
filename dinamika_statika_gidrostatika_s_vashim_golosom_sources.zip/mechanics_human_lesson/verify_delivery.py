"""Verify the measured 110-cue own-voice edition against its source assets.

This validates actual delivery media, exact PCM placement, and frame partitions.
ASR is an alignment aid; this report does not certify pronunciation or perform
human listening. Source held frames are decoded over their complete intervals.
"""
from __future__ import annotations
from dataclasses import asdict
from fractions import Fraction
import argparse,hashlib,json,subprocess,wave
from pathlib import Path
import numpy as np
from retime_video import build_segments,input_at_frame

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'visual_source'
ORIGINAL_SOURCE=ROOT.parent/'mechanics_lesson'
PREFIX='dinamika_statika_gidrostatika_s_vashim_golosom'
FPS=60;RATE=48000
CHAPTER_COUNT=22;CUES_PER_CHAPTER=5;CUE_COUNT=CHAPTER_COUNT*CUES_PER_CHAPTER;SOURCE_SECONDS=1680

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def probe(p):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-show_chapters','-of','json',str(p)]))
def wav(p,rate=RATE):
    with wave.open(str(p)) as w:
        assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,rate),p
        return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy()
def video_info(p,frames,audio):
    d=probe(p);vs=[s for s in d['streams'] if s['codec_type']=='video'];ads=[s for s in d['streams'] if s['codec_type']=='audio']
    assert len(vs)==1 and len(ads)==int(audio),p
    v=vs[0];assert (v['width'],v['height'],Fraction(v['avg_frame_rate']))==(1920,1080,FPS),p
    assert int(v['nb_frames'])==frames,(p,v['nb_frames'],frames)
    assert abs(float(d['format']['duration'])-frames/FPS)<.06,p
    if audio:
        a=ads[0];assert (a['codec_name'],int(a['sample_rate']),a['channels'])==('aac',RATE,1),p
        assert abs(float(a['duration'])-frames/FPS)<.06,p
    return d

def interval_frames(p,a,b,width=160,height=90):
    inputs,first=input_at_frame(p,a)
    raw=subprocess.check_output(['ffmpeg','-v','error','-filter_threads','1',*inputs,'-an',
       '-vf',f'trim=start_frame={first}:end_frame={first+b-a},scale={width}:{height},format=rgb24',
       '-frames:v',str(b-a),'-f','rawvideo','pipe:1'])
    frames=np.frombuffer(raw,dtype=np.uint8).reshape(-1,height,width,3)
    assert len(frames)==b-a,(p,a,b,len(frames))
    return frames

def static_limits(p,item,source_sha):
    limits={'mean_limit':.15,'channel_limit':8}
    exceptions=ROOT/'static_exceptions.json'
    if exceptions.exists():
        for exception in read(exceptions)['exceptions']:
            if (source_sha,item['old_start_frame'],item['old_end_frame'])!=(exception['source_sha256'],exception['start_frame'],exception['end_frame']):continue
            if exception.get('require_frozen_wait'):
                chapters=read(ROOT/'output/source_timeline.json')['chapters']
                chapter=next(ch for ch in chapters if Path(ch['source']).name==p.name)
                assert any(e['kind']=='wait' and e['frozen_wait'] and
                    (e['source_start_frame'],e['source_end_frame'])==(exception['start_frame'],exception['end_frame'])
                    for e in chapter['events']),exception
            limits={k:exception[k] for k in ('mean_limit','channel_limit','reason')}
    return limits

def verify_static(p,item,source_sha):
    a,b=item['old_start_frame'],item['old_end_frame']
    frames=interval_frames(p,a,b)
    diff=np.abs(frames.astype(np.int16)-frames[len(frames)//2].astype(np.int16))
    means=diff.mean(axis=(1,2,3));maximum=int(diff.max())
    limits=static_limits(p,item,source_sha)
    assert float(means.max())<limits['mean_limit'] and maximum<=limits['channel_limit'],(p,item['label'],float(means.max()),maximum)
    return {'label':item['label'],'start_frame':a,'end_frame':b,'decoded_frames':len(frames),
            'max_frame_mean_abs_rgb_difference':round(float(means.max()),6),'max_channel_difference':maximum,
            'accepted_limits':limits}

def cached_static(p,item,source_sha):
    """Reuse only complete decoded checks of the identical source/interval."""
    cache_path=ROOT/'output/source_static_validation.json'
    cache=read(cache_path) if cache_path.exists() else {'schema':1,'checks':{}}
    key=f"{source_sha}:{item['old_start_frame']}:{item['old_end_frame']}"
    check=cache['checks'].get(key)
    if check is None:
        check=verify_static(p,item,source_sha);cache['checks'][key]=check
        temporary=cache_path.with_suffix('.tmp.json')
        temporary.write_text(json.dumps(cache,ensure_ascii=False,indent=2)+'\n');temporary.replace(cache_path)
    limits=static_limits(p,item,source_sha)
    assert check['max_frame_mean_abs_rgb_difference']<limits['mean_limit'] and check['max_channel_difference']<=limits['channel_limit']
    return {**check,'label':item['label'],'source_sha256':source_sha}

def boundary_checks(cuts,guide,edits):
    assert len(cuts)==len(edits)==CUE_COUNT
    assert cuts[0]['source_start']==0
    assert abs(cuts[-1]['source_end']-len(guide)/16000)<=1/16000
    checks=[]
    for a,b in zip(cuts,cuts[1:]):
        assert abs(a['source_end']-b['source_start'])<1e-6
        t=a['source_end'];window=guide[max(0,round((t-.02)*16000)):round((t+.02)*16000)].astype(float)/32768
        rms=float(np.sqrt(np.mean(window**2)))
        assert rms<.01,(a['key'],b['key'],t,rms)
        checks.append({'after':a['key'],'time':t,'boundary_40ms_rms_dbfs':round(20*np.log10(max(rms,1e-9)),3)})
    # Removed content must be quiet edge pauses, never a recognized word range.
    for c,e in zip(cuts,edits):
        assert c['key']==e['key']
        for lo,hi in ((c['source_start'],e['retained_source_start']),(e['retained_source_end'],c['source_end'])):
            g=guide[round(lo*16000):round(hi*16000)].astype(float)/32768
            n=len(g)//160
            if n:
                rms=np.sqrt((g[:n*160].reshape(n,160)**2).mean(axis=1))
                assert float(rms.max())<.008,(c['key'],lo,hi,float(rms.max()))
    return checks

def mapped_frame(point,replacements):
    delta=0
    for item in replacements:
        if point>=item['old_end_frame']:
            delta+=item['new_frame_count']-(item['old_end_frame']-item['old_start_frame'])
        elif point>item['old_start_frame']:
            raise AssertionError(('Audio anchor inside replaced interval',point,item))
    return point+delta

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--skip-decode',action='store_true',help='Diagnostic only; report is explicitly incomplete.')
    parser.add_argument('--source-only',action='store_true',help='Precheck immutable source hold intervals before final assembly.')
    args=parser.parse_args()
    if args.source_only:
        full_timeline=ROOT/'output/source_timeline.json'
        if full_timeline.exists():
            timeline=read(full_timeline)
        else:
            available=sorted((ROOT/'output').glob('source_timeline_chapter_*.json'))
            assert available,'No complete per-chapter source timeline is available yet'
            timeline={'chapters':[read(p)['chapters'][0] for p in available]}
        print(f"Prechecking {len(timeline['chapters'])}/{CHAPTER_COUNT} available source chapters",flush=True)
        for chapter in timeline['chapters']:
            path=Path(chapter['source']);source_sha=digest(path)
            for beat in chapter['beats']:
                item={'label':f"{chapter['id']:02d}_{beat['index']+1:02d}",
                      'old_start_frame':beat['terminal_hold_start_frame'],'old_end_frame':beat['terminal_hold_end_frame']}
                result=cached_static(path,item,source_sha)
                print(f"Static {item['label']}: meanDifference={result['max_frame_mean_abs_rgb_difference']}; channelMax={result['max_channel_difference']}",flush=True)
        return
    out=ROOT/'output';plan=read(ROOT/'plan.json');source_plan=read(SOURCE/'plan.json');mapping=read(ROOT/'frame_map.json')
    corrections=read(ROOT/'visual_corrections.json')
    corrected={c['id']:c for c in corrections['chapters']}
    assert set(corrected)==set(corrections['corrected_chapter_ids'])=={3,5}
    assert corrections['all22_original_chapters_unchanged'] and corrections['only_label_positions_changed']
    anchors={c['key']:c for c in read(ROOT/'narration_anchors.json')['cues']}
    source_timeline={c['id']:c for c in read(ROOT/'output/source_timeline.json')['chapters']}
    assert len(plan['chapters'])==len(mapping['chapters'])==len(source_plan['chapters'])==CHAPTER_COUNT
    assert source_plan['duration']==SOURCE_SECONDS
    assert plan['voice']['synthetic_speech_used'] is False
    movie=out/f'{PREFIX}_1080p60.mp4'
    final=video_info(movie,plan['duration']*FPS,True)
    assert len(final['chapters'])==CHAPTER_COUNT
    guide=wav(ROOT/'materials/recording_16k.wav',16000)
    recording=read(ROOT/'recording_manifest.json')
    asr_recording=read(ROOT/'asr_recording_manifest.json')
    assert recording['sha256']==asr_recording['source_sha256']
    assert recording['original_bytes']==asr_recording['source_bytes']
    assert digest(ROOT/'materials/recording_16k.wav')==asr_recording['guide_sha256']
    if recording.get('processed_wav_sha256'):
        assert digest(ROOT/'materials/recording_processed.wav')==recording['processed_wav_sha256']
    edits=read(out/'edit_decisions.json');cuts=read(ROOT/'cuts.json')['cues']
    boundaries=boundary_checks(cuts,guide,edits)
    processed=wav(ROOT/'materials/recording_processed.wav')
    for cut,edit in zip(cuts,edits):
        # Reconstruct the exact segment from the levelled supplied recording,
        # including the documented5ms edge fade, rather than trusting a filename.
        a=round(cut['source_start']*RATE)
        left=round((edit['retained_source_start']-cut['source_start'])*RATE)
        right=round((edit['retained_source_end']-cut['source_start'])*RATE)
        expected=processed[a+left:a+right].copy()
        ramp=min(240,len(expected)//2)
        expected[:ramp]=(expected[:ramp]*np.linspace(0,1,ramp)).astype('<i2')
        expected[-ramp:]=(expected[-ramp:]*np.linspace(1,0,ramp)).astype('<i2')
        part=out/'audio/parts'/f"{cut['key']}.wav"
        assert edit['sha256']==digest(part)
        assert len(expected)==edit['samples'] and np.array_equal(expected,wav(part)),cut['key']
    del processed
    master=wav(out/'audio/narration.wav');assert len(master)==plan['duration']*RATE
    offset=0;all_cues=[];chapters=[];source_hashes=[];original_hashes=[]
    original_baseline={c['id']:c['sha256'] for c in read(ROOT/'original_source_manifest.json')['chapters']}
    for ch,old,mp,meta in zip(plan['chapters'],source_plan['chapters'],mapping['chapters'],final['chapters']):
        assert ch['id']==old['id']==mp['id']
        assert ch['start']==offset
        assert abs(float(meta['start_time'])-offset)<.0011
        assert abs(float(meta['end_time'])-offset-ch['duration'])<.0011
        assert meta['tags']['title']==ch['title']
        name=f"{ch['id']:02d}_{ch['class']}.mp4"
        source=SOURCE/'output/chapters'/name;clip=out/'chapters'/name
        video_info(source,old['duration']*FPS,False);video_info(clip,ch['duration']*FPS,False)
        partition=build_segments(old['duration']*FPS,mp['replacements'],ch['duration']*FPS)
        report=read(out/'retime_reports'/f"{ch['id']:02d}.json")
        source_sha=digest(source);source_hashes.append({'chapter':ch['id'],'sha256':source_sha})
        original_sha=digest(ORIGINAL_SOURCE/'output/chapters'/name)
        assert original_sha==original_baseline[ch['id']],(ch['id'],'Original source modified')
        original_hashes.append({'chapter':ch['id'],'sha256':original_sha})
        if ch['id'] not in (3,5):assert source_sha==original_sha,(ch['id'],'Unexpected source change')
        else:
            correction=corrected[ch['id']]
            assert source_sha!=original_sha,(ch['id'],'Corrected visual source not rendered')
            assert (source_sha,original_sha)==(correction['new_sha256'],correction['original_sha256'])
            assert correction['source_frames']==old['duration']*FPS==sum(correction['partial_frame_counts'])
            assert correction['same_frame_count'] and correction['partial_frame_counts_unchanged'] and correction['event_timing_unchanged']
        assert report['source_sha256']==source_sha
        assert report['sha256']==digest(clip)
        assert report['source_frames']==old['duration']*FPS and report['frames']==ch['duration']*FPS
        assert report['non_hold_frames_preserved_in_order'] is True and report['motion_speed_changed'] is False
        assert len(partition)==len(report['segments'])
        for seg,actual in zip(partition,report['segments']):
            assert all(actual[k]==v for k,v in asdict(seg).items()),(ch['id'],seg)
        holds=[]
        for r in mp['replacements']:
            if r['label']=='tail_padding':assert r['old_end_frame']-r['old_start_frame']==1;continue
            if r['label'] in anchors:
                anchor=anchors[r['label']]
                assert (r['old_start_frame'],r['old_end_frame'])==(anchor['hold_start_frame'],anchor['hold_end_frame'])
            elif r['old_end_frame']-r['old_start_frame']>1:
                # Reviewed additional pauses (e.g. zero velocity at the apex)
                # must lie inside a real source Wait event, then decode static.
                waits=[e for e in source_timeline[ch['id']]['events'] if e['kind']=='wait']
                assert any(e['source_start_frame']<=r['old_start_frame']<r['old_end_frame']<=e['source_end_frame'] for e in waits),r
            else:
                # An inserted readable pause repeats one existing frame without
                # discarding or slowing any of the following movement frames.
                assert r['old_end_frame']-r['old_start_frame']==1,r
            holds.append(cached_static(source,r,source_sha))
        track=wav(out/'audio/chapters'/f"{ch['id']:02d}.wav");assert len(track)==ch['duration']*RATE
        assert np.array_equal(master[offset*RATE:(offset+ch['duration'])*RATE],track)
        cursor=0
        assert len(ch['cues'])==CUES_PER_CHAPTER
        for cue in ch['cues']:
            assert cue['chapter']==ch['id']
            assert abs(mapped_frame(cue['speech_source_start_frame'],mp['replacements'])/FPS-cue['at'])<1e-8,cue['key']
            a=round(cue['at']*RATE);pcm=wav(ROOT/cue['file']);b=a+len(pcm)
            assert a>=cursor and b<=len(track)
            assert not np.any(track[cursor:a])
            assert np.array_equal(track[a:b],pcm),cue['key']
            assert abs(len(pcm)/RATE-cue['speech_duration'])<1/RATE
            assert abs(cue['global_at']-(offset+cue['at']))<1e-7
            r=next(r for r in mp['replacements'] if r['label']==cue['key'])
            next_transition=(r['new_start_frame']+r['new_frame_count'])/FPS
            assert cue['at']+cue['speech_duration']<=next_transition-.3,(cue['key'],next_transition)
            cursor=b;all_cues.append(cue)
        assert not np.any(track[cursor:])
        fade=interval_frames(clip,ch['duration']*FPS-72,ch['duration']*FPS)
        energy=fade.mean(axis=(1,2,3))
        assert energy[-1]/max(energy[0],.001)<.08,(ch['id'],energy[0],energy[-1])
        assert float(np.diff(energy).max())<.12,(ch['id'],float(np.diff(energy).max()))
        corner=interval_frames(movie,offset*FPS+180,offset*FPS+181,160,90)[0,:2,:2]
        assert int(corner.max())<=1,(ch['id'],corner.max())
        chapters.append({'id':ch['id'],'frames':ch['duration']*FPS,'static_holds':holds,
            'source_non_hold_frames_partition_preserved':True,'fades_to_black':True,'black_corner':True})
        offset+=ch['duration'];print(f"Verified chapter {ch['id']:02d}:{CUES_PER_CHAPTER}cues,{len(holds)}static holds",flush=True)
    assert len(all_cues)==CUE_COUNT and offset==plan['duration']
    decoded=subprocess.check_output(['ffmpeg','-v','error','-i',str(movie),'-map','0:a:0','-f','s16le','-ac','1','-ar',str(RATE),'pipe:1'])
    actual=np.frombuffer(decoded,dtype='<i2')
    assert len(master)<=len(actual)<=len(master)+1024,(len(master),len(actual))
    actual=actual[:len(master)]
    # AAC is lossy. Exact PCM placement above is complemented by correlation
    # against actual delivered speech, so a stale/different mux fails.
    audio_checks=[]
    for cue in all_cues:
        a=round(cue['global_at']*RATE);b=a+round(cue['speech_duration']*RATE)
        expected=master[a:b].astype(float);heard=actual[a:b].astype(float)
        corr=float(np.dot(expected,heard)/max(1.,np.linalg.norm(expected)*np.linalg.norm(heard)))
        assert corr>.975,(cue['key'],corr)
        audio_checks.append({'key':cue['key'],'aac_pcm_correlation':round(corr,6)})
    decode_log=out/'decode_check.log'
    if not args.skip_decode:
        print('Decoding entire video and audio...',flush=True)
        with decode_log.open('w') as log:
            result=subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(movie),'-map','0:v:0','-map','0:a:0','-f','null','-'],stderr=log)
        assert result.returncode==0 and decode_log.stat().st_size==0,decode_log
    summary={'title':plan['title'],'duration_seconds':plan['duration'],'resolution':[1920,1080],
        'fps':FPS,'frames':plan['duration']*FPS,'audio_streams':1,'audio_format':'AAC mono48k',
        'provided_recording':True,'synthetic_speech_used':False,'speech_speed_changed':False,
        'cues':CUE_COUNT,'chapters':chapters,'source_chapter_hashes':source_hashes,'acoustic_boundaries':boundaries,
        'original_source_chapter_hashes':original_hashes,
        'visual_corrections':corrections,
        'static_tolerance_exceptions':read(ROOT/'static_exceptions.json')['exceptions'],
        'exact_parts_from_provided_processed_recording_passed':True,
        'recording_sha256':recording['sha256'],
        'exact_master_pcm_placement_passed':True,'delivered_aac_checks':audio_checks,
        'full_decode_passed':not args.skip_decode,'complete':not args.skip_decode,
        'bytes':movie.stat().st_size,'sha256':digest(movie),
        'limitations':'ASR and acoustic checks do not certify pronunciation. Motion preservation is verified structurally against explicit frame partitions and encoder reports; static source windows are decoded completely.'}
    (out/'quality_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(f"VERIFIED {movie.name}: {plan['duration']}s; {summary['bytes']} bytes; {summary['sha256']}",flush=True)

if __name__=='__main__':main()
