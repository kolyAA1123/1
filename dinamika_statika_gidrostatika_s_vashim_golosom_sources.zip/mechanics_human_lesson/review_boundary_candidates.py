"""Recognize short candidate-cut sides; never edits audio or infers word times."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse, json, wave, hashlib
import numpy as np
ROOT=Path(__file__).resolve().parent
MODEL=ROOT.parent.parent/'asr_models/sherpa-onnx-whisper-small'

def init_worker():
    global AUDIO,RECOGNIZER
    import sherpa_onnx
    with wave.open(str(ROOT/'materials/recording_16k.wav'))as w:
        AUDIO=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
    RECOGNIZER=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(MODEL/'small-encoder.int8.onnx'),decoder=str(MODEL/'small-decoder.int8.onnx'),tokens=str(MODEL/'small-tokens.txt'),language='ru',task='transcribe',num_threads=2,provider='cpu',enable_segment_timestamps=True)

def recognize(item):
    before,after,c,signature,context=item;at=c['time']
    cache=ROOT/'output/boundary_candidate_asr'/f'{before}_{after}_{at:.4f}_{context:.1f}s.json'
    if cache.exists():
        found=json.loads(cache.read_text())
        if found['guide_sha256']==signature:return found
    entry={'before':before,'after':after,'time':at,'pause':c['pause'],'guide_sha256':signature,'context_seconds':context}
    for side,start,end in [('left',max(0,at-context),at),('right',at,min(len(AUDIO)/16000,at+context))]:
        stream=RECOGNIZER.create_stream();stream.accept_waveform(16000,AUDIO[round(start*16000):round(end*16000)]);RECOGNIZER.decode_stream(stream)
        entry[side+'_text']=stream.result.text
    cache.write_text(json.dumps(entry,ensure_ascii=False,indent=2)+'\n')
    return entry

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--before',nargs='*');p.add_argument('--candidates',type=int,default=3);p.add_argument('--jobs',type=int,default=2);p.add_argument('--context',type=float,default=12);args=p.parse_args()
    review=json.loads((ROOT/'output/boundary_review.json').read_text())
    guide=ROOT/'materials/recording_16k.wav'
    with guide.open('rb')as f:signature=hashlib.file_digest(f,'sha256').hexdigest()
    chosen=[b for b in review if (b['before']in args.before if args.before else b['needs_review'])]
    (ROOT/'output/boundary_candidate_asr').mkdir(exist_ok=True)
    items=[(b['before'],b['after'],c,signature,args.context)for b in chosen for c in b['candidate_pauses'][:args.candidates]]
    results={}
    with ProcessPoolExecutor(max_workers=args.jobs,initializer=init_worker)as pool:
        for f in as_completed([pool.submit(recognize,item)for item in items]):
            r=f.result();results[(r['before'],r['time'])]=r
            print(r,flush=True)
    output=[{**b,'side_recognition':[results[(b['before'],c['time'])]for c in b['candidate_pauses'][:args.candidates]]}for b in chosen]
    (ROOT/'output/boundary_candidate_recognition.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
