"""Build a measured own-voice edit; preserve motion and speech speed.

The source movie has five complete visual demonstrations per chapter. Narration
starts on a reviewed readable state (or on a fully prepared motion scene).
Only the final static hold of each demonstration is shortened/extended.
"""
from pathlib import Path
import hashlib,json,math,wave
import numpy as np

ROOT=Path(__file__).resolve().parent
FPS=60; RATE=48000

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def loadwav(p,rate):
    with wave.open(str(p)) as w:
        assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,rate)
        return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy()
def savewav(p,a):
    p.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(p),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE);w.writeframes(a.tobytes())
def stamp(t):
    ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
    return f'{h:02d}:{m:02d}:{s:02d}.{ms:03d}'

def main():
    source=read(ROOT.parent/'mechanics_theory_revision/narration_theory.json')
    visual_source=read(ROOT.parent/'mechanics_lesson/narration.json')
    visual_cues={(ch['id'],c['beat']):c for ch in visual_source['chapters'] for c in ch['cues']}
    sync_path=ROOT/'sync_adjustments.json'
    sync=read(sync_path) if sync_path.exists() else {}
    timeline=read(ROOT/'output/source_timeline.json')
    anchors=read(ROOT/'narration_anchors.json')
    if isinstance(anchors,dict):anchors=anchors['cues']
    anchor_map={c['key']:c for c in anchors}
    cuts=read(ROOT/'cuts.json')['cues'];cutmap={c['key']:c for c in cuts}
    assert len(cuts)==len(anchor_map)==110
    audio=loadwav(ROOT/'materials/recording_processed.wav',RATE)
    guide=loadwav(ROOT/'materials/recording_16k.wav',16000)
    parts={};editlog=[];retained_starts={}
    for c in cuts:
        s,e=c['source_start'],c['source_end']
        a=audio[round(s*RATE):round(e*RATE)]
        g=guide[round(s*16000):round(e*16000)]
        hop=160;n=len(g)//hop
        energy=np.sqrt((g[:n*hop].astype(float).reshape(n,hop)**2).mean(axis=1))
        active=np.flatnonzero(energy>32768*10**(-45/20))
        assert len(active),c['key']
        left=max(0,round((active[0]*.01-.18)*RATE))
        right=min(len(a),round(((active[-1]+1)*.01+.25)*RATE))
        pcm=a[left:right].copy()
        ramp=min(240,len(pcm)//2)
        pcm[:ramp]=(pcm[:ramp]*np.linspace(0,1,ramp)).astype('<i2')
        pcm[-ramp:]=(pcm[-ramp:]*np.linspace(1,0,ramp)).astype('<i2')
        path=ROOT/'output/audio/parts'/f"{c['key']}.wav";savewav(path,pcm)
        parts[c['key']]=pcm
        retained_starts[c['key']]=s+left/RATE
        editlog.append({'key':c['key'],'source_start':s,'source_end':e,
                        'retained_source_start':s+left/RATE,'retained_source_end':s+right/RATE,
                        'samples':len(pcm),'sha256':digest(path),
                        'edit':'Only quiet edge handles trimmed;5ms edge fade; no speed/pitch change.'})
    plan={'title':'Динамика, статика и гидростатика — с вашим голосом',
          'duration':0,'fps':FPS,'voice':{'type':'provided_recording','synthetic_speech_used':False,
            'processing':'Mono48k;65Hz highpass;level normalization;quiet-edge trim;no speed/pitch changes'},'chapters':[]}
    mapping={'fps':FPS,'chapters':[]};narrative={'title':plan['title'],'chapters':[]};master=[];offset=0
    text=[plan['title'].upper(),'Сценарий с фактическими временами реплик в озвученной версии.',
          'Это исходный сценарий, а не дословная расшифровка записи. Авторские переформулировки сохранены в аудио.','']
    for old,t in zip(source['chapters'],timeline['chapters']):
        assert old['id']==t['id']
        replacements=[];delta=0;cues=[]
        for cue in old['cues']:
            key=f"{old['id']:02d}_{cue['beat']:02d}";anchor=anchor_map[key]
            start=int(anchor['speech_source_start_frame'])
            a,b=int(anchor['hold_start_frame']),int(anchor['hold_end_frame'])
            assert 0<=start<=a<b<=t['source_frames'],(key,start,a,b)
            speech=parts[key];speech_frames=math.ceil(len(speech)/RATE*FPS)
            # Explicit reviewed static pauses can be added within a cue. Their
            # source intervals must precede its terminal hold. No motion is cut.
            adjustment=sync.get(key,{})
            extras=list(adjustment.get('holds',[]))
            cue_source_start=adjustment.get('speech_source_start_frame',start)
            if 'initial_hold_until_recording_time' in adjustment:
                # Keep the prepared physical state while its introductory
                # sentence is spoken, then show the complete original motion.
                pre=start-1;cue_source_start=pre
                count=max(1,round((adjustment['initial_hold_until_recording_time']
                                  -retained_starts[key])*FPS))
                extras.insert(0,{'old_start_frame':pre,'old_end_frame':start,
                                 'new_frame_count':count,'label':'initial_explanation'})
            cue_start_frame=cue_source_start+delta
            assert cue_source_start<=a
            for extra in extras:
                x,y=int(extra['old_start_frame']),int(extra['old_end_frame'])
                before=x+delta-cue_start_frame
                if extra.get('through_speech_end'):
                    count=max(1,speech_frames+24-before)
                elif 'until_recording_time' in extra:
                    count=max(1,round((extra['until_recording_time']-retained_starts[key])*FPS)-before)
                else:count=int(extra['new_frame_count'])
                assert cue_source_start<=x<y<=a and count>=0,(key,extra)
                replacements.append({'old_start_frame':x,'old_end_frame':y,
                    'new_frame_count':count,'new_start_frame':x+delta,
                    'label':key+'_'+extra['label']})
                delta+=count-(y-x)
            available=a+delta-cue_start_frame
            hold_count=max(48,speech_frames-available+24)
            replacements.append({'old_start_frame':a,'old_end_frame':b,
                'new_frame_count':hold_count,'new_start_frame':a+delta,'label':key})
            cue_at=cue_start_frame/FPS
            cues.append({'key':key,'chapter':old['id'],'beat':cue['beat'],'at':cue_at,
                'global_at':offset+cue_at,'speech_duration':len(speech)/RATE,
                'speech_source_start_frame':cue_source_start,
                'global_until':offset+cue_at+len(speech)/RATE,'text':cue['text'],
                'visual':cue['visual'],'completion':visual_cues[(old['id'],cue['beat'])].get('completion','Полный показ процесса завершён.'),
                'anchor_reason':anchor['reason'],'file':f'output/audio/parts/{key}.wav'})
            delta+=hold_count-(b-a)
        raw=t['source_frames']+delta;pad=(-raw)%FPS
        if pad:
            a=t['source_frames']-1
            replacements.append({'old_start_frame':a,'old_end_frame':a+1,
                'new_frame_count':pad+1,'new_start_frame':a+delta,'label':'tail_padding'})
        frames=raw+pad;duration=frames//FPS
        track=np.zeros(duration*RATE,dtype='<i2')
        previous_end=0
        for cue in cues:
            pcm=parts[cue['key']];at=round(cue['at']*RATE)
            assert at>=previous_end and at+len(pcm)<=len(track)
            track[at:at+len(pcm)]=pcm;previous_end=at+len(pcm)
        path=ROOT/'output/audio/chapters'/f"{old['id']:02d}.wav";savewav(path,track);master.append(track)
        ch={k:old[k] for k in ('id','class','title','source','pages')}
        ch.update(start=offset,duration=duration,cues=cues)
        plan['chapters'].append(ch);narrative['chapters'].append(ch)
        mapping['chapters'].append({'id':ch['id'],'class':ch['class'],
            'expected_frames':frames,'replacements':replacements})
        text.extend([f"{ch['id']:02d}. {ch['title']} — {stamp(offset)}",''])
        for cue in cues:text.extend([f"[{stamp(cue['global_at'])}–{stamp(cue['global_until'])}] {cue['text']}",''])
        offset+=duration
    plan['duration']=offset;narrative['total_duration']=offset
    dump(ROOT/'plan.json',plan);dump(ROOT/'narration.json',narrative)
    dump(ROOT/'frame_map.json',mapping);dump(ROOT/'output/edit_decisions.json',editlog)
    savewav(ROOT/'output/audio/narration.wav',np.concatenate(master))
    (ROOT/'tekst_ozvuchki.txt').write_text('\n'.join(text).rstrip()+'\n',encoding='utf-8-sig')
    print(f'Prepared110cues;{offset//60}:{offset%60:02d};{offset*FPS}frames',flush=True)

if __name__=='__main__':main()
