"""Hydrostatics: seven source-bound chapters from the supplied 12-page PDF.

Every physical movement has a finite tracker endpoint. Source limitations and
corrections are documented in materials/hydrostatics_analysis.md.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mechanics_style import *


def fitted_text(text, size=25, color=INK, width=6):
    result = txt(text, size, color)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result


def fitted_eq(tex, size=32, color=INK, width=6):
    result = eq(tex, size, color)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result


def tank(x=0, bottom=-2, top=1.8, width=3, level=1.15, color=CYAN):
    """Open vessel; liquid is behind the walls and any body added later."""
    water = Rectangle(width=width-.08, height=level-bottom,
                      stroke_width=0, fill_color=color, fill_opacity=.24)
    water.move_to([x, (level+bottom)/2, 0])
    walls = VMobject(color=MUTED, stroke_width=2.2).set_points_as_corners([
        [x-width/2, top, 0], [x-width/2, bottom, 0],
        [x+width/2, bottom, 0], [x+width/2, top, 0]])
    surface = Line([x-width/2+.04, level, 0],
                   [x+width/2-.04, level, 0], color=color, stroke_width=1.6)
    return VGroup(water, walls, surface)


def dimension(x, low, high, label, color=MUTED, side=RIGHT, size=25):
    stem = DoubleArrow([x, low, 0], [x, high, 0], buff=0, color=color,
                       stroke_width=1.5, max_tip_length_to_length_ratio=.11)
    ticks = VGroup(*[Line([x-.1, y, 0], [x+.1, y, 0],
                         color=color, stroke_width=1.2) for y in (low, high)])
    text = eq(label, size, color).next_to(stem, side, buff=.13)
    return VGroup(stem, ticks, text)


def block(center, width=1.0, height=1.0, color=LAVENDER):
    return RoundedRectangle(width=width, height=height, corner_radius=.08,
                            stroke_color=color, stroke_width=2,
                            fill_color=color, fill_opacity=.55).move_to(center)


def cylinder(center, width=.95, height=1.25, color=LAVENDER):
    c = np.asarray(center, dtype=float)
    front = Rectangle(width=width, height=height, color=color, stroke_width=1.8,
                      fill_color=color, fill_opacity=.55).move_to(c)
    top = Ellipse(width=width, height=.18, color=color, stroke_width=1.8,
                  fill_color=color, fill_opacity=.72).move_to(c+UP*height/2)
    bottom = Arc(radius=width/2, start_angle=PI, angle=PI, color=color,
                 stroke_width=1.4).stretch_to_fit_height(.09)
    bottom.move_to(c+DOWN*height/2)
    return VGroup(front, bottom, top)


def pressure_forces(center, up_length=.9, down_length=.9, labels=True):
    c = np.asarray(center, dtype=float)
    up = arrow(c, UP*up_length, CYAN)
    down = arrow(c, DOWN*down_length, GOLD)
    result = VGroup(up, down)
    if labels:
        result.add(eq(r'F_{\mathrm{Арх}}', 24, CYAN).move_to(c+RIGHT*.63+UP*up_length*.65),
                   eq('mg', 25, GOLD).move_to(c+RIGHT*.6+DOWN*down_length*.65))
    return result


def dynamic_pressure_forces(x, y_tracker, up_length_fn, down_length):
    """Only arrows are rebuilt per frame; prebuilt TeX labels simply move."""
    geometry = always_redraw(lambda: VGroup(
        arrow([x,y_tracker.get_value(),0],UP*up_length_fn(),CYAN),
        arrow([x,y_tracker.get_value(),0],DOWN*down_length,GOLD)))
    up_label = eq(r'F_{\mathrm{Арх}}',24,CYAN)
    down_label = eq('mg',25,GOLD)
    up_label.add_updater(lambda mob: mob.move_to([x+.63,y_tracker.get_value()+up_length_fn()*.65,0]))
    down_label.add_updater(lambda mob: mob.move_to([x+.6,y_tracker.get_value()-down_length*.65,0]))
    return VGroup(geometry,up_label,down_label)


def u_walls():
    outer = VMobject(color=MUTED, stroke_width=2.3).set_points_as_corners([
        [-3, 2.05, 0], [-3, -1.5, 0], [-2.5, -2.05, 0],
        [2.5, -2.05, 0], [3, -1.5, 0], [3, 2.05, 0]])
    inner = VMobject(color=MUTED, stroke_width=2.3).set_points_as_corners([
        [-2, 2.05, 0], [-2, -1, 0], [2, -1, 0], [2, 2.05, 0]])
    return VGroup(outer, inner)


def u_water(left_level, right_level, color=CYAN):
    return Polygon(
        [-2.96,left_level,0], [-2.04,left_level,0], [-2.04,-1.04,0],
        [2.04,-1.04,0], [2.04,right_level,0], [2.96,right_level,0],
        [2.96,-1.48,0], [2.48,-2.01,0], [-2.48,-2.01,0], [-2.96,-1.48,0],
        stroke_width=0, fill_color=color, fill_opacity=.3)


class PressureTransmission(ChapterScene):
    chapter_id = 16

    def chapter(self):
        self.beat(0, 'Одна нагрузка, разная площадь опоры: обувь и лыжи.')
        snow = VGroup(*[Line([x-1.7,-1.1,0],[x+1.7,-1.1,0],color=MUTED,
                             stroke_width=2) for x in (-3,3)])
        foot = RoundedRectangle(width=.95,height=.3,corner_radius=.08,
                                color=LAVENDER,fill_color=LAVENDER,fill_opacity=.5).move_to([-3,-.92,0])
        ski = RoundedRectangle(width=3.0,height=.14,corner_radius=.06,
                               color=CYAN,fill_color=CYAN,fill_opacity=.5).move_to([3,-1.01,0])
        f1 = arrow([-3,.95,0], DOWN*1.55, GOLD)
        f2 = arrow([3,.95,0], DOWN*1.55, GOLD)
        labels = VGroup(txt('Обычная обувь',25).move_to([-3,1.7,0]),
                        txt('Лыжи',25).move_to([3,1.7,0]),
                        eq('F',31,GOLD).move_to([-2.55,.4,0]),
                        eq('F',31,GOLD).move_to([3.45,.4,0]),
                        txt('меньшая площадь',22,MUTED).move_to([-3,-1.85,0]),
                        txt('большая площадь',22,MUTED).move_to([3,-1.85,0]))
        self.show(snow, foot, ski, f1, f2, labels, run_time=1.2)
        self.play(foot.animate.shift(DOWN*.32), f1.animate.shift(DOWN*.32), run_time=1.8)
        self.show(txt('При той же силе большая площадь уменьшает давление.',25,CYAN).move_to([0,-2.6,0]))

        self.beat(1, 'Давление — скалярная величина; единица СИ — паскаль.')
        self.clear_stage()
        formula = eq(r'p=\frac{F}{S}',70).move_to([-3,.35,0])
        definitions = VGroup(
            eq(r'p\quad\text{— давление, Па}',32),
            eq(r'F\quad\text{— сила давления, Н}',32),
            eq(r'S\quad\text{— площадь, м}^{2}',32)
        ).arrange(DOWN,buff=.55,aligned_edge=LEFT).move_to([2.2,.3,0])
        self.show(formula, definitions, run_time=1.3)
        self.show(txt('Сила, приходящаяся на единицу площади',28,MUTED).move_to([0,-2,0]))

        self.beat(2, 'В показанном опыте кирпич передаёт нагрузку к опоре.')
        self.clear_stage()
        brick = block([-2,-.25,0],2.7,1.5,LAVENDER)
        base = Line([-3.7,-1.08,0],[-.3,-1.08,0],color=MUTED,stroke_width=3)
        press = Rectangle(width=2.7,height=.18,color=MUTED,fill_color=MUTED,
                          fill_opacity=1).move_to([-2,.61,0])
        external = arrow([-2,2.1,0],DOWN*1.3,GOLD)
        inside = VGroup(*[arrow([x,.35,0],DOWN*.85,CYAN) for x in (-2.9,-2,-1.1)])
        support_load = VGroup(*[arrow([x,-1.12,0],DOWN*.82,CYAN) for x in (-2.9,-2,-1.1)])
        self.show(brick,base,press,external,run_time=1.1)
        self.show(inside,run_time=1.0,create=True)
        self.show(support_load,run_time=1.0,create=True)
        self.show(VGroup(txt('Кирпич под прессом',27).move_to([2.8,.8,0]),
                         fitted_text('Нагрузка направлена к опоре',26,MUTED,5.3).move_to([2.8,-.3,0])))

        self.beat(3, 'Подвижные шары перестраиваются и давят на стенки сосуда.')
        self.clear_stage()
        vessel = VMobject(color=MUTED,stroke_width=2).set_points_as_corners([
            [-1.7,1.75,0],[-1.7,-1.9,0],[1.7,-1.9,0],[1.7,1.75,0]])
        balls = VGroup(*[Circle(radius=.34,color=LAVENDER,fill_color=LAVENDER,
                                fill_opacity=.38).move_to([x,y,0])
                         for y in (.6,-.25,-1.1) for x in (-1.05,0,1.05)])
        piston = Rectangle(width=3.3,height=.17,color=INK,fill_color=INK,
                           fill_opacity=.85).move_to([0,1.38,0])
        down = arrow([0,2.4,0],DOWN*.8,GOLD)
        self.show(vessel,balls,piston,down,run_time=1.2)
        targets = [[x,y,0] for y in (.15,-.57,-1.29) for x in (-.77,0,.77)]
        self.play(piston.animate.shift(DOWN*.6),
                  *[ball.animate.move_to(target) for ball,target in zip(balls,targets)],run_time=2.8)
        side = VGroup(arrow([-1.7,-.65,0],LEFT*.9,CYAN),
                      arrow([1.7,-.65,0],RIGHT*.9,CYAN),
                      arrow([0,-1.9,0],DOWN*.65,CYAN))
        self.show(side,run_time=1.1,create=True)

        self.beat(4, 'Жидкости и газы передают приложенное давление во всех направлениях.')
        self.clear_stage()
        vessel = tank(0,-1.7,1.4,3.2,.55)
        piston = Rectangle(width=3.1,height=.15,color=INK,fill_color=INK,
                           fill_opacity=.85).move_to([0,.65,0])
        down = arrow([0,2.05,0],DOWN*1.1,GOLD)
        self.show(vessel,piston,down,run_time=1.0)
        self.play(Indicate(down,color=GOLD,scale_factor=1.12),run_time=1.5)
        forces = VGroup(arrow([-1.6,-.6,0],LEFT*1.15,CYAN),
                        arrow([1.6,-.6,0],RIGHT*1.15,CYAN),
                        *[arrow([x,-1.7,0],DOWN*.72,CYAN) for x in (-.9,0,.9)])
        self.show(forces,run_time=1.1,create=True)
        self.show(txt('Во всех направлениях',29,CYAN).move_to([0,2.4,0]))


class PascalLaw(ChapterScene):
    chapter_id = 17

    def chapter(self):
        self.beat(0, 'Два сосуда с поршнями соединены заполненной жидкостью трубкой.')
        p = ValueTracker(0)
        def piston(x,y):
            return VGroup(Rectangle(width=1.16,height=.14,color=INK,fill_color=INK,
                                    fill_opacity=.9).move_to([x,y,0]),
                          Line([x,y+.08,0],[x,y+.85,0],color=INK,stroke_width=6))
        walls = VGroup(*[VMobject(color=MUTED,stroke_width=2).set_points_as_corners([
            [x-.62,1.8,0],[x-.62,-1.3,0],[x+.62,-1.3,0],[x+.62,1.8,0]]) for x in (-2.2,2.2)])
        channel = CubicBezier([-2.2,-1.3,0],[-2.2,-2.65,0],[2.2,-2.65,0],[2.2,-1.3,0],
                              color=CYAN,stroke_width=25,stroke_opacity=.35)
        fluid = always_redraw(lambda: VGroup(*[
            Rectangle(width=1.16,height=level+1.27,stroke_width=0,
                      fill_color=CYAN,fill_opacity=.25).move_to([x,(level-1.27)/2,0])
            for x,level in [(-2.2,.5-.55*p.get_value()),(2.2,.5+.55*p.get_value())]]))
        pistons = always_redraw(lambda: VGroup(piston(-2.2,.5-.55*p.get_value()),
                                               piston(2.2,.5+.55*p.get_value())))
        self.show(channel,fluid,walls,pistons,run_time=1.3)
        self.show(txt('Соединённые сосуды',26).move_to([0,2.35,0]))

        self.beat(1, 'Первый поршень опускается; второй поднимается и останавливается.')
        loads = always_redraw(lambda: VGroup(
            arrow([-2.2,1.9-.55*p.get_value(),0],DOWN*.9,GOLD),
            arrow([2.2,.72+.55*p.get_value(),0],UP*.75,CYAN)))
        self.show(loads,run_time=.8)
        self.play(p.animate.set_value(1),run_time=4,rate_func=smooth)
        freeze(fluid,pistons,loads)

        self.beat(2, 'Закон Паскаля: давление передаётся без изменения во всех направлениях.')
        self.clear_stage()
        law = VGroup(txt('Давление передаётся без изменения',30,CYAN),
                     txt('в любую точку жидкости или газа',30),
                     txt('во всех направлениях',30)).arrange(DOWN,buff=.24).move_to([0,.85,0])
        directions = VGroup(*[arrow([0,-1.5,0],vector*.85,CYAN) for vector in (UP,DOWN,LEFT,RIGHT)])
        self.show(law,directions,run_time=1.2)

        self.beat(3, 'Шар Паскаля: поршень создаёт давление в жидкости.')
        self.clear_stage()
        ball = Circle(radius=.83,color=MUTED,stroke_width=2,
                      fill_color=CYAN,fill_opacity=.32).move_to([-.9,-.55,0])
        stroke = ValueTracker(0)
        neck = VGroup(Line([-1.25,.2,0],[-1.25,1.95,0],color=MUTED),
                      Line([-.55,.2,0],[-.55,1.95,0],color=MUTED))
        neck_water = always_redraw(lambda: Rectangle(width=.64,height=1.03-.42*stroke.get_value(),
                          stroke_width=0,fill_color=CYAN,fill_opacity=.25)
                          .move_to([-.9,.72-.21*stroke.get_value(),0]))
        piston = VGroup(Rectangle(width=.64,height=.11,color=INK,
                                 fill_color=INK,fill_opacity=.9).move_to([-.9,1.26,0]),
                        Line([-.9,1.3,0],[-.9,2.05,0],color=INK,stroke_width=4),
                        Line([-1.18,2.05,0],[-.62,2.05,0],color=INK,stroke_width=4))
        holes = VGroup(*[Circle(radius=.045,color=INK,fill_color=INK,
                               fill_opacity=1).move_to([x,-.72,0]) for x in (-1.4,-.9,-.4)])
        label = txt('Шар Паскаля',29).move_to([2.55,1.3,0])
        self.show(ball,neck_water,neck,piston,holes,label,run_time=1.3)

        self.beat(4, 'Идеальная схема: одинаковые отверстия, одинаковое давление и скорости струй.')
        jets = VGroup(*[arrow([x,-.72,0],vec,CYAN,2.2) for x,vec in [
            (-1.4,np.array([-.6,-.8,0])),(-.9,DOWN),(-.4,np.array([.6,-.8,0]))]])
        self.play(piston.animate.shift(DOWN*.42),stroke.animate.set_value(1),
                  *[Create(jet) for jet in jets],run_time=2.2)
        freeze(neck_water)
        self.show(eq(r'v_1=v_2=v_3',35,CYAN).move_to([2.6,.2,0]))
        self.show(VGroup(txt('Одинаковые отверстия',21,MUTED),
                         txt('на одной высоте',21,MUTED)).arrange(DOWN,buff=.15).move_to([2.6,-.7,0]))
        self.wait(1)
        self.play(FadeOut(jets),run_time=1.1)


class HydrostaticPressure(ChapterScene):
    chapter_id = 18

    def chapter(self):
        self.beat(0, 'Столб жидкости: высота h, площадь дна S, давление над поверхностью p₀.')
        vessel = tank(-2.7,-1.85,1.95,2.55,1.35)
        height = dimension(-.92,-1.85,1.35,'h',CYAN)
        atmos = VGroup(*[arrow([x,2.2,0],DOWN*.7,MUTED,2) for x in (-3.55,-2.7,-1.85)])
        labels = VGroup(eq('p_0',31,MUTED).move_to([-2.7,2.52,0]),
                        eq('S',34).move_to([-2.7,-2.25,0]))
        self.show(vessel,height,atmos,labels,run_time=1.4)

        self.beat(1, 'Масса столба m=ρSh; его давление равно ρgh.')
        mass = fitted_eq(r'm=\rho_{\mathrm{ж}}Sh',35,width=5.7).move_to([3,1.45,0])
        derivation = fitted_eq(r'p_{\mathrm{жидк}}=\frac{mg}{S}',35,width=5.7).move_to([3,.3,0])
        self.show(mass,derivation,run_time=1.2)
        middle = fitted_eq(r'p_{\mathrm{жидк}}=\frac{\rho_{\mathrm{ж}}Shg}{S}',35,width=5.7).move_to([3,.3,0])
        self.play(TransformMatchingTex(derivation,middle),run_time=1.2)
        result = fitted_eq(r'p_{\mathrm{жидк}}=\rho_{\mathrm{ж}}gh',35,CYAN,5.7).move_to([3,.3,0])
        self.play(TransformMatchingTex(middle,result),run_time=1.2)

        self.beat(2, 'Полное давление на дно складывается из атмосферного и гидростатического.')
        total = fitted_eq(r'p_{\mathrm{дно}}=p_0+\rho_{\mathrm{ж}}gh',35,width=6.1).move_to([3,-.9,0])
        self.show(total,run_time=1.1)
        self.show(VGroup(txt('Гидростатическое давление',24,CYAN),
                         txt('зависит от ρ, g и h',25,MUTED)).arrange(DOWN,buff=.23).move_to([3,-2,0]))

        self.beat(3, 'Опыт Паскаля: высокий столб воды в тонкой трубке раскалывает бочку.')
        self.clear_stage()
        barrel = RoundedRectangle(width=1.8,height=1.6,corner_radius=.2,
                                  color=GOLD,fill_color=GOLD,fill_opacity=.13).move_to([-2,-1.15,0])
        bands = VGroup(*[Line([-2.9,y,0],[-1.1,y,0],color=MUTED,stroke_width=2.5)
                         for y in (-1.65,-.65)])
        pipe = VGroup(Line([-2.1,-.35,0],[-2.1,2.2,0],color=MUTED),
                      Line([-1.9,-.35,0],[-1.9,2.2,0],color=MUTED))
        level = ValueTracker(.05)
        tube_water = always_redraw(lambda: Rectangle(width=.16,height=level.get_value()+.35,
                    stroke_width=0,fill_color=CYAN,fill_opacity=.65).move_to([-2,(level.get_value()-.35)/2,0]))
        glass = VGroup(VMobject(color=INK,stroke_width=2).set_points_as_corners([
            [-.85,2.2,0],[-.7,1.65,0],[-.25,1.65,0],[-.1,2.2,0]]),
            Line([-.78,1.96,0],[-.18,1.96,0],color=CYAN,stroke_width=2))
        label = txt('Один стакан воды',25).move_to([2.1,1.8,0])
        self.show(barrel,bands,pipe,tube_water,glass,label,run_time=1.3)
        self.play(glass.animate.rotate(.5).shift(LEFT*.5),level.animate.set_value(2.03),run_time=3)
        freeze(tube_water)
        pressure = VGroup(arrow([-2.9,-1.1,0],LEFT*.75,CYAN),arrow([-1.1,-1.1,0],RIGHT*.75,CYAN))
        crack = VMobject(color=INK,stroke_width=4).set_points_as_corners([
            [-2.2,-.43,0],[-2.02,-.83,0],[-2.22,-1.03,0],[-1.98,-1.39,0],[-2.14,-1.88,0]])
        self.show(pressure,run_time=.8,create=True)
        self.show(crack,run_time=1.2,create=True)
        self.show(VGroup(txt('Высокий столб воды',27,CYAN),
                         txt('создаёт большое давление',25)).arrange(DOWN,buff=.25).move_to([2.4,.1,0]))

        self.beat(4, 'Столб пресной воды 10 м создаёт примерно 10⁵ Па гидростатического давления.')
        self.clear_stage()
        column = tank(-2.8,-1.9,2.05,1.8,1.8)
        measure = dimension(-1.4,-1.9,1.8,r'h=10\ \text{м}',CYAN,size=28)
        self.show(column,measure,run_time=1.1)
        self.show(VGroup(txt('Пресная вода',27).move_to([-2.8,2.4,0]),
                         fitted_eq(r'p_{\mathrm{гидростат}}\approx10^5\ \text{Па}',39,CYAN,6.2).move_to([2.8,.85,0]),
                         fitted_text('Примерно нормальное атмосферное давление',23,MUTED,6.1).move_to([2.8,-.55,0])),run_time=1.3)


class BuoyancyDerivation(ChapterScene):
    chapter_id = 19

    def chapter(self):
        self.beat(0, 'Давление снизу больше: нижняя грань бруска находится глубже.')
        vessel = tank(-2.7,-2,1.95,3.2,1.5)
        body = block([-2.7,-.3,0],1.6,1.2)
        depth_axis = VGroup(DashedLine([-.62,1.5,0],[-.62,-1.35,0],color=MUTED,dash_length=.08),
                            *[Line([-.74,y,0],[-.5,y,0],color=MUTED) for y in (1.5,.3,-.9)],
                            eq('0',22,MUTED).move_to([-.3,1.5,0]),
                            eq(r'y_{\mathrm{верх}}',23).move_to([.05,.3,0]),
                            eq(r'y_{\mathrm{низ}}',23).move_to([.05,-.9,0]))
        vertical = VGroup(*[arrow([x,.95,0],DOWN*.6,GOLD,2) for x in (-3.2,-2.7,-2.2)],
                          *[arrow([x,-1.8,0],UP*.85,CYAN,2) for x in (-3.2,-2.7,-2.2)])
        sides = VGroup(*[arrow([x,y,0],vec,CYAN,2) for x,vec in [(-4.1,RIGHT*.55),(-1.3,LEFT*.55)]
                        for y in (-.05,-.55)])
        self.show(vessel,body,depth_axis,vertical,sides,run_time=1.3)
        self.show(VGroup(txt('Боковые силы',26).move_to([3.3,.75,0]),
                         txt('компенсируются',26,MUTED).move_to([3.3,.15,0])))
        self.play(sides.animate.set_opacity(.18),run_time=1)

        self.beat(1, 'На каждой грани F=pS; нижнее давление определяется большей глубиной.')
        self.clear_stage(keep=(vessel,body,depth_axis,vertical,sides))
        formulas = VGroup(
            fitted_eq(r'p_{\mathrm{верх}}=p_0+\rho_{\mathrm{ж}}gy_{\mathrm{верх}}',29,width=5.2),
            fitted_eq(r'p_{\mathrm{низ}}=p_0+\rho_{\mathrm{ж}}gy_{\mathrm{низ}}',29,CYAN,5.2),
            fitted_eq(r'F_{\mathrm{верх}}=p_{\mathrm{верх}}S',30,width=5.2),
            fitted_eq(r'F_{\mathrm{низ}}=p_{\mathrm{низ}}S',30,CYAN,5.2)
        ).arrange(DOWN,buff=.36).move_to([3.3,.15,0])
        self.show(formulas,run_time=1.4)

        self.beat(2, 'При вычитании сил одинаковые атмосферные слагаемые сокращаются.')
        self.clear_stage()
        full = fitted_eq(r'F_{\mathrm{низ}}-F_{\mathrm{верх}}='
                         r'\underbrace{p_0S-p_0S}_{0}+'
                         r'\rho_{\mathrm{ж}}gS(y_{\mathrm{низ}}-y_{\mathrm{верх}})',40,width=12.2).move_to([0,.45,0])
        self.show(txt('Разность сил давления',28).move_to([0,2.1,0]),full,run_time=1.2)
        self.wait(.8)
        short = fitted_eq(r'F_{\mathrm{низ}}-F_{\mathrm{верх}}='
                          r'\rho_{\mathrm{ж}}gS(y_{\mathrm{низ}}-y_{\mathrm{верх}})',40,CYAN,11.7).move_to([0,.45,0])
        self.play(TransformMatchingTex(full,short),run_time=1.6)
        self.show(txt('Остаётся вклад разности глубин',27,MUTED).move_to([0,-1.3,0]))

        self.beat(3, 'Разность глубин — высота бруска, а Sh — объём погружённой части.')
        self.clear_stage()
        body = block([-3.4,-.3,0],1.8,1.35)
        top = Polygon([-4.3,.375,0],[-4.0,.65,0],[-2.2,.65,0],[-2.5,.375,0],
                      color=LAVENDER,fill_color=LAVENDER,fill_opacity=.3)
        h = dimension(-1.95,-.975,.375,'h',MUTED)
        s = eq('S',32).move_to([-3.3,1.0,0])
        up = arrow([-3.4,-.3,0],UP*1.8,CYAN)
        flabel = eq(r'F_{\mathrm{Арх}}',30,CYAN).move_to([-2.55,1.5,0])
        formulas = VGroup(fitted_eq(r'y_{\mathrm{низ}}-y_{\mathrm{верх}}=h',33,width=5.5),
                          fitted_eq(r'Sh=V_{\mathrm{погр}}',36,width=5.5),
                          fitted_eq(r'F_{\mathrm{Арх}}=\rho_{\mathrm{ж}}gV_{\mathrm{погр}}',36,CYAN,5.5)
                          ).arrange(DOWN,buff=.58).move_to([2.8,.3,0])
        self.show(body,top,h,s,up,flabel,formulas,run_time=1.4)

        self.beat(4, 'Сила Архимеда равна весу вытесненной жидкости.')
        self.clear_stage()
        vessel = tank(-3,-1.85,1.65,2.9,1.15)
        body = block([-3,-.3,0],1.25,1.0)
        displaced = Rectangle(width=1.25,height=1,stroke_color=CYAN,
                              fill_color=CYAN,fill_opacity=.35).move_to([1.6,.75,0])
        volume_labels = VGroup(eq(r'V_{\mathrm{погр}}',27).move_to([-3,-1.15,0]),
                               eq(r'V_{\mathrm{погр}}',27,CYAN).next_to(displaced,UP,buff=.16))
        transfer = arrow([-1.15,.75,0],RIGHT*1.75,MUTED,2)
        m = fitted_eq(r'm_{\mathrm{выт}}=\rho_{\mathrm{ж}}V_{\mathrm{погр}}',34,width=6.1).move_to([2.25,-.65,0])
        force = fitted_eq(r'F_{\mathrm{Арх}}=m_{\mathrm{выт}}g',38,CYAN,6.1).move_to([2.25,-1.65,0])
        self.show(vessel,body,displaced,volume_labels,transfer,m,force,run_time=1.4)
        self.show(txt('Вытесненная жидкость',26,CYAN).move_to([2.2,2.1,0]))


class FloatConditions(ChapterScene):
    chapter_id = 20

    def chapter(self):
        self.beat(0, 'Свободное погружённое тело: сила тяжести вниз, сила Архимеда вверх.')
        vessel = tank(-2.6,-2.15,1.95,3.1,1.45)
        body = block([-2.6,-.15,0],.9,.9)
        forces = pressure_forces([-2.6,-.15,0],1.15,.9)
        self.show(vessel,body,forces,run_time=1.3)
        self.show(VGroup(txt('Сила Архимеда',28,CYAN),txt('и сила тяжести',28,GOLD))
                  .arrange(DOWN,buff=.5).move_to([2.7,.4,0]))

        self.beat(1, 'Если жидкость плотнее тела, оно всплывает и приходит к равновесию на поверхности.')
        self.clear_stage()
        vessel = tank(-2.7,-2.2,1.9,2.8,1.3)
        y = ValueTracker(-.5)
        body = always_redraw(lambda: block([-2.7,y.get_value(),0],.8,.8))
        forces = dynamic_pressure_forces(-2.7,y,
            lambda: 1.2*np.clip((1.3-(y.get_value()-.4))/.8,0,1),.9)
        inequality = fitted_eq(r'F_{\mathrm{Арх}}>mg',39,CYAN,5.6).move_to([2.7,1.2,0])
        density = fitted_eq(r'\rho_{\mathrm{ж}}>\rho_{\mathrm{т}}',39,width=5.6).move_to([2.7,.1,0])
        self.show(vessel,body,forces,inequality,density,run_time=1.1)
        self.play(y.animate.set_value(1.1),run_time=4,rate_func=smooth)
        freeze(body,forces)
        balance = fitted_eq(r'F_{\mathrm{Арх}}=mg',39,CYAN,5.6).move_to([2.7,1.2,0])
        self.play(TransformMatchingTex(inequality,balance),run_time=1.0)
        self.show(txt('На поверхности — покой',25,MUTED).move_to([2.7,-1.1,0]))

        self.beat(2, 'Если тело плотнее жидкости, оно опускается до дна.')
        self.clear_stage()
        vessel = tank(-2.7,-2.2,1.9,2.8,1.3)
        y = ValueTracker(.15)
        body = always_redraw(lambda: block([-2.7,y.get_value(),0],.8,.8))
        forces = dynamic_pressure_forces(-2.7,y,lambda:.65,1.1)
        density = fitted_eq(r'\rho_{\mathrm{ж}}<\rho_{\mathrm{т}}',39,width=5.6).move_to([2.7,1.2,0])
        inequality = fitted_eq(r'F_{\mathrm{Арх}}<mg',37,GOLD,5.6).move_to([2.7,.1,0])
        self.show(vessel,body,forces,density,inequality,run_time=1.1)
        self.play(y.animate.set_value(-1.5),run_time=3.2,rate_func=smooth)
        freeze(forces)
        self.play(y.animate.set_value(-1.8),FadeOut(forces),FadeOut(inequality),run_time=1.2)
        freeze(body)
        self.show(txt('Тело достигло дна',27,MUTED).move_to([2.7,-.5,0]))

        self.beat(3, 'При равных плотностях неподвижное тело остаётся в толще жидкости.')
        self.clear_stage()
        vessel = tank(-2.7,-2.2,1.9,2.8,1.3)
        body = block([-2.7,-.2,0],.8,.8)
        forces = pressure_forces([-2.7,-.2,0],.9,.9)
        formulas = VGroup(eq(r'\rho_{\mathrm{ж}}=\rho_{\mathrm{т}}',39),
                          eq(r'F_{\mathrm{Арх}}=mg',37,CYAN)).arrange(DOWN,buff=.7).move_to([2.7,.55,0])
        self.show(vessel,body,forces,formulas,run_time=1.2)
        self.show(txt('Не всплывает и не тонет',25,MUTED).move_to([2.7,-1.25,0]))

        self.beat(4, 'Свеча из опыта всплывает в воде и тонет в растительном масле.')
        self.clear_stage()
        vessels = VGroup(tank(-2.8,-2.1,1.75,2.8,1.2,CYAN),
                         tank(2.8,-2.1,1.75,2.8,1.2,GOLD))
        p = ValueTracker(0)
        def candle(x,y):
            return VGroup(RoundedRectangle(width=.85,height=.65,corner_radius=.08,
                                           color=INK,fill_color=INK,fill_opacity=.62).move_to([x,y,0]),
                          Line([x,y+.325,0],[x,y+.44,0],color=INK,stroke_width=2))
        candles = always_redraw(lambda: VGroup(candle(-2.8,-.5+1.55*p.get_value()),
                                               candle(2.8,.1-1.875*p.get_value())))
        labels = VGroup(txt('Вода',28,CYAN).move_to([-2.8,2.2,0]),
                        txt('Растительное масло',27,GOLD).move_to([2.8,2.2,0]),
                        eq(r'\rho_{\mathrm{воды}}>\rho_{\mathrm{воска}}',28).move_to([-2.8,-2.55,0]),
                        eq(r'\rho_{\mathrm{масла}}<\rho_{\mathrm{воска}}',28).move_to([2.8,-2.55,0]))
        self.show(vessels,candles,labels,run_time=1.3)
        self.play(p.animate.set_value(1),run_time=4,rate_func=smooth)
        freeze(candles)


class FloatingVolume(ChapterScene):
    chapter_id = 21

    def chapter(self):
        self.beat(0, 'Сравниваем один и тот же цилиндр в воде, масле и спирте.')
        specimen = cylinder([-3,-.1,0],1.6,1.85)
        title = txt('Один и тот же цилиндр',29).move_to([2,1.5,0])
        condition = fitted_eq(r'\rho_{\mathrm{т}}<\rho_{\mathrm{спирта}}',36,width=6).move_to([2,.35,0])
        liquids = VGroup(txt('вода',27,CYAN),txt('растительное масло',27,GOLD),
                         txt('спирт',27,LAVENDER)).arrange(DOWN,buff=.3).move_to([2,-1.15,0])
        self.show(specimen,title,condition,liquids,run_time=1.3)

        self.beat(1, 'В воде цилиндр плавает с наименьшим погружённым объёмом из трёх опытов.')
        self.clear_stage()
        xs = (-4.2,0,4.2)
        vessels = VGroup(*[tank(x,-1.95,1.55,2.4,.95,color)
                              for x,color in zip(xs,(CYAN,GOLD,LAVENDER))])
        labels = VGroup(*[txt(label,25,color).move_to([x,1.95,0]) for x,label,color in
                            zip(xs,('Вода','Масло','Спирт'),(CYAN,GOLD,LAVENDER))])
        y1 = ValueTracker(.15)
        c1 = always_redraw(lambda: cylinder([-4.2,y1.get_value(),0]))
        self.show(vessels,labels,c1,run_time=1.2)
        self.play(y1.animate.set_value(.75),run_time=2.8,rate_func=smooth)
        freeze(c1)

        self.beat(2, 'В менее плотном масле погружённая часть того же цилиндра больше.')
        y2 = ValueTracker(.05)
        c2 = always_redraw(lambda: cylinder([0,y2.get_value(),0]))
        self.show(c2,run_time=.9)
        self.play(y2.animate.set_value(.55),run_time=2.8,rate_func=smooth)
        freeze(c2)

        self.beat(3, 'В спирте цилиндр погружён ещё глубже, но остаётся плавать на поверхности.')
        y3 = ValueTracker(0)
        c3 = always_redraw(lambda: cylinder([4.2,y3.get_value(),0]))
        self.show(c3,run_time=.9)
        self.play(y3.animate.set_value(.4),run_time=2.8,rate_func=smooth)
        freeze(c3)

        self.beat(4, 'Плотность жидкости уменьшается, погружённый объём растёт, сила Архимеда равна mg.')
        self.show(fitted_eq(r'mg=\rho_{\mathrm{ж}}gV_{\mathrm{погр}}',34,CYAN,7).move_to([0,2.4,0]),run_time=1.1)
        conclusion = VGroup(eq(r'\rho_{\mathrm{ж}}\downarrow\quad V_{\mathrm{погр}}\uparrow',31),
                            eq(r'F_{\mathrm{Арх}}=mg',31,CYAN)).arrange(RIGHT,buff=1.2).move_to([0,-2.5,0])
        self.show(conclusion,run_time=1.1)


class CommunicatingVessels(ChapterScene):
    chapter_id = 22

    def chapter(self):
        self.beat(0, 'В сообщающихся сосудах жидкость может свободно перетекать между коленами.')
        p = ValueTracker(0)
        water = always_redraw(lambda: u_water(1.35-.5*p.get_value(),.35+.5*p.get_value()))
        walls = u_walls()
        flow = arrow([-1.1,-1.52,0],RIGHT*2.2,CYAN,2)
        self.show(water,walls,flow,run_time=1.3)
        self.show(txt('Соединённые открытые колена',28).move_to([0,2.4,0]))

        self.beat(1, 'Для одной жидкости в покое свободные поверхности устанавливаются на одной высоте.')
        self.play(p.animate.set_value(1),FadeOut(flow),run_time=4,rate_func=smooth)
        freeze(water)
        common = DashedLine([-3.5,.85,0],[3.5,.85,0],color=GOLD,dash_length=.1,stroke_width=1.5)
        equality = fitted_eq(r'p_{\mathrm{слева}}=p_{\mathrm{справа}}',32,width=6).move_to([0,-2.55,0])
        self.show(common,equality,run_time=1.1)
        self.show(txt('Общий уровень',26,CYAN).move_to([0,1.35,0]))

        self.beat(2, 'Форма и наклон открытых колен не меняют общий равновесный уровень.')
        self.clear_stage()
        # Four connected branches: tilted, narrow, bulb-shaped and wide.
        level = .8
        main = Rectangle(width=10.5,height=.55,stroke_width=0,
                         fill_color=CYAN,fill_opacity=.28).move_to([0,-1.825,0])
        tilt_fill = Polygon([-5.02,level,0],[-4.22,level,0],[-3.9,-1.55,0],[-4.7,-1.55,0],
                            stroke_width=0,fill_color=CYAN,fill_opacity=.28)
        narrow_fill = Rectangle(width=.5,height=level+1.55,stroke_width=0,
                                fill_color=CYAN,fill_opacity=.28).move_to([-1.85,(level-1.55)/2,0])
        bulb_fill = Polygon([.4,level,0],[.9,level,0],[.9,.4,0],[1.4,0,0],[1.2,-.7,0],
                            [.9,-1.55,0],[.4,-1.55,0],[.1,-.7,0],[-.1,0,0],[.4,.4,0],
                            stroke_width=0,fill_color=CYAN,fill_opacity=.28)
        wide_fill = Rectangle(width=1.5,height=level+1.55,stroke_width=0,
                              fill_color=CYAN,fill_opacity=.28).move_to([4.1,(level-1.55)/2,0])
        edges = [
            [[-5.2,2.1,0],[-4.7,-1.55,0]], [[-4.4,2.1,0],[-3.9,-1.55,0]],
            [[-2.1,2.1,0],[-2.1,-1.55,0]], [[-1.6,2.1,0],[-1.6,-1.55,0]],
            [[.4,2.1,0],[.4,.4,0],[-.1,0,0],[.1,-.7,0],[.4,-1.55,0]],
            [[.9,2.1,0],[.9,.4,0],[1.4,0,0],[1.2,-.7,0],[.9,-1.55,0]],
            [[3.35,2.1,0],[3.35,-1.55,0]], [[4.85,2.1,0],[4.85,-1.55,0]],
            [[-4.7,-1.55,0],[-5.25,-1.55,0],[-5.25,-2.1,0],[5.25,-2.1,0],
             [5.25,-1.55,0],[4.85,-1.55,0]],
            [[-3.9,-1.55,0],[-2.1,-1.55,0]], [[-1.6,-1.55,0],[.4,-1.55,0]],
            [[.9,-1.55,0],[3.35,-1.55,0]]]
        outlines = VGroup(*[VMobject(color=MUTED,stroke_width=2).set_points_as_corners(points)
                             for points in edges])
        line = DashedLine([-5.55,level,0],[5.55,level,0],color=GOLD,dash_length=.1,stroke_width=1.5)
        self.show(main,tilt_fill,narrow_fill,bulb_fill,wide_fill,outlines,line,run_time=1.5)
        self.show(txt('Разная форма — одна высота свободной поверхности',26,CYAN).move_to([0,2.4,0]))

        self.beat(3, 'Масло в левом колене не смешивается с водой; уровни плавно устанавливаются.')
        self.clear_stage()
        q = ValueTracker(0)
        water = always_redraw(lambda: u_water(.55-.6*q.get_value(),.55+.6*q.get_value()))
        def oil_column():
            interface = .55-.6*q.get_value()
            height = max(.001,1.5*q.get_value())
            return Rectangle(width=.92,height=height,stroke_width=0,
                             fill_color=GOLD,fill_opacity=.42*q.get_value()).move_to([-2.5,interface+height/2,0])
        oil = always_redraw(oil_column)
        walls = u_walls()
        pour = arrow([-1.4,2.35,0],np.array([-.9,-.65,0]),GOLD,2)
        label = txt('Растительное масло',27,GOLD).move_to([1.4,2.45,0])
        self.show(water,oil,walls,pour,label,run_time=1.2)
        self.play(q.animate.set_value(1),run_time=4,rate_func=smooth)
        freeze(water,oil)
        self.play(FadeOut(pour),run_time=.7)

        self.beat(4, 'На уровне границы давления равны; столб менее плотного масла выше столба воды.')
        interface = -.05
        reference = DashedLine([-3.85,interface,0],[3.85,interface,0],color=MUTED,
                               dash_length=.09,stroke_width=1.4)
        h2 = dimension(-3.5,interface,1.45,'h_2',GOLD,LEFT,28)
        h1 = dimension(3.5,interface,1.15,'h_1',CYAN,RIGHT,28)
        density = fitted_eq(r'\rho_{\mathrm{масла}}<\rho_{\mathrm{воды}}',30,width=3.5).move_to([0,-.55,0])
        heights = eq(r'h_2>h_1',37,GOLD).move_to([0,.55,0])
        equal = fitted_text('Одинаковое давление на уровне границы',22,MUTED,10).move_to([0,-2.6,0])
        self.show(reference,h2,h1,density,heights,equal,run_time=1.4)
