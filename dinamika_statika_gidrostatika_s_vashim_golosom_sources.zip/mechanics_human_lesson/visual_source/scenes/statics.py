"""Statics, chapters 12–15, from the seven-page supplied PDF only."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mechanics_style import *


def foot_on_line(point, base, direction):
    """Exact Euclidean projection, so the drawn moment arm is perpendicular."""
    point, base, direction = map(lambda p: np.array(p, dtype=float),
                                 (point, base, direction))
    return base + direction * np.dot(point-base, direction) / np.dot(direction, direction)


def right_corner(foot, direction, toward, color=GOLD, size=.12):
    along = np.array(direction, dtype=float)
    along /= np.linalg.norm(along)
    normal = np.array(toward, dtype=float)-foot
    normal /= np.linalg.norm(normal)
    return VMobject(color=color, stroke_width=1.5).set_points_as_corners([
        foot+size*along, foot+size*(along+normal), foot+size*normal])


def fitted_eq(tex, point, size=35, color=INK, width=5.3):
    result = eq(tex, size, color)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result.move_to(point)


def force_arm(origin, start, force, index, color):
    foot = foot_on_line(origin, start, force)
    action = DashedLine(start-force*.42, start+force*1.18,
                        color=MUTED, stroke_width=1.15)
    vector = arrow(start, force, color)
    shoulder = Line(origin, foot, color=color, stroke_width=2.3)
    square = right_corner(foot, force, origin, color, .1)
    # The labels are placed explicitly below where the four forces are combined.
    return VGroup(action, vector, shoulder, square), foot


class RigidLever(ChapterScene):
    chapter_id = 12

    def chapter(self):
        self.beat(0, "Твёрдое тело сохраняет расстояния между своими точками")
        body = RoundedRectangle(width=3.5, height=1.3, corner_radius=.22,
                                color=MUTED, fill_color=GRID, fill_opacity=.24)
        body.move_to([-3.7, .4, 0])
        a = Dot([-4.8, .4, 0], radius=.065, color=CYAN)
        b = Dot([-2.6, .4, 0], radius=.065, color=GOLD)
        segment = Line(a.get_center(), b.get_center(), color=INK, stroke_width=2)
        points = VGroup(eq('A', 25, CYAN).next_to(a, DOWN, buff=.16),
                        eq('B', 25, GOLD).next_to(b, DOWN, buff=.16))
        rigid = VGroup(body, segment, a, b, points)
        intro = VGroup(txt('Статика: условия равновесия', 26),
                       eq('AB=\\mathrm{const}', 39, GOLD),
                       txt('Поступательное и вращательное', 22, MUTED),
                       txt('составляющие перемещения', 22, MUTED)).arrange(DOWN, buff=.42)
        intro.move_to([2.6, .4, 0])
        self.show(rigid, intro, run_time=1.1)
        translation = txt('Поступательное', 23, CYAN).move_to([-3.1, 1.8, 0])
        self.show(translation, run_time=.6)
        self.play(rigid.animate.shift(RIGHT*.9), run_time=2.6, rate_func=smooth)
        rotation = txt('Вращательное', 23, GOLD).move_to([-3.1, 1.8, 0])
        self.play(FadeOut(translation), FadeIn(rotation), run_time=.6)
        self.play(Rotate(rigid, angle=PI/7, about_point=body.get_center()),
                  run_time=2.5, rate_func=smooth)

        self.beat(1, "Продлим линии действия и сложим силы по правилу параллелограмма")
        self.clear_stage(run_time=.9)
        common = np.array([-5.8, 0., 0.])
        u = np.array([2.8, 1.26, 0.])
        v = np.array([2.1, -1.26, 0.])
        fraction = .55
        origin = common+fraction*(u+v)
        outline = Ellipse(width=4.5, height=4.15, color=GRID, stroke_width=1.7).move_to(origin)
        original1 = arrow(common+.45*u, u, CYAN)
        original2 = arrow(common+.45*v, v, GOLD)
        force_labels = VGroup(
            eq(r'\vec F_1', 28, CYAN).move_to(common+1.3*u+UP*.35),
            eq(r'\vec F_2', 28, GOLD).move_to(common+1.28*v+DOWN*.35))
        self.show(outline, run_time=.7)
        self.show(original1, original2, force_labels, run_time=.9)
        action1 = DashedLine(common-u*.03, common+u*1.42, color=CYAN,
                             stroke_width=1.2).set_opacity(.5)
        action2 = DashedLine(common-v*.03, common+v*1.42, color=GOLD,
                             stroke_width=1.2).set_opacity(.5)
        self.show(action1, action2, create=True, run_time=1.1)
        crossing = Dot(common, radius=.045, color=INK)
        self.show(crossing, run_time=.45)
        f1, f2 = arrow(common, u, CYAN), arrow(common, v, GOLD)
        self.play(TransformFromCopy(original1, f1), TransformFromCopy(original2, f2),
                  original1.animate.set_opacity(.2), original2.animate.set_opacity(.2),
                  run_time=1.4)
        parallel = VGroup(DashedLine(common+u, common+u+v, color=MUTED),
                          DashedLine(common+v, common+u+v, color=MUTED))
        self.show(parallel, create=True, run_time=1.2)
        resultant = arrow(common, u+v, ROSE, 4)
        result_label = eq(r'\vec F', 28, ROSE).move_to(common+(u+v)*.82+UP*.24)
        self.show(resultant, create=True, run_time=1.1)
        self.show(result_label, run_time=.5)
        sum_formula = fitted_eq(r'\vec F=\vec F_1+\vec F_2', [3.1, .5, 0], 39)
        self.show(sum_formula, run_time=.9)

        self.beat(2, "Плечи — перпендикулярные расстояния от O до линий сил")
        o = Dot(origin, radius=.055, color=INK)
        o_label = eq('O', 25).move_to(origin+RIGHT*.24+DOWN*.2)
        self.show(o, o_label, run_time=.7)
        foot1 = foot_on_line(origin, common, u)
        foot2 = foot_on_line(origin, common, v)
        arms = VGroup(Line(origin, foot1, color=CYAN, stroke_width=2.4),
                      Line(origin, foot2, color=GOLD, stroke_width=2.4),
                      right_corner(foot1, u, origin, CYAN),
                      right_corner(foot2, v, origin, GOLD))
        b1_end, b2_end = common+fraction*u, common+fraction*v
        auxiliary = VGroup(Line(origin, b1_end, color=LAVENDER, stroke_width=1.6),
                           Line(origin, b2_end, color=LAVENDER, stroke_width=1.6))
        distance_labels = VGroup(
            eq('d_1', 24, CYAN).move_to((origin+foot1)/2+RIGHT*.22),
            eq('d_2', 24, GOLD).move_to((origin+foot2)/2+RIGHT*.23),
            eq('b_1', 24, LAVENDER).move_to((origin+b1_end)/2+UP*.23),
            eq('b_2', 24, LAVENDER).move_to((origin+b2_end)/2+DOWN*.24))
        self.show(arms, create=True, run_time=1.6)
        self.show(auxiliary, create=True, run_time=1.1)
        self.show(distance_labels, run_time=.7)
        line_through_o = txt('Результирующая проходит через O', 23, MUTED).move_to([3.05, -1.0, 0])
        if line_through_o.width > 5.7:
            line_through_o.scale_to_fit_width(5.7)
        self.show(line_through_o, run_time=.8)
        diagram = VGroup(outline, original1, original2, force_labels, action1,
                         action2, crossing, f1, f2, parallel, resultant, result_label,
                         o, o_label, arms, auxiliary, distance_labels)

        self.beat(3, "Подобие параллелограммов и два прямоугольных треугольника")
        self.clear_stage(keep=(diagram,), run_time=.8)
        theta_u, theta_v = np.arctan2(u[1], u[0]), np.arctan2(v[1], v[0])
        angle = theta_u-theta_v
        arcs = VGroup(Arc(radius=.25, start_angle=theta_v, angle=angle, color=LAVENDER).shift(b1_end),
                      Arc(radius=.25, start_angle=theta_v, angle=angle, color=LAVENDER).shift(b2_end))
        alpha_labels = VGroup(eq(r'\alpha', 24, LAVENDER).move_to(b1_end+LEFT*.02+UP*.31),
                             eq(r'\alpha', 24, LAVENDER).move_to(b2_end+RIGHT*.34+DOWN*.1))
        self.show(arcs, create=True, run_time=.9)
        self.show(alpha_labels, run_time=.6)
        similar = fitted_eq(r'\frac{b_1}{b_2}=\frac{F_2}{F_1}', [3.1, 1.15, 0], 43)
        sine = fitted_eq(r'\sin\alpha=\frac{d_1}{b_1}=\frac{d_2}{b_2}', [3.1, -.5, 0], 39)
        self.show(similar, run_time=1.1)
        self.show(sine, run_time=1.2)

        self.beat(4, "Правило рычага: равны произведения сил на их плечи")
        self.clear_stage(keep=(diagram, arcs, alpha_labels), run_time=.8)
        ratio = fitted_eq(r'\frac{F_2}{F_1}=\frac{b_1}{b_2}=\frac{d_1}{d_2}', [3.1, 1.35, 0], 40)
        rule = fitted_eq(r'F_1d_1=F_2d_2', [3.1, -.25, 0], 49, GOLD)
        box = SurroundingRectangle(rule, color=GOLD, buff=.22, stroke_width=1.8)
        name = txt('Правило рычага', 27, GOLD).move_to([3.1, -1.5, 0])
        self.show(ratio, run_time=1.1)
        self.show(rule, run_time=1.2)
        self.show(box, create=True, run_time=.8)
        self.show(name, run_time=.7)


class TorqueEquilibrium(ChapterScene):
    chapter_id = 13

    def chapter(self):
        self.beat(0, "Модуль момента силы равен силе, умноженной на плечо")
        origin = np.array([-3., 0., 0.])
        body = Ellipse(width=3.8, height=3.2, color=GRID).move_to(origin)
        o = Dot(origin, radius=.055)
        o_label = eq('O', 26).move_to(origin+LEFT*.2+DOWN*.25)
        start, force = origin+np.array([1.25, .7, 0.]), np.array([0., -1.8, 0.])
        diagram, foot = force_arm(origin, start, force, 1, CYAN)
        labels = VGroup(eq('F', 30, CYAN).move_to(start+force*.5+RIGHT*.35),
                        eq('d', 30, GOLD).move_to((origin+foot)/2+UP*.25))
        formula = fitted_eq(r'|M|=Fd', [3., .85, 0], 49, GOLD)
        unit = fitted_eq(r'[M]=\mathrm{Н}\cdot\mathrm{м}', [3., -.5, 0], 34, MUTED)
        self.show(body, o, o_label, run_time=.8)
        self.show(diagram[0], diagram[1], create=True, run_time=1.2)
        self.show(diagram[2], diagram[3], create=True, run_time=1.0)
        self.show(labels, formula, unit, run_time=1.0)

        self.beat(1, "Для каждой силы строится собственное перпендикулярное плечо")
        self.clear_stage(run_time=.9)
        origin = np.array([-2.8, .1, 0.])
        outline = Ellipse(width=4.9, height=4., color=GRID, stroke_width=1.7).move_to(origin)
        center = VGroup(Dot(origin, radius=.055),
                        eq('O', 25).move_to(origin+RIGHT*.2+DOWN*.22))
        specs = [([1.5, .6, 0], [0, -1.5, 0], ROSE),
                 ([-.8, .4, 0], [0, -1.3, 0], GOLD),
                 ([-1.05, 1., 0], [.8, .85, 0], ROSE),
                 ([-1.65, .6, 0], [-.5, -1.1, 0], GOLD)]
        self.show(outline, center, run_time=.8)
        drawings, label_sets, products = [], [], []
        force_label_offsets = [RIGHT*.25, LEFT*.25, UP*.23, LEFT*.3+DOWN*.12]
        arm_label_offsets = [UP*.22, DOWN*.22, RIGHT*.12+UP*.24, LEFT*.22+DOWN*.17]
        for index, (relative, vector, color) in enumerate(specs, start=1):
            start = origin+np.array(relative, dtype=float)
            force = np.array(vector, dtype=float)
            drawing, foot = force_arm(origin, start, force, index, color)
            labels = VGroup(
                eq(f'F_{index}', 25, color).move_to(start+force*.85+force_label_offsets[index-1]),
                eq(f'd_{index}', 23, color).move_to((origin+foot)/2+arm_label_offsets[index-1]))
            product = fitted_eq(fr'|M_{index}|=F_{index}d_{index}',
                                [3.25, 1.55-(index-1)*.9, 0], 34, color)
            self.show(drawing, create=True, run_time=.9)
            self.show(labels, product, run_time=.55)
            drawings.append(drawing); label_sets.append(labels); products.append(product)
        four_forces = VGroup(outline, center, *drawings, *label_sets)

        self.beat(2, "Против часовой стрелки — плюс; по часовой — минус")
        self.clear_stage(keep=(four_forces,), run_time=.8)
        counter = Arc(radius=.53, start_angle=-PI/4, angle=3*PI/2,
                      color=GOLD, stroke_width=3).add_tip(tip_length=.14).shift([1.75, 1.1, 0])
        clockwise = Arc(radius=.53, start_angle=PI/4, angle=-3*PI/2,
                        color=ROSE, stroke_width=3).add_tip(tip_length=.14).shift([1.75, -1.1, 0])
        plus = fitted_eq(r'M_2>0,\quad M_4>0', [4.25, 1.1, 0], 34, GOLD, 3.7)
        minus = fitted_eq(r'M_1<0,\quad M_3<0', [4.25, -1.1, 0], 34, ROSE, 3.7)
        self.show(counter, create=True, run_time=1.3)
        self.show(plus, run_time=.7)
        self.show(clockwise, create=True, run_time=1.3)
        self.show(minus, run_time=.7)

        self.beat(3, "Знаковая сумма и равенство модулей — две записи одного правила")
        self.clear_stage(run_time=.9)
        sign_rows = VGroup(
            eq(r'M_1=-F_1d_1', 31, ROSE).move_to([-3.2, 1.65, 0]),
            eq(r'M_3=-F_3d_3', 31, ROSE).move_to([3.2, 1.65, 0]),
            eq(r'M_2=+F_2d_2', 31, GOLD).move_to([-3.2, .85, 0]),
            eq(r'M_4=+F_4d_4', 31, GOLD).move_to([3.2, .85, 0]))
        signed = eq(r'M_1+M_2+M_3+M_4=0', 44).move_to([0, -.35, 0])
        modules = eq(r'|M_2|+|M_4|=|M_1|+|M_3|', 43, GOLD).move_to([0, -1.65, 0])
        self.show(sign_rows, run_time=1.0)
        self.show(signed, run_time=1.1)
        self.show(modules, run_time=1.2)

        self.beat(4, "Для сохранения покоя выполняются оба условия равновесия")
        self.clear_stage(run_time=.9)
        body = RoundedRectangle(width=3.2, height=1.5, corner_radius=.2,
                                color=MUTED, fill_color=GRID, fill_opacity=.24).move_to([-3., .3, 0])
        origin = np.array([-3., .3, 0.])
        forces = VGroup(arrow(origin+LEFT*1.6, LEFT*1.1, CYAN),
                        arrow(origin+RIGHT*1.6, RIGHT*1.1, GOLD))
        action = DashedLine([-5.8, .3, 0], [-.2, .3, 0], color=GRID)
        system = fitted_eq(r'\begin{cases}\sum_i\vec F_i=\vec0\\[8pt]\sum_iM_i=0\end{cases}',
                           [3.1, .3, 0], 46, GOLD)
        label = txt('Тело сохраняет покой', 30).move_to([0, -2., 0])
        self.show(body, action, run_time=.9)
        self.show(forces, create=True, run_time=1.1)
        self.show(system, run_time=1.2)
        self.show(label, run_time=.8)


class CenterMass(ChapterScene):
    chapter_id = 14

    def chapter(self):
        self.beat(0, "Центр масс характеризует распределение масс в системе")
        origin = np.array([-5.3, -1.5, 0.])
        places = [np.array([-4.8, 1.3, 0.]), np.array([-2.1, .9, 0.]),
                  np.array([-3.9, -.7, 0.])]
        colors = [CYAN, GOLD, LAVENDER]
        vectors, masses, labels = VGroup(), VGroup(), VGroup()
        for i, (point, color) in enumerate(zip(places, colors), start=1):
            vectors.add(arrow(origin, point-origin, color, 2))
            masses.add(Dot(point, radius=.09+.015*i, color=color))
            labels.add(eq(f'm_{i}', 28, color).move_to(point+UP*.3))
            labels.add(eq(fr'\vec r_{i}', 24, color).move_to((point+origin)/2+RIGHT*.22))
        base = VGroup(Dot(origin, radius=.04), eq('O', 24).move_to(origin+LEFT*.18+DOWN*.18))
        formula = fitted_eq(r'\vec r_{\mathrm{ц.м.}}=\frac{m_1\vec r_1+m_2\vec r_2+\cdots}{m_1+m_2+\cdots}',
                            [2.8, .65, 0], 37, INK, 6.3)
        definition = txt('Положение взвешено по массам', 23, MUTED).move_to([2.7, -1., 0])
        self.show(base, vectors, create=True, run_time=1.3)
        self.show(masses, labels, run_time=.9)
        self.show(formula, definition, run_time=1.1)

        self.beat(1, "Сила через центр масс не создаёт вращающего действия относительно него")
        self.clear_stage(run_time=.9)
        coordinate = fitted_eq(r'x_{\mathrm{ц.м.}}=\frac{m_1x_1+m_2x_2+\cdots}{m_1+m_2+\cdots}',
                               [0, 2., 0], 39, INK, 10.8)
        center = np.array([-3.8, -.35, 0.])
        body = RoundedRectangle(width=2.6, height=1.2, corner_radius=.18,
                                color=MUTED, fill_color=GRID, fill_opacity=.24).move_to(center)
        marker = Dot(center, radius=.055, color=GOLD)
        label = txt('ц. м.', 22, GOLD).move_to(center+DOWN*.4)
        force = arrow(center, RIGHT*1.3, CYAN)
        force_label = eq(r'\vec F', 29, CYAN).move_to(center+RIGHT*.65+UP*.27)
        moving = VGroup(body, marker, label, force, force_label)
        line = DashedLine([-5.5, -.35, 0], [-.1, -.35, 0], color=GRID)
        explanations = VGroup(txt('Через центр масс', 26, GOLD),
                              txt('Без начального вращения', 23, MUTED)).arrange(DOWN, buff=.55)
        explanations.move_to([3.1, -.35, 0])
        self.show(coordinate, line, run_time=.9)
        self.show(moving, explanations, run_time=.9)
        self.play(moving.animate.shift(RIGHT*1.6), run_time=3.2, rate_func=smooth)

        self.beat(2, "Пример из файла: три шарика на невесомой палочке")
        self.clear_stage(run_time=.9)
        def x_position(x):
            return -4.+.95*x
        rod = Line([x_position(0)-.35, .55, 0], [x_position(8)+.5, .55, 0],
                   color=LAVENDER, stroke_width=2.6)
        axis = arrow(np.array([-4.8, -.8, 0]), np.array([10., 0, 0]), MUTED, 1.5)
        axis_label = eq('x', 28, MUTED).move_to([5.4, -.8, 0])
        tick_group, balls, mass_labels = VGroup(), VGroup(), VGroup()
        for coord, mass, radius, color in [(0, '0{,}5', .10, CYAN),
                                            (3, '2', .15, GOLD),
                                            (8, '1', .12, LAVENDER)]:
            xpos = x_position(coord)
            tick_group.add(Line([xpos, -.9, 0], [xpos, -.7, 0], color=MUTED))
            tick_group.add(DashedLine([xpos, -.7, 0], [xpos, .44, 0], color=GRID))
            tick_group.add(eq(str(coord), 28, MUTED).move_to([xpos, -1.22, 0]))
            balls.add(Dot([xpos, .55, 0], radius=radius, color=color))
            mass_labels.add(eq(fr'{mass}\ \mathrm{{кг}}', 30, color).move_to([xpos, 1.15, 0]))
        title = txt('Невесомая палочка', 25, MUTED).move_to([0, 2.05, 0])
        self.show(axis, rod, create=True, run_time=1.2)
        self.show(axis_label, tick_group, run_time=.8)
        self.show(balls, mass_labels, title, run_time=1.0)
        example = VGroup(rod, axis, axis_label, tick_group, balls, mass_labels)

        self.beat(3, "Подставим массы и координаты, сохраняя каждый член суммы")
        self.play(FadeOut(title), run_time=.5)
        substitution = fitted_eq(r'x_{\mathrm{ц.м.}}=\frac{0{,}5\cdot0+2\cdot3+1\cdot8}{0{,}5+2+1}',
                                 [0, 2.05, 0], 39, INK, 11.6)
        result = eq(r'x_{\mathrm{ц.м.}}=\frac{14}{3{,}5}=4', 44, GOLD).move_to([0, -2.2, 0])
        self.show(substitution, run_time=1.4)
        self.show(result, run_time=1.3)

        self.beat(4, "Вычисленный центр масс находится при x = 4")
        self.clear_stage(keep=(example, result), run_time=.8)
        point = np.array([x_position(4), .55, 0])
        mark = Circle(radius=.13, color=GOLD, stroke_width=3).move_to(point)
        projection = DashedLine(point, [point[0], -.8, 0], color=GOLD, stroke_width=1.4)
        tick = Line([point[0], -.92, 0], [point[0], -.68, 0], color=GOLD, stroke_width=2)
        number = eq('4', 29, GOLD).move_to([point[0], -1.22, 0])
        pointer = arrow(point+np.array([.65, 1.1, 0]), np.array([-.58, -.93, 0]), GOLD, 2)
        label = txt('Центр масс', 28, GOLD).move_to([point[0]+1.2, 2.05, 0])
        self.show(mark, run_time=.8)
        self.show(projection, tick, create=True, run_time=1.0)
        self.show(number, pointer, label, run_time=.9)


def equilibrium_surface(center_x, kind, width=3.3, base=-.85, coefficient=.34):
    sign = {'stable': 1, 'unstable': -1, 'neutral': 0}[kind]
    def contact(parameter, radius=.20):
        slope = 2*sign*coefficient*parameter
        normal = np.array([-slope, 1., 0.])/np.sqrt(1+slope*slope)
        return np.array([center_x+parameter, base+sign*coefficient*parameter**2, 0.])+radius*normal
    curve = ParametricFunction(lambda p: np.array([center_x+p,
                                base+sign*coefficient*p*p, 0.]),
                               t_range=[-width/2, width/2], color=LAVENDER,
                               stroke_width=2.5)
    return curve, contact


def small_equilibrium(center_x, kind, final=False):
    base = -.95 if kind == 'stable' else (-.05 if kind == 'unstable' else -.75)
    curve, contact = equilibrium_surface(center_x, kind, width=3.25, base=base, coefficient=.35)
    parameter = (1.13 if kind == 'unstable' else .8) if final and kind != 'stable' else 0.
    color = {'stable': CYAN, 'unstable': ROSE, 'neutral': GOLD}[kind]
    ball = Circle(radius=.2, color=color, fill_color=color, fill_opacity=.75,
                  stroke_width=1.7).move_to(contact(parameter))
    title = {'stable': 'Устойчивое', 'unstable': 'Неустойчивое', 'neutral': 'Безразличное'}[kind]
    label = txt(title, 24, color).move_to([center_x, 1.65, 0])
    items = [curve, ball, label]
    if final and kind != 'stable':
        ghost = Circle(radius=.2, color=MUTED, stroke_width=1.4).set_opacity(.45).move_to(contact(0))
        items.append(ghost)
    return VGroup(*items)


class Stability(ChapterScene):
    chapter_id = 15

    def chapter(self):
        self.beat(0, "Три вида равновесия различают по результату малого смещения")
        previews = VGroup(small_equilibrium(-4.3, 'stable'),
                          small_equilibrium(0, 'unstable'),
                          small_equilibrium(4.3, 'neutral'))
        self.show(previews, run_time=1.4)

        self.beat(1, "Устойчивое равновесие: после отклонения шарик возвращается")
        self.clear_stage(run_time=.9)
        curve, contact = equilibrium_surface(-2.5, 'stable', width=4.6, base=-1.25, coefficient=.30)
        shift = ValueTracker(0.)
        ball = always_redraw(lambda: Circle(radius=.22, color=CYAN, fill_color=CYAN,
                             fill_opacity=.75, stroke_width=1.7).move_to(contact(shift.get_value(), .22)))
        initial = Circle(radius=.22, color=MUTED, stroke_width=1.5).set_opacity(.5).move_to(contact(0, .22))
        heading = txt('Устойчивое', 31, CYAN).move_to([3.1, 1.25, 0])
        self.show(curve, create=True, run_time=1.1)
        self.show(initial, ball, heading, run_time=.8)
        self.play(shift.animate.set_value(1.25), run_time=2.0, rate_func=smooth)
        self.play(shift.animate.set_value(0.), run_time=3.0, rate_func=smooth)
        returned = txt('Возвращается', 29, CYAN).move_to([3.1, -.15, 0])
        self.show(returned, run_time=.7)

        self.beat(2, "Неустойчивое равновесие: отклонённый шарик удаляется от вершины")
        self.clear_stage(run_time=.9)
        curve, contact = equilibrium_surface(-2.5, 'unstable', width=4.6, base=.7, coefficient=.32)
        shift = ValueTracker(0.)
        ball = always_redraw(lambda: Circle(radius=.22, color=ROSE, fill_color=ROSE,
                             fill_opacity=.75, stroke_width=1.7).move_to(contact(shift.get_value(), .22)))
        initial = Circle(radius=.22, color=MUTED, stroke_width=1.5).set_opacity(.5).move_to(contact(0, .22))
        heading = txt('Неустойчивое', 30, ROSE).move_to([3.1, 1.25, 0])
        self.show(curve, create=True, run_time=1.0)
        self.show(initial, ball, heading, run_time=.8)
        self.play(shift.animate.set_value(.22), run_time=1.0, rate_func=smooth)
        self.play(shift.animate.set_value(1.9), run_time=3.4, rate_func=smooth)
        result = VGroup(txt('Удаляется', 28, ROSE),
                        txt('Не возвращается', 26, MUTED)).arrange(DOWN, buff=.45).move_to([3.1, -.35, 0])
        self.show(result, run_time=.8)

        self.beat(3, "Безразличное равновесие: новое положение также равновесно")
        self.clear_stage(run_time=.9)
        curve, contact = equilibrium_surface(-2.5, 'neutral', width=5.4, base=-.8)
        shift = ValueTracker(-1.2)
        ball = always_redraw(lambda: Circle(radius=.22, color=GOLD, fill_color=GOLD,
                             fill_opacity=.75, stroke_width=1.7).move_to(contact(shift.get_value(), .22)))
        initial = Circle(radius=.22, color=MUTED, stroke_width=1.5).set_opacity(.5).move_to(contact(-1.2, .22))
        heading = txt('Безразличное', 30, GOLD).move_to([3.1, 1.25, 0])
        self.show(curve, create=True, run_time=.9)
        self.show(initial, ball, heading, run_time=.8)
        external = arrow(np.array([-3.7, .2, 0]), np.array([2.4, 0, 0]), GOLD, 2)
        self.show(external, create=True, run_time=.7)
        self.play(shift.animate.set_value(1.2), run_time=3.0, rate_func=smooth)
        self.play(FadeOut(external), run_time=.6)
        result = VGroup(txt('Новое положение —', 26, GOLD),
                        txt('тоже равновесие', 26, GOLD)).arrange(DOWN, buff=.3).move_to([3.1, -.3, 0])
        self.show(result, run_time=.8)

        self.beat(4, "Возврат, удаление или новое равновесное положение")
        self.clear_stage(run_time=.9)
        summaries = VGroup(small_equilibrium(-4.3, 'stable', final=True),
                           small_equilibrium(0, 'unstable', final=True),
                           small_equilibrium(4.3, 'neutral', final=True))
        results = VGroup(txt('Возвращается', 23, CYAN).move_to([-4.3, -2., 0]),
                         txt('Удаляется', 23, ROSE).move_to([0, -2., 0]),
                         txt('Новое равновесие', 23, GOLD).move_to([4.3, -2., 0]))
        self.show(summaries, run_time=1.2)
        self.show(results, run_time=.9)
