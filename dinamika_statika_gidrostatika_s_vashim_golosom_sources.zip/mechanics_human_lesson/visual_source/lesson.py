"""Manim entry points for rendering an individual chapter manually."""
from scenes import dynamics as _dynamics
from scenes import statics as _statics
from scenes import hydrostatics as _hydrostatics

class InertiaFirstLaw(_dynamics.InertiaFirstLaw):
    pass

class NewtonLaws(_dynamics.NewtonLaws):
    pass

class ForceSuperposition(_dynamics.ForceSuperposition):
    pass

class BasicForces(_dynamics.BasicForces):
    pass

class WeightElevator(_dynamics.WeightElevator):
    pass

class FrictionModels(_dynamics.FrictionModels):
    pass

class ElasticGravity(_dynamics.ElasticGravity):
    pass

class GravityOrbits(_dynamics.GravityOrbits):
    pass

class IdealString(_dynamics.IdealString):
    pass

class FixedPulley(_dynamics.FixedPulley):
    pass

class MovingPulley(_dynamics.MovingPulley):
    pass

class RigidLever(_statics.RigidLever):
    pass

class TorqueEquilibrium(_statics.TorqueEquilibrium):
    pass

class CenterMass(_statics.CenterMass):
    pass

class Stability(_statics.Stability):
    pass

class PressureTransmission(_hydrostatics.PressureTransmission):
    pass

class PascalLaw(_hydrostatics.PascalLaw):
    pass

class HydrostaticPressure(_hydrostatics.HydrostaticPressure):
    pass

class BuoyancyDerivation(_hydrostatics.BuoyancyDerivation):
    pass

class FloatConditions(_hydrostatics.FloatConditions):
    pass

class FloatingVolume(_hydrostatics.FloatingVolume):
    pass

class CommunicatingVessels(_hydrostatics.CommunicatingVessels):
    pass
