"""Package only verified deliverables and reusable source; exclude uploaded PDFs."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parent
PREFIX = 'dinamika_statika_gidrostatika'


if __name__ == '__main__':
    quality_path = ROOT / 'output/quality_validation.json'
    quality = json.loads(quality_path.read_text())
    movie = ROOT / 'output' / f'{PREFIX}_1080p60.mp4'
    with movie.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert digest == quality['sha256'] and quality['full_decode_passed']
    assert movie.stat().st_size < 100 * 1024**2, 'GitHub file limit'
    shutil.copyfile(movie, REPOSITORY / movie.name)
    text = (ROOT / 'tekst_ozvuchki.txt').read_text(encoding='utf-8-sig').rstrip('\r\n') + '\n'
    (REPOSITORY / f'{PREFIX}_ozvuchka.txt').write_text(text, encoding='utf-8-sig')
    files = [REPOSITORY / name for name in
             ['install.sh', 'setup_env.sh', 'requirements.lock', 'AGENTS.md']]
    files += [ROOT / name for name in [
        'mechanics_style.py', 'render_mechanics.py', 'verify_delivery.py',
        'package_sources.py', 'lesson.py', 'plan.json', 'manim.cfg', 'narration.json',
        'narration.md', 'tekst_ozvuchki.txt', 'storyboard.md',
        'SOURCE_NOTES.md', 'README.md',
    ]]
    files += sorted((ROOT / 'scenes').glob('*.py'))
    files += sorted((ROOT / 'scenes').glob('*_beats.json'))
    files += sorted((ROOT / 'materials').glob('*_analysis.md'))
    archive = REPOSITORY / f'{PREFIX}_sources.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for path in files:
            target.write(path, path.relative_to(REPOSITORY))
        target.write(quality_path, 'mechanics_lesson/DELIVERY_CHECK.json')
    with zipfile.ZipFile(archive) as target:
        assert target.testzip() is None
        assert len(target.namelist()) == len(files) + 1
        assert not any(name.endswith(('.pdf', '.mp4', '.png', '.jpg'))
                       for name in target.namelist())
    print(f'Packaged {movie.name}, narration, and {len(files) + 1} source files.')
