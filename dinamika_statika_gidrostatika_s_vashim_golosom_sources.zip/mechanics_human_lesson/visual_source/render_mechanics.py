"""Render and verify the user's source-based, silent physics lesson."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'plan.json').read_text())

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-show_chapters','-of','json',str(path)]))

def render_chapter(ch,preview=False,force=False):
    width,height,fps=(854,480,15) if preview else (1920,1080,60)
    dest=ROOT/'output'/('preview_chapters' if preview else 'chapters')
    dest.mkdir(parents=True,exist_ok=True)
    path=dest/f"{ch['id']:02d}_{ch['class']}.mp4"
    log=path.with_suffix('.log')
    sources=[ROOT/'mechanics_style.py',ROOT/'plan.json',ROOT/'scenes'/ch['module']]
    fresh=path.exists() and path.stat().st_mtime>max(p.stat().st_mtime for p in sources)
    if force or not fresh:
        print(f"Rendering {ch['id']:02d} {ch['class']} ({width}x{height}@{fps})",flush=True)
        cache=ROOT/'output'/'render_cache'/f"{ch['id']:02d}"
        cmd=[sys.executable,'-m','manim',str(ROOT/'scenes'/ch['module']),ch['class'],'-r',f'{width},{height}','--fps',str(fps),'--format','mp4','--media_dir',str(cache),'--output_file',str(path),'--verbosity','WARNING','--progress_bar','none']
        with log.open('w') as f:r=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
        if r.returncode:raise RuntimeError(f"Chapter {ch['id']}: exit {r.returncode}\n{log.read_text()[-7000:]}")
    report=probe(path)
    v=next(s for s in report['streams'] if s['codec_type']=='video')
    actual=float(report['format']['duration'])
    n,d=map(int,v['avg_frame_rate'].split('/'))
    if (v['width'],v['height'])!=(width,height) or abs(n/d-fps)>.005 or abs(actual-ch['duration'])>.15:
        raise RuntimeError(f"Bad chapter {ch['id']}: {v['width']}x{v['height']} {n/d}fps {actual}s")
    if any(s['codec_type']=='audio' for s in report['streams']):raise RuntimeError('Audio is forbidden by the user')
    print(f"Verified {ch['id']:02d}: {actual:.3f}s",flush=True)
    return ch['id'],path

def assemble(paths,preview=False):
    out=ROOT/'output'
    concat=out/('preview_concat.txt' if preview else 'concat.txt')
    concat.write_text(''.join("file '"+str(p).replace("'","'\\''")+"'\n" for p in paths))
    metadata=out/'chapters.ffmeta'
    lines=[';FFMETADATA1','title=Динамика, статика и гидростатика по трём конспектам','artist=Анимация по материалам пользователя']
    for ch in PLAN['chapters']:
        start=ch['start'];end=start+ch['duration']
        lines.extend(['[CHAPTER]','TIMEBASE=1/1000',f'START={start*1000}',f'END={end*1000}',f"title={ch['title']}"])
    metadata.write_text('\n'.join(lines)+'\n')
    path=out/('dinamika_statika_gidrostatika_preview.mp4' if preview else 'dinamika_statika_gidrostatika_1080p60.mp4')
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(metadata),'-map','0:v:0','-map_metadata','1','-map_chapters','1','-c:v','copy','-an','-movflags','+faststart',str(path)],check=True)
    report=probe(path)
    v=next(s for s in report['streams'] if s['codec_type']=='video')
    assert not any(s['codec_type']=='audio' for s in report['streams'])
    assert abs(float(report['format']['duration'])-PLAN['duration'])<(.2 if preview else .05)
    assert len(report['chapters'])==len(PLAN['chapters'])
    if not preview:
        assert (v['width'],v['height'],v['avg_frame_rate'])==(1920,1080,'60/1')
        assert int(v['nb_frames'])==PLAN['duration']*60
    (out/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(f"COMPLETE {path} ({path.stat().st_size/1024**2:.1f}MiB)",flush=True)
    return path

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--preview',action='store_true')
    parser.add_argument('--force',action='store_true')
    parser.add_argument('--jobs',type=int,default=3)
    parser.add_argument('--chapters',nargs='*',type=int)
    parser.add_argument('--no-assemble',action='store_true')
    args=parser.parse_args()
    chapters=[c for c in PLAN['chapters'] if not args.chapters or c['id'] in args.chapters]
    results={}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for f in as_completed([pool.submit(render_chapter,c,args.preview,args.force) for c in chapters]):
            n,path=f.result();results[n]=path
    if len(results)==len(PLAN['chapters']) and not args.no_assemble:
        assemble([results[c['id']] for c in PLAN['chapters']],args.preview)
