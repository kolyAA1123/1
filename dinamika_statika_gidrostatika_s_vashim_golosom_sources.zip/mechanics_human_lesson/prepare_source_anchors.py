"""Apply reviewed conservative speech anchors to exact original frame intervals."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
out=ROOT/'output'
timeline=json.loads((out/'source_timeline.json').read_text())
choices=[]
for name in ['anchor_choices_dynamics.json','anchor_choices_statics_hydro.json']:
    choices+=json.loads((out/name).read_text())
indexed={(c['chapter'],c['beat']):c for c in choices}
assert len(indexed)==len(choices)==110
cues=[]
for ch in timeline['chapters']:
    for b in ch['beats']:
        choice=indexed[(ch['id'],b['index']+1)]
        hold_start=b['terminal_hold_start_frame'];hold_end=b['terminal_hold_end_frame']
        anchor=hold_start;selected_event=None
        if choice['mode']=='before_motion':
            events=[e for e in ch['events'] if b['source_start_frame']<=e['source_start_frame']<b['end_frame'] and e['source_code_line']==choice['source_code_line'] and e['kind']=='play']
            if not events:raise ValueError(f'No reviewed event {ch["id"]}:{b["index"]+1}:line{choice["source_code_line"]}')
            # Helper play lines can recur in one beat (e.g. two path sections).
            selected_event=events[0]['index'];anchor=events[0]['source_start_frame']
        assert b['source_start_frame']<=anchor<=hold_start<hold_end<=b['end_frame']
        cues.append({'key':f"{ch['id']:02d}_{b['index']+1:02d}",'chapter':ch['id'],'beat':b['index']+1,
                     'speech_source_start_frame':anchor,'hold_start_frame':hold_start,'hold_end_frame':hold_end,
                     'fixed_frames_after_speech_start':hold_start-anchor,'mode':choice['mode'],
                     'motion_event_index':selected_event,'source_code_line':choice.get('source_code_line'),
                     'reason':choice['reason'],
                     'review_notes':{k:v for k,v in choice.items() if k not in ('chapter','beat','mode','source_code_line','reason')}})
result={'fps':60,'method':'Reviewed core visible state before demonstration motion; otherwise final readable state; expanded theory reviewed against source actions. Original actions stay in order at native60fps. Terminal waits may change duration.',
        'cues':cues}
(out/'narration_anchors.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(ROOT/'narration_anchors.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(f'{len(cues)}reviewed anchors; {sum(c["mode"]=="before_motion" for c in cues)}motion, {sum(c["mode"]=="final_readable" for c in cues)}finalreadable')
