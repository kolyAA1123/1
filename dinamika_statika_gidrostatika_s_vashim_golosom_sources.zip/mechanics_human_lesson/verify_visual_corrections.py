"""Validate isolated label-only source corrections and preserve original assets."""
from pathlib import Path
import hashlib,json,difflib
from audit_source_timeline import mp4_frames,probe

ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'mechanics_lesson';NEW=ROOT/'visual_source'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def partials(ch,root):
    cls=ch['class'];module=ch['module'][:-3]
    p=root/f"output/render_cache/{ch['id']:02d}/videos/{module}/1080p60/partial_movie_files/{cls}/partial_movie_file_list.txt"
    paths=[Path(s[6:-1].removeprefix('file:')) for s in p.read_text().splitlines() if s.startswith("file '")]
    return [mp4_frames(p) for p in paths]

def main():
    before=read(ROOT/'output/visual_source_before.json');plan=read(OLD/'plan.json')
    originals=[]
    for item in before['original_chapters']:
        p=OLD/'output/chapters'/item['name'];actual=sha(p)
        assert actual==item['sha256'],p
        originals.append({'id':int(item['name'][:2]),'name':item['name'],
            'before_sha256':item['sha256'],'after_sha256':actual,'unchanged':True})
    for item in before['original_files']:
        assert sha(OLD/item['relative'])==item['sha256'],item['relative']
    diff=list(difflib.unified_diff((OLD/'scenes/dynamics.py').read_text().splitlines(),
                                  (NEW/'scenes/dynamics.py').read_text().splitlines(),n=2))
    changed=[s for s in diff if s.startswith(('+','-')) and not s.startswith(('+++','---'))]
    assert len(changed)==4,changed
    assert 'GOLD,UP*.35,24)' in changed[0] and 'GOLD,DOWN*.65,24)' in changed[1]
    assert '[2.6,-.6,0]' in changed[2] and '[2.6,-1.2,0]' in changed[3]
    corrections=[]
    for ch in plan['chapters']:
        name=f"{ch['id']:02d}_{ch['class']}.mp4";p=NEW/'output/chapters'/name
        if ch['id'] not in [3,5]:
            assert p.is_symlink() and p.resolve()==OLD/'output/chapters'/name
            continue
        assert p.is_file() and not p.is_symlink(),p
        old_frames=partials(ch,OLD);new_frames=partials(ch,NEW)
        assert old_frames==new_frames,(ch['id'],old_frames,new_frames)
        v=probe(p);assert (int(v['width']),int(v['height']),v['r_frame_rate'])==(1920,1080,'60/1')
        assert int(v['nb_frames'])==mp4_frames(p)==ch['duration']*60==sum(old_frames)
        corrections.append({'id':ch['id'],'class':ch['class'],
            'original_sha256':sha(OLD/'output/chapters'/name),'new_sha256':sha(p),
            'source_frames':int(v['nb_frames']),'same_frame_count':True,
            'partial_frame_counts_unchanged':True,'partial_frame_counts':new_frames,
            'event_timing_unchanged':True,'label_changes':
            'Friction label moved belowleft ofblock to separate from normal-force N.' if ch['id']==3 else
            'Condition text moved below supportline, away from its firstletter.'})
    result={'new_source_root':str(NEW),'original_sources_unchanged':True,
            'original_source_files_checked':len(before['original_files']),
            'original_chapters_before_after':originals,'all22_original_chapters_unchanged':True,
            'only_label_positions_changed':True,'source_diff':diff,'chapters':corrections,
            'corrected_chapter_ids':[3,5]}
    (ROOT/'visual_corrections.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('Verified two label-only corrected sources;22originalclips andallsourcefiles unchanged.')

if __name__=='__main__':main()
