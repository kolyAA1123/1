"""Capture readable states from the delivered MP4, using measured edit points."""
from pathlib import Path
import json,subprocess
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parent
PREFIX='dinamika_statika_gidrostatika_s_vashim_golosom'

def main():
    plan=json.loads((ROOT/'plan.json').read_text())
    mapping=json.loads((ROOT/'frame_map.json').read_text())
    movie=ROOT/'output'/f'{PREFIX}_1080p60.mp4'
    out=ROOT/'output/final_contacts';out.mkdir(exist_ok=True)
    cases=[('03_03','speech'),('03_04','speech'),('05_03','speech'),
           ('07_03','initial_explanation'),('07_03','result'),('10_02','initial_explanation'),
           ('17_05','jets_explanation'),('19_03','full_pressure_formula'),('19_03','result'),
           ('20_02','initial_explanation'),('20_02','result'),
           ('20_03','initial_explanation'),('20_03','result'),('22_05','speech')]
    captured=[]
    for key,phase in cases:
        ident,beat=map(int,key.split('_'));ch=plan['chapters'][ident-1]
        cue=next(c for c in ch['cues'] if c['key']==key)
        if phase=='speech':local=cue['at']+cue['speech_duration']/2
        else:
            label=key if phase=='result' else key+'_'+phase
            hold=next(r for r in mapping['chapters'][ident-1]['replacements'] if r['label']==label)
            local=(hold['new_start_frame']+hold['new_frame_count']/2)/60
        at=ch['start']+local;dest=out/f'{key}_{phase}.png'
        subprocess.run(['ffmpeg','-v','error','-threads','1','-ss',str(at),'-i',str(movie),
                        '-frames:v','1','-threads','1','-y',str(dest)],check=True)
        captured.append({'key':key,'phase':phase,'time':at,'file':dest.name,
                         'speech_active':cue['at']<=local<=cue['at']+cue['speech_duration']})
    for sheet_i,start in enumerate(range(0,len(captured),6),1):
        items=captured[start:start+6];sheet=Image.new('RGB',(1920,776),'#151515');draw=ImageDraw.Draw(sheet)
        for i,c in enumerate(items):
            x=i%3*640;y=i//3*388
            im=Image.open(out/c['file']);im.thumbnail((640,360));sheet.paste(im,(x,y))
            draw.text((x+8,y+364),f"{c['key']} / {c['phase']} / final {c['time']:.2f}s",fill='white')
        sheet.save(out/f'sheet_{sheet_i:02d}.jpg',quality=95)
    (out/'manifest.json').write_text(json.dumps(captured,ensure_ascii=False,indent=2)+'\n')
    print(f'Captured {len(captured)} delivered frames',flush=True)

if __name__=='__main__':main()
