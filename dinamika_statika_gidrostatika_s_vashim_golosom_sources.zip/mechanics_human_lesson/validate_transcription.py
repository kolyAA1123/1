"""Validate complete ASR cache provenance and report broad timestamp limits."""
from pathlib import Path
import hashlib,json,wave
ROOT=Path(__file__).resolve().parent

def main():
 guide=ROOT/'materials/recording_16k.wav'
 with guide.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 with wave.open(str(guide)) as f:duration=f.getnframes()/f.getframerate()
 plan=json.loads((ROOT/'output/asr_chunks_plan.json').read_text())
 transcript=json.loads((ROOT/'output/transcription.json').read_text())
 assert len(plan)==len(transcript),(len(plan),len(transcript))
 warnings=[];empty=[];segment_count=0
 for item,ref in zip(transcript,plan):
  assert item['index']==ref['index']
  assert item['recording_sha256']==digest==ref['recording_sha256']
  assert item['start']==ref['start'] and item['end']==ref['end']
  assert 0<=item['start']<item['end']<=duration+0.001
  if not item['text'].strip():empty.append(item['index'])
  for j,s in enumerate(item.get('segments',[])):
   segment_count+=1
   if not (item['start']<=s['start']<s['end']<=item['end']):
    warnings.append({'chunk':item['index'],'segment':j,'bounds':[s['start'],s['end']],'chunk_bounds':[item['start'],item['end']]})
 coverage=[]
 for a,b in zip(plan,plan[1:]):
  gap=b['start']-a['end']
  if abs(gap)>0.001:coverage.append({'left_chunk':a['index'],'right_chunk':b['index'],'gap_seconds':round(gap,4)})
 report={'complete':True,'chunks':len(plan),'native_segments':segment_count,'guide_sha256':digest,'guide_duration_seconds':duration,'empty_chunks':empty,'segment_bounds_needing_clipping_or_fallback':warnings,'adjacent_chunk_gaps_or_overlaps':coverage,'timing_precision':'ASR segment/chunk bounds only. This report does not establish word timing, pronunciation correctness or correspondence to script.'}
 (ROOT/'output/asr_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k not in ('segment_bounds_needing_clipping_or_fallback','adjacent_chunk_gaps_or_overlaps')},ensure_ascii=False))
 print('segment warnings',len(warnings),'adjacent gaps/overlaps',len(coverage))
if __name__=='__main__':main()
