"""Optional local ASR clause probe; does not change any audio or cut."""
from pathlib import Path
import json, wave
import numpy as np
ROOT=Path(__file__).resolve().parent

def main():
 import sherpa_onnx
 model=ROOT.parent.parent/'asr_models/sherpa-onnx-whisper-small'
 rec=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(model/'small-encoder.int8.onnx'),decoder=str(model/'small-decoder.int8.onnx'),tokens=str(model/'small-tokens.txt'),language='ru',task='transcribe',num_threads=2,provider='cpu',enable_segment_timestamps=True)
 with wave.open(str(ROOT/'materials/recording_16k.wav'))as w:a=np.frombuffer(w.readframes(w.getnframes()),'<i2').astype(np.float32)/32768
 out=[]
 for start,end in [(1929.46,1939.205),(1939.205,1949.7),(1937.635,1942.0),(1941.955,1949.7)]:
  s=rec.create_stream();s.accept_waveform(16000,a[round(start*16000):round(end*16000)]);rec.decode_stream(s)
  r=s.result
  d={'start':start,'end':end,'text':r.text,'segments':[{'start':start+float(t),'end':start+float(t)+float(d),'text':txt}for t,d,txt in zip(r.segment_timestamps,r.segment_durations,r.segment_texts)]}
  print(json.dumps(d,ensure_ascii=False),flush=True);out.append(d)
 (ROOT/'output/motion_phrase_probes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
