"""Eleven completed, source-bound chapters from ДИНАМИКА.pdf."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from mechanics_style import *


_LABEL_TEMPLATES={}

def cached_eq(tex,size=27,color=INK):
    key=(tex,size,color)
    if key not in _LABEL_TEMPLATES:_LABEL_TEMPLATES[key]=eq(tex,size,color)
    return _LABEL_TEMPLATES[key].copy()


def block(center=ORIGIN,label='m',color=CYAN,width=.9,height=.65):
    shape=RoundedRectangle(width=width,height=height,corner_radius=.08,
        stroke_color=color,stroke_width=2,fill_color=color,fill_opacity=.19).move_to(center)
    return VGroup(shape,cached_eq(label,27,color).move_to(center))


def ground(x1=-5.8,x2=5.8,y=-.8):
    main=Line([x1,y,0],[x2,y,0],color=MUTED,stroke_width=2)
    hatch=VGroup(*[Line([x,y,0],[x-.16,y-.14,0],color=GRID,stroke_width=1.2)
        for x in np.arange(x1+.2,x2,.35)])
    return VGroup(main,hatch)


def spring(a,b,color=GOLD,coils=10,amplitude=.11):
    a=np.array(a,dtype=float);b=np.array(b,dtype=float)
    d=b-a;L=np.linalg.norm(d);u=d/max(L,1e-9);n=np.array([-u[1],u[0],0])
    pts=[a,a+.1*d]
    for i in range(2*coils+1):
        f=.12+.76*i/(2*coils)
        pts.append(a+f*d+(-1 if i%2 else 1)*amplitude*n)
    pts.extend([a+.9*d,b])
    return VMobject(color=color,stroke_width=2).set_points_as_corners(pts)


def label_vector(start,vec,label,color=CYAN,offset=UP*.2,size=27):
    arr=arrow(start,vec,color)
    lab=cached_eq(label,size,color).move_to(np.array(start)+np.array(vec)*.55+offset)
    norm=np.linalg.norm(vec)
    if norm<.08:lab.set_opacity(norm/.08)
    return VGroup(arr,lab)


def statement(text,y=1.7,size=29,color=INK):
    m=txt(text,size,color).move_to([0,y,0])
    if m.width>12:m.scale_to_fit_width(12)
    return m


class InertiaFirstLaw(ChapterScene):
    chapter_id=1
    def chapter(self):
        self.beat(0,'Инерция: сохранение покоя или равномерного прямолинейного движения')
        rest=block([-4.6,.0,0]);floor=ground(y=-.325)
        track=Line([-1.5,0,0],[5.3,0,0],color=GRID)
        p=ValueTracker(0)
        moving=always_redraw(lambda:block([-1.3+6*p.get_value(),0,0],label='m',color=GOLD))
        v=always_redraw(lambda:label_vector([-1.3+6*p.get_value(),.65,0],[.9,0,0],r'\vec v',GOLD,UP*.2))
        self.show(floor,rest,track,moving,v)
        self.show(txt('Покой',24,CYAN).move_to([-4.6,1.2,0]),txt('Гладкая поверхность',24,GOLD).move_to([2,1.6,0]))
        self.beat(1,'Наблюдаем конечный интервал; скорость свободного тела сохраняется')
        marks=VGroup(*[Dot([-1.3+1.5*i,-.75,0],radius=.035,color=GOLD) for i in range(5)])
        self.show(marks)
        self.play(p.animate.set_value(1),run_time=5,rate_func=linear)
        self.show(eq(r'\vec v=\mathrm{const}',35,GOLD).move_to([2,-1.7,0]),
                  txt('Конец наблюдаемого интервала',20,MUTED).move_to([2,-2.3,0]))
        self.beat(2,'Свободное тело: внешние воздействия отсутствуют, малы или компенсированы')
        self.clear_stage()
        cards=[]
        for x,title,body in [(-4.1,'Нет существенных сил','Человек вдали\nот заметного притяжения'),
                (0,'Воздействие мало','Столкновение человека\nс пылинкой'),
                (4.1,'Силы компенсированы','Брусок на гладкой\nгоризонтальной плоскости')]:
            box=RoundedRectangle(width=3.75,height=3.1,corner_radius=.12,color=GRID).move_to([x,.1,0])
            heading=txt(title,21,CYAN)
            details=txt(body,21)
            for label in (heading,details):
                if label.width>3.35:label.scale_to_fit_width(3.35)
            cards.append(VGroup(box,heading.move_to([x,.9,0]),details.move_to([x,-.2,0])))
        self.show(*cards,run_time=1.2)
        self.beat(3,'В системе Земли для этих задач используем приближение ИСО')
        self.clear_stage()
        b=block([0,0,0]);floor=ground(y=-.325)
        n=label_vector([0,0,0],[0,1.5,0],r'\vec N',CYAN,RIGHT*.4)
        g=label_vector([0,0,0],[0,-1.5,0],r'm\vec g',ROSE,RIGHT*.5)
        self.show(floor,b,n,g)
        self.show(eq(r'\sum\vec F=\vec 0',38).move_to([3.9,.3,0]),txt('Покой в ИСО',25).move_to([-3.9,.3,0]))
        self.beat(4,'Первый закон Ньютона задаёт существование инерциальных систем отсчёта')
        self.clear_stage()
        self.show(statement('Существуют инерциальные системы отсчёта',1.6,31),
                  eq(r'\sum\vec F=\vec0\quad\Longrightarrow\quad\vec v=\mathrm{const}',43,CYAN).move_to([0,.25,0]),
                  statement('Покой или равномерное прямолинейное движение',-1.15,28),
                  statement('При отсутствии сил или их компенсации',-2,23,MUTED))


class NewtonLaws(ChapterScene):
    chapter_id=2
    def chapter(self):
        self.beat(0,'Второй закон: ускорение сонаправлено равнодействующей сил')
        b=block([-3.1,0,0]);F=label_vector([-3.1,0,0],[1.8,0,0],r'\vec F',CYAN,UP*.28)
        a=label_vector([-3.1,1.3,0],[1.2,0,0],r'\vec a',GOLD,UP*.25)
        form=eq(r'\vec a=\frac{\vec F}{m}',47).move_to([2.3,.4,0])
        self.show(b,F,a,form)
        self.show(txt('В инерциальной системе',24,MUTED).move_to([2.3,-1,0]))
        self.beat(1,'Масса характеризует инертность; F здесь — равнодействующая')
        self.play(Transform(form,eq(r'\vec F=m\vec a',47).move_to(form)),run_time=1.3)
        self.show(statement('Ускорение прямо пропорционально силе',-1.8,25),
                  statement('и обратно пропорционально массе',-2.35,25))
        self.beat(2,'Третий закон относится к взаимодействию двух разных тел')
        self.clear_stage()
        left=Circle(radius=.8,color=CYAN,fill_opacity=.18,fill_color=CYAN).move_to([-1,0,0])
        right=Circle(radius=.8,color=GOLD,fill_opacity=.18,fill_color=GOLD).move_to([1,0,0])
        self.show(left,right,txt('Левый шар',25,CYAN).move_to([-2.5,1.6,0]),txt('Правый шар',25,GOLD).move_to([2.5,1.6,0]))
        self.play(left.animate.shift(RIGHT*.2),right.animate.shift(LEFT*.2),run_time=1.5)
        self.beat(3,'Силы равны по модулю, противоположны и приложены к разным шарам')
        force_left=label_vector([-.8,0,0],[-1.6,0,0],r'\vec F_{21}',CYAN,UP*.35)
        force_right=label_vector([.8,0,0],[1.6,0,0],r'\vec F_{12}',GOLD,UP*.35)
        self.show(force_left,run_time=1.1,create=True)
        self.show(force_right,run_time=1.1,create=True)
        self.show(Line([-3,0,0],[3,0,0],color=GRID,stroke_width=.8))
        self.beat(4,'Эти силы не компенсируют друг друга на одном теле')
        self.show(eq(r'\vec F_{12}=-\vec F_{21}',44).move_to([0,-1.6,0]),
                  statement('Каждая сила действует на свой шар',-2.4,27))


class ForceSuperposition(ChapterScene):
    chapter_id=3
    def chapter(self):
        self.beat(0,'Четыре природы взаимодействий из конспекта')
        rows=[('Гравитационное','Тяжесть и тяготение',CYAN),
              ('Электромагнитное','Опора, натяжение, упругость, трение',GOLD),
              ('Сильное','Удерживает протоны и нейтроны в ядрах',LAVENDER),
              ('Слабое','В частности, связано с бета-распадом',ROSE)]
        for i,(name,desc,col) in enumerate(rows):
            y=2.0-i*1.12
            self.show(txt(name,27,col).move_to([-3.7,y,0]),txt(desc,23).move_to([2.3,y,0]),run_time=.55)
        self.beat(1,'Суперпозиция: равнодействующая равна векторной сумме сил')
        self.clear_stage()
        o=np.array([-4.7,-.55,0]);vectors=[np.array([1.5,1.15,0]),np.array([1.7,-.7,0]),np.array([-.8,.65,0])]
        colors=[CYAN,GOLD,LAVENDER]
        original=VGroup(*[label_vector(o,v,rf'\vec F_{i+1}',c,UP*.22) for i,(v,c) in enumerate(zip(vectors,colors))])
        self.show(Dot(o,color=INK),original)
        head=o.copy()
        for v,c in zip(vectors,colors):
            self.show(arrow(head,v,c),run_time=.7,create=True);head=head+v
        self.show(label_vector(o,head-o,r'\vec F',ROSE,DOWN*.35),run_time=.9,create=True)
        self.show(eq(r'\vec F=\vec F_1+\vec F_2+\vec F_3',34).move_to([2.1,1,0]))
        self.beat(2,'На брусок действуют тяга, трение, тяжесть и реакция опоры')
        self.clear_stage()
        o=np.array([-2.8,.1,0]);b=block(o);floor=ground(-5.7,.4,-.225)
        forces=[label_vector(o,[1.5,.8,0],r'\vec F',CYAN,UP*.2),
                label_vector(o,[-.5,0,0],r'\vec F_{\text{тр}}',GOLD,UP*.35,24),
                label_vector(o,[0,-1.5,0],r'm\vec g',ROSE,RIGHT*.4),
                label_vector(o,[0,.7,0],r'\vec N',LAVENDER,LEFT*.4)]
        self.show(floor,b,*forces)
        self.show(label_vector([-2.8,1.75,0],[1,0,0],r'\vec a',GOLD,UP*.2))
        self.beat(3,'Второй закон записываем для суммы всех сил на этом бруске')
        self.show(eq(r'\vec F_{\text{тр}}+\vec F+m\vec g+\vec N=m\vec a',32).move_to([2.4,.4,0]),
                  txt('Вертикальные составляющие\nскомпенсированы',23,MUTED).move_to([2.4,-1.2,0]))
        self.beat(4,'Принцип Галилея: законы механики одинаковы во всех ИСО')
        self.clear_stage()
        frame=RoundedRectangle(width=4.2,height=2.4,corner_radius=.15,color=CYAN).move_to([-3.3,.1,0])
        carbody=VGroup(frame,block([-3.3,-.5,0]),txt('Автомобиль: v = const',22,CYAN).move_to([-3.3,1.8,0]))
        earth=VGroup(ground(.7,5.4,-.825),block([3,-.5,0]),txt('Система Земли',23).move_to([3,1.8,0]))
        self.show(carbody,earth)
        self.play(carbody.animate.shift(RIGHT*.65),run_time=3,rate_func=linear)
        self.show(statement('Одни и те же законы классической механики',-2,28))


class BasicForces(ChapterScene):
    chapter_id=4
    def chapter(self):
        self.beat(0,'Сила тяжести направлена вертикально вниз')
        b=block([-2.8,.6,0]);g=label_vector([-2.8,.6,0],[0,-1.8,0],r'm\vec g',ROSE,RIGHT*.45)
        self.show(b,g,eq(r'\vec F_{\text{т}}=m\vec g',44).move_to([2.3,.9,0]),
                  txt('m — масса, кг\ng — ускорение, м/с²',26).move_to([2.3,-.6,0]))
        self.beat(1,'Деформация опоры порождает нормальную реакцию')
        self.clear_stage()
        q=ValueTracker(0);base=ground(-5.6,-.8,-1.65)
        top=always_redraw(lambda:Line([-5.1,-.5-.25*q.get_value(),0],[-1.3,-.5-.25*q.get_value(),0],color=INK))
        springs=always_redraw(lambda:VGroup(*[spring([x,-1.65,0],[x,-.5-.25*q.get_value(),0],coils=6,amplitude=.07) for x in [-4.7,-3.95,-3.2,-2.45,-1.7]]))
        body=always_redraw(lambda:block([-3.2,-.175-.25*q.get_value(),0]))
        self.show(base,top,springs,body,txt('Модель опоры:\nмаленькие пружины',26).move_to([2.6,.5,0]))
        self.play(q.animate.set_value(1),run_time=2.5)
        self.show(label_vector([-3.2,-.425,0],[0,1.4,0],r'\vec N',CYAN,RIGHT*.4))
        self.beat(2,'Нормальная реакция всегда перпендикулярна поверхности')
        self.clear_stage()
        for x,angle in [(-4.1,0),(0,PI/6),(4.1,PI/2)]:
            normal=np.array([-np.sin(angle),np.cos(angle),0]);tangent=np.array([np.cos(angle),np.sin(angle),0])
            c=np.array([x,-.2,0]);line=Line(c-1.2*tangent,c+1.2*tangent,color=MUTED,stroke_width=2)
            bc=c+.325*normal
            b=block(bc).rotate(angle,about_point=bc)
            self.show(line,b,label_vector(bc,1.3*normal,r'\vec N',CYAN,normal*.1+tangent*.3),run_time=.8)
        self.beat(3,'Натяжение направлено вдоль нити от тела')
        self.clear_stage()
        ceiling=ground(-1.6,1.6,2.0);rope=Line([0,2,0],[0,.325,0],color=INK)
        b=block([0,0,0]);T=label_vector([0,0,0],[0,1.3,0],r'\vec T',GOLD,RIGHT*.4)
        self.show(ceiling,rope,b,T,txt('Натянутая нить',26,GOLD).move_to([3,.5,0]))
        self.beat(4,'Для каждой силы указываем источник, направление и точку приложения')
        self.clear_stage()
        data=[(-4.1,'Тяжесть',r'm\vec g',[0,-1.25,0],ROSE),(0,'Реакция',r'\vec N',[0,1.25,0],CYAN),(4.1,'Натяжение',r'\vec T',[0,1.25,0],GOLD)]
        for x,title,lab,vec,col in data:
            c=np.array([x,-.1,0]);self.show(block(c),label_vector(c,vec,lab,col,RIGHT*.4),txt(title,27,col).move_to([x,2,0]),run_time=.7)
        self.show(statement('Силы опоры и нити действуют на тело',-2.3,26))


class WeightElevator(ChapterScene):
    chapter_id=5
    def chapter(self):
        self.beat(0,'Вес — сила тела на опору или подвес')
        floor=ground(-5.4,.1,-.5);b=block([-2.7,-.175,0])
        P=label_vector([-2.7,-.5,0],[0,-1.5,0],r'\vec P',GOLD,RIGHT*.4)
        self.show(floor,b,P,txt('На опору',27,GOLD).move_to([2.5,.5,0]),txt('Вес не является силой\nпланеты на тело',25).move_to([2.5,-.7,0]))
        self.beat(1,'Реакция и вес — пара третьего закона, действующая на разные объекты')
        N=label_vector([-2.7,-.175,0],[0,1.5,0],r'\vec N',CYAN,LEFT*.4)
        self.show(N,eq(r'\vec N=-\vec P',42).move_to([2.5,1.5,0]))
        self.beat(2,'Без вертикального ускорения на горизонтальной опоре: N = P = mg')
        self.clear_stage()
        self.show(ground(-4.8,.2,-.5),block([-2.3,-.175,0]),
            label_vector([-2.3,-.175,0],[0,1.35,0],r'\vec N',CYAN,LEFT*.4),
            label_vector([-2.3,-.175,0],[0,-1.35,0],r'm\vec g',ROSE,RIGHT*.4),
            eq(r'N=P=mg',43).move_to([2.6,.5,0]),txt('Нет других вертикальных сил',23,MUTED).move_to([2.6,-.6,0]))
        self.beat(3,'При ускорении лифта вверх вес больше силы тяжести')
        self.clear_stage()
        y=ValueTracker(0)
        cabin=always_redraw(lambda:RoundedRectangle(width=2.8,height=3.3,corner_radius=.08,color=MUTED).move_to([-2.6,.2+y.get_value(),0]))
        floor=always_redraw(lambda:ground(-3.9,-1.3,-.65+y.get_value()))
        b=always_redraw(lambda:block([-2.6,-.325+y.get_value(),0]))
        force=always_redraw(lambda:VGroup(label_vector([-2.6,-.325+y.get_value(),0],[0,1.55,0],r'\vec N',CYAN,LEFT*.4),label_vector([-2.6,-.325+y.get_value(),0],[0,-1,0],r'm\vec g',ROSE,RIGHT*.45)))
        self.show(cabin,floor,b,force,label_vector([-.3,0,0],[0,1.2,0],r'\vec a',GOLD,RIGHT*.4),eq(r'P>mg',43,GOLD).move_to([3,1,0]))
        self.play(y.animate.set_value(.55),run_time=2.5,rate_func=lambda t:t*t)
        self.beat(4,'При ускорении лифта вниз вес меньше силы тяжести')
        self.clear_stage()
        y=ValueTracker(0)
        cabin=always_redraw(lambda:RoundedRectangle(width=2.8,height=3.3,corner_radius=.08,color=MUTED).move_to([-2.6,.7+y.get_value(),0]))
        floor=always_redraw(lambda:ground(-3.9,-1.3,-.15+y.get_value()))
        b=always_redraw(lambda:block([-2.6,.175+y.get_value(),0]))
        force=always_redraw(lambda:VGroup(label_vector([-2.6,.175+y.get_value(),0],[0,.65,0],r'\vec N',CYAN,LEFT*.4),label_vector([-2.6,.175+y.get_value(),0],[0,-1,0],r'm\vec g',ROSE,RIGHT*.45)))
        self.show(cabin,floor,b,force,label_vector([-.3,1.2,0],[0,-1.2,0],r'\vec a',GOLD,RIGHT*.4),eq(r'P<mg',43,GOLD).move_to([3,1,0]))
        self.play(y.animate.set_value(-.55),run_time=2.5,rate_func=lambda t:t*t)
        self.show(txt('Направление ускорения\nопределяет изменение веса',24).move_to([3,-.7,0]))


class FrictionModels(ChapterScene):
    chapter_id=6
    def chapter(self):
        self.beat(0,'Тянем брусок динамометром, постепенно увеличивая силу')
        q=ValueTracker(.12);s=ValueTracker(0)
        floor=ground(-5.9,5.9,-.7)
        b=always_redraw(lambda:block([-3.4+s.get_value(),-.375,0]))
        dyn=always_redraw(lambda:VGroup(Line([-2.95+s.get_value(),-.375,0],[-1.4+s.get_value(),-.375,0],color=INK),
            RoundedRectangle(width=2.6,height=.65,corner_radius=.1,color=MUTED).move_to([-.1+s.get_value(),-.375,0]),
            spring([-1.2+s.get_value(),-.375,0],[.8+.25*q.get_value()+s.get_value(),-.375,0],coils=12)))
        self.show(floor,b,dyn)
        self.show(txt('Динамометр',25).move_to([.2,.6,0]))
        self.beat(1,'До начала движения сила трения покоя уравновешивает тягу')
        forces=always_redraw(lambda:VGroup(label_vector([-3.4+s.get_value(),-.375,0],[1.2*q.get_value(),0,0],r'\vec F',CYAN,UP*.38),
            label_vector([-3.4+s.get_value(),-.375,0],[-1.2*min(q.get_value(),1),0,0],r'\vec F_{\text{тр}}',GOLD,DOWN*.5,25),
            label_vector([-3.4+s.get_value(),-.375,0],[0,1.15,0],r'\vec N',LAVENDER,LEFT*.4),
            label_vector([-3.4+s.get_value(),-.375,0],[0,-1.15,0],r'm\vec g',ROSE,RIGHT*.45)))
        static_law=eq(r'F_{\text{тр.покоя}}=F',35).move_to([0,1.7,0])
        self.show(forces,static_law)
        self.play(q.animate.set_value(1),run_time=3.4)
        self.beat(2,'После начала скольжения трение направлено против относительной скорости')
        self.play(FadeOut(static_law),q.animate.set_value(1.25),run_time=.8)
        self.play(s.animate.set_value(1.0),run_time=3.2,rate_func=lambda t:t*t)
        self.show(eq(r'F_{\text{тр.ск}}=\mu N',37,GOLD).move_to([3,1.65,0]),txt('μ — безразмерный коэффициент',22,MUTED).move_to([2.5,-1.8,0]))
        self.show(txt('Конец наблюдаемого интервала',20,MUTED).move_to([-2,-2.45,0]),run_time=.7)
        self.beat(3,'В реальном опыте может наблюдаться эффект застоя')
        self.clear_stage()
        ax=axes((0,4,1),(0,1.7,.5),width=7.2,height=3.5,center=LEFT*.5+DOWN*.15)
        labels=VGroup(eq('F',29).next_to(ax.x_axis.get_end(),RIGHT),eq(r'F_{\text{тр}}',29).next_to(ax.y_axis.get_end(),UP))
        c1=Line(ax.c2p(0,0),ax.c2p(1.25,1.25),color=CYAN,stroke_width=3)
        c2=Line(ax.c2p(1.25,1.25),ax.c2p(1.25,1),color=CYAN,stroke_width=3)
        c3=Line(ax.c2p(1.25,1),ax.c2p(3.8,1),color=CYAN,stroke_width=3)
        self.show(ax,labels,txt('С эффектом застоя',25,CYAN).move_to([1,2.3,0]))
        self.show(c1,create=True,run_time=1.5);self.show(c2,create=True,run_time=.7);self.show(c3,create=True,run_time=1.5)
        self.show(DashedLine(ax.c2p(0,1),ax.c2p(3.8,1),color=GRID),eq(r'\mu N',28,GOLD).next_to(ax.c2p(0,1),LEFT))
        self.beat(4,'В модели конспекта эффект застоя не учитывается')
        self.clear_stage()
        ax=axes((0,4,1),(0,1.7,.5),width=7.2,height=3.5,center=LEFT*.5+DOWN*.15)
        self.show(ax,eq('F',29).next_to(ax.x_axis.get_end(),RIGHT),eq(r'F_{\text{тр}}',29).next_to(ax.y_axis.get_end(),UP),
                  txt('Модель без эффекта застоя',25,CYAN).move_to([1,2.3,0]))
        curve=VMobject(color=CYAN,stroke_width=3).set_points_as_corners([ax.c2p(0,0),ax.c2p(1,1),ax.c2p(3.8,1)])
        self.show(curve,create=True,run_time=2.5)
        self.show(eq(r'F_{\text{тр.покоя}}\leq\mu N',32,GOLD).move_to([0,-2.55,0]),
                  txt('Покой',22).move_to(ax.c2p(.45,.7)+LEFT*.7),txt('Скольжение',22).move_to(ax.c2p(2.5,1.2)))


class ElasticGravity(ChapterScene):
    chapter_id=7
    def chapter(self):
        self.beat(0,'Сила упругости возникает при упругой деформации')
        q=ValueTracker(0);anchor=np.array([-5.3,0,0]);xeq=-2.7
        wall=Line([-5.3,-.7,0],[-5.3,.7,0],color=MUTED)
        coil=always_redraw(lambda:spring(anchor,[xeq+q.get_value(),0,0],coils=11))
        b=always_redraw(lambda:block([xeq+.45+q.get_value(),0,0]))
        self.show(wall,coil,b,DashedLine([xeq,-1.5,0],[xeq,1.5,0],color=GRID),txt('Равновесие',24).move_to([-2.7,1.9,0]))
        state=eq(r'x=0',32).move_to([2.4,.5,0]);self.show(state)
        self.beat(1,'Минус в законе Гука задаёт направление против смещения')
        f=always_redraw(lambda:label_vector([xeq+.45+q.get_value(),0,0],[-1.2*q.get_value(),0,0],r'\vec F_{\text{упр}}',ROSE,UP*.45,26))
        self.show(f)
        self.play(q.animate.set_value(1.0),Transform(state,eq(r'x>0',32).move_to(state)),run_time=2.5)
        self.show(eq(r'F_{\text{упр},x}=-kx',39).move_to([2.3,1.2,0]),txt('k — жёсткость, Н/м\nx — смещение, м',25).move_to([2.3,-.4,0]))
        self.beat(2,'При сжатии направление возвращающей силы меняется')
        self.play(q.animate.set_value(-.6),Transform(state,eq(r'x<0',32).move_to(state)),run_time=2.2)
        self.show(txt('Упругая область деформаций',24,MUTED).move_to([1.7,-1.9,0]))
        self.play(q.animate.set_value(0),Transform(state,eq(r'x=0',32).move_to(state)),run_time=2.5)
        self.beat(3,'Всемирное тяготение: силы притяжения двух сферических тел')
        self.clear_stage()
        c1=np.array([-3,0,0]);c2=np.array([1.3,0,0])
        sphere1=Circle(radius=.65,color=CYAN,fill_color=CYAN,fill_opacity=.18).move_to(c1)
        sphere2=Circle(radius=.85,color=GOLD,fill_color=GOLD,fill_opacity=.18).move_to(c2)
        self.show(sphere1,sphere2,eq('m_1',30,CYAN).move_to(c1),eq('m_2',30,GOLD).move_to(c2))
        self.show(DoubleArrow(c1+DOWN*1.35,c2+DOWN*1.35,buff=0,color=MUTED),eq('R',30).move_to([-.85,-1.7,0]))
        self.show(eq(r'F=G\frac{m_1m_2}{R^2}',38).move_to([3.9,1.45,0]))
        self.beat(4,'Силы притяжения образуют равную противоположную пару')
        self.show(label_vector(c1,[1.25,0,0],r'\vec F_1',CYAN,UP*.4),label_vector(c2,[-1.25,0,0],r'\vec F_2',GOLD,UP*.4))
        self.show(eq(r'\vec F_1=-\vec F_2',36).move_to([.1,2.2,0]),
                  eq(r'G=6{,}7\cdot10^{-11}\;\text{Н}\cdot\text{м}^2/\text{кг}^2',32).move_to([0,-2.4,0]))


class GravityOrbits(ChapterScene):
    chapter_id=8
    def chapter(self):
        self.beat(0,'Приравниваем тяжесть и силу тяготения у поверхности планеты')
        center=np.array([-3.6,0,0]);R=1.35
        planet=Circle(radius=R,color=CYAN,fill_color=CYAN,fill_opacity=.12).move_to(center)
        body=Dot(center+RIGHT*R,color=GOLD,radius=.07)
        self.show(planet,body,Line(center,center+RIGHT*R,color=MUTED),eq('M',32,CYAN).move_to(center),eq('R',29).move_to(center+RIGHT*.65+DOWN*.3))
        form=eq(r'mg=G\frac{mM}{R^2}',39).move_to([2.4,.8,0]);self.show(form)
        self.play(Transform(form,eq(r'g=G\frac{M}{R^2}',43).move_to(form)),run_time=1.5)
        self.show(txt('Масса падающего тела сократилась',23,MUTED).move_to([2.4,-.65,0]))
        self.beat(1,'На высоте h расстояние до центра равно R + h')
        self.play(body.animate.move_to(center+RIGHT*2.4),run_time=2)
        self.show(Line(center+RIGHT*R,center+RIGHT*2.4,color=GOLD),eq('h',29,GOLD).move_to(center+RIGHT*1.9+UP*.3))
        self.play(Transform(form,eq(r'g(h)=G\frac{M}{(R+h)^2}',40).move_to(form)),run_time=1.5)
        self.beat(2,'Для круговой орбиты притяжение создаёт центростремительное ускорение')
        self.clear_stage()
        c=np.array([-3.3,0,0]);r=1.85;theta=ValueTracker(0)
        planet=Circle(radius=1.55,color=CYAN,fill_color=CYAN,fill_opacity=.11).move_to(c)
        orbit=Circle(radius=r,color=GRID).move_to(c)
        sat=always_redraw(lambda:Dot(c+r*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0]),radius=.075,color=GOLD))
        radial=always_redraw(lambda:arrow(c+r*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0]),-.8*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0]),ROSE))
        tangent=always_redraw(lambda:arrow(c+r*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0]),.75*np.array([-np.sin(theta.get_value()),np.cos(theta.get_value()),0]),GOLD))
        self.show(planet,orbit,sat,radial,tangent,eq(r'ma_{\text{ц}}=G\frac{mM}{R^2}',37).move_to([2.6,1.2,0]),txt('aц — к центру\nv — по касательной',24).move_to([2.6,-.4,0]))
        self.beat(3,'Подставляем aц = v₁²/R и доводим вывод до первой космической скорости')
        self.clear_stage(keep=(planet,orbit,sat,radial,tangent))
        deriv=VGroup(eq(r'\frac{mv_1^2}{R}=G\frac{mM}{R^2}',35),eq(r'v_1=\sqrt{G\frac MR}',39),eq(r'v_1=7{,}9\;\mathrm{км/с}',32,GOLD)).arrange(DOWN,buff=.55).move_to([2.6,.3,0])
        self.show(deriv)
        self.play(theta.animate.set_value(TAU),run_time=6,rate_func=linear)
        self.beat(4,'Вторая космическая позволяет уйти от планеты без дальнейшей тяги')
        self.clear_stage()
        self.show(statement('Первая и вторая космические скорости',2,31),
                  eq(r'v_2=v_1\sqrt2',46,GOLD).move_to([0,.7,0]),
                  eq(r'v_1=7{,}9\;\mathrm{км/с}',34,CYAN).move_to([-3.2,-.7,0]),
                  eq(r'v_2=11{,}2\;\mathrm{км/с}',34,GOLD).move_to([3.2,-.7,0]),
                  statement('Значения для Земли из конспекта',-1.8,24,MUTED))


class IdealString(ChapterScene):
    chapter_id=9
    def chapter(self):
        self.beat(0,'Два бруска связаны невесомой нерастяжимой нитью на гладкой плоскости')
        s=ValueTracker(0)
        pair=always_redraw(lambda:VGroup(block([-3.5+s.get_value(),0,0],label='m_2'),block([-.3+s.get_value(),0,0],label='m_1',color=GOLD),
            Line([-3.05+s.get_value(),0,0],[-.75+s.get_value(),0,0],color=INK)))
        external=always_redraw(lambda:label_vector([-.3+s.get_value(),0,0],[1.65,0,0],r'\vec F',ROSE,UP*.35))
        self.show(ground(-5.5,5.5,-.325),pair,external)
        self.beat(1,'Нить тянет каждый брусок к другому; её длина сохраняется')
        Ts=always_redraw(lambda:VGroup(label_vector([-3.5+s.get_value(),0,0],[.85,0,0],r'\vec T_2',CYAN,DOWN*.5),
            label_vector([-.3+s.get_value(),0,0],[-.85,0,0],r'\vec T_1',GOLD,DOWN*.5)))
        self.show(Ts,label_vector([-3.5,1.4,0],[1.1,0,0],r'\vec a',GOLD,UP*.2))
        self.play(s.animate.set_value(1.3),run_time=3,rate_func=lambda t:t*t)
        self.show(txt('Конец наблюдаемого интервала',21,MUTED).move_to([1.7,-1.7,0]))
        self.beat(2,'Теперь отдельно рассматриваем силы, действующие на саму нить')
        self.clear_stage()
        rope=Line([-2,.2,0],[2,.2,0],color=INK,stroke_width=4)
        self.show(rope,label_vector([-2,.2,0],[-1.2,0,0],r"\vec T'_2",CYAN,UP*.35),label_vector([2,.2,0],[1.2,0,0],r"\vec T'_1",GOLD,UP*.35))
        self.show(eq(r"|T_1|=|T'_1|\qquad |T_2|=|T'_2|",35).move_to([0,1.8,0]),txt('Пары третьего закона',24,MUTED).move_to([0,-1.15,0]))
        self.beat(3,'Второй закон для нити: при нулевой массе силы на концах равны')
        formula=eq(r"T'_1-T'_2=m_0a",39).move_to([0,-2.1,0]);self.show(formula)
        self.show(eq(r'm_0=0',35,ROSE).move_to([4,-.8,0]))
        self.play(Transform(formula,eq(r"T'_1-T'_2=0\quad\Longrightarrow\quad T'_1=T'_2",35).move_to(formula)),run_time=1.6)
        self.beat(4,'По третьему закону получаем одинаковое натяжение вдоль идеальной нити')
        self.clear_stage()
        self.show(block([-3,0,0],label='m_2'),block([3,0,0],label='m_1',color=GOLD),Line([-2.55,0,0],[2.55,0,0],color=INK),
                  label_vector([-3,0,0],[1,0,0],r'\vec T_2',CYAN,UP*.4),label_vector([3,0,0],[-1,0,0],r'\vec T_1',GOLD,UP*.4),
                  eq(r'T_1=T_2',45).move_to([0,1.7,0]),statement('Невесомая нерастяжимая нить',-1.7,28))


def fixed_pulley_picture(d=0,spring_mode=False):
    cx=-2.8;cy=1.45;r=.6
    left_y=-.95-d
    right_y=-.95+(d*.25 if spring_mode else d)
    left=block([cx-r,left_y,0],label='M',width=.68,height=.8)
    right=block([cx+r,right_y,0],label='m',color=GOLD,width=.56,height=.6)
    wheel=Circle(radius=r,color=CYAN,fill_color=CYAN,fill_opacity=.12).move_to([cx,cy,0])
    hub=Dot([cx,cy,0],radius=.055,color=INK)
    support=VGroup(Line([cx,cy,0],[cx,2.55,0],color=MUTED),Line([cx-.8,2.55,0],[cx+.8,2.55,0],color=MUTED))
    top=Arc(radius=r,start_angle=0,angle=PI,color=INK).shift([cx,cy,0])
    L=Line([cx-r,cy,0],[cx-r,left_y+.4,0],color=INK)
    if spring_mode:
        spring_top=-.05+d
        R=Line([cx+r,cy,0],[cx+r,spring_top,0],color=INK)
        extension=spring([cx+r,spring_top,0],[cx+r,right_y+.3,0],coils=8,amplitude=.11)
    else:
        R=Line([cx+r,cy,0],[cx+r,right_y+.3,0],color=INK);extension=VGroup()
    return VGroup(support,wheel,hub,top,L,R,extension,left,right)


class FixedPulley(ChapterScene):
    chapter_id=10
    def chapter(self):
        self.beat(0,'Идеальный неподвижный блок: центр закреплён, трением в оси пренебрегаем')
        d=ValueTracker(0);picture=always_redraw(lambda:fixed_pulley_picture(d.get_value()))
        self.show(picture,txt('Невесомый блок\nБез трения в оси',26).move_to([2.6,1.1,0]))
        self.beat(1,'Неподвижный блок изменяет направление силы, но не даёт выигрыша в ней')
        self.show(eq(r'M>m',37).move_to([2.6,-.2,0]),txt('Выигрыша в силе нет',27,GOLD).move_to([2.6,-1.3,0]))
        self.play(d.animate.set_value(.55),run_time=3,rate_func=lambda t:t*t)
        self.beat(2,'С пружиной в одной ветви ускорения могут отличаться')
        self.clear_stage()
        d=ValueTracker(0);picture=always_redraw(lambda:fixed_pulley_picture(d.get_value(),True))
        self.show(picture,eq(r'|a_1|\ne|a_2|',39,GOLD).move_to([2.7,.6,0]),txt('Пружина меняет длину',26).move_to([2.7,-.7,0]))
        self.play(d.animate.set_value(.6),run_time=3,rate_func=lambda t:t*t)
        self.beat(3,'Нерастяжимая нить связывает противоположные перемещения грузов')
        self.clear_stage()
        d=ValueTracker(0);picture=always_redraw(lambda:fixed_pulley_picture(d.get_value()))
        self.show(picture,txt('Нерастяжимая нить',28,CYAN).move_to([2.7,1.2,0]))
        self.show(label_vector([-4.1,-.65,0],[0,-.7,0],r'\vec a_1',CYAN,LEFT*.3),label_vector([-1.5,-1.15,0],[0,.7,0],r'\vec a_2',GOLD,RIGHT*.35))
        self.play(d.animate.set_value(.7),run_time=3,rate_func=lambda t:t*t)
        self.beat(4,'Модули ускорений одинаковы, направления противоположны')
        self.show(eq(r'|a_1|=|a_2|',43).move_to([2.7,-.1,0]),txt('Один и тот же конечный\nинтервал наблюдения',24,MUTED).move_to([2.7,-1.6,0]))


def moving_pulley_picture(q=0):
    upper=np.array([-3,1.6,0]);ru=.5
    lower=np.array([-1.85,-.05+q,0]);rl=.65
    yl=-.9-2*q;yr=-1.65+q
    supports=VGroup(Line([-3,1.6,0],[-3,2.5,0],color=MUTED),Line([-3.8,2.5,0],[-.8,2.5,0],color=MUTED))
    wheels=VGroup(Circle(radius=ru,color=CYAN,fill_color=CYAN,fill_opacity=.12).move_to(upper),
        Circle(radius=rl,color=GOLD,fill_color=GOLD,fill_opacity=.12).move_to(lower),Dot(upper,color=INK,radius=.045),Dot(lower,color=INK,radius=.045))
    cable=VGroup(Line([-3.5,yl+.325,0],[-3.5,1.6,0],color=INK),
        Arc(radius=ru,start_angle=0,angle=PI,color=INK).shift(upper),
        Line([-2.5,1.6,0],[-2.5,lower[1],0],color=INK),
        Arc(radius=rl,start_angle=PI,angle=PI,color=INK).shift(lower),
        Line([-1.2,lower[1],0],[-1.2,2.5,0],color=INK),
        Line(lower+DOWN*rl,[-1.85,yr+.325,0],color=ROSE))
    weights=VGroup(block([-3.5,yl,0],label='m_1',width=.7),block([-1.85,yr,0],label='m_2',color=GOLD,width=.7))
    return VGroup(supports,wheels,cable,weights)


class MovingPulley(ChapterScene):
    chapter_id=11
    def chapter(self):
        self.beat(0,'Подвижный блок перемещается вместе с подвешенным грузом')
        picture=moving_pulley_picture()
        self.show(picture,txt('Две идеальные нити\nДва идеальных блока',25).move_to([2.8,1.5,0]),
                  txt('Длинная нить: две ветви\nподдерживают нижний блок',23).move_to([2.8,-.15,0]))
        self.beat(1,'На каждой невесомой нити натяжение одинаково по всей длине')
        self.show(label_vector([-3.5,-.9,0],[0,.75,0],r'T_1',CYAN,LEFT*.35,25),
            label_vector([-2.5,-.05,0],[0,.75,0],r'T_2',CYAN,LEFT*.35,25),
            label_vector([-1.2,-.05,0],[0,.75,0],r'T_3',CYAN,RIGHT*.35,25),
            eq(r'T_4',25,ROSE).move_to([-2.18,-.8,0]),
            eq(r'T_5',25,ROSE).move_to([-1.5,-1.25,0]),
            eq(r'T_1=T_2=T_3=T',33,CYAN).move_to([2.8,-1.25,0]),
            eq(r'T_4=T_5=T_{45}',33,ROSE).move_to([2.8,-2.05,0]))
        self.beat(2,'Для невесомого нижнего блока две силы T уравновешивают T₄₅')
        self.clear_stage()
        c=np.array([-3,.4,0]);circle=Circle(radius=.65,color=GOLD).move_to(c)
        self.show(circle,label_vector(c+LEFT*.65,[0,1.0,0],'T',CYAN,LEFT*.3),
            label_vector(c+RIGHT*.65,[0,1.0,0],'T',CYAN,RIGHT*.3),
            label_vector(c,[0,-2.0,0],'T_{45}',ROSE,RIGHT*.5))
        deriv=VGroup(eq(r'T+T-T_{45}=0',37),eq(r'2T=T_{45}',39),eq(r'T=\frac{T_{45}}2',43,GOLD)).arrange(DOWN,buff=.5).move_to([2.4,.45,0])
        self.show(deriv,run_time=1.5)
        self.show(txt('T меньше T₄₅ вдвое',26,GOLD).move_to([2.4,-2.0,0]))
        self.beat(3,'За выигрыш в силе платим увеличенным перемещением конца нити')
        self.clear_stage()
        q=ValueTracker(0);picture=always_redraw(lambda:moving_pulley_picture(q.get_value()))
        self.show(picture,eq(r'x_1=2x_2',43).move_to([2.7,1.1,0]),
                  txt('Обе поддерживающие ветви\nукорачиваются на x₂',25).move_to([2.7,-.2,0]))
        self.show(DashedLine([-4.25,-.9,0],[-3.0,-.9,0],color=GRID),DashedLine([-2.25,-1.65,0],[-1.1,-1.65,0],color=GRID))
        self.play(q.animate.set_value(.55),run_time=4,rate_func=lambda t:t*t)
        self.show(label_vector([-4.3,-.9,0],[0,-1.1,0],'x_1',CYAN,LEFT*.35),
            label_vector([-.55,-1.65,0],[0,.55,0],'x_2',GOLD,RIGHT*.35))
        self.beat(4,'При нулевой начальной скорости получаем связь модулей ускорений')
        self.clear_stage()
        self.show(eq(r'x_0=0,\qquad v_0=0',32,MUTED).move_to([0,2.1,0]))
        self.show(eq(r'x_1=2x_2\quad\Longrightarrow\quad\frac{|a_1|t^2}{2}=2\frac{|a_2|t^2}{2}',37).move_to([0,.8,0]))
        self.show(eq(r'|a_1|=2|a_2|',44,GOLD).move_to([0,-.4,0]))
        self.show(statement('Выигрыш в силе — проигрыш в перемещении',-1.5,27),statement('Выигрыша в работе нет',-2.25,27,CYAN))
