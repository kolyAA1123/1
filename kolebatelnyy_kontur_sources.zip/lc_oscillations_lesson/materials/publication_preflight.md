# Publication preflight: LC circuit and energy transmission

Status: passed; no open publication-preflight findings. This is a read-only
metadata/source-packaging review. It does not substitute for final rendering,
visual review, full decode or post-push HTTP verification.

## Content and timing consistency

- plan.json: 9 contiguous chapters, 29 beats, 1641 seconds (27:21),
  1920×1080 delivery target at 60fps, silent.
- narration.json: 58 passages, 2389 words. All 58 texts exactly match the
  corresponding plan beats, UTF-8 TXT paragraphs and DOCX paragraphs.
- Every passage has matching chapter/beat/phase and start/end time. All
  58 formatted time cues also exactly match TXT and Word. Intro reading
  ends before each action; result reading begins after action completion.
- Document exports contain recording guidance and separate theory/result
  windows; titles and cues are not intended to be spoken.

## Source and scope

Source manifest matches the actual uploaded PDF, 2,816,844 bytes, 8 pages,
SHA256 0e4a8eab8dd628d6b21bbca2357ffdd8a5c087be7ceddb687aed35b1a00c013b.
All eight page rasters and the independent page audit exist. Coverage maps
pages 1–8 to the nine chapters, including the title page and the transmission
and transformer sections. No accidental magnetism/direct-current project
paths, former output prefixes or former film titles occur in the LC project
text/code/config exports inspected.

## Download descriptions and preservation

The new root README section has exactly these four correctly named links:

1. kolebatelnyy_kontur_1080p60.mp4
2. kolebatelnyy_kontur_tekst.docx
3. kolebatelnyy_kontur_tekst.txt
4. kolebatelnyy_kontur_sources.zip

Its duration/counts/silent-black/FullHD60 descriptions match the plan. The
previous committed README remains a verbatim suffix. The previous AGENTS.md
remains a verbatim prefix, with only the new LC workflow appended. Existing
film artifacts were not modified by this preflight review.

## Reproduction and packaging

The project README installs Word dependencies through uv in the existing
virtual environment, then exports Word before package_sources.py. This
works with the uv environment even when it has no pip module. The source
packer targets the LC MP4/TXT/DOCX/ZIP, requires a matching checked movie
hash and successful full decode, and enforces the 100MiB movie limit. It
includes LC code, beat data, plan/narration, source audits/notes, reproduction
files and layout/sync/alignment/quality reports. Source ZIP excludes PDFs,
page images, temporary movies, audio and DOCX; Word is regenerated using
the documented export step. Shared setup_env.sh, install.sh, requirements.lock
and AGENTS.md exist. Historical project instructions inside the shared
AGENTS.md are intentional preservation, not mixed LC output paths.

## Git state checked

Local HEAD and remote main both: d964404ec6e8129e052327b1e2e6848974cc910a.
`git diff --check` passed. Only the intended root README/AGENTS edits are
tracked changes at this point; the new film outputs will be packaged later.

Intended final staging set: AGENTS.md, README.md, and the four root LC
delivery files listed above. Root still must run final validation, package,
commit/push explicitly, and verify all four pinned download URLs.

This reviewer wrote only this report and made no source, plan, narration,
README, Git or rendering mutations.
