"""Generator, transmission losses and transformer: source pages 6–8."""
from lc_style import *


def lc_c_generator_frame(angle, center=(-3.1, .2, 0)):
    """Project a fixed-area spatial rectangle rotated about its vertical axis."""
    u = np.array([np.cos(angle), 0, -np.sin(angle)])
    v = np.array([0, 1, 0])
    def project(p):
        return np.array(center) + np.array([1.6*p[0] + .45*p[1], .55*p[1] + 1.1*p[2], 0])
    corners = [project(.9*(a*u+b*v)) for a, b in [(-1,-1),(1,-1),(1,1),(-1,1)]]
    return Polygon(*corners, color=GOLD, stroke_width=3, fill_opacity=0)


def lc_c_ac_circuit():
    wires = VGroup(*[Line(a,b,color=MUTED,stroke_width=2) for a,b in [
        ((-4.9,.45,0),(-4.9,1.25,0)),((-4.9,1.25,0),(-1.3,1.25,0)),
        ((-1.3,1.25,0),(-1.3,.5,0)),((-1.3,-.5,0),(-1.3,-1.25,0)),
        ((-1.3,-1.25,0),(-4.9,-1.25,0)),((-4.9,-1.25,0),(-4.9,-.45,0))]])
    source = Circle(radius=.45,color=GOLD,stroke_width=2).move_to([-4.9,0,0])
    wave = VMobject(color=GOLD,stroke_width=2).set_points_smoothly(
        [np.array([-4.9+x,.17*np.sin(x*PI/.3),0]) for x in np.linspace(-.3,.3,32)])
    load = Rectangle(width=.35,height=1,color=INK,stroke_width=2).move_to([-1.3,0,0])
    labels = VGroup(words('Генератор',[-4.9,-1.8,0],22,MUTED,width=2),
                    words('Нагрузка',[-1.3,-1.8,0],22,MUTED,width=2),
                    formula('i(t)',[-3.1,1.85,0],29,CYAN,width=1.2))
    return VGroup(wires,source,wave,load,labels)


def lc_c_transformer(center=(-3.1,.1,0)):
    x,y,_ = center
    core = VGroup(Rectangle(width=2.65,height=2.45,color=LAVENDER,stroke_width=2,
                            fill_color=LAVENDER,fill_opacity=.16).move_to(center),
                  Rectangle(width=1.4,height=1.25,color=LAVENDER,stroke_width=1,
                            fill_color=BLACK_BG,fill_opacity=1).move_to(center))
    def winding(cx,turns,color):
        curve=VMobject(color=color,stroke_width=2.5)
        curve.set_points_smoothly([
            np.array([cx+.38*np.cos(a), y+1.0-2.0*a/(TAU*turns)+.09*np.sin(a), 0])
            for a in np.linspace(0,TAU*turns,turns*36+1)])
        return curve
    primary = winding(x-1.0,6,GOLD)
    secondary = winding(x+1.0,3,CYAN)
    leads = VGroup(*[Line(a,b,color=color,stroke_width=2) for a,b,color in [
        ((x-2.4,y+1,0),(x-.62,y+1,0),GOLD),
        ((x-2.4,y-1,0),(x-.62,y-1,0),GOLD),
        ((x+1.38,y+1,0),(x+2.4,y+1,0),CYAN),
        ((x+1.38,y-1,0),(x+2.4,y-1,0),CYAN)]])
    terminals = VGroup(*[Circle(radius=.055,color=c,stroke_width=2,
                                fill_color=BLACK_BG,fill_opacity=1).move_to([xx,yy,0])
                        for xx,c in [(x-2.4,GOLD),(x+2.4,CYAN)] for yy in [y-1,y+1]])
    labels = VGroup(formula('N_1',[x-1,y+1.7,0],30,GOLD,width=.8),
                    formula('N_2',[x+1,y+1.7,0],30,CYAN,width=.8),
                    formula('U_1',[x-2.65,y,0],29,GOLD,width=.8),
                    formula('U_2',[x+2.65,y,0],29,CYAN,width=.8),
                    words('Общий сердечник',[x,y-1.8,0],22,MUTED,width=4.5))
    return VGroup(core,primary,secondary,leads,terminals,labels)


class LCGeneratorAndPower(LCScene):
    chapter_id=7

    def chapter(self):
        self.beat(0)
        frame=lc_c_generator_frame(0)
        field=VGroup(*[arrow([x,-1.3,0],[0,3.1,0],CYAN,2) for x in [-5.1,-3.1,-1.1]])
        field.add(formula('B',[-5.6,2.1,0],27,CYAN,width=.5))
        drive=words('Вода → турбина → вал',[-3.1,-2.2,0],24,MUTED,width=5.5)
        meaning=words(['Рамка вращается в магнитном поле',
                       'Магнитный поток меняется'],[3.1,1.1,0],26,width=5.5)
        law=formula(r'\varepsilon_i=-\Phi^{\prime}(t)',[3.1,-.5,0],43,GOLD)
        self.show(field,frame,drive,meaning,run_time=1.2);self.intro(0)
        self.act(0,UpdateFromAlphaFunc(frame,lambda m,a:m.become(lc_c_generator_frame(TAU*a))),
                 Write(law),rate_func=linear)
        self.show(words(['Один полный поворот завершён','Механическая энергия питает генератор'],[3.1,-1.9,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        circuit=lc_c_ac_circuit()
        ax=axes(x_range=(0,TAU,PI/2),y_range=(-1.2,1.2,.5),width=4.1,height=2.7,center=RIGHT*3.1)
        ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
        tags=VGroup(formula('t',ax.x_axis.get_end()+RIGHT*.28,25,MUTED,width=.4),
                    formula(r'\varepsilon_i',ax.y_axis.get_end()+UP*.25,27,GOLD,width=.8),
                    formula('T',ax.c2p(TAU,0)+DOWN*.35,24,MUTED,width=.5))
        sine=ax.plot(np.sin,x_range=(0,TAU,.035),color=GOLD,stroke_width=3)
        current=arrow([-3.65,1.25,0],[0,0,0],CYAN)
        self.show(circuit,ax,tags,current,words('Один период переменной ЭДС',[3.1,2.2,0],23,MUTED),run_time=1.2);self.intro(1)
        def update_current(m,a):
            value=np.sin(TAU*a)
            start=np.array([-3.1-.65*value,1.25,0])
            m.become(arrow(start,[1.3*value,0,0],CYAN))
        self.act(1,Create(sine),UpdateFromAlphaFunc(current,update_current),rate_func=linear)
        self.show(words(['Ток меняет направление','Внешняя цепь замкнута нагрузкой'],[3.1,-2.05,0],23,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        given=words(['Uист и I — действующие значения',
                     'Pист — средняя активная мощность'],[-3.1,1.15,0],25)
        condition=words(['Упрощённая модель','Активная нагрузка, ток и напряжение синфазны'],[-3.1,-.55,0],23,MUTED)
        law=formula(r'P_{\mathrm{ист}}=I U_{\mathrm{ист}}',[3.1,1.1,0],43)
        current=formula(r'I=\frac{P_{\mathrm{ист}}}{U_{\mathrm{ист}}}',[3.1,-.35,0],45,GOLD)
        self.show(given,condition,law,run_time=1.2);self.intro(2)
        self.act(2,Write(current))
        self.show(words(['При одной и той же мощности','Большее напряжение — меньший ток'],[3.1,-1.95,0],24,MUTED),run_time=1.2);self.result(2)


class LCTransmissionLoss(LCScene):
    chapter_id=8

    def chapter(self):
        self.beat(0)
        line=VGroup(*[Line(a,b,color=MUTED,stroke_width=2) for a,b in [
            ((-5.6,.7,0),(-3.65,.7,0)),((-2.55,.7,0),(-.6,.7,0)),
            ((-5.6,-.8,0),(-.6,-.8,0))]])
        resistor=Rectangle(width=1.1,height=.45,color=INK,stroke_width=2).move_to([-3.1,.7,0])
        labels=VGroup(formula('r',[-3.1,.05,0],31,ROSE,width=.5),
                      words('Источник',[-5.0,-1.4,0],22,MUTED,width=2),
                      words('Потребитель',[-1.3,-1.4,0],22,MUTED,width=2.4))
        heat=VGroup(*[arrow([x,1.05,0],[0,.85,0],ROSE,2) for x in [-3.4,-3.1,-2.8]],
                    words('Тепло',[-3.1,2.2,0],24,ROSE,width=2))
        law=formula(r'P_{\mathrm{пот}}=I^2r',[3.1,1.2,0],46,ROSE)
        conditions=words(['r — сопротивление выбранных потерь линии',
                          'I — действующий ток'],[3.1,-.1,0],23,MUTED)
        self.show(line,resistor,labels,conditions,run_time=1.2);self.intro(0)
        self.act(0,FadeIn(heat),Write(law))
        self.show(words(['Энергия поля переходит во внутреннюю','При большей длине линии её r растёт'],[3.1,-1.9,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        source=formula(r'I=\frac{P_{\mathrm{ист}}}{U_{\mathrm{ист}}}',[-3.1,1.0,0],43)
        loss=formula(r'P_{\mathrm{пот}}=I^2r',[3.1,1.0,0],43)
        first=formula(r'P_{\mathrm{пот}}=\left(\frac{P_{\mathrm{ист}}}{U_{\mathrm{ист}}}\right)^2r',[0,-.3,0],42,width=11.5)
        final=formula(r'P_{\mathrm{пот}}=\frac{P_{\mathrm{ист}}^2}{U_{\mathrm{ист}}^2}\,r',[0,-1.65,0],45,GOLD,width=11.5)
        self.show(source,loss,words('Подставим ток в выражение мощности потерь',[0,2.2,0],24,MUTED,width=11.5),run_time=1.2);self.intro(1)
        self.act(1,Succession(Write(first),Write(final)))
        self.show(words('Сравниваем при фиксированных Pист и r',[0,-2.65,0],24,MUTED,width=11.5),run_time=1.0);self.result(1)

        self.beat(2)
        centers=[-5.5,-2.75,0,2.75,5.5]
        titles=[['Генератор'],['Повышающий','трансформатор'],['Линия','передачи'],['Понижающий','трансформатор'],['Потребитель']]
        nodes=VGroup(*[VGroup(RoundedRectangle(width=1.95,height=1.35,corner_radius=.12,
                                               color=GRID,stroke_width=2).move_to([x,.8,0]),
                             words(title,[x,.8,0],20,INK,width=1.7))
                       for x,title in zip(centers,titles)])
        links=VGroup(*[arrow([x+.99,.8,0],[.77,0,0],GOLD,2) for x in centers[:-1]])
        tags=VGroup(words('U ↑',[-2.75,-.35,0],27,GOLD,width=1.5),
                    words('I ↓',[0,-.35,0],27,CYAN,width=1.5),
                    words('U ↓',[2.75,-.35,0],27,GOLD,width=1.5))
        self.show(nodes,words('Передаём одну и ту же мощность',[0,2.15,0],25,MUTED,width=11.5),run_time=1.2);self.intro(2)
        self.act(2,Succession(*[Create(a) for a in links]),FadeIn(tags))
        self.show(words(['Высокое напряжение в линии уменьшает ток и потери',
                         'У потребителя напряжение понижают'],[0,-1.75,0],25,width=11.5),
                  words('Преобразование напряжения не создаёт дополнительной энергии',[0,-2.75,0],22,MUTED,width=11.5),run_time=1.2);self.result(2)


class LCTransformer(LCScene):
    chapter_id=9

    def chapter(self):
        self.beat(0)
        transformer=lc_c_transformer()
        meaning=words(['Две раздельные обмотки','Общий магнитный сердечник'],[3.1,1.3,0],26)
        common=RoundedRectangle(width=2.0,height=1.8,corner_radius=.17,color=LAVENDER,
                                stroke_width=3).move_to([-3.1,.1,0])
        flux=formula(r'\Phi(t)',[-3.1,.1,0],28,LAVENDER,width=1.15)
        self.show(transformer,meaning,run_time=1.2);self.intro(0)
        self.act(0,Create(common),FadeIn(flux))
        self.show(words(['Общий поток изменяется со временем',
                         'Проводящего соединения между обмотками нет'],[3.1,-.8,0],24,MUTED),
                  words('Первичную обмотку питают переменным напряжением',[3.1,-2.3,0],22,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        given=words(['Один и тот же поток Φ(t)','N₁ и N₂ — числа витков'],[-3.1,1.25,0],26)
        first=formula(r'\varepsilon_1=-N_1\Phi^{\prime}(t)',[3.1,1.15,0],40,GOLD)
        second=formula(r'\varepsilon_2=-N_2\Phi^{\prime}(t)',[3.1,-.1,0],40,CYAN)
        magnitude=formula(r'|\varepsilon_j|=N_j|\Phi^{\prime}(t)|',[-3.1,-1.1,0],34)
        self.show(given,words('Идеальная связь с общим потоком',[-3.1,-.1,0],23,MUTED),run_time=1.2);self.intro(1)
        self.act(1,Succession(Write(first),Write(second)))
        self.show(magnitude,words(['Обходы обмоток согласованы','Минус выражает правило Ленца'],[3.1,-1.8,0],23,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        first=formula(r'|\varepsilon_1|=N_1|\Phi^{\prime}|',[-3.1,1.05,0],38,GOLD)
        second=formula(r'|\varepsilon_2|=N_2|\Phi^{\prime}|',[3.1,1.05,0],38,CYAN)
        ratio=formula(r'\frac{|\varepsilon_2|}{|\varepsilon_1|}=\frac{N_2|\Phi^{\prime}|}{N_1|\Phi^{\prime}|}=\frac{N_2}{N_1}',[0,-.4,0],42,width=11.5)
        voltage=formula(r'\frac{U_2}{U_1}=\frac{N_2}{N_1}',[0,-1.75,0],49,LAVENDER,width=10)
        self.show(first,second,words('Идеальная модель; при делении Φ′ ≠ 0',[0,2.2,0],24,MUTED,width=11.5),run_time=1.2);self.intro(2)
        self.act(2,Write(ratio))
        self.show(voltage,words('U₁ и U₂ — амплитуды или действующие напряжения',[0,-2.75,0],23,MUTED,width=11.5),run_time=1.2);self.result(2)

        self.beat(3)
        titles=VGroup(words('Понижающий',[-3.1,2.1,0],27,GOLD,width=3),
                      words('Повышающий',[3.1,2.1,0],27,CYAN,width=3))
        turns=VGroup(formula(r'N_2<N_1',[-3.1,1.15,0],36),formula(r'N_2>N_1',[3.1,1.15,0],36))
        low=formula(r'U_2<U_1',[-3.1,.25,0],38,GOLD)
        high=formula(r'U_2>U_1',[3.1,.25,0],38,CYAN)
        ax=axes(x_range=(0,TAU,PI/2),y_range=(-1.2,1.2,.5),width=8,height=1.2,center=DOWN*1.9)
        ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
        tags=VGroup(formula('t',ax.x_axis.get_end()+RIGHT*.28,25,MUTED,width=.4),
                    formula('T',ax.c2p(TAU,0)+DOWN*.7,25,MUTED,width=.5))
        input_wave=ax.plot(np.sin,x_range=(0,TAU,.035),color=GOLD,stroke_width=3)
        output_wave=ax.plot(lambda t:.5*np.sin(t),x_range=(0,TAU,.035),color=CYAN,stroke_width=3)
        legend=words('Пример понижения: разные амплитуды, один период',[0,-.85,0],23,MUTED,width=11.5)
        same=formula(r'f_2=f_1',[0,2.1,0],34,LAVENDER,width=1.7)
        self.show(titles,turns,ax,tags,legend,run_time=1.2);self.intro(3)
        self.act(3,Write(low),Write(high),Create(input_wave),Create(output_wave),rate_func=linear)
        self.show(same,run_time=1.2);self.result(3)
