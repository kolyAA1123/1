"""LC circuit, a completed cycle and signed q/I graphs: source pages1–4."""
from lc_style import *


def a_coil(x=-3.1,y=.7,length=2.4,turns=5):
    r=length/(2*turns)
    return VGroup(*[Arc(radius=r,start_angle=PI,angle=-PI,color=MUTED,stroke_width=3)
                    .shift([x-length/2+r+2*r*k,y,0]) for k in range(turns)])


def a_sign(center,color=ROSE):
    x,y,_=center
    return VGroup(Line([x-.12,y,0],[x+.12,y,0],color=color,stroke_width=2.4),
                  Line([x,y-.12,0],[x,y+.12,0],color=color,stroke_width=2.4))


def a_circuit(phase=0):
    """q is the left plate charge; +I runs left across the top coil.

    No conducting path is drawn through the capacitor gap. Dynamic marks are
    lines, not newly typeset glyphs; all state changes share one physical phase.
    """
    wire=VGroup(*[Line(p,q,color=MUTED,stroke_width=2) for p,q in [
        ([-5.2,.7,0],[-4.3,.7,0]),([-1.9,.7,0],[-1.,.7,0]),
        ([-5.2,.7,0],[-5.2,-1.2,0]),([-1.,.7,0],[-1.,-1.2,0]),
        ([-5.2,-1.2,0],[-3.35,-1.2,0]),([-2.85,-1.2,0],[-1.,-1.2,0])]])
    coil=a_coil()
    left=Line([-3.35,-1.65,0],[-3.35,-.75,0],stroke_width=3)
    right=Line([-2.85,-1.65,0],[-2.85,-.75,0],stroke_width=3)
    signs=VGroup(a_sign([-3.55,-.38,0]),a_sign([-2.65,-.38,0],CYAN))
    to_right=arrow([-3.95,1.95,0],[1.7,0,0],CYAN)
    to_left=arrow([-2.25,1.95,0],[-1.7,0,0],CYAN)
    current_name=formula('I',[-1.75,1.95,0],29,CYAN,width=.5)
    names=VGroup(formula('L',[-3.1,1.35,0],30,CYAN,width=.7),
                 formula('C',[-3.1,-2.05,0],30,GOLD,width=.7))
    group=VGroup(wire,coil,left,right,signs,to_right,to_left,current_name,names)
    palette={value:ManimColor(value) for value in (INK,MUTED,CYAN,ROSE)}
    def state(theta):
        charge_value=float(np.cos(theta));current_value=float(-np.sin(theta))
        if abs(charge_value)<1e-8:charge_value=0.
        if abs(current_value)<1e-8:current_value=0.
        magnitude=abs(charge_value)
        left_color=ROSE if charge_value>=0 else CYAN
        right_color=CYAN if charge_value>=0 else ROSE
        left.set_color(interpolate_color(palette[INK],palette[left_color],magnitude))
        right.set_color(interpolate_color(palette[INK],palette[right_color],magnitude))
        signs[0].set_color(left_color);signs[1].set_color(right_color)
        signs[0][0].set_opacity(magnitude);signs[1][0].set_opacity(magnitude)
        signs[0][1].set_opacity(magnitude if charge_value>0 else 0)
        signs[1][1].set_opacity(magnitude if charge_value<0 else 0)
        coil.set_color(interpolate_color(palette[MUTED],palette[CYAN],abs(current_value)))
        to_right.set_opacity(max(0,-current_value))
        to_left.set_opacity(max(0,current_value))
        current_name.set_opacity(abs(current_value))
    state(phase)
    return group,state


def a_phase(group,state,start,end):
    return UpdateFromAlphaFunc(group,lambda _mob,alpha:state(start+(end-start)*alpha))


def a_time_graph(y_label=r'q/q_{\max}',module=False):
    y_range=(0,1.25,.25) if module else (-1.25,1.25,.5)
    ax=axes((0,1.04,.25),y_range,5.1,3.15,np.array([-3.15,.15,0]))
    ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
    names=VGroup(formula(y_label,[-3.15,2.15,0],28,MUTED,width=4.8),
                 formula('t',ax.c2p(1.04,0)+RIGHT*.28,27,MUTED,width=.5))
    time_names=['0',r'T/4',r'T/2',r'3T/4','T']
    ticks=VGroup()
    for t,name in zip([0,.25,.5,.75,1],time_names):
        p=ax.c2p(t,0)
        ticks.add(Line(p+UP*.055,p+DOWN*.055,color=MUTED,stroke_width=1.3),
                  formula(name,[p[0],-1.85,0],22,MUTED,width=.85))
    amp=VGroup(formula('1',ax.c2p(0,1)+LEFT*.27,23,MUTED,width=.4))
    if not module:amp.add(formula('-1',ax.c2p(0,-1)+LEFT*.30,23,MUTED,width=.6))
    return ax,VGroup(ax,names,ticks,amp)


class LCStructureFirstQuarter(LCScene):
    chapter_id=1
    def chapter(self):
        self.beat(0)
        circuit,state=a_circuit(0)
        self.show(circuit,words(['Конденсатор C и катушка L','Идеальная модель: потери малы'],[3.1,1.45,0],25),
                  words(['q — заряд левой обкладки','Сразу после замыкания'],[3.1,.1,0],24,MUTED),run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(VGroup(formula(r'q(0)=q_{\max}>0',[3.1,-1.15,0],31,GOLD),
                                formula(r'I(0)=0',[3.1,-2.15,0],31,CYAN))))
        self.show(words('После запуска внешний источник не нужен',[0,-2.75,0],23,MUTED,width=11.8),run_time=1.2)
        self.result(0)

        self.beat(1)
        ax=axes((0,1.04,.25),(0,1.2,.25),5.1,3.0,np.array([-3.15,.05,0]))
        ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
        graph_names=VGroup(formula(r'|I|/I_{\max}',[-5.2,2.05,0],28,MUTED,width=2.2),
                           formula('0',ax.c2p(0,0)+DOWN*.3,24,MUTED,width=.5),
                           formula('T/4',ax.c2p(1,0)+DOWN*.3,24,MUTED,width=.9),
                           formula('t',ax.c2p(1.04,0)+RIGHT*.28,26,MUTED,width=.4),
                           formula('1',ax.c2p(0,1)+LEFT*.3,24,MUTED,width=.4))
        curve=ax.plot(lambda u:np.sin(PI*u/2),x_range=[0,1,.01],color=CYAN,stroke_width=3)
        self.show(ax,graph_names,words(['Первая четверть периода','Самоиндукция противодействует','изменению тока'],[3.1,1.1,0],25),run_time=1.2)
        self.intro(1)
        self.act(1,Create(curve),rate_func=linear)
        self.show(words(['Ток начинает расти сразу','Скачка тока нет'],[3.1,-.9,0],25,GOLD),
                  formula(r'|I(T/4)|=I_{\max}',[3.1,-2.1,0],29,CYAN),run_time=1.2)
        self.result(1)

        self.beat(2)
        circuit,state=a_circuit(0)
        self.show(circuit,words(['Та же первая четверть','Левая обкладка сначала положительна'],[3.1,1.45,0],24),
                  formula(r't:0\longrightarrow T/4',[3.1,.05,0],32),run_time=1.2)
        self.intro(2)
        self.act(2,a_phase(circuit,state,0,PI/2),rate_func=linear)
        self.show(formula(r'q=0,\qquad U=0',[3.1,-1.0,0],31,GOLD),
                  formula(r'|I|=I_{\max}',[3.1,-2.0,0],31,CYAN),
                  words('Разряд завершён; ток ещё не прекратился',[0,-2.75,0],23,MUTED,width=11.8),run_time=1.2)
        self.result(2)


class LCFullCycle(LCScene):
    chapter_id=2
    def chapter(self):
        self.beat(0)
        circuit,state=a_circuit(PI/2)
        self.show(circuit,words(['После полного разряда','Ток сохраняет прежнее направление'],[3.1,1.4,0],24),
                  formula(r't:T/4\longrightarrow T/2',[3.1,.05,0],31),run_time=1.2)
        self.intro(0)
        self.act(0,a_phase(circuit,state,PI/2,PI),rate_func=linear)
        self.show(formula(r'q=-q_{\max},\quad I=0',[3.1,-1.1,0],30,GOLD),
                  words('Полярность конденсатора обратная',[3.1,-2.2,0],23,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        circuit,state=a_circuit(PI)
        self.show(circuit,words(['Вторая половина периода','Обратный разряд и перезарядка'],[3.1,1.4,0],24),
                  formula(r't:T/2\longrightarrow T',[3.1,.05,0],31),run_time=1.2)
        self.intro(1)
        self.act(1,a_phase(circuit,state,PI,TAU),rate_func=linear)
        self.show(formula(r'q=q_{\max},\quad I=0',[3.1,-1.1,0],30,GOLD),
                  words('Исходное состояние восстановлено',[3.1,-2.2,0],23,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        xs=[-4.3,-2.15,0,2.15,4.3]
        labels=VGroup(formula('t',[-6.0,1.9,0],28,MUTED,width=.5),
                      formula(r'q/q_{\max}',[-6.0,.8,0],27,MUTED,width=1.6),
                      formula(r'|I|/I_{\max}',[-6.0,-.2,0],27,MUTED,width=1.6),
                      words('Ток',[-6.0,-1.25,0],22,MUTED,width=1.2))
        headings=VGroup(*[formula(t,[x,1.9,0],28,width=1.5) for x,t in zip(xs,['0','T/4','T/2','3T/4','T'])])
        columns=VGroup()
        for x,qv,iv,direction in zip(xs,['1','0','-1','0','1'],['0','1','0','1','0'],[0,1,0,-1,0]):
            part=VGroup(formula(qv,[x,.8,0],30,GOLD,width=.8),formula(iv,[x,-.2,0],30,CYAN,width=.8))
            if direction:part.add(arrow([x-direction*.45,-1.25,0],[direction*.9,0,0],CYAN))
            else:part.add(words('нет',[x,-1.25,0],21,MUTED,width=1.2))
            columns.add(part)
        self.show(labels,headings,run_time=1.2)
        self.intro(2)
        self.act(2,LaggedStart(*[FadeIn(c) for c in columns],lag_ratio=.18))
        boxes=VGroup(*[RoundedRectangle(width=1.65,height=4.0,corner_radius=.12,color=GOLD,stroke_width=1.5).move_to([x,.3,0]) for x in (xs[0],xs[-1])])
        self.show(boxes,words('Один период T: возвращаются заряд, ток и полярность',[0,-2.55,0],25,GOLD,width=12),run_time=1.2)
        self.result(2)


class LCChargeAndCurrent(LCScene):
    chapter_id=3
    def chapter(self):
        self.beat(0)
        circuit,state=a_circuit(0)
        reference=VGroup(arrow([3.95,-.05,0],[-1.7,0,0],CYAN),
                         formula('+I',[4.7,-.05,0],29,CYAN,width=.9))
        self.show(circuit,words(['q — заряд фиксированной','левой обкладки'],[3.1,1.6,0],25),
                  words('Положительное направление тока',[3.1,.65,0],23,MUTED),run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(reference))
        self.show(formula(r'I=q^{\prime}(t)',[3.1,-1.15,0],33,GOLD),
                  words(['Первый разряд: ток вправо','При выбранном отсчёте I < 0'],[3.1,-2.25,0],22,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        ax,base=a_time_graph()
        curve=ax.plot(lambda t:np.cos(TAU*t),x_range=[0,1,.005],color=GOLD,stroke_width=3)
        self.show(base,formula(r'q(t)=q_{\max}\cos(\omega t)',[3.1,1.65,0],33,GOLD),
                  formula(r'q_{\max}>0',[3.1,.55,0],30),
                  words('Идеальный контур, первоначально заряжен',[3.1,-.4,0],23,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,Create(curve),rate_func=linear)
        self.show(formula(r'q(T/2)=-q_{\max}',[3.1,-1.35,0],29,GOLD),
                  formula(r'q(T)=q_{\max}',[3.1,-2.25,0],29,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        qlaw=formula(r'q(t)=q_{\max}\cos(\omega t)',[0,1.8,0],36,GOLD,width=11.8)
        derivative=formula(r'I(t)=q^{\prime}(t)=-q_{\max}\omega\sin(\omega t)',[0,.5,0],35,CYAN,width=11.8)
        amplitude=formula(r'I_{\max}=q_{\max}\omega>0',[0,-.8,0],34,GOLD,width=11.8)
        final=formula(r'I(t)=-I_{\max}\sin(\omega t)',[0,-2.1,0],36,CYAN,width=11.8)
        self.show(qlaw,words('Ток — скорость изменения выбранного заряда',[0,2.45,0],22,MUTED,width=11.8),run_time=1.2)
        self.intro(2)
        self.act(2,LaggedStart(FadeIn(derivative),FadeIn(amplitude),lag_ratio=.35))
        self.show(final,run_time=1.2)
        self.result(2)

        self.beat(3)
        ax,base=a_time_graph(y_label=r'q/q_{\max},\ I/I_{\max}')
        qcurve=ax.plot(lambda t:np.cos(TAU*t),x_range=[0,1,.005],color=GOLD,stroke_width=2.8)
        icurve=ax.plot(lambda t:-np.sin(TAU*t),x_range=[0,1,.005],color=CYAN,stroke_width=2.8)
        self.show(base,formula(r'q/q_{\max}=\cos(\omega t)',[3.1,1.65,0],31,GOLD),
                  formula(r'I/I_{\max}=-\sin(\omega t)',[3.1,.55,0],31,CYAN),
                  words('Общий период заряда и тока — T',[3.1,-.5,0],24),run_time=1.2)
        self.intro(3)
        self.act(3,Create(qcurve),Create(icurve),rate_func=linear)
        self.show(formula(r'|q|=q_{\max}\ \Rightarrow\ I=0',[3.1,-1.35,0],29,MUTED),
                  formula(r'q=0\ \Rightarrow\ |I|=I_{\max}',[3.1,-2.25,0],29,MUTED),run_time=1.2)
        self.result(3)
