"""Electric/magnetic field energy, Thomson period and damping: PDF pp4–6."""
from lc_style import *


def lcb_energy_axes(y_name=r'W/W_0'):
    """One full charge/current period; energy repeats twice inside it."""
    ax = Axes(x_range=[0, 1, .25], y_range=[0, 1.18, .5],
              x_length=4.65, y_length=2.8,
              axis_config={'color': MUTED, 'stroke_width': 1.4,
                           'include_tip': True, 'tip_width': .09, 'tip_height': .1},
              tips=True).move_to([-3.35, -.05, 0])
    ax.x_axis.ticks.set_opacity(0)
    ax.y_axis.ticks.set_opacity(0)
    labels = VGroup()
    for x, label in [(0, '0'), (.25, r'T/4'), (.5, r'T/2'), (.75, r'3T/4'), (1, 'T')]:
        tick = Line(ax.c2p(x, 0)+DOWN*.045, ax.c2p(x, 0)+UP*.045,
                    color=MUTED, stroke_width=1.3)
        name = eq(label, 21, MUTED).next_to(tick, DOWN, buff=.13)
        labels.add(tick, name)
    labels.add(eq(y_name, 25, MUTED).move_to([-5.6, 1.94, 0]),
               eq('t', 24, MUTED).next_to(ax.x_axis, RIGHT, buff=.12),
               eq('1', 21, MUTED).next_to(ax.c2p(0, 1), LEFT, buff=.12))
    guide = DashedLine(ax.c2p(0, 1), ax.c2p(1, 1), color=GRID,
                       dash_length=.08, stroke_width=1)
    return ax, VGroup(ax, guide, labels)


def lcb_curve(ax, function, color):
    return ax.plot(function, x_range=[0, 1, .006], color=color,
                   stroke_width=3.1, use_smoothing=False)


def lcb_damping_axes():
    ax = Axes(x_range=[0, 4.35, 1], y_range=[0, 1.18, .5],
              x_length=4.65, y_length=2.8,
              axis_config={'color': MUTED, 'stroke_width': 1.4,
                           'include_tip': True, 'tip_width': .09, 'tip_height': .1},
              tips=True).move_to([-3.35, -.05, 0])
    ax.x_axis.ticks.set_opacity(0)
    ax.y_axis.ticks.set_opacity(0)
    labels = VGroup(eq('W_L', 26, MUTED).move_to([-5.6, 1.94, 0]),
                    eq('t', 24, MUTED).next_to(ax.x_axis, RIGHT, buff=.12),
                    eq('0', 21, MUTED).next_to(ax.c2p(0, 0), LEFT, buff=.13))
    note = words(['Качественный график', 'Конечный интервал наблюдения'],
                 (-3.35, -2.25, 0), 18, MUTED, width=4.7)
    return ax, VGroup(ax, labels, note)


class LCFieldEnergies(LCScene):
    chapter_id = 4

    def chapter(self):
        self.beat(0)
        ax, drawing = lcb_energy_axes(r'W_C/W_0')
        source = formula(r'q(t)=q_{\max}\cos(\omega t)', (3, 1.65, 0), 34, CYAN)
        energy = formula(r'W_C=\frac{q^2}{2C}', (3, .6, 0), 38, CYAN)
        reference = formula(r'W_0=\frac{q_{\max}^2}{2C}', (3, -.5, 0), 35)
        self.show(drawing, source, energy, reference, run_time=1.2)
        self.intro(0)
        curve = lcb_curve(ax, lambda t: np.cos(TAU*t)**2, CYAN)
        self.act(0, Create(curve), rate_func=linear)
        result = formula(r'W_C(t)=W_0\cos^2(\omega t)', (3, -1.8, 0), 35, CYAN)
        self.show(result, run_time=1.2)
        self.result(0)

        self.beat(1)
        ax, drawing = lcb_energy_axes(r'W_L/W_0')
        source = formula(r'I(t)=-I_{\max}\sin(\omega t)', (3, 1.65, 0), 33, ROSE)
        energy = formula(r'W_L=\frac{LI^2}{2}', (3, .6, 0), 38, ROSE)
        reference = formula(r'W_0=\frac{LI_{\max}^2}{2}', (3, -.5, 0), 35)
        self.show(drawing, source, energy, reference, run_time=1.2)
        self.intro(1)
        curve = lcb_curve(ax, lambda t: np.sin(TAU*t)**2, ROSE)
        self.act(1, Create(curve), rate_func=linear)
        result = formula(r'W_L(t)=W_0\sin^2(\omega t)', (3, -1.8, 0), 35, ROSE)
        self.show(result, run_time=1.2)
        self.result(1)

        self.beat(2)
        ax, drawing = lcb_energy_axes()
        c_curve = lcb_curve(ax, lambda t: np.cos(TAU*t)**2, CYAN)
        l_curve = lcb_curve(ax, lambda t: np.sin(TAU*t)**2, ROSE)
        c_formula = formula(r'W_C=W_0\cos^2(\omega t)', (3, 1.6, 0), 34, CYAN)
        l_formula = formula(r'W_L=W_0\sin^2(\omega t)', (3, .65, 0), 34, ROSE)
        c_dot = Dot(ax.c2p(0, 1), radius=.055, color=CYAN)
        l_dot = Dot(ax.c2p(0, 0), radius=.055, color=ROSE)
        cursor = Line(ax.c2p(0, 0), ax.c2p(0, 1.08), color=GOLD,
                      stroke_width=1.3, stroke_opacity=.65)
        moving = VGroup(c_dot, l_dot, cursor)
        self.show(drawing, c_curve, l_curve, c_formula, l_formula, moving, run_time=1.2)
        self.intro(2)

        def advance(group, alpha):
            group[0].move_to(ax.c2p(alpha, np.cos(TAU*alpha)**2))
            group[1].move_to(ax.c2p(alpha, np.sin(TAU*alpha)**2))
            group[2].put_start_and_end_on(ax.c2p(alpha, 0), ax.c2p(alpha, 1.08))
        self.act(2, UpdateFromAlphaFunc(moving, advance), rate_func=linear)
        period = formula(r'T_{W_C}=T_{W_L}=\frac{T}{2}', (3, -.7, 0), 36, GOLD)
        positive = formula(r'W_C\geq0,\qquad W_L\geq0', (3, -1.9, 0), 32)
        self.show(period, positive, run_time=1.2)
        self.result(2)


class LCThomsonFrequency(LCScene):
    chapter_id = 5

    def chapter(self):
        self.beat(0)
        choice = words(['Фиксированная левая обкладка', 'Ток I входит в выбранную обкладку'],
                       (-3.25, 1.65, 0), 22, MUTED, width=5.4)
        q_def = formula(r'U=\frac{q}{C},\qquad I=q^{\prime}', (-3.25, .25, 0), 34)
        conditions = words(['L и C постоянны', 'Потерями пренебрегаем'],
                           (-3.25, -1.3, 0), 23, MUTED, width=5.2)
        cap = formula('q=CU', (3.05, 1.65, 0), 39, CYAN)
        balance = formula(r'U=-LI^{\prime}', (3.05, .5, 0), 39, ROSE)
        self.show(choice, q_def, conditions, cap, balance, run_time=1.2)
        self.intro(0)
        combined = formula(r'q=-LCI^{\prime}', (3.05, -.75, 0), 38)
        self.act(0, FadeIn(combined))
        result = formula(r'q+LCI^{\prime}=0', (3.05, -2.0, 0), 39, GOLD)
        self.show(result, run_time=1.2)
        self.result(0)

        self.beat(1)
        original = formula(r'q+LCI^{\prime}=0', (-3.2, 1.5, 0), 39)
        current = formula(r'I=q^{\prime}', (-3.2, .15, 0), 39, CYAN)
        positive = formula(r'L>0,\qquad C>0', (-3.2, -1.3, 0), 33, MUTED)
        title = words('Уравнение для заряда', (3.05, 1.8, 0), 25, MUTED)
        self.show(original, current, positive, title, run_time=1.2)
        self.intro(1)
        derivative = formula(r'I^{\prime}=q^{\prime\prime}', (3.05, .7, 0), 40, CYAN)
        replacement = formula(r'q+LCq^{\prime\prime}=0', (3.05, -.35, 0), 37)
        self.act(1, Succession(FadeIn(derivative), FadeIn(replacement)))
        harmonic = formula(r'q^{\prime\prime}+\frac{1}{LC}q=0', (3.05, -1.8, 0), 38, GOLD)
        self.show(harmonic, run_time=1.2)
        self.result(1)

        self.beat(2)
        actual = formula(r'q^{\prime\prime}+\frac{1}{LC}q=0', (-3.2, 1.5, 0), 38)
        general = formula(r'x^{\prime\prime}+\omega^2x=0', (-3.2, .15, 0), 38)
        period_definition = formula(r'T=\frac{2\pi}{\omega}', (3.05, 1.5, 0), 40)
        self.show(actual, general, period_definition, run_time=1.2)
        self.intro(2)
        squared = formula(r'\omega^2=\frac{1}{LC}', (-3.2, -1.2, 0), 38, CYAN)
        omega = formula(r'\omega=\frac{1}{\sqrt{LC}}', (3.05, .05, 0), 40, CYAN)
        self.act(2, FadeIn(squared), FadeIn(omega))
        thomson = formula(r'T=2\pi\sqrt{LC}', (3.05, -1.65, 0), 41, GOLD)
        note = words('Формула Томсона', (-3.2, -2.35, 0), 23, GOLD)
        self.show(thomson, note, run_time=1.2)
        self.result(2)


class LCConservationAndDamping(LCScene):
    chapter_id = 6

    def chapter(self):
        self.beat(0)
        ax, drawing = lcb_energy_axes()
        c_curve = lcb_curve(ax, lambda t: np.cos(TAU*t)**2, CYAN)
        l_curve = lcb_curve(ax, lambda t: np.sin(TAU*t)**2, ROSE)
        c_formula = formula(r'W_C=W_0\cos^2(\omega t)', (3, 1.55, 0), 34, CYAN)
        l_formula = formula(r'W_L=W_0\sin^2(\omega t)', (3, .5, 0), 34, ROSE)
        self.show(drawing, c_curve, l_curve, c_formula, l_formula, run_time=1.2)
        self.intro(0)
        total = Line(ax.c2p(0, 1), ax.c2p(1, 1), color=GOLD, stroke_width=3.2)
        self.act(0, Create(total), rate_func=linear)
        conservation = formula(r'W_C+W_L=W_0=\mathrm{const}', (3, -.9, 0), 36, GOLD)
        note = words('Идеальный контур без потерь', (3, -2.1, 0), 23, MUTED)
        self.show(conservation, note, run_time=1.2)
        self.result(0)

        self.beat(1)
        base_y = -.9
        bar_height = 1.8
        c_x, l_x = -4.45, -2.1
        baseline = Line([-5.25, base_y, 0], [-1.3, base_y, 0], color=MUTED, stroke_width=1.5)
        guides = VGroup(*[DashedLine([x-.55, base_y+bar_height, 0],
                                    [x+.55, base_y+bar_height, 0], color=GRID,
                                    dash_length=.08, stroke_width=1) for x in (c_x, l_x)])
        names = VGroup(formula('W_C', (c_x, -1.4, 0), 30, CYAN),
                       formula('W_L', (l_x, -1.4, 0), 30, ROSE))
        title = words('Обмен за четверть периода', (-3.25, 1.8, 0), 23, MUTED)

        def bar(x, energy, color):
            height = bar_height*float(np.clip(energy, 0, 1))
            result = Rectangle(width=.72, height=max(height, .001), color=color,
                               stroke_width=2, fill_color=color, fill_opacity=.4)
            result.move_to([x, base_y+height/2, 0])
            if height<1e-7:result.set_opacity(0)
            return result
        bars = VGroup(bar(c_x, 1, CYAN), bar(l_x, 0, ROSE))
        instantaneous = formula(r'W_C+W_L=\frac{CU^2}{2}+\frac{LI^2}{2}', (3.1, 1.65, 0), 32)
        cap_max = formula(r'W_0=\frac{CU_{\max}^2}{2}', (3.1, .35, 0), 37, CYAN)
        coil_max = formula(r'W_0=\frac{LI_{\max}^2}{2}', (3.1, -.95, 0), 37, ROSE)
        self.show(baseline, guides, names, title, bars, instantaneous, cap_max, coil_max, run_time=1.2)
        self.intro(1)

        def exchange(group, alpha):
            phase=PI*alpha/2
            group[0].become(bar(c_x, np.cos(phase)**2, CYAN))
            group[1].become(bar(l_x, np.sin(phase)**2, ROSE))
        self.act(1, UpdateFromAlphaFunc(bars, exchange), rate_func=linear)
        conclusion = words(['Максимумы достигаются', 'в разные моменты'],
                           (3.1, -2.3, 0), 22, GOLD, width=5.4)
        self.show(conclusion, run_time=1.2)
        self.result(1)

        self.beat(2)
        ax, drawing = lcb_damping_axes()
        title = words('Реальный контур', (3.05, 1.75, 0), 26)
        resistance = words('Сопротивление проводников', (3.05, .85, 0), 23, MUTED)
        positive = formula('R>0', (3.05, 0, 0), 37, ROSE)
        regime = words(['Потери достаточно малы', 'Колебательный режим'],
                       (3.05, -.95, 0), 22, MUTED)
        self.show(drawing, title, resistance, positive, regime, run_time=1.2)
        self.intro(2)
        # The envelope is only drawing geometry for a qualitative sketch.
        # No analytic RLC solution or exponential formula is taught here.
        curve = ax.plot(lambda t: np.exp(-.43*t)*np.sin(PI*t)**2,
                        x_range=[0, 4.35, .008], color=ROSE,
                        stroke_width=3.1, use_smoothing=False)
        envelope = ax.plot(lambda t: np.exp(-.43*t), x_range=[0, 4.35, .025],
                           color=MUTED, stroke_width=1.4, use_smoothing=False)
        envelope.set_stroke(opacity=.6)
        envelope.set_fill(opacity=0)
        self.act(2, Create(curve), Create(envelope), rate_func=linear)
        heat = words(['Энергия полей → внутренняя', 'энергия проводников'],
                     (3.05, -2.25, 0), 22, GOLD, width=5.5)
        self.show(heat, run_time=1.2)
        self.result(2)
