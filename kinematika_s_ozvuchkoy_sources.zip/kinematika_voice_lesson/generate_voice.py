"""Synthesize the selected Mari voice first, then derive every visual/speech time.

Run with ../.venv-speech/bin/python. No speech is accelerated to fit a scene.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import math
import subprocess
from pathlib import Path
import textwrap
import wave
import numpy as np
import onnxruntime as ort
from piper import PiperVoice, SynthesisConfig
from piper.config import PiperConfig
from sample_voice import VOICES, DATA_REVISIONS, digest

ROOT=Path(__file__).resolve().parent
RATE=48000
SETTINGS={'length_scale':1.05,'noise_scale':.4,'noise_w_scale':.45,'normalize_audio':True,'volume':.9}

def save_wav(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(path),'wb') as stream:
        stream.setnchannels(1);stream.setsampwidth(2);stream.setframerate(RATE)
        stream.writeframes(np.asarray(data,dtype='<i2').tobytes())

def read_wav(path):
    with wave.open(str(path),'rb') as stream:
        assert (stream.getnchannels(),stream.getsampwidth(),stream.getframerate())==(1,2,RATE)
        return np.frombuffer(stream.readframes(stream.getnframes()),dtype='<i2').copy()

def trim_silence(data):
    # Preserve soft consonants and breathing space; never stretch or shift pitch.
    threshold=max(12,int(np.max(np.abs(data.astype(np.int32))))*.0015)
    active=np.flatnonzero(np.abs(data.astype(np.int32))>threshold)
    if not len(active):raise RuntimeError('Empty synthesized speech')
    left=max(0,int(active[0]) - round(.10*RATE));right=min(len(data),int(active[-1])+round(.18*RATE))
    result=data[left:right].copy()
    ramp=min(round(.005*RATE),len(result)//2)
    result[:ramp]=(result[:ramp]*np.linspace(0,1,ramp)).astype(np.int16)
    result[-ramp:]=(result[-ramp:]*np.linspace(1,0,ramp)).astype(np.int16)
    return result

def frame(seconds):return math.ceil((seconds-1e-9)*60)/60

def stamp(seconds,srt=False):
    ms=round(seconds*1000);hours,ms=divmod(ms,3600000);minutes,ms=divmod(ms,60000);sec,ms=divmod(ms,1000)
    return f'{hours:02d}:{minutes:02d}:{sec:02d}{"," if srt else "."}{ms:03d}'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--force',action='store_true');args=parser.parse_args()
    script=json.loads((ROOT/'script.json').read_text())
    spec=VOICES['mari'];model=next((ROOT/'voice_models/mari').rglob('*.onnx'))
    assert digest(model)==spec['model_sha256']
    config=Path(str(model)+'.json');assert digest(config)==spec['config_sha256']
    data_dir=ROOT/'voice_models/espeak-ng-data-legacy'
    data_manifest=json.loads((data_dir/'custom_manifest.json').read_text())
    assert data_manifest['revision']==DATA_REVISIONS['legacy']
    for item in data_manifest['custom_files']:assert digest(data_dir/item['name'])==item['sha256']
    options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
    voice=PiperVoice(config=PiperConfig.from_dict(json.loads(config.read_text())),
        session=ort.InferenceSession(str(model),sess_options=options,providers=['CPUExecutionProvider']),
        espeak_data_dir=data_dir,download_dir=ROOT/'voice_models')
    audio_dir=ROOT/'output/audio/parts';audio_dir.mkdir(parents=True,exist_ok=True)
    chunks={}
    for chapter in script['chapters']:
        for beat in chapter['beats']:
            for part in ['intro','result']:
                key=f"{chapter['id']:02d}_{beat['index']+1:02d}_{part}"
                path=audio_dir/f'{key}.wav';meta=path.with_suffix('.json')
                signature=hashlib.sha256(json.dumps({'text':beat[part],'settings':SETTINGS,
                    'model':spec['model_sha256'],'phonemizer':data_manifest['revision'],
                    'trim':'retain100ms180ms-edge5ms','output_sample_rate':RATE},ensure_ascii=False,sort_keys=True).encode()).hexdigest()
                if args.force or not path.exists() or not meta.exists() or json.loads(meta.read_text()).get('signature')!=signature:
                    raw=audio_dir/f'{key}.raw.wav'
                    with wave.open(str(raw),'wb') as wav:voice.synthesize_wav(beat[part],wav,syn_config=SynthesisConfig(**SETTINGS))
                    subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-ac','1','-ar',str(RATE),
                                    '-c:a','pcm_s16le',str(path)],check=True)
                    pcm=trim_silence(read_wav(path));save_wav(path,pcm);raw.unlink()
                    record={'signature':signature,'text':beat[part],'samples':len(pcm),'sample_rate':RATE,
                            'duration':len(pcm)/RATE,'sha256':digest(path),'settings':SETTINGS}
                    meta.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
                record=json.loads(meta.read_text());assert digest(path)==record['sha256']
                chunks[key]=(path,record)
                print(f'{key}: {record["duration"]:.3f}s',flush=True)
    plan={'title':'Кинематика: теория и понятные демонстрации','duration':0,'fps':60,
          'voice':{'name':'Mari','engine':'Piper','engine_version':importlib.metadata.version('piper-tts'),
                   'model_sha256':spec['model_sha256'],'phonemizer_revision':DATA_REVISIONS['legacy'],
                   'settings':SETTINGS,'selected_by_user':True,'sample_rate':RATE},'chapters':[]}
    narrative={'title':plan['title'],'total_duration':0,'audio':{'enabled':True,**plan['voice']},'chapters':[]}
    full=[];subs=[];txt=['КИНЕМАТИКА — ТЕОРИЯ И ПОНЯТНЫЕ ДЕМОНСТРАЦИИ','Точный текст выбранной женской озвучки.',''];md=['# Кинематика: текст озвучки',''];story=['# Речь и кадр: общий измеренный график','']
    offset=0;serial=1
    for source in script['chapters']:
        ident=source['id'];module='foundations.py' if ident<=4 else 'motion.py' if ident<=8 else 'advanced.py'
        chapter={'id':ident,'class':source['class'],'title':source['title'],'module':module,'start':offset,
                 'duration':0,'audio_file':f'output/audio/chapters/{ident:02d}.wav','beats':[]}
        cues=[];cursor=.8
        for beat in source['beats']:
            i=beat['index'];p_intro,r_intro=chunks[f'{ident:02d}_{i+1:02d}_intro'];p_result,r_result=chunks[f'{ident:02d}_{i+1:02d}_result']
            start=frame(cursor);intro_at=frame(start+3.2)
            action_at=frame(intro_at+r_intro['duration']+.30)
            action_seconds=frame(float(beat['action_seconds']))
            result_at=frame(action_at+action_seconds+1.60)
            end=frame(result_at+r_result['duration']+.80)
            timed={**beat,'start':start,'intro_at':intro_at,'intro_duration':r_intro['duration'],
                   'intro_file':str(p_intro.relative_to(ROOT)),'action_at':action_at,'action_seconds':action_seconds,
                   'result_at':result_at,'result_duration':r_result['duration'],'result_file':str(p_result.relative_to(ROOT)),'end':end}
            chapter['beats'].append(timed);cursor=end
            for name,at,path,rec in [('intro',intro_at,p_intro,r_intro),('result',result_at,p_result,r_result)]:
                cue={'beat':i+1,'part':name,'at':at,'global_at':offset+at,'speech_duration':rec['duration'],
                     'until':at+rec['duration'],'global_until':offset+at+rec['duration'],'text':beat[name],
                     'file':str(path.relative_to(ROOT)),'sha256':rec['sha256']}
                cues.append(cue)
                subs.append(f'{serial}\n{stamp(cue["global_at"],True)} --> {stamp(cue["global_until"],True)}\n'+ '\n'.join(textwrap.wrap(cue['text'],50))+'\n');serial+=1
        chapter['duration']=math.ceil(cursor+1.2)
        track=np.zeros(round(chapter['duration']*RATE),dtype=np.int16)
        for cue in cues:
            pcm=read_wav(ROOT/cue['file']);where=round(cue['at']*RATE);track[where:where+len(pcm)]=pcm
        save_wav(ROOT/chapter['audio_file'],track);full.append(track)
        plan['chapters'].append(chapter);narrative['chapters'].append({**{k:v for k,v in chapter.items() if k!='beats'},'cues':cues})
        heading=f"{ident:02d}. {source['title']} — {stamp(offset)}"
        txt.extend([heading,'']);md.extend(['## '+heading,'']);story.extend(['## '+heading,''])
        for cue in cues:
            line=f"[{stamp(cue['global_at'])}–{stamp(cue['global_until'])}] {cue['text']}"
            txt.extend([line,'']);md.extend([line,''])
        for beat in chapter['beats']:
            story.extend([f"### Такт {beat['index']+1}: {beat['caption']}",
                f"Кадр {stamp(offset+beat['start'])}: {beat['visual_before']}",
                f"Введение {stamp(offset+beat['intro_at'])}: {beat['intro']}",
                f"Действие {stamp(offset+beat['action_at'])}–{stamp(offset+beat['action_at']+beat['action_seconds'])}: {beat['action']}",
                f"Готовый результат: {beat['visual_after']}",
                f"Объяснение {stamp(offset+beat['result_at'])}: {beat['result']}",''])
        offset+=chapter['duration']
    plan['duration']=offset;narrative['total_duration']=offset
    (ROOT/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'narration.json').write_text(json.dumps(narrative,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'tekst_ozvuchki.txt').write_text('\n'.join(txt).rstrip()+'\n',encoding='utf-8-sig')
    (ROOT/'narration.md').write_text('\n'.join(md).rstrip()+'\n')
    (ROOT/'storyboard.md').write_text('\n'.join(story).rstrip()+'\n')
    (ROOT/'subtitles.srt').write_text('\n'.join(subs),encoding='utf-8-sig')
    save_wav(ROOT/'output/audio/narration_raw.wav',np.concatenate(full))
    save_wav(ROOT/'output/audio/narration.wav',np.concatenate(full))
    print(f'VOICE READY: {offset}s,12 chapters,120 measured parts; no time compression.',flush=True)

if __name__=='__main__':main()
