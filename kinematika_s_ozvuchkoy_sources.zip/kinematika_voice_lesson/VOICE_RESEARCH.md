# Пробы женской русской озвучки

Подготовлены два новых варианта голоса Piper из стороннего зеркала
[Rotem12/piper-russian-voices](https://github.com/Rotem12/piper-russian-voices).
Зеркало фиксирует исходные репозитории, ревизии и SHA-256 в
[NOTICE.md](https://raw.githubusercontent.com/Rotem12/piper-russian-voices/main/NOTICE.md)
и [MODEL_MANIFEST.json](https://raw.githubusercontent.com/Rotem12/piper-russian-voices/main/MODEL_MANIFEST.json).

| Голос | Архив | SHA-256 архива | SHA-256 ONNX |
|---|---|---|---|
| Mari | [ru_RU-mari-medium_epoch5699.zip](https://github.com/Rotem12/piper-russian-voices/releases/download/russian-voices-2026-09-15-r2/ru_RU-mari-medium_epoch5699.zip) | `9b729a70b059781636fdda3c313c6569a5d83a46c6eeffc39f5680b4832da631` | `8f1b7a19d42d564f7e4951bf828a9e910d85e8f9e78cb495b31db9f29f580112` |
| Terra | [ru_RU-terra5871-medium.zip](https://github.com/Rotem12/piper-russian-voices/releases/download/russian-voices-2026-09-15-r2/ru_RU-terra5871-medium.zip) | `35ef3a7b78cf814b99f191744fcff5ec9888b6f041bc53ff555ce9f4b2b7ee34` | `edf8010bf52550896347b074eaee969dc8efec72cf116cdb10db7d54a84473e8` |

Оба архива, обе модели и оба JSON проверены по SHA-256. В каждом архиве
сохранены `LICENSE.txt` с полным Apache License 2.0 и `NOTICE.md`, где
Apache-2.0 относится к артефактам `rraaww/ru_piper` на ревизии
`f340fe24a52e696bdacbc457d242ac2b0e3bb9ac`, согласно метаданным исходного
репозитория. Отдельные карточки по голосам исходный репозиторий не публикует.
Зеркало не документирует исходные записи или личность диктора, поэтому
утверждать обучение на живой записи или гарантировать человеческое звучание
по этим материалам нельзя. Здесь используются готовые общедоступные модели;
специального клонирования голоса не выполнялось.

## Изолированный фонемайзер

[Описание автора кастомных данных](https://github.com/mitrokun/espeak-ng-data)
предупреждает, что эти модели требуют изменённого русского фонемайзера.
Подготовлены две отдельные копии стандартных данных Piper 1.8.0, в каждой
заменены только `phondata`, `phondata-manifest`, `phonindex`, `phontab`, `ru_dict`:

- `voice_models/espeak-ng-data-legacy`: ревизия
  `73f339ecd170d35975ef57ee2b22a57ca7456fe3`, ветка `legacy`.
- `voice_models/espeak-ng-data-current`: ревизия
  `68fa929628d0818dff86d4ee7eb976d584158829`, ветка `main`.

В каждую папку записан `custom_manifest.json`: точные URL, размеры и SHA-256
пяти заменённых файлов. Установленные файлы Piper и существующие голоса
сохранены. Соответствие конкретных ревизий моделей и словарей upstream явно
не закрепляет, поэтому сохранены обе пробы для сравнения.

## Воспроизведение

Из папки проекта, среда `.venv-speech` находится рядом:

```bash
../.venv-speech/bin/python sample_voice.py prepare
OMP_NUM_THREADS=2 ../.venv-speech/bin/python sample_voice.py mari --data legacy
OMP_NUM_THREADS=2 ../.venv-speech/bin/python sample_voice.py terra --data legacy
OMP_NUM_THREADS=2 ../.venv-speech/bin/python sample_voice.py mari --data current
OMP_NUM_THREADS=2 ../.venv-speech/bin/python sample_voice.py terra --data current
```

Каждая команда синтеза запускается в своём процессе, потому что Piper
кеширует выбранный фонемайзер глобально. CPU, моно PCM16, 22050 Гц.
Настройки: `length_scale=1.05`, `noise_scale=0.4`, `noise_w_scale=0.45`,
`normalize_audio=True`, `volume=0.9`. Изменения высоты и растягивания готового
аудио нет. Случайные операции модели могут менять отдельные отсчёты между
повторными запусками; SHA-256 рядом с WAV относится к сохранённой пробе.

Текст одинаков во всех пробах:

> Кинематика описывает движение тел. Положение точки задают координаты.
> Чтобы определить перемещение, соединим начальное положение с конечным.
> Путь измеряет длину всей траектории, а перемещение зависит только от двух её концов.

| Файл в `output/voice_samples` | Длительность | Клиппинг |
|---|---:|---:|
| `mari.wav` | 15.81 с | 0 отсчётов |
| `mari_current.wav` | 15.93 с | 0 отсчётов |
| `terra.wav` | 11.31 с | 0 отсчётов |
| `terra_current.wav` | 11.35 с | 0 отсчётов |

В заданном тексте 29 слов. Пробы сохранены с естественной длительностью,
без дополнения до 30 секунд тишиной. При одинаковой настройке Mari читает
медленнее; это кандидат для первого прослушивания. Оценку тембра и
разборчивости следует делать по самим WAV. Результаты технической проверки
записаны в `output/voice_samples/sample_validation.json`; рядом с каждым WAV
сохранён JSON с текстом, параметрами, ревизией фонемайзера и SHA-256 аудио.

## Остальные проверенные варианты

- [Silero v5_6_ru](https://github.com/snakers4/silero-models): `xenia`,
  `kseniya`, `baya`; CPU, 8/24/48 кГц, автоматические ударения/омографы и SSML.
  Веса: `https://models.silero.ai/models/tts/ru/v5_6_ru.pt`.
  Основная фактическая LICENSE содержит CC BY-NC-SA 4.0; README сокращает
  название неточно. Пакет `silero` скачивает веса отдельно.
- Silero `v5_cis_base`/`v5_cis_base_nostress`: MIT
  ([LICENSE_CIS](https://github.com/snakers4/silero-models/blob/master/LICENSE_CIS)),
  ряд русских `ru_*` голосов, без автоматических ударений/омографов.
  Веса: `https://models.silero.ai/models/tts/ru/v5_cis_base_nostress.pt`.
- Официальный каталог Piper предоставляет русские `denis`, `dmitri`,
  `irina`, `ruslan` в качестве medium. Обновление одного runtime не создаёт
  нового русского женского голоса high.

Прямой доступ к хостам моделей Silero, Hugging Face и Microsoft Speech в этой
среде возвращал 403 на уровне исходящего proxy. Использовано доступное
публичное GitHub-зеркало с закреплёнными хешами; никаких прокси-обходов не было.
