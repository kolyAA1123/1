"""Prepare verified MP4, timed text and source ZIP; never bundle voice weights."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import zipfile

from render_lecture import PREFIX, ROOT, load_plan

REPOSITORY = ROOT.parent


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def source_files():
    files = {REPOSITORY / name for name in ("install.sh", "setup_env.sh", "requirements.lock", "AGENTS.md")}
    required = ["lecture_style.py", "visual_style.py", "render_lecture.py", "verify_delivery.py",
                "package_sources.py", "sample_voice.py", "generate_voice.py", "install_voice.sh",
                "script.json", "plan.json", "narration.json", "tekst_ozvuchki.txt", "README.md"]
    for name in required:
        path = ROOT / name
        assert path.is_file(), f"Missing reproducible source: {path}"
        files.add(path)
    for pattern in ("*.py", "*.json", "*.md", "*.srt", "requirements*.txt", "requirements*.lock", "manim.cfg"):
        files.update(ROOT.glob(pattern))
    files.difference_update({ROOT / "elevenlabs_access.py", ROOT / "ELEVENLABS_SETUP.md"})
    files.update((ROOT / "scenes").glob("*.py"))
    files.update((ROOT / "scenes").glob("*_beats.json"))
    files.update((ROOT / "materials").glob("*_analysis.md"))
    files.update((ROOT / "output").glob("*.srt"))
    assert any(path.suffix == ".srt" for path in files), "Missing timed subtitles"
    for folder in ("layout_checks", "sync_checks"):
        reports = sorted((ROOT / "output" / folder).glob("*.json"))
        assert len(reports) == 12, (folder, len(reports))
        files.update(reports)
    # Preserve attribution and pinned manifests, but no ONNX weights, archives,
    # phonemizer dictionaries, recordings, or enormous model/data directories.
    notices = []
    for path in (ROOT / "voice_models").rglob("*"):
        if not path.is_file():
            continue
        name = path.name.lower()
        if path.suffix.lower() not in (".txt", ".md", ".json"):
            continue
        if name.startswith(("license", "notice", "copying")) or "manifest" in name or (path.parent.name == "LICENSES" and name == "readme.md"):
            assert path.stat().st_size < 2 * 1024**2, path
            notices.append(path)
    assert any(path.name.lower().startswith("license") for path in notices), "Missing voice license"
    assert any(path.name.lower().startswith("notice") for path in notices), "Missing voice attribution"
    assert any("manifest" in path.name.lower() for path in notices), "Missing pinned voice manifest"
    files.update(notices)
    for path in files:
        assert path.is_file(), path
        assert path.suffix.lower() not in (".wav", ".onnx", ".zip", ".mp4", ".pdf", ".png", ".jpg", ".pyc"), path
    return sorted(files)


def main():
    plan = load_plan()
    quality_path = ROOT / "output/quality_validation.json"
    quality = json.loads(quality_path.read_text(encoding="utf-8"))
    movie = ROOT / "output" / f"{PREFIX}_1080p60.mp4"
    assert digest(movie) == quality["sha256"] and quality["full_decode_passed"]
    assert quality["audio_streams"] == quality["video_streams"] == 1
    assert quality["narration_parts"] == 120 and quality["chapters"] == 12
    assert quality["frames"] == plan["duration"] * 60
    assert digest(ROOT / "output/audio/narration.wav") == quality["master_audio"]["sha256"]
    assert movie.stat().st_size < 100 * 1024**2, "GitHub single-file limit"
    files = source_files()
    # Fail before copying anything if source/report data changed after verification.
    checked = [path for path in files if path.parent.name in ("layout_checks", "sync_checks")]
    checked += [ROOT / "plan.json", ROOT / "lecture_style.py", ROOT / "visual_style.py"]
    checked += list((ROOT / "scenes").glob("*.py"))
    assert quality_path.stat().st_mtime >= max(path.stat().st_mtime for path in checked)
    shutil.copyfile(movie, REPOSITORY / movie.name)
    text = (ROOT / "tekst_ozvuchki.txt").read_text(encoding="utf-8-sig").rstrip("\r\n") + "\n"
    (REPOSITORY / f"{PREFIX}_tekst.txt").write_text(text, encoding="utf-8-sig", newline="\n")
    archive = REPOSITORY / f"{PREFIX}_sources.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for path in files:
            target.write(path, path.relative_to(REPOSITORY))
        target.write(quality_path, "kinematika_voice_lesson/DELIVERY_CHECK.json")
    with zipfile.ZipFile(archive) as target:
        assert target.testzip() is None
        assert len(target.namelist()) == len(files) + 1
        assert not any(name.lower().endswith((".wav", ".onnx", ".mp4", ".pdf", ".png", ".jpg", ".pyc"))
                       for name in target.namelist())
    print(f"Packaged {movie.name}, {PREFIX}_tekst.txt, and {len(files) + 1} source/check files.", flush=True)


if __name__ == "__main__":
    main()
