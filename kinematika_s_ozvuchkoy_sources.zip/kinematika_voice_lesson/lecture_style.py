"""A shared clock for visible theory, a completed demonstration and its explanation."""
from pathlib import Path
import json
import math
import os
import numpy as np
from manim import *
from visual_style import (
    ChapterScene, txt, eq, axes, arrow, car, freeze,
    BLACK_BG, INK, MUTED, CYAN, GOLD, ROSE, LAVENDER, GRID,
)

ROOT = Path(__file__).resolve().parent
label = txt
equation = eq
velocity_arrow = arrow


def chart(center=(-3.0, 0, 0), width=5.2, height=3.5,
          x_range=(0, 5, 1), y_range=(0, 4, 1), x_label='t', y_label='x'):
    ax = axes(x_range, y_range, width, height, np.array(center, dtype=float))
    ax.x_axis.ticks.set_opacity(0)
    ax.y_axis.ticks.set_opacity(0)
    names = VGroup(eq(x_label, 26, MUTED).next_to(ax.x_axis, RIGHT, buff=.15),
                   eq(y_label, 26, MUTED).next_to(ax.y_axis, UP, buff=.13))
    return ax, VGroup(ax, names)


def lines(*strings, center=(3, 0, 0), size=25, color=INK, width=5.6):
    group = VGroup(*[txt(s, size, color) for s in strings]).arrange(DOWN, buff=.22)
    if group.width > width: group.scale_to_fit_width(width)
    return group.move_to(center)


class LectureScene(ChapterScene):
    """Never announce a result until its demonstration and equation are visible."""

    def construct(self):
        plan = json.loads((ROOT/'plan.json').read_text())
        self.camera.background_color = BLACK_BG
        self.meta = plan['chapters'][self.chapter_id-1]
        self.chapter_duration = self.meta['duration']
        self.started = self.time
        self.layout_samples = []
        self.sync_events = []
        self.caption = None
        title = txt(self.meta['title'], 27).to_edge(LEFT, buff=.55).to_edge(UP, buff=.28)
        if title.width > 11: title.scale_to_fit_width(11).to_edge(LEFT, buff=.55)
        count = txt(f"{self.chapter_id:02d} / {len(plan['chapters'])}", 16, MUTED).move_to([6.1,3.55,0])
        rule = Line([-6.55,2.91,0],[6.55,2.91,0],color=GRID,stroke_width=1)
        self.header = VGroup(title,count,rule)
        self.play(FadeIn(self.header),run_time=.8)
        self.chapter()
        remaining = self.chapter_duration - (self.time-self.started)
        if remaining < 1.18: raise RuntimeError(f'No final fade in chapter {self.chapter_id}: {remaining}')
        self.wait(max(0,remaining-1.2))
        freeze(*self.mobjects)
        self.play(*[FadeOut(m) for m in list(self.mobjects)],run_time=1.2)
        path = ROOT/'output/sync_checks'/f'{self.chapter_id:02d}.json'
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({'chapter':self.chapter_id,'events':self.sync_events,
                                    'duration':self.time-self.started},ensure_ascii=False,indent=2))

    def wait_until(self,stamp,phase):
        actual=self.time-self.started
        # Individual animations may round by one frame. Speech follows the same clock.
        if actual>stamp+.085:
            raise RuntimeError(f'Chapter {self.chapter_id} {phase}: {actual:.3f} > {stamp:.3f}')
        if stamp>actual+1e-6:self.wait(stamp-actual)

    def beat(self,index,note=None,clear=True):
        beat=self.meta['beats'][index]
        self.wait_until(beat['start'],f'beat {index+1}')
        if clear:self.clear_stage(run_time=.6)
        new=txt(note or beat['caption'],23,MUTED).move_to([0,-3.36,0])
        if new.width>12.4:new.scale_to_fit_width(12.4)
        animations=[FadeIn(new)]
        if self.caption is not None:animations.append(FadeOut(self.caption))
        self.play(*animations,run_time=.4)
        self.caption=new

    def intro(self,index):
        beat=self.meta['beats'][index]
        self.sync_events.append({'beat':index+1,'event':'intro_ready','time':self.time-self.started,
                                 'speech_at':beat['intro_at']})
        self.wait_until(beat['intro_at'],f'intro {index+1}')
        self.wait(beat['intro_duration'])

    def act(self,index,*animations,rate_func=smooth):
        beat=self.meta['beats'][index]
        self.wait_until(beat['action_at'],f'action {index+1}')
        self.sync_events.append({'beat':index+1,'event':'action_start','time':self.time-self.started})
        if animations:self.play(*animations,run_time=beat['action_seconds'],rate_func=rate_func)
        else:self.wait(beat['action_seconds'])
        self.sync_events.append({'beat':index+1,'event':'action_end','time':self.time-self.started})

    def result(self,index):
        beat=self.meta['beats'][index]
        self.sync_events.append({'beat':index+1,'event':'result_ready','time':self.time-self.started,
                                 'speech_at':beat['result_at']})
        self.wait_until(beat['result_at'],f'result {index+1}')
        self.wait(beat['result_duration'])

    def audit_layout(self):
        # visual_style uses its own module ROOT; keep the report beside this project.
        super().audit_layout()

