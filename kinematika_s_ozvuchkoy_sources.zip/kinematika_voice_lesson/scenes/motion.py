"""Synchronized theory and completed demonstrations for chapters 5–8.

Each beat starts from its own physical initial state.  Trackers only move forwards;
all arrows are derivatives of the displayed position law in its model time.
"""
import numpy as np
from manim import *
from lecture_style import (
    LectureScene, label, equation, chart, lines, velocity_arrow,
    INK, MUTED, CYAN, GOLD, ROSE, LAVENDER, GRID, freeze,
)


def formula(tex, y=0.5, color=INK, size=34, x=3.25, width=5.5):
    obj = equation(tex, size, color).move_to([x, y, 0])
    if obj.width > width:
        obj.scale_to_fit_width(width)
    return obj


def legend(items, center=(3.2, -1.6, 0), size=23):
    return lines(*items, center=center, size=size, width=5.4)


def road(y=-.45, left=-5.8, right=.15):
    return Line([left,y,0],[right,y,0],color=GRID,stroke_width=2)


def tracked_dot(position, tracker, color=CYAN, radius=.1):
    return always_redraw(lambda: Dot(position(tracker.get_value()), radius=radius, color=color))


def plot_curve(ax, function, color=CYAN, start=0, end=1):
    return ax.plot(function, x_range=[start,end,.01], color=color, stroke_width=3)


def moving_velocity(position, derivative, tracker, scale=.15, offset=UP*.48, color=CYAN):
    return always_redraw(lambda: velocity_arrow(
        position(tracker.get_value())+offset,
        np.asarray(derivative(tracker.get_value()))*scale,
        color=color))


def area_under(ax, func, end, color=CYAN, start=0, opacity=.26):
    """A polygon grows from zero, including the initial zero-area state."""
    stop=max(start+1e-5,float(end))
    xs=np.linspace(start,stop,70)
    points=[ax.c2p(start,0),*[ax.c2p(x,func(x)) for x in xs],ax.c2p(stop,0)]
    return Polygon(*points,stroke_width=0,fill_color=color,fill_opacity=opacity)


class ConstantAcceleration(LectureScene):
    chapter_id=5

    def chapter(self):
        # 1. A constant derivative means equal changes in equal model-time steps.
        self.beat(0)
        u=ValueTracker(0)
        pos=lambda q: np.array([-5.45+4.7*(.15*q+.85*q*q),-.28,0])
        vel=lambda q: np.array([4.7*(.15+1.7*q),0,0])
        dot=tracked_dot(pos,u)
        va=moving_velocity(pos,vel,u,scale=.16)
        aa=always_redraw(lambda: velocity_arrow(pos(u.get_value())+DOWN*.65,[.9,0,0],GOLD))
        marks=VGroup(*[Line(pos(q)+DOWN*.21,pos(q)+DOWN*.35,color=MUTED,stroke_width=1.3)
                       for q in np.linspace(0,1,5)])
        notes=legend(['Голубая стрелка — скорость','Жёлтая стрелка — ускорение'],center=(3.2,-1.45,0))
        self.show(road(),dot,va,aa,marks,formula(r'a_x=\mathrm{const}',1.35,GOLD),notes,run_time=1.7)
        self.intro(0)
        self.act(0,u.animate.set_value(1),rate_func=linear)
        freeze(dot,va,aa)
        self.show(formula(r'\Delta v_x=a_x\Delta t',.25),run_time=1.2)
        self.result(0)

        # 2. The straight velocity graph is a completed construction.
        self.beat(1)
        ax,frame=chart(center=(-3.1,-.05,0),width=5.2,height=3.4,
                       x_range=(0,1,.2),y_range=(0,1.3,.3),x_label='t',y_label='v_x')
        v0=.26; a=.82
        initial=Dot(ax.c2p(0,v0),radius=.07,color=CYAN)
        initial_label=equation('v_{0x}',26,CYAN).next_to(initial,LEFT,buff=.17)
        graph=plot_curve(ax,lambda t:v0+a*t)
        self.show(frame,initial,initial_label,
                  legend(['Начальная скорость: v₀ₓ','Прибавка за время t: aₓt'],center=(3.2,-1.2,0)),
                  formula(r'a_x=\mathrm{const}',1.4,GOLD),run_time=1.7)
        self.intro(1)
        self.act(1,Create(graph),rate_func=linear)
        self.show(formula(r'v_x=v_{0x}+a_xt',.25),run_time=1.2)
        self.result(1)

        # 3. The same clock drives both the coordinate and its velocity.
        self.beat(2)
        u=ValueTracker(0)
        pos=lambda q: np.array([-5.45+4.7*(.2*q+.8*q*q),-.25,0])
        vel=lambda q: np.array([4.7*(.2+1.6*q),0,0])
        dot=tracked_dot(pos,u)
        va=moving_velocity(pos,vel,u,scale=.15)
        origin=Dot(pos(0),radius=.065,color=MUTED)
        displacement=always_redraw(lambda: velocity_arrow(pos(0)+DOWN*.65,
            pos(u.get_value())-pos(0),LAVENDER,width=2))
        self.show(road(),dot,va,origin,displacement,
                  equation('x_0',25,MUTED).move_to([-5.45,-1.4,0]),
                  legend(['x₀ — начальная координата','v₀ₓt — вклад начальной скорости','aₓt²/2 — вклад ускорения'],center=(3.2,-1.45,0),size=22),
                  formula(r'a_x=\mathrm{const}',1.65,GOLD),run_time=1.7)
        self.intro(2)
        self.act(2,u.animate.set_value(1),rate_func=linear)
        freeze(dot,va,displacement)
        self.show(formula(r'x=x_0+v_{0x}t+\frac{a_xt^2}{2}',.45,size=32),run_time=1.2)
        self.result(2)

        # 4. A new run: compare endpoints, without rewinding a visible body.
        self.beat(3)
        u=ValueTracker(0)
        pos=lambda q: np.array([-5.45+4.5*(.25*q+.75*q*q),-.15,0])
        vel=lambda q: np.array([4.5*(.25+1.5*q),0,0])
        dot=tracked_dot(pos,u)
        va=moving_velocity(pos,vel,u,scale=.16)
        ghost=Dot(pos(0),radius=.08,color=MUTED)
        start_label=equation(r'x_0,\ v_{0x}',25,MUTED).move_to([-5.0,-1.15,0])
        self.show(road(),ghost,dot,va,start_label,
                  legend(['Сравним начало и конец','Время можно исключить'],center=(3.2,-1.6,0)),
                  formula(r'a_x=\mathrm{const}',1.55,GOLD),run_time=1.7)
        self.intro(3)
        self.act(3,u.animate.set_value(1),rate_func=linear)
        freeze(dot,va)
        self.show(formula(r'v_x^2-v_{0x}^2=2a_x(x-x_0)',.4,size=31),run_time=1.2)
        self.result(3)

        # 5. Two genuine moving bodies, one gaining speed and one losing it.
        self.beat(4)
        u=ValueTracker(0)
        p_fast=lambda q: np.array([-5.45+4.6*(.2*q+.8*q*q),1.0,0])
        p_slow=lambda q: np.array([-5.45+4.6*(1.8*q-.8*q*q),-1.0,0])
        v_fast=lambda q: np.array([4.6*(.2+1.6*q),0,0])
        v_slow=lambda q: np.array([4.6*(1.8-1.6*q),0,0])
        d1=tracked_dot(p_fast,u);d2=tracked_dot(p_slow,u,color=LAVENDER)
        a1=moving_velocity(p_fast,v_fast,u,scale=.13,offset=UP*.45)
        a2=moving_velocity(p_slow,v_slow,u,scale=.13,offset=UP*.45,color=LAVENDER)
        accel1=always_redraw(lambda:velocity_arrow(p_fast(u.get_value())+DOWN*.4,[.7,0,0],GOLD))
        accel2=always_redraw(lambda:velocity_arrow(p_slow(u.get_value())+DOWN*.4,[-.7,0,0],GOLD))
        self.show(road(.82),road(-1.18),d1,d2,a1,a2,accel1,accel2,
                  formula(r'v_xa_x>0',1.45,CYAN),formula(r'v_xa_x<0',-.55,LAVENDER),
                  legend(['Совпадающие знаки: разгон','Разные знаки: торможение'],center=(3.2,-2.05,0),size=22),run_time=1.7)
        self.intro(4)
        self.act(4,u.animate.set_value(1),rate_func=linear)
        freeze(d1,d2,a1,a2,accel1,accel2)
        self.show(formula(r'a_x=\mathrm{const}',.45,GOLD),run_time=1.2)
        self.result(4)


class Graphs(LectureScene):
    chapter_id=6

    def chapter(self):
        # 1. All three curves describe one motion on the same time interval.
        self.beat(0)
        panels=[];curves=[]
        for center,yr,yl,func,color in [
            ((-4.5,0,0),(0,1.1,.25),'x',lambda t:.15+.25*t+.6*t*t,CYAN),
            ((0,0,0),(0,1.7,.4),'v_x',lambda t:.25+1.2*t,GOLD),
            ((4.5,0,0),(0,1.7,.4),'a_x',lambda t:1.2,LAVENDER)]:
            ax,frame=chart(center=center,width=3.2,height=3.2,x_range=(0,1,.2),y_range=yr,x_label='t',y_label=yl)
            panels.append(frame);curves.append(plot_curve(ax,func,color))
        self.show(*panels,run_time=1.7)
        self.intro(0)
        self.act(0,*[Create(c) for c in curves],rate_func=linear)
        self.show(equation(r'x\ \longrightarrow\ v_x\ \longrightarrow\ a_x',31).move_to([0,-2.45,0]),run_time=1.2)
        self.result(0)

        # 2. The tangent is evaluated at a moving point, not an arbitrary angle.
        self.beat(1)
        ax,frame=chart(center=(-3.1,-.05,0),width=5.1,height=3.5,
                       x_range=(0,1,.2),y_range=(0,1.1,.25),x_label='t',y_label='x')
        f=lambda t:.12+.22*t+.65*t*t
        curve=plot_curve(ax,f)
        u=ValueTracker(.12)
        point=always_redraw(lambda:Dot(ax.c2p(u.get_value(),f(u.get_value())),radius=.075,color=GOLD))
        tangent=always_redraw(lambda:Line(
            ax.c2p(u.get_value()-.11,f(u.get_value())-(.22+1.3*u.get_value())*.11),
            ax.c2p(u.get_value()+.11,f(u.get_value())+(.22+1.3*u.get_value())*.11),color=GOLD,stroke_width=3))
        self.show(frame,legend(['Наклон касательной к x(t)','задаёт проекцию скорости'],center=(3.2,-1.5,0)),run_time=.9)
        self.show(curve,point,tangent,run_time=.9,create=True)
        self.intro(1)
        self.act(1,u.animate.set_value(.84),rate_func=linear)
        freeze(point,tangent)
        self.show(formula(r'v_x=\frac{dx}{dt}',.75,CYAN),
                  formula(r'a_x=\mathrm{const}',-.25,GOLD,size=30),run_time=1.2)
        self.result(1)

        # 3. Complete the rectangle plus triangle before reading the sum.
        self.beat(2)
        ax,frame=chart(center=(-3.1,-.05,0),width=5.1,height=3.5,
                       x_range=(0,1,.2),y_range=(0,1.2,.25),x_label='t',y_label='v_x')
        f=lambda t:.3+.75*t
        curve=plot_curve(ax,f)
        u=ValueTracker(0)
        rectangle=always_redraw(lambda:Polygon(ax.c2p(0,0),ax.c2p(max(u.get_value(),1e-5),0),
            ax.c2p(max(u.get_value(),1e-5),.3),ax.c2p(0,.3),stroke_width=0,fill_color=CYAN,fill_opacity=.33))
        triangle=always_redraw(lambda:Polygon(ax.c2p(0,.3),ax.c2p(max(u.get_value(),1e-5),.3),
            ax.c2p(max(u.get_value(),1e-5),f(max(u.get_value(),1e-5))),stroke_width=0,fill_color=GOLD,fill_opacity=.34))
        self.show(frame,legend(['Прямоугольник: v₀ₓt','Треугольник: aₓt²/2'],center=(3.2,-1.45,0)),run_time=.9)
        self.show(curve,rectangle,triangle,run_time=.9,create=True)
        self.intro(2)
        self.act(2,u.animate.set_value(1),rate_func=linear)
        freeze(rectangle,triangle)
        self.show(formula(r'\Delta x=v_{0x}t+\frac{a_xt^2}{2}',.75,size=32),run_time=1.2)
        self.result(2)

        # 4. A signed acceleration area is a velocity change, not distance.
        self.beat(3)
        ax,frame=chart(center=(-3.1,-.05,0),width=5.1,height=3.5,
                       x_range=(0,1,.2),y_range=(0,1.2,.25),x_label='t',y_label='a_x')
        curve=plot_curve(ax,lambda t:.8,GOLD)
        u=ValueTracker(0)
        fill=always_redraw(lambda:area_under(ax,lambda t:.8,u.get_value(),GOLD))
        self.show(frame,legend(['Площадь под aₓ(t)','равна изменению скорости'],center=(3.2,-1.45,0)),run_time=.9)
        self.show(curve,fill,run_time=.9,create=True)
        self.intro(3)
        self.act(3,u.animate.set_value(1),rate_func=linear)
        freeze(fill)
        self.show(formula(r'\Delta v_x=a_x\Delta t',.75,GOLD),run_time=1.2)
        self.result(3)

        # 5. Equal areas of opposite sign cancel only in displacement.
        self.beat(4)
        ax,frame=chart(center=(-3.1,-.05,0),width=5.1,height=3.5,
                       x_range=(0,1,.2),y_range=(-1.2,1.2,.5),x_label='t',y_label='v_x')
        f=lambda t:1-2*t
        curve=plot_curve(ax,f)
        u=ValueTracker(0)
        posarea=always_redraw(lambda:area_under(ax,f,min(u.get_value(),.5),CYAN))
        negarea=always_redraw(lambda:area_under(ax,f,max(.5,u.get_value()),ROSE,start=.5))
        self.show(frame,legend(['A₊ и A₋ — модули площадей','Путь учитывает оба участка'],center=(3.2,-1.7,0),size=22),run_time=.9)
        self.show(curve,posarea,negarea,run_time=.9,create=True)
        self.intro(4)
        self.act(4,u.animate.set_value(1),rate_func=linear)
        freeze(posarea,negarea)
        self.show(formula(r'\Delta x=A_+-A_-=0',1.15,size=31),
                  formula(r'S=A_++A_->0',.15,GOLD,size=31),run_time=1.2)
        self.result(4)


def fall_stage(upward=True):
    ground=Line([-5.6,-2.0,0],[-.5,-2.0,0],color=MUTED,stroke_width=2)
    if upward:
        axis=Arrow([-5.3,-1.9,0],[-5.3,2.15,0],buff=0,color=MUTED,stroke_width=1.5)
        name=equation('y',26,MUTED).move_to([-5.3,2.42,0])
    else:
        axis=Arrow([-5.3,1.9,0],[-5.3,-1.85,0],buff=0,color=MUTED,stroke_width=1.5)
        name=equation('s',26,MUTED).move_to([-5.65,-1.85,0])
    return VGroup(ground,axis,name)


class FreeFall(LectureScene):
    chapter_id=7

    def chapter(self):
        # 1. A model valid before contact, with air resistance neglected.
        self.beat(0)
        u=ValueTracker(0)
        pos=lambda q:np.array([-3.45,1.8-3.66*q*q,0])
        vel=lambda q:np.array([0,-7.32*q,0])
        dot=tracked_dot(pos,u,radius=.13)
        va=moving_velocity(pos,vel,u,scale=.15,offset=RIGHT*.15)
        gvec=velocity_arrow([-1.55,1.4,0],[0,-1.1,0],GOLD)
        self.show(fall_stage(),dot,va,gvec,equation('g',27,GOLD).next_to(gvec,RIGHT,buff=.2),
                  legend(['Сопротивлением воздуха пренебрегаем','Ускорение направлено к Земле'],center=(3.2,-1.65,0),size=22),
                  formula(r'g\approx9{,}8\ \frac{\text{м}}{\text{с}^{2}}',1.25,GOLD,size=31),run_time=1.7)
        self.intro(0)
        self.act(0,u.animate.set_value(1),rate_func=linear)
        freeze(dot,va)
        self.show(formula(r'a_y=-g',.2,GOLD),run_time=1.2)
        self.result(0)

        # 2. Start a separate drop at rest; the growing gaps are equal time steps.
        self.beat(1)
        u=ValueTracker(0)
        pos=lambda q:np.array([-3.45,1.8-3.66*q*q,0])
        vel=lambda q:np.array([0,-7.32*q,0])
        dot=tracked_dot(pos,u,radius=.13)
        va=moving_velocity(pos,vel,u,scale=.15,offset=RIGHT*.15)
        ghost=VGroup(*[Dot(pos(q),radius=.055,color=MUTED).set_opacity(.5) for q in np.linspace(0,1,5)])
        self.show(fall_stage(),dot,va,ghost,formula(r'v_{0y}=0',1.7,CYAN),
                  legend(['Падение из состояния покоя','Ось y направлена вверх'],center=(3.2,-1.75,0)),run_time=1.7)
        self.intro(1)
        self.act(1,u.animate.set_value(1),rate_func=linear)
        freeze(dot,va)
        self.show(formula(r'v_y=-gt',.65,size=32),
                  formula(r'y=y_0-\frac{gt^2}{2}',-.35,size=32),run_time=1.2)
        self.result(1)

        # 3. Reverse the coordinate convention, never the real gravitational vector.
        self.beat(2)
        u=ValueTracker(0)
        ground=Line([-5.8,-1.8,0],[-.5,-1.8,0],color=GRID)
        upaxis=Arrow([-5.45,-1.75,0],[-5.45,1.8,0],buff=0,color=MUTED)
        downaxis=Arrow([-2.6,1.8,0],[-2.6,-1.75,0],buff=0,color=MUTED)
        p1=lambda q:np.array([-4.6,1.5-3.16*q*q,0])
        p2=lambda q:np.array([-1.7,1.5-3.16*q*q,0])
        d1=tracked_dot(p1,u,radius=.12);d2=tracked_dot(p2,u,radius=.12)
        av1=always_redraw(lambda:velocity_arrow(p1(u.get_value())+RIGHT*.25,[0,-.75,0],GOLD))
        av2=always_redraw(lambda:velocity_arrow(p2(u.get_value())+RIGHT*.25,[0,-.75,0],GOLD))
        self.show(ground,upaxis,downaxis,d1,d2,av1,av2,
                  equation(r'y\uparrow',25,MUTED).move_to([-4.8,2.23,0]),
                  equation(r's\downarrow',25,MUTED).move_to([-1.9,2.23,0]),
                  legend(['Направление силы тяжести одно','Знак проекции зависит от оси'],center=(3.2,-1.75,0),size=22),run_time=1.7)
        self.intro(2)
        self.act(2,u.animate.set_value(1),rate_func=linear)
        freeze(d1,d2,av1,av2)
        self.show(formula(r'a_y=-g',1.2,GOLD),formula(r'a_s=+g',.15,GOLD),run_time=1.2)
        self.result(2)

        # 4. A complete ascent, deliberately ending at the explicitly marked apex.
        self.beat(3)
        u=ValueTracker(0)
        pos=lambda q:np.array([-3.45,-1.8+3.2*(2*q-q*q),0])
        vel=lambda q:np.array([0,6.4*(1-q),0])
        dot=tracked_dot(pos,u,radius=.13)
        va=moving_velocity(pos,vel,u,scale=.16,offset=RIGHT*.13)
        aa=always_redraw(lambda:velocity_arrow(pos(u.get_value())+RIGHT*.75,[0,-.85,0],GOLD))
        top=DashedLine([-4.4,1.4,0],[-2.4,1.4,0],color=GRID)
        self.show(fall_stage(),dot,va,aa,top,formula(r'v_y=v_{0y}-gt',1.5,CYAN,size=32),
                  legend(['Скорость при подъёме уменьшается','Ускорение остаётся вниз'],center=(3.2,-1.7,0),size=22),run_time=1.7)
        self.intro(3)
        self.act(3,u.animate.set_value(1),rate_func=linear)
        freeze(dot,va,aa)
        self.show(formula(r'v_y=0,\qquad a_y=-g\ne0',.3,size=29),
                  Circle(radius=.24,color=GOLD).move_to(pos(1)),run_time=1.2)
        self.result(3)

        # 5. A separate full up-and-down flight reaches the original height.
        self.beat(4)
        u=ValueTracker(0)
        pos=lambda q:np.array([-3.45,-1.8+12.8*q*(1-q),0])
        vel=lambda q:np.array([0,12.8*(1-2*q),0])
        dot=tracked_dot(pos,u,radius=.13)
        va=moving_velocity(pos,vel,u,scale=.095,offset=RIGHT*.15)
        aa=always_redraw(lambda:velocity_arrow(pos(u.get_value())+RIGHT*.8,[0,-.85,0],GOLD))
        self.show(fall_stage(),dot,va,aa,formula(r'a_y=-g',1.55,GOLD),
                  legend(['Старт и финиш на одной высоте','Сопротивления воздуха нет'],center=(3.2,-1.7,0),size=22),run_time=1.7)
        self.intro(4)
        self.act(4,u.animate.set_value(1),rate_func=linear)
        freeze(dot,va,aa)
        self.show(formula(r'y=y_0,\qquad v_y=-v_{0y}',.25,size=31),run_time=1.2)
        self.result(4)


def projectile_stage():
    ax=Axes(x_range=(0,1,.25),y_range=(0,1,.25),x_length=5.6,y_length=3.5,
            axis_config={'color':MUTED,'stroke_width':1.4,'include_ticks':False,
                         'tip_width':.1,'tip_height':.11},tips=True)
    # A stable launch point; unlike Axes.move_to, align its origin explicitly.
    ax.shift(np.array([-5.65,-1.65,0])-ax.c2p(0,0))
    names=VGroup(equation('x',26,MUTED).next_to(ax.x_axis,RIGHT,buff=.15),
                 equation('y',26,MUTED).next_to(ax.y_axis,UP,buff=.15))
    return ax,VGroup(ax,names)


def projectile_run(ax,tracker,height=.8):
    point=lambda q:ax.c2p(q,4*height*q*(1-q))
    dot=tracked_dot(point,tracker,radius=.105)
    trace=TracedPath(dot.get_center,stroke_color=CYAN,stroke_width=2.7)
    return point,dot,trace


class Projectile(LectureScene):
    chapter_id=8

    def chapter(self):
        # 1. Simultaneous projections belong to the same particle and clock.
        self.beat(0)
        ax,frame=projectile_stage();u=ValueTracker(0)
        pos,dot,trace=projectile_run(ax,u)
        guides=always_redraw(lambda:VGroup(
            DashedLine(ax.c2p(u.get_value(),0),pos(u.get_value()),color=GRID,dash_length=.08),
            DashedLine(ax.c2p(0,3.2*u.get_value()*(1-u.get_value())),pos(u.get_value()),color=GRID,dash_length=.08)))
        dx=always_redraw(lambda:Dot(ax.c2p(u.get_value(),0),radius=.065,color=GOLD))
        dy=always_redraw(lambda:Dot(ax.c2p(0,3.2*u.get_value()*(1-u.get_value())),radius=.065,color=LAVENDER))
        self.show(frame,dot,trace,guides,dx,dy,
                  legend(['По горизонтали — равномерно','По вертикали — свободное падение'],center=(3.2,-1.7,0),size=22),run_time=1.7)
        self.intro(0)
        self.act(0,u.animate.set_value(1),rate_func=linear)
        freeze(dot,trace,guides,dx,dy)
        self.show(formula(r'a_x=0,\qquad a_y=-g',.7,size=32),run_time=1.2)
        self.result(0)

        # 2. Resolve one initial vector; the angle is measured from positive x.
        self.beat(1)
        ax,frame=projectile_stage()
        origin=ax.c2p(0,0)
        vx=np.array([2.75,0,0]);vy=np.array([0,2.2,0])
        total=velocity_arrow(origin,vx+vy,CYAN)
        compx=velocity_arrow(origin,vx,GOLD)
        compy=velocity_arrow(origin+vx,vy,LAVENDER)
        helper=DashedLine(origin+vy,origin+vy+vx,color=GRID)
        angle=Arc(radius=.68,start_angle=0,angle=np.arctan2(vy[1],vx[0]),color=MUTED).shift(origin)
        alpha=equation(r'\alpha',25,MUTED).move_to(origin+[.95,.32,0])
        vlab=equation(r'\vec v_0',28,CYAN).move_to(origin+[1.1,1.65,0])
        self.show(frame,total,angle,alpha,vlab,
                  legend(['α отсчитываем от горизонтали','Один вектор — две проекции'],center=(3.2,-1.75,0),size=22),run_time=1.7)
        self.intro(1)
        self.act(1,Create(compx),Create(compy),Create(helper),rate_func=linear)
        self.show(formula(r'v_{0x}=v_0\cos\alpha',1.25,GOLD,size=31),
                  formula(r'v_{0y}=v_0\sin\alpha',.2,LAVENDER,size=31),run_time=1.2)
        self.result(1)

        # 3. The two laws use exactly the same parameter throughout a full flight.
        self.beat(2)
        ax,frame=projectile_stage();u=ValueTracker(0)
        pos,dot,trace=projectile_run(ax,u)
        guides=always_redraw(lambda:VGroup(
            DashedLine(ax.c2p(u.get_value(),0),pos(u.get_value()),color=GRID,dash_length=.08),
            DashedLine(ax.c2p(0,3.2*u.get_value()*(1-u.get_value())),pos(u.get_value()),color=GRID,dash_length=.08)))
        self.show(frame,dot,trace,guides,formula(r'x_0=y_0=0',1.9,MUTED,size=29),
                  legend(['Одно время t задаёт','сразу обе координаты'],center=(3.2,-1.75,0)),run_time=1.7)
        self.intro(2)
        self.act(2,u.animate.set_value(1),rate_func=linear)
        freeze(dot,trace,guides)
        self.show(formula(r'x=v_0\cos\alpha\,t',.8,size=31),
                  formula(r'y=v_0\sin\alpha\,t-\frac{gt^2}{2}',-.25,size=30),run_time=1.2)
        self.result(2)

        # 4. These formulas are explicitly conditional on equal endpoint heights.
        self.beat(3)
        ax,frame=projectile_stage();u=ValueTracker(0)
        pos,dot,trace=projectile_run(ax,u)
        ground=Line(ax.c2p(0,0),ax.c2p(1,0),color=GOLD,stroke_width=2)
        cond=label('Старт и финиш на одной высоте',22,GOLD).move_to([-2.8,2.3,0])
        if cond.width>5.7:cond.scale_to_fit_width(5.7)
        landing=Dot(ax.c2p(1,0),radius=.06,color=MUTED)
        self.show(frame,ground,dot,trace,landing,cond,
                  legend(['Без сопротивления воздуха','Начало координат — в точке броска'],center=(3.2,-1.85,0),size=21),run_time=1.7)
        self.intro(3)
        self.act(3,u.animate.set_value(1),rate_func=linear)
        freeze(dot,trace)
        length=DoubleArrow(ax.c2p(0,0)+DOWN*.55,ax.c2p(1,0)+DOWN*.55,buff=0,color=GOLD,stroke_width=2)
        self.show(formula(r'T=\frac{2v_0\sin\alpha}{g}',1.25,size=31),
                  formula(r'L=\frac{v_0^2\sin2\alpha}{g}',.1,size=31),length,
                  formula(r'\alpha=45^\circ\ \Rightarrow\ \sin2\alpha=1',-1.0,GOLD,size=26),
                  equation('L',25,GOLD).next_to(length,DOWN,buff=.1),run_time=1.2)
        self.result(3)

        # 5. A fresh horizontal launch falls all the way to the ground.
        self.beat(4)
        u=ValueTracker(0)
        pos=lambda q:np.array([-5.3+4.8*q,1.5-3.35*q*q,0])
        vel=lambda q:np.array([4.8,-6.7*q,0])
        dot=tracked_dot(pos,u,radius=.12)
        trace=TracedPath(dot.get_center,stroke_color=CYAN,stroke_width=2.7)
        va=moving_velocity(pos,vel,u,scale=.16,offset=UP*.22)
        ground=Line([-5.8,-2,0],[.25,-2,0],color=MUTED)
        platform=VGroup(Line([-5.8,1.38,0],[-5.0,1.38,0],color=MUTED),
                        Line([-5.0,1.38,0],[-5.0,-2,0],color=GRID))
        height=DoubleArrow([-5.65,-1.85,0],[-5.65,1.5,0],buff=0,color=MUTED,stroke_width=1.6)
        hlabel=equation('h',26,MUTED).move_to([-6.02,-.2,0])
        self.show(ground,platform,height,hlabel,dot,trace,va,formula(r'v_{0y}=0',1.8,LAVENDER,size=31),
                  legend(['Горизонтальный бросок с высоты h','Вертикальная скорость растёт вниз'],center=(3.2,-1.75,0),size=22),run_time=1.7)
        self.intro(4)
        self.act(4,u.animate.set_value(1),rate_func=linear)
        freeze(dot,trace,va)
        self.show(formula(r'x=v_0t',.75,size=32),
                  formula(r'y=h-\frac{gt^2}{2}',-.25,size=32),run_time=1.2)
        self.result(4)
