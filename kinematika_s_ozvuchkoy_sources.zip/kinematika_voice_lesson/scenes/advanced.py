"""Completed visual arguments for chapters 9–12 of the voiced lecture.

Each beat has an independent, explicitly introduced stage.  Speech is scheduled
by LectureScene only after the corresponding visual state is fully visible.
"""
from manim import *
import numpy as np

from lecture_style import (
    LectureScene, txt, eq, arrow, car, freeze,
    INK, MUTED, CYAN, GOLD, ROSE, LAVENDER, GRID,
)


def formulas(*strings, center=(2.7, .15, 0), size=33, color=INK, width=5.5):
    rows = VGroup(*[eq(s, size, color) for s in strings]).arrange(DOWN, buff=.38)
    if rows.width > width:
        rows.scale_to_fit_width(width)
    return rows.move_to(center)


def words(*strings, center=(2.8, 0, 0), size=24, color=MUTED, width=5.2):
    rows = VGroup(*[txt(s, size, color) for s in strings]).arrange(DOWN, buff=.25)
    if rows.width > width:
        rows.scale_to_fit_width(width)
    return rows.move_to(center)


def circle_stage(radius=1.55, center=(-3.25, -.1, 0), color=GRID):
    center = np.array(center, dtype=float)
    circle = Circle(radius=radius, color=color, stroke_width=2).move_to(center)
    origin = Dot(center, radius=.045, color=MUTED)
    origin_name = eq('O', 25, MUTED).move_to(center + LEFT*.2 + DOWN*.25)
    return center, VGroup(circle, origin, origin_name)


def throwing_stage(top=False):
    """One fixed scale; the following beats never visibly rewind the ball."""
    bottom = np.array([-3.7, -2.0, 0])
    summit = bottom + UP*3.7
    axis = Arrow(bottom+DOWN*.15, bottom+UP*4.5, buff=0,
                 color=MUTED, stroke_width=1.6,
                 max_tip_length_to_length_ratio=.04)
    axis_name = eq('y', 27, MUTED).next_to(axis.get_end(), RIGHT, buff=.18)
    ground = Line(bottom+LEFT*1.3, bottom+RIGHT*1.3, color=GRID)
    zero = eq('0', 25, MUTED).move_to(bottom+LEFT*.25+DOWN*.27)
    ball = Dot(summit if top else bottom, radius=.105, color=CYAN)
    return bottom, summit, ball, VGroup(axis, axis_name, ground, zero)


class CircularMotion(LectureScene):
    chapter_id = 9

    def clock(self, tracker, center=(2.8, 1.5, 0)):
        x, y, _ = center
        line = Line([x-1.4, y, 0], [x+1.4, y, 0], color=GRID)
        labels = VGroup(eq('0', 25, MUTED).move_to([x-1.4, y-.4, 0]),
                        eq('T', 25, GOLD).move_to([x+1.4, y-.4, 0]),
                        eq('t', 25, MUTED).move_to([x-1.8, y, 0]))
        hand = always_redraw(lambda: Dot([x-1.4+2.8*tracker.get_value()/TAU, y, 0],
                                        radius=.075, color=GOLD))
        return VGroup(line, labels), hand

    def chapter(self):
        self.beat(0)
        center, stage = circle_stage()
        theta = ValueTracker(0)
        position = lambda: center+1.55*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0])
        point = always_redraw(lambda: Dot(position(), radius=.095, color=CYAN))
        velocity = always_redraw(lambda: arrow(position(), .95*np.array([-np.sin(theta.get_value()),np.cos(theta.get_value()),0]), CYAN))
        radius = always_redraw(lambda: Line(center, position(), color=GRID, stroke_width=1.5))
        trace = always_redraw(lambda: Arc(radius=1.55, angle=max(.001, theta.get_value()),
                               color=CYAN, stroke_width=4).move_arc_center_to(center))
        start = Line(center+RIGHT*1.55+DOWN*.13, center+RIGHT*1.55+UP*.13, color=GOLD)
        names = VGroup(eq('R', 28, MUTED).move_to(center+RIGHT*.7+DOWN*.3),
                       eq(r'\vec v', 28, CYAN).move_to([-1.35, .65, 0]))
        clock, hand = self.clock(theta)
        concepts = words('Период T  ·  частота ν', center=(2.8, 2.3, 0), size=24)
        answer = formulas(r'\nu=\frac1T', r'[\nu]=\mathrm{Hz}', center=(2.8, -.7, 0), size=36)
        self.show(stage, start, radius, point, velocity, trace, names, clock, hand, concepts, run_time=1.4)
        self.intro(0)
        self.act(0, theta.animate.set_value(TAU), rate_func=linear)
        freeze(point, velocity, radius, trace, hand)
        self.play(Write(answer), run_time=1.2)
        self.result(0)

        self.beat(1)
        center, stage = circle_stage()
        theta = ValueTracker(0)
        position = lambda: center+1.55*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0])
        point = always_redraw(lambda: Dot(position(), radius=.09, color=CYAN))
        radius = always_redraw(lambda: Line(center, position(), color=GOLD, stroke_width=2))
        angle = always_redraw(lambda: Arc(radius=.7, angle=max(.001, theta.get_value()),
                               color=GOLD, stroke_width=3).move_arc_center_to(center))
        start = Line(center, center+RIGHT*1.55, color=GRID, stroke_width=1.5)
        phi = eq(r'\varphi', 29, GOLD).move_to(center+RIGHT*.8+DOWN*.35)
        clock, hand = self.clock(theta, center=(2.8, 1.8, 0))
        definition = formulas(r'\omega=\frac{\Delta\varphi}{\Delta t}', center=(2.8, .4, 0), size=36)
        answer = formulas(r'\omega=\frac{2\pi}{T}=2\pi\nu', r'[\omega]=\mathrm{rad/s}',
                          center=(2.8, -1.25, 0), size=33)
        full_angle = eq(r'2\pi', 29, GOLD).move_to(center+RIGHT*.8+DOWN*.35)
        self.show(stage, start, point, radius, angle, phi, clock, hand, definition, run_time=1.4)
        self.intro(1)
        self.act(1, theta.animate.set_value(TAU), rate_func=linear)
        freeze(point, radius, angle, hand)
        self.play(Write(answer), Transform(phi, full_angle), run_time=1.2)
        self.result(1)

        self.beat(2)
        center = np.array([-3.4, -.25, 0])
        r1, r2 = .85, 1.65
        theta = ValueTracker(0)
        circles = VGroup(Circle(radius=r1, color=GRID, stroke_width=2).move_to(center),
                         Circle(radius=r2, color=GRID, stroke_width=2).move_to(center),
                         Dot(center, radius=.045, color=MUTED))
        radii = VGroup(Line(center, center+LEFT*r1, color=CYAN, stroke_width=1.5),
                       Line(center, center+np.array([-1, -1, 0])/np.sqrt(2)*r2, color=GOLD, stroke_width=1.5))
        names = VGroup(eq('R_1', 27, CYAN).move_to(center+LEFT*.55+UP*.25),
                       eq('R_2', 27, GOLD).move_to(center+LEFT*.55+DOWN*1.15))
        points, velocities, arcs = VGroup(), VGroup(), VGroup()
        for radius_value, color in ((r1, CYAN), (r2, GOLD)):
            def pos(r=radius_value):
                return center+r*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0])
            points.add(always_redraw(lambda p=pos, c=color: Dot(p(), radius=.085, color=c)))
            velocities.add(always_redraw(lambda p=pos, r=radius_value, c=color:
                arrow(p(), .65*r*np.array([-np.sin(theta.get_value()),np.cos(theta.get_value()),0]), c)))
            arcs.add(always_redraw(lambda r=radius_value, c=color:
                Arc(radius=r, angle=max(.001, theta.get_value()), color=c,
                    stroke_width=4).move_arc_center_to(center)))
        condition = formulas(r'\omega_1=\omega_2', r'\Delta t_1=\Delta t_2',
                             center=(2.8, 1.35, 0), size=31)
        answer = formulas(r'v=\omega R', center=(2.8, -.4, 0), size=44)
        explanation = words('Одинаковый угол', 'больший радиус — большая дуга',
                            center=(2.8, -1.7, 0), size=22)
        self.show(circles, radii, names, points, velocities, arcs, condition, run_time=1.4)
        self.intro(2)
        self.act(2, theta.animate.set_value(PI/2), rate_func=linear)
        freeze(points, velocities, arcs)
        self.play(Write(answer), FadeIn(explanation), run_time=1.2)
        self.result(2)

        self.beat(3)
        center, stage = circle_stage()
        phi_value = 1.25
        radius = Line(center, center+RIGHT*1.55, color=MUTED)
        end_radius = Line(center, center+1.55*np.array([np.cos(phi_value),np.sin(phi_value),0]), color=MUTED)
        angle = Arc(radius=.5, angle=phi_value, color=GOLD, stroke_width=2).move_arc_center_to(center)
        endpoints = VGroup(Dot(center+RIGHT*1.55, radius=.055, color=GOLD),
                           Dot(center+1.55*np.array([np.cos(phi_value),np.sin(phi_value),0]), radius=.055, color=GOLD))
        names = VGroup(eq('R', 29, MUTED).move_to(center+RIGHT*.75+DOWN*.3),
                       eq(r'\varphi', 29, GOLD).move_to(center+np.array([.75,.5,0])))
        radian = txt('φ в радианах', 25, GOLD).move_to([2.8, 1.8, 0])
        arc = Arc(radius=1.55, angle=phi_value, color=CYAN, stroke_width=5).move_arc_center_to(center)
        copy = arc.copy()
        straight = Line([1.6, .65, 0], [1.6+1.55*phi_value, .65, 0], color=CYAN, stroke_width=5)
        s_name = eq('s', 32, CYAN).move_to([2.55, .2, 0])
        answer = formulas(r'\varphi=\frac{s}{R}', r's=R\varphi', center=(2.8, -1.35, 0), size=35)
        self.show(stage, radius, end_radius, angle, endpoints, names, radian, run_time=1.4)
        self.intro(3)
        self.act(3, Succession(Create(arc), Transform(copy, straight)))
        self.play(Write(answer), FadeIn(s_name), run_time=1.2)
        self.result(3)

        self.beat(4)
        center, stage = circle_stage(radius=1.45, center=(-3.8, -.15, 0))
        theta = ValueTracker(0)
        theta_end = .35
        pos = lambda t: center+1.45*np.array([np.cos(t),np.sin(t),0])
        tangent = lambda t: 1.45*np.array([-np.sin(t),np.cos(t),0])
        point = always_redraw(lambda: Dot(pos(theta.get_value()), radius=.09, color=CYAN))
        velocity = always_redraw(lambda: arrow(pos(theta.get_value()), tangent(theta.get_value())*.65, CYAN))
        short_arc = Arc(radius=1.45, angle=theta_end, color=GOLD, stroke_width=4).move_arc_center_to(center)
        copy1 = arrow(pos(0), tangent(0), CYAN)
        copy2 = arrow(pos(theta_end), tangent(theta_end), LAVENDER)
        q = np.array([2.6, .3, 0])
        target1 = arrow(q, tangent(0), CYAN)
        target2 = arrow(q, tangent(theta_end), LAVENDER)
        difference = arrow(q+tangent(0), tangent(theta_end)-tangent(0), GOLD)
        labels = VGroup(eq(r'\vec v_1', 27, CYAN).move_to([3.25, 1.75, 0]),
                        eq(r'\vec v_2', 27, LAVENDER).move_to([1.5, 1.7, 0]),
                        eq(r'\Delta\vec v', 27, GOLD).move_to([2.35, 2.3, 0]))
        dt = eq(r'\Delta t', 29, MUTED).move_to([2.6, -.15, 0])
        acceleration = arrow(pos(theta_end), -.95*np.array([np.cos(theta_end),np.sin(theta_end),0]), ROSE)
        direction_labels = VGroup(eq(r'\vec v', 28, CYAN).move_to([-2.0, 1.3, 0]),
                                 eq(r'\vec a', 28, ROSE).move_to([-2.85, -.25, 0]))
        comparison = VGroup(copy1, copy2, difference)
        def reduce_interval(group, alpha):
            delta = interpolate(theta_end, .06, alpha)
            v1, v2 = tangent(theta_end-delta), tangent(theta_end)
            group[0].become(arrow(q, v1, CYAN))
            group[1].become(arrow(q, v2, LAVENDER))
            group[2].become(arrow(q+v1, v2-v1, GOLD))
        answer = formulas(r'a=\frac{v^2}{R}=\omega^2R', r'\vec a\perp\vec v',
                          center=(2.8, -1.5, 0), size=33)
        self.show(stage, short_arc, point, velocity, copy1, copy2, dt, run_time=1.4)
        self.intro(4)
        self.act(4, Succession(theta.animate.set_value(theta_end),
                    AnimationGroup(Transform(copy1, target1), Transform(copy2, target2)),
                    Create(difference), UpdateFromAlphaFunc(comparison, reduce_interval),
                    Create(acceleration)))
        freeze(point, velocity)
        self.play(Write(answer), FadeIn(labels), FadeIn(direction_labels),
                  Transform(dt, eq(r'\Delta t\to0', 29, MUTED).move_to(dt)), run_time=1.2)
        self.result(4)


class RelativeMotion(LectureScene):
    chapter_id = 10

    def road_pair(self, opposing=False):
        a = car(CYAN).move_to([-4.4, .85, 0])
        b = car(GOLD).move_to([-4.4, -1.15, 0])
        if opposing:
            b.flip(UP)
        roads = VGroup(*[Line([-5.6, y-.3, 0], [-.65, y-.3, 0],
                             color=GRID, stroke_width=2) for y in (.85, -1.15)])
        names = VGroup(txt('A', 24, CYAN).move_to([-5.1, .85, 0]),
                       txt('B', 24, GOLD).move_to([-5.1, -1.15, 0]))
        return a, b, VGroup(roads, names)

    def chapter(self):
        # 1. The observer is explicitly attached to the frame being subtracted.
        self.beat(0)
        a, b, roads = self.road_pair()
        va = arrow([-4.4, 1.5, 0], [1.7, 0, 0], CYAN)
        vb = arrow([-4.4, -.5, 0], [.85, 0, 0], GOLD)
        labels = VGroup(eq(r'\vec v_A', 29, CYAN).move_to([-2.4, 1.5, 0]),
                        eq(r'\vec v_B', 29, GOLD).move_to([-3.05, -.5, 0]))
        earth = txt('Система Земли', 22, MUTED).move_to([-3.3, -2.25, 0])
        observer = VGroup(Circle(radius=.1, color=GOLD).move_to(b.get_center()+UP*.55),
                          txt('наблюдатель B', 21, GOLD).move_to([2.7, 1.6, 0]))
        relation = formulas(r'\vec v_{A/B}=\vec v_A-\vec v_B', center=(2.7, .35, 0))
        meaning = txt('A относительно B', 24, MUTED).move_to([2.7, -.6, 0])
        self.show(a, b, roads, va, vb, labels, earth, run_time=1.4)
        self.intro(0)
        self.act(0, FadeIn(observer), Write(relation), FadeIn(meaning))
        self.result(0)

        # 2. A true change of frame: B is stationary and A has relative speed 2.
        self.beat(1)
        a, b, roads = self.road_pair()
        va = arrow([-4.4, 1.5, 0], [1.8, 0, 0], CYAN)
        vb = arrow([-4.4, -.5, 0], [.6, 0, 0], GOLD)
        va_label = eq(r'v_A=+3\,\mathrm{m/s}', 28, CYAN).move_to([-3.15, 2.15, 0])
        vb_label = eq(r'v_B=+1\,\mathrm{m/s}', 28, GOLD).move_to([-3.15, -2.05, 0])
        earth = txt('Система Земли', 23, MUTED).move_to([2.7, 1.85, 0])
        relation = formulas(r'\vec v_{A/B}=\vec v_A-\vec v_B', center=(2.7, .95, 0), size=30)
        answer = formulas(r'v_{A/B}=3-1=2\,\mathrm{m/s}', r'v_{B/B}=0',
                          center=(2.7, -.65, 0), size=31)
        frame_b = txt('Система автомобиля B', 23, GOLD).move_to(earth)
        relative_label = eq(r'v_{A/B}=+2\,\mathrm{m/s}', 28, CYAN).move_to(va_label)
        stopped_label = eq(r'v_{B/B}=0', 28, GOLD).move_to(vb_label)
        self.show(a, b, roads, va, vb, va_label, vb_label, earth, relation, run_time=1.4)
        self.intro(1)
        self.act(1, a.animate.shift(RIGHT*1.5),
                 Transform(va, arrow([-2.9, 1.5, 0], [1.2, 0, 0], CYAN)),
                 FadeOut(vb), Transform(earth, frame_b), Transform(va_label, relative_label),
                 Transform(vb_label, stopped_label), Write(answer), rate_func=linear)
        self.result(1)

        # 3. Signed projections must remain visible in the opposite-direction case.
        self.beat(2)
        a, b, roads = self.road_pair(opposing=True)
        va = arrow([-4.4, 1.5, 0], [1.8, 0, 0], CYAN)
        vb = arrow([-3.1, -.5, 0], [-.6, 0, 0], GOLD)
        labels = VGroup(eq(r'v_A=+3\,\mathrm{m/s}', 28, CYAN).move_to([-3.2, 2.15, 0]),
                        eq(r'v_B=-1\,\mathrm{m/s}', 28, GOLD).move_to([-3.2, -2.05, 0]))
        positive = VGroup(arrow([.8, 1.8, 0], [1.1, 0, 0], MUTED),
                          eq('+x', 25, MUTED).move_to([2.3, 1.8, 0]))
        relation = formulas(r'\vec v_{A/B}=\vec v_A-\vec v_B', center=(2.7, .8, 0), size=30)
        answer = formulas(r'v_{A/B}=3-(-1)=4\,\mathrm{m/s}', center=(2.7, -.35, 0), size=31)
        relative = VGroup(arrow([1.0, -1.5, 0], [2.4, 0, 0], LAVENDER),
                          eq(r'\vec v_{A/B}', 29, LAVENDER).move_to([4.0, -1.5, 0]))
        self.show(a, b, roads, va, vb, labels, positive, relation, run_time=1.4)
        self.intro(2)
        self.act(2, Write(answer), Create(relative))
        self.result(2)

        # 4. The difference is the connector from the tip of B to the tip of A.
        self.beat(3)
        origin = np.array([-4.8, -1.35, 0])
        end_a = origin + np.array([3.2, 1.0, 0])
        end_b = origin + np.array([.9, 2.8, 0])
        a = arrow(origin, end_a-origin, CYAN)
        b = arrow(origin, end_b-origin, GOLD)
        names = VGroup(eq(r'\vec v_A', 30, CYAN).move_to([-2.45, -1.12, 0]),
                       eq(r'\vec v_B', 30, GOLD).move_to([-4.8, .55, 0]),
                       eq('O', 23, MUTED).move_to(origin+DOWN*.3))
        relation = formulas(r'\vec v_{A/B}=\vec v_A-\vec v_B', center=(2.8, .75, 0))
        difference = arrow(end_b, end_a-end_b, LAVENDER)
        difference_name = eq(r'\vec v_{A/B}', 30, LAVENDER).move_to([-2.25, .85, 0])
        explanation = words('От конца второго', 'к концу первого', center=(2.8, -.65, 0))
        self.show(a, b, names, relation, run_time=1.4)
        self.intro(3)
        self.act(3, Create(difference), FadeIn(difference_name), FadeIn(explanation))
        self.result(3)

        # 5. Explicit head-to-tail construction, rather than scalar arithmetic.
        self.beat(4)
        origin = np.array([-4.8, -1.35, 0])
        rel_v = np.array([2.4, .1, 0])
        b_v = np.array([.8, 2.4, 0])
        relative = arrow(origin, rel_v, LAVENDER)
        b = arrow(origin, b_v, GOLD)
        names = VGroup(eq(r'\vec v_{A/B}', 29, LAVENDER).move_to([-3.6, -1.85, 0]),
                       eq(r'\vec v_B', 29, GOLD).move_to([-4.9, .35, 0]))
        shifted_name = eq(r'\vec v_B', 29, GOLD).move_to([-1.6, .05, 0])
        total = arrow(origin, rel_v+b_v, CYAN)
        total_name = eq(r'\vec v_A', 29, CYAN).move_to([-3.4, .7, 0])
        relation = formulas(r'\vec v_A=\vec v_{A/B}+\vec v_B', center=(2.7, .7, 0))
        conditions = words('Инерциальные системы', 'равномерное движение систем', center=(2.7, -1.0, 0), size=22)
        self.show(relative, b, names, conditions, run_time=1.4)
        self.intro(4)
        self.act(4, b.animate.shift(rel_v), Transform(names[1], shifted_name),
                 Create(total), FadeIn(total_name), Write(relation))
        self.result(4)


class WorkedExample(LectureScene):
    chapter_id = 11

    def chapter(self):
        self.beat(0)
        bottom, summit, ball, stage = throwing_stage()
        # The opposing arrows occupy different lanes and have separate labels.
        v = arrow(bottom+LEFT*.65, UP*1.45, CYAN)
        g = arrow(bottom+RIGHT*.65+UP*1.45, DOWN*1.25, ROSE)
        names = VGroup(eq(r'\vec v_0', 28, CYAN).move_to([-4.8, -1.2, 0]),
                       eq(r'\vec g', 28, ROSE).move_to([-2.55, -1.2, 0]))
        givens = formulas(r'v_0=20\,\mathrm{m/s}', r'g=10\,\mathrm{m/s^2}', r'y_0=0',
                          center=(2.7, .9, 0), size=32)
        assumptions = words('Без сопротивления воздуха', 'ускорение тяжести постоянно',
                            center=(2.7, -1.0, 0), size=21)
        questions = formulas(r't_{\max}=?\qquad h_{\max}=?', center=(2.7, -2.15, 0), size=31, color=GOLD)
        self.show(stage, ball, v, g, names, givens, assumptions, run_time=1.4)
        self.intro(0)
        self.act(0, Write(questions), Indicate(stage[3], color=GOLD))
        self.result(0)

        self.beat(1)
        bottom, summit, ball, stage = throwing_stage()
        v = arrow(bottom+LEFT*.65, UP*1.45, CYAN)
        g = arrow(bottom+RIGHT*.65+UP*1.45, DOWN*1.25, ROSE)
        names = VGroup(eq(r'\vec v_0', 28, CYAN).move_to([-4.8, -1.2, 0]),
                       eq(r'\vec g', 28, ROSE).move_to([-2.55, -1.2, 0]))
        axis_sign = eq('+y', 27, MUTED).move_to([-2.8, 2.2, 0])
        givens = formulas(r'v_0=+20\,\mathrm{m/s}', r'a_y=-g', center=(2.7, 1.3, 0), size=31)
        law = formulas(r'v_y=v_0-gt=20-10t', r'a_y=-10\,\mathrm{m/s^2}', center=(2.7, -.55, 0), size=33)
        self.show(stage, ball, v, g, names, axis_sign, givens, run_time=1.4)
        self.intro(1)
        self.act(1, Write(law))
        self.result(1)

        self.beat(2)
        bottom, summit, ball, stage = throwing_stage()
        tau = ValueTracker(0)
        ball.add_updater(lambda mob: mob.move_to(bottom+UP*(20*tau.get_value()-5*tau.get_value()**2)*3.7/20))
        v = always_redraw(lambda: arrow(ball.get_center()+LEFT*.6,
                                      UP*1.3*max(0, 1-tau.get_value()/2), CYAN))
        g = always_redraw(lambda: arrow(ball.get_center()+RIGHT*.6+UP*.6, DOWN*1.1, ROSE))
        names = VGroup(eq(r'v_y', 28, CYAN).move_to([-4.95, .0, 0]),
                       eq(r'a_y=-g\ne0', 28, ROSE).move_to([-1.75, -1.35, 0]))
        law = formulas(r'v_y=20-10t', r'\text{В вершине: }v_y=0',
                       center=(2.7, 1.15, 0), size=32)
        solve = formulas(r'0=20-10t', r't_{\max}=\frac{20}{10}=2\,\mathrm{s}',
                         center=(2.7, -.9, 0), size=33, color=GOLD)
        self.show(stage, ball, v, g, names, law, run_time=1.4)
        self.intro(2)
        self.act(2, tau.animate.set_value(2), rate_func=linear)
        freeze(ball, v, g)
        self.play(Write(solve), run_time=1.2)
        self.result(2)

        self.beat(3)
        bottom, summit, ball, stage = throwing_stage(top=True)
        brace = BraceBetweenPoints(bottom+LEFT*.65, summit+LEFT*.65, direction=LEFT, color=GOLD)
        known = formulas(r't_{\max}=2\,\mathrm{s}', r'v_y=0', center=(2.7, 1.55, 0), size=31)
        law = formulas(r'h=v_0t-\frac{gt^2}{2}',
                       r'h_{\max}=20\cdot2-\frac{10\cdot2^2}{2}=20\,\mathrm{m}',
                       center=(2.7, -.25, 0), size=32)
        height = eq(r'20\,\mathrm{m}', 28, GOLD).next_to(brace, LEFT, buff=.2)
        self.show(stage, ball, brace, known, run_time=1.4)
        self.intro(3)
        self.act(3, Write(law), FadeIn(height))
        self.result(3)

        self.beat(4)
        bottom, summit, ball, stage = throwing_stage(top=True)
        brace = BraceBetweenPoints(bottom+LEFT*.65, summit+LEFT*.65, direction=LEFT, color=GOLD)
        height = eq(r'20\,\mathrm{m}', 28, GOLD).next_to(brace, LEFT, buff=.2)
        known = formulas(r'v_0=20\,\mathrm{m/s},\quad v_y=0', r't=2\,\mathrm{s}',
                         center=(2.7, 1.45, 0), size=29)
        check = formulas(r'\overline v_y=\frac{20+0}{2}=10\,\mathrm{m/s}',
                         r'h=\overline v_y t=10\cdot2=20\,\mathrm{m}',
                         center=(2.7, -.55, 0), size=32, color=GOLD)
        self.show(stage, ball, brace, height, known, run_time=1.4)
        self.intro(4)
        self.act(4, Write(check), Indicate(height, color=CYAN))
        self.result(4)


class Finale(LectureScene):
    chapter_id = 12

    def chapter(self):
        self.beat(0)
        axis = Arrow([-5.7, -.55, 0], [-.9, -.55, 0], buff=0, color=MUTED,
                     stroke_width=1.6, max_tip_length_to_length_ratio=.035)
        axis_name = eq('x', 26, MUTED).next_to(axis.get_end(), RIGHT, buff=.15)
        origin = Dot([-5.2, -.55, 0], radius=.055, color=MUTED)
        body_ref = words('Тело отсчёта', center=(-4.9, -1.7, 0), size=21)
        point = Dot([-4.3, -.55, 0], color=CYAN, radius=.095)
        first = VGroup(eq('x_0', 29, CYAN).move_to([-4.3, -.95, 0]),
                       eq('t_0', 27, MUTED).move_to([-4.3, .1, 0]))
        clock = VGroup(Circle(radius=.4, color=MUTED).move_to([2.7, 1.6, 0]),
                       Line([2.7, 1.6, 0], [2.7, 1.87, 0], color=GOLD),
                       Line([2.7, 1.6, 0], [2.9, 1.48, 0], color=GOLD))
        clock_name = txt('Часы', 21, MUTED).move_to([2.7, .9, 0])
        next_point = Dot([-1.9, -.55, 0], color=GOLD, radius=.095)
        second = VGroup(eq('x(t)', 29, GOLD).move_to([-1.9, -.95, 0]),
                        eq('t', 27, MUTED).move_to([-1.9, .1, 0]))
        relation = formulas(r'x=x(t)', center=(2.7, -.4, 0), size=39)
        self.show(axis, axis_name, origin, body_ref, point, first, clock, clock_name, run_time=1.4)
        self.intro(0)
        self.act(0, FadeIn(next_point), FadeIn(second), Write(relation),
                 Create(DashedLine(point.get_center()+UP*.75, next_point.get_center()+UP*.75, color=GRID)))
        self.result(0)

        self.beat(1)
        center, stage = circle_stage()
        circle = stage[0]
        start = center+RIGHT*1.55
        dot = Dot(start, radius=.09, color=CYAN)
        theta = ValueTracker(0)
        dot.add_updater(lambda mob: mob.move_to(center+1.55*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0])))
        track = VMobject(color=CYAN, stroke_width=4)
        track.add_updater(lambda mob: mob.become(Arc(radius=1.55, start_angle=0,
                                                   angle=max(.001, theta.get_value()), color=CYAN,
                                                   stroke_width=4).move_arc_center_to(center)))
        names = words('Путь — длина траектории', 'Перемещение — от начала к концу',
                      center=(2.8, 1.35, 0), size=22)
        start_label = txt('начало = конец', 22, GOLD).move_to([-3.25, -2.3, 0])
        answer = formulas(r'S>0', r'\Delta\vec r=\vec0', center=(2.8, -.65, 0), size=38)
        self.show(circle, dot, track, names, run_time=1.4)
        self.intro(1)
        self.act(1, theta.animate.set_value(TAU), rate_func=linear)
        freeze(dot, track)
        self.play(Write(answer), FadeIn(start_label), run_time=1.2)
        self.result(1)

        self.beat(2)
        center, stage = circle_stage()
        theta = ValueTracker(0)
        position = lambda: center+1.55*np.array([np.cos(theta.get_value()),np.sin(theta.get_value()),0])
        point = always_redraw(lambda: Dot(position(), radius=.095, color=CYAN))
        radius = always_redraw(lambda: Line(center, position(), color=GRID, stroke_width=1.5))
        velocity = always_redraw(lambda: arrow(position(),
                                    1.0*np.array([-np.sin(theta.get_value()),np.cos(theta.get_value()),0]), CYAN))
        acceleration = arrow(center+RIGHT*1.55, LEFT*1.05, ROSE)
        labels = VGroup(eq(r'\vec v', 29, CYAN).move_to([-1.35, .65, 0]),
                        eq(r'\vec a', 29, ROSE).move_to([-2.5, -.55, 0]))
        definitions = formulas(r'\vec v=\frac{d\vec r}{dt}', r'\vec a=\frac{d\vec v}{dt}',
                               r'|\vec v|=\mathrm{const},\quad\vec a\ne\vec0',
                               center=(2.8, .1, 0), size=32)
        self.show(stage, point, radius, velocity, run_time=1.4)
        self.intro(2)
        self.act(2, theta.animate.set_value(TAU), rate_func=linear)
        freeze(point, radius, velocity)
        self.play(Create(acceleration), FadeIn(labels), Write(definitions), run_time=1.2)
        self.result(2)

        self.beat(3)
        left_title = words('Постоянная скорость', center=(-3.3, 1.9, 0), color=CYAN)
        right_title = words('Постоянное ускорение', center=(3.1, 1.9, 0), color=GOLD)
        divider = Line([0, 2.35, 0], [0, -2.35, 0], color=GRID)
        left = formulas(r'v_x=\mathrm{const}', r'x=x_0+v_xt',
                        center=(-3.3, .2, 0), size=32, width=5.3)
        right = formulas(r'a_x=\mathrm{const}', r'x=x_0+v_{0x}t+\frac{a_xt^2}{2}',
                         center=(3.1, .2, 0), size=31, width=5.3)
        projections = words('Начальные значения и знаки проекций сохраняем',
                            center=(0, -2.0, 0), size=23, width=11.8)
        self.show(left_title, right_title, divider, run_time=1.4)
        self.intro(3)
        self.act(3, Write(left), Write(right), FadeIn(projections))
        self.result(3)

        self.beat(4)
        titles = ['Рисунок\nи оси', 'Условия\nдвижения', 'Уравнения', 'Проверка']
        centers = [-4.65, -1.55, 1.55, 4.65]
        colors = [CYAN, LAVENDER, GOLD, ROSE]
        boxes = VGroup()
        for name, x, color in zip(titles, centers, colors):
            box = RoundedRectangle(width=2.55, height=1.25, corner_radius=.13,
                                   color=color, stroke_width=2).move_to([x, .4, 0])
            title = txt(name, 23, INK, line_spacing=.8).move_to(box)
            boxes.add(VGroup(box, title))
        links = VGroup(*[arrow([centers[i]+1.32, .4, 0], [.46, 0, 0], MUTED)
                         for i in range(3)])
        checklist = words('Единицы  ·  знаки  ·  направление  ·  разумность ответа',
                          center=(0, -1.45, 0), size=23, width=11.8)
        self.show(boxes, run_time=1.4)
        self.intro(4)
        self.act(4, Create(links), LaggedStart(*[Indicate(box[0], color=color)
                         for box, color in zip(boxes, colors)], lag_ratio=.25), FadeIn(checklist))
        self.result(4)
