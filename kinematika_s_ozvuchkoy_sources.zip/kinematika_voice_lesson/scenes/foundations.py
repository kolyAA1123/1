"""Foundations: visible premises, a completed experiment, then its conclusion.

No narration is started by a scene. ``LectureScene`` owns the measured speech
clock; each beat contains a still introduction, one bounded action and a still
result. All moving parameters are local to that beat, so no rewind is visible.
"""
from manim import *
import numpy as np

from lecture_style import (
    LectureScene, txt, eq, chart, lines, arrow, car, freeze,
    INK, MUTED, CYAN, GOLD, ROSE, LAVENDER, GRID,
)


def _panel(title, *details, formula=None):
    parts = [txt(title, 25, INK)]
    parts += [txt(s, 22, MUTED) for s in details]
    if formula:
        parts.append(eq(formula, 33, CYAN))
    for part in parts:
        if part.width > 5.45:
            part.scale_to_fit_width(5.45)
    return VGroup(*parts).arrange(DOWN, buff=.27).move_to([3.25, .95, 0])


def _conclusion(*items, color=GOLD):
    parts = []
    for item in items:
        part = eq(item, 32, color)
        if part.width > 5.45:
            part.scale_to_fit_width(5.45)
        parts.append(part)
    return VGroup(*parts).arrange(DOWN, buff=.25).move_to([3.25, -1.65, 0])


def _trace(path, progress, color=CYAN, width=4):
    def redraw():
        p = np.clip(progress.get_value(), 0, 1)
        line = path.copy().pointwise_become_partial(path, 0, max(p, 1e-6))
        line.set_stroke(color, width=width, opacity=min(1, p * 100))
        return line
    return always_redraw(redraw)


def _moving_dot(path, progress, color=CYAN):
    return always_redraw(lambda: Dot(path.point_from_proportion(progress.get_value()),
                                    radius=.075, color=color))


def _route():
    return CubicBezier(np.array([-5.35, -1.15, 0]), np.array([-4.45, 2.0, 0]),
                       np.array([-2.1, -1.9, 0]), np.array([-.9, .85, 0]))


def _point_label(letter, point, offset=DOWN * .3, color=MUTED):
    return eq(letter, 27, color).move_to(np.asarray(point) + offset)


class Opening(LectureScene):
    chapter_id = 1

    def chapter(self):
        # 1. A trajectory is a record of successive positions, not a decoration.
        self.beat(0)
        route = _route()
        p = ValueTracker(0)
        trace = _trace(route, p)
        body = always_redraw(lambda: car().move_to(route.point_from_proportion(p.get_value())))
        marks = VGroup(_point_label('A', route.get_start(), LEFT * .25 + DOWN * .35),
                       _point_label('B', route.get_end(), RIGHT * .2 + UP * .3))
        panel = _panel('Кинематика', 'Как меняется положение тела', 'Причины движения пока не рассматриваем')
        self.show(body, marks, trace, panel, run_time=1.6)
        self.intro(0)
        self.act(0, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'\text{движение: }\vec r=\vec r(t)'), run_time=1.0)
        self.result(0)

        # 2. A reference body, coordinates and a clock are shown together.
        self.beat(1)
        p = ValueTracker(0)
        origin = np.array([-5.15, -1.0, 0])
        axis = VGroup(arrow(origin, [4.35, 0, 0], MUTED, 1.5),
                      arrow(origin, [0, 3.0, 0], MUTED, 1.5))
        names = VGroup(_point_label('O', origin, DOWN * .3 + LEFT * .15),
                       eq('x', 27, MUTED).move_to([-.55, -1.05, 0]),
                       eq('y', 27, MUTED).move_to([-5.15, 2.25, 0]))
        landmark = VGroup(Rectangle(width=.42, height=.58, color=GOLD, stroke_width=2),
                          Polygon([-.25, .29, 0], [0, .48, 0], [.25, .29, 0],
                                  color=GOLD, stroke_width=2)).move_to([-5.75, -.73, 0])
        body = always_redraw(lambda: car().move_to([-4.55 + 3.05*p.get_value(), -.73, 0]))
        clock_center = np.array([-1.65, 1.45, 0])
        clock = Circle(radius=.48, color=MUTED, stroke_width=2).move_to(clock_center)
        hand = always_redraw(lambda: Line(clock_center, clock_center + .37*np.array([
            np.sin(TAU*p.get_value()), np.cos(TAU*p.get_value()), 0]), color=GOLD, stroke_width=2.5))
        time_label = eq('t', 27, MUTED).move_to([-1.65, 2.12, 0])
        panel = _panel('Система отсчёта', 'Тело отсчёта', 'Оси координат', 'Часы')
        self.show(axis, names, landmark, body, clock, hand, time_label, panel, run_time=1.6)
        self.intro(1)
        self.act(1, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'\vec r=\vec r(t)\ \text{в выбранной системе}'), run_time=1.0)
        self.result(1)

        # 3. The replacement by a point is an explicit modelling step.
        self.beat(2)
        route = Line([-5.25, -.45, 0], [-1.0, -.45, 0])
        p = ValueTracker(0)
        guide = route.copy().set_stroke(GRID, 2)
        body = always_redraw(lambda: car().scale(max(.04, 1-p.get_value())).move_to(
            route.point_from_proportion(p.get_value())))
        dot = always_redraw(lambda: Dot(route.point_from_proportion(p.get_value()), radius=.075,
                                       color=CYAN).set_opacity(p.get_value()))
        length_mark = DoubleArrow([-5.25, -1.35, 0], [-1.0, -1.35, 0], buff=0,
                                 color=MUTED, stroke_width=1.6)
        labels = VGroup(eq('L', 28, MUTED).move_to([-3.1, -1.7, 0]),
                        eq(r'\ell', 28, CYAN).move_to([-5.25, .2, 0]))
        panel = _panel('Материальная точка', 'Размеры тела малы', 'в условиях данной задачи', formula=r'\ell\ll L')
        self.show(guide, body, dot, length_mark, labels, panel, run_time=1.6)
        self.intro(2)
        self.act(2, p.animate.set_value(1), rate_func=linear)
        freeze(body)
        # Keep the final material point, not a tiny car shape on top of it.
        body.set_opacity(0)
        self.show(_conclusion(r'\text{тело }\longrightarrow\text{ точка с массой}'), run_time=1.0)
        self.result(2)

        # 4. Coordinate projections and a radius vector describe one position.
        self.beat(3)
        ax, frame = chart(center=(-3.25, -.25, 0), width=4.8, height=3.6,
                          x_range=(0, 4, 1), y_range=(0, 3, 1), x_label='x', y_label='y')
        p = ValueTracker(0)
        xy = lambda: (1 + 2*p.get_value(), .65 + 1.55*p.get_value())
        body = always_redraw(lambda: Dot(ax.c2p(*xy()), radius=.075, color=CYAN))
        radius = always_redraw(lambda: arrow(ax.c2p(0, 0), ax.c2p(*xy())-ax.c2p(0, 0), CYAN, 3))
        projections = always_redraw(lambda: VGroup(
            DashedLine(ax.c2p(xy()[0], 0), ax.c2p(*xy()), color=GOLD, stroke_width=1.5),
            DashedLine(ax.c2p(0, xy()[1]), ax.c2p(*xy()), color=GOLD, stroke_width=1.5)))
        panel = _panel('Координаты и радиус-вектор', 'Вектор направлен от начала отсчёта к точке',
                       formula=r'\vec r=x\vec i+y\vec j')
        self.show(frame, radius, projections, body, panel, run_time=1.6)
        self.intro(3)
        self.act(3, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'P(x,y)\ \longleftrightarrow\ \vec r'), run_time=1.0)
        self.result(3)

        # 5. Read a coordinate from a completed law-of-motion graph.
        self.beat(4)
        ax, frame = chart(center=(-3.1, -.1, 0), width=5.0, height=3.6,
                          x_range=(0, 5, 1), y_range=(0, 4, 1))
        f = lambda t: .65 + .3*t + .06*t*t
        path = ax.plot(f, x_range=(0, 4.4), color=CYAN)
        p = ValueTracker(0)
        trace = _trace(path, p)
        dot = _moving_dot(path, p)
        panel = _panel('Закон движения', 'Координата зависит от времени', formula=r'x=x(t)')
        self.show(frame, trace, dot, panel, run_time=1.6)
        self.intro(4)
        self.act(4, p.animate.set_value(1), rate_func=linear)
        t1, x1 = 4.4, f(4.4)
        readout = VGroup(DashedLine(ax.c2p(t1, 0), ax.c2p(t1, x1), color=GOLD, stroke_width=1.5),
                         DashedLine(ax.c2p(0, x1), ax.c2p(t1, x1), color=GOLD, stroke_width=1.5),
                         eq('t_1', 24, GOLD).next_to(ax.c2p(t1, 0), DOWN, buff=.16),
                         eq('x_1', 24, GOLD).next_to(ax.c2p(0, x1), LEFT, buff=.16))
        self.show(readout, _conclusion(r'x_1=x(t_1)'), run_time=1.0)
        self.result(4)


class PathDisplacement(LectureScene):
    chapter_id = 2

    def chapter(self):
        self.beat(0)
        route = _route()
        p = ValueTracker(0)
        trace, dot = _trace(route, p), _moving_dot(route, p)
        ends = VGroup(_point_label('A', route.get_start(), LEFT*.2 + DOWN*.3),
                      _point_label('B', route.get_end(), RIGHT*.2 + UP*.3))
        panel = _panel('Траектория', 'Последовательные положения тела', 'образуют линию движения')
        self.show(trace, dot, ends, panel, run_time=1.6)
        self.intro(0)
        self.act(0, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'\text{траектория — линия движения}'), run_time=1.0)
        self.result(0)

        self.beat(1)
        points = [np.array([-5.25, -1.0, 0]), np.array([-3.25, 1.35, 0]), np.array([-.95, -1.0, 0])]
        route = VMobject().set_points_as_corners(points)
        guide = route.copy().set_stroke(GRID, 2)
        p = ValueTracker(0)
        trace, dot = _trace(route, p, GOLD), _moving_dot(route, p, GOLD)
        segment_names = VGroup(eq('S_1', 28, GOLD).move_to([-4.6, .5, 0]),
                               eq('S_2', 28, GOLD).move_to([-1.75, .5, 0]))
        panel = _panel('Путь — длина траектории', 'Скалярная величина', formula=r'S\geq0')
        self.show(guide, trace, dot, segment_names, panel, run_time=1.6)
        self.intro(1)
        self.act(1, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'S=S_1+S_2'), run_time=1.0)
        self.result(1)

        self.beat(2)
        route = _route()
        guide = route.copy().set_stroke(GRID, 2)
        p = ValueTracker(0)
        dot, trace = _moving_dot(route, p), _trace(route, p)
        direct = arrow(route.get_start(), route.get_end()-route.get_start(), GOLD, 3)
        labels = VGroup(_point_label('A', route.get_start(), LEFT*.23 + DOWN*.25),
                        _point_label('B', route.get_end(), RIGHT*.18 + UP*.27))
        panel = _panel('Перемещение — вектор', 'Соединяет начальное и конечное положения',
                       formula=r'\Delta\vec r=\vec r_B-\vec r_A')
        self.show(guide, trace, dot, labels, panel, run_time=1.6)
        self.intro(2)
        self.act(2, p.animate.set_value(1), Create(direct), rate_func=linear)
        self.show(_conclusion(r'\Delta\vec r:\quad A\longrightarrow B'), run_time=1.0)
        self.result(2)

        self.beat(3)
        start, end = np.array([-5.25, -.85, 0]), np.array([-.95, -.85, 0])
        short = Line(start, end)
        long = CubicBezier(start, np.array([-4.8, 2.2, 0]), np.array([-1.4, 2.2, 0]), end)
        p = ValueTracker(0)
        traces = VGroup(_trace(short, p, CYAN), _trace(long, p, GOLD))
        dots = VGroup(_moving_dot(short, p, CYAN), _moving_dot(long, p, GOLD))
        guides = VGroup(short.copy().set_stroke(GRID, 2), long.copy().set_stroke(GRID, 2))
        labels = VGroup(eq('S_1', 28, CYAN).move_to([-3.1, -1.3, 0]),
                        eq('S_2', 28, GOLD).move_to([-3.1, 1.85, 0]),
                        _point_label('A', start, LEFT*.25 + DOWN*.2),
                        _point_label('B', end, RIGHT*.2 + DOWN*.2))
        panel = _panel('Два маршрута между A и B', 'Начало и конец совпадают', 'Форма траектории различается')
        self.show(guides, traces, dots, labels, panel, run_time=1.6)
        self.intro(3)
        self.act(3, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'S_2>S_1', r'\Delta\vec r_2=\Delta\vec r_1'), run_time=1.0)
        self.result(3)

        self.beat(4)
        center, radius = np.array([-3.25, 0, 0]), 1.7
        route = Circle(radius=radius).move_to(center)
        guide = route.copy().set_stroke(GRID, 2)
        p = ValueTracker(0)
        trace, dot = _trace(route, p, GOLD), _moving_dot(route, p, GOLD)
        start_label = _point_label('A', route.get_start(), RIGHT*.32 + DOWN*.2)
        radius_line = Line(center, route.get_start(), color=MUTED, stroke_width=1.5)
        radius_label = eq('R', 27, MUTED).move_to(center + np.array([.8, -.3, 0]))
        panel = _panel('Полный оборот', 'Возвращение в начальную точку', 'Путь и перемещение различаются')
        self.show(guide, trace, dot, start_label, radius_line, radius_label, panel, run_time=1.6)
        self.intro(4)
        self.act(4, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'S=2\pi R>0', r'\Delta\vec r=\vec0'), run_time=1.0)
        self.result(4)


class Velocity(LectureScene):
    chapter_id = 3

    def chapter(self):
        self.beat(0)
        f = lambda u: np.array([-5.25+4.15*u, -.65+.85*np.sin(PI*u), 0])
        path = ParametricFunction(f, t_range=(0, 1), color=GRID, stroke_width=2)
        p = ValueTracker(0)
        dot = always_redraw(lambda: Dot(f(p.get_value()), radius=.075, color=CYAN))
        velocity = always_redraw(lambda: arrow(f(p.get_value()),
            [1.05, 1.05*.85*PI/4.15*np.cos(PI*p.get_value()), 0], CYAN, 3))
        trace = _trace(path, p)
        panel = _panel('Мгновенная скорость', 'Направлена по касательной к траектории',
                       formula=r'\vec v=\lim_{\Delta t\to0}\frac{\Delta\vec r}{\Delta t}')
        self.show(path, dot, velocity, trace, panel, run_time=1.6)
        self.intro(0)
        self.act(0, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'\vec v\ \text{описывает движение в данный момент}'), run_time=1.0)
        self.result(0)

        self.beat(1)
        route = _route()
        p = ValueTracker(0)
        guide = route.copy().set_stroke(GRID, 2)
        trace = _trace(route, p, GOLD)
        point = lambda: route.point_from_proportion(p.get_value() if p.get_value() <= 1 else 2-p.get_value())
        dot = always_redraw(lambda: Dot(point(), radius=.075, color=CYAN))
        direct = always_redraw(lambda: arrow(route.get_start(), point()-route.get_start(), CYAN, 3))
        panel = _panel('Две средние характеристики', 'Один и тот же промежуток времени',
                       formula=r'v_{\text{пут}}=\frac{S}{\Delta t}')
        second = eq(r'\vec v_{\text{ср}}=\frac{\Delta\vec r}{\Delta t}', 33, CYAN).move_to([3.25, -.65, 0])
        self.show(guide, trace, dot, direct, panel, second, run_time=1.6)
        self.intro(1)
        self.act(1, p.animate.set_value(2), rate_func=linear)
        freeze(dot, trace, direct)
        self.show(_conclusion(r'S>0,\qquad\Delta\vec r=\vec0',r'\vec v_{\text{ср}}=\vec0'), run_time=1.0)
        self.result(1)

        self.beat(2)
        ax, frame = chart(center=(-3.2, -.8, 0), width=4.6, height=2.45,
                          x_range=(0, 4, 1), y_range=(0, 4, 1))
        path = ax.plot(lambda t: .65+.65*t, x_range=(0, 4), color=CYAN)
        p = ValueTracker(0)
        trace, dot = _trace(path, p), _moving_dot(path, p)
        rail = Line([-5.45, 1.65, 0], [-.95, 1.65, 0], color=GRID, stroke_width=2)
        body = always_redraw(lambda: car().move_to([-5.1+3.8*p.get_value(), 1.88, 0]))
        panel = _panel('Равномерное прямолинейное движение', 'Проекция скорости постоянна',
                       formula=r'x=x_0+v_xt')
        self.show(frame, rail, body, trace, dot, panel, run_time=1.6)
        self.intro(2)
        self.act(2, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'\Delta x=v_x\Delta t'), run_time=1.0)
        self.result(2)

        self.beat(3)
        p = ValueTracker(0)
        rail1 = arrow([-5.75, 1.2, 0], [5.0, 0, 0], MUTED, 1.5)
        rail2 = arrow([-5.75, -.65, 0], [5.0, 0, 0], MUTED, 1.5)
        upper = lambda: np.array([-3.7+1.7*p.get_value(), 1.2, 0])
        lower = lambda: np.array([-2.5-1.7*p.get_value(), -.65, 0])
        dots = VGroup(always_redraw(lambda: Dot(upper(), radius=.075, color=CYAN)),
                      always_redraw(lambda: Dot(lower(), radius=.075, color=ROSE)))
        arrows = VGroup(always_redraw(lambda: arrow(upper(), [1.0, 0, 0], CYAN)),
                        always_redraw(lambda: arrow(lower(), [-1.0, 0, 0], ROSE)))
        names = VGroup(eq('x', 26, MUTED).move_to([-.55, 1.2, 0]),
                       eq('x', 26, MUTED).move_to([-.55, -.65, 0]))
        panel = _panel('Знак проекции скорости', 'Отсчитываем вдоль выбранной оси',
                       formula=r'v_x>0\quad\text{вправо}')
        negative = eq(r'v_x<0\quad\text{влево}', 33, ROSE).move_to([3.25, -.55, 0])
        self.show(rail1, rail2, dots, arrows, names, panel, negative, run_time=1.6)
        self.intro(3)
        self.act(3, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'|v_x|\ \text{задаёт быстроту движения}'), run_time=1.0)
        self.result(3)

        self.beat(4)
        ax, frame = chart(center=(-3.2, -.1, 0), width=4.8, height=3.6,
                          x_range=(0, 4, 1), y_range=(0, 4, 1))
        up = ax.plot(lambda t: .45+.72*t, x_range=(0, 4), color=CYAN)
        flat = ax.plot(lambda t: 2, x_range=(0, 4), color=GOLD)
        down = ax.plot(lambda t: 3.7-.72*t, x_range=(0, 4), color=ROSE)
        legend = VGroup(eq(r'v_x>0', 31, CYAN), eq(r'v_x=0', 31, GOLD),
                        eq(r'v_x<0', 31, ROSE)).arrange(DOWN, buff=.25).move_to([3.25, .75, 0])
        title = txt('Наклон графика координаты', 25).move_to([3.25, 2.0, 0])
        if title.width > 5.45: title.scale_to_fit_width(5.45)
        self.show(frame, legend, title, run_time=1.6)
        self.intro(4)
        self.act(4, Create(up), Create(flat), Create(down), rate_func=linear)
        self.show(_conclusion(r'v_x=\frac{\Delta x}{\Delta t}\quad\text{для прямой}'), run_time=1.0)
        self.result(4)


class Acceleration(LectureScene):
    chapter_id = 4

    def chapter(self):
        self.beat(0)
        origin1, origin2, origin_sum = [np.array([-5.25, y, 0]) for y in [1.45, .2, -1.25]]
        initial = arrow(origin1, [1.35, 0, 0], CYAN)
        final = arrow(origin2, [2.8, 0, 0], CYAN)
        sum_first = arrow(origin_sum, [1.35, 0, 0], CYAN)
        delta = arrow(origin_sum+[1.35, 0, 0], [1.45, 0, 0], GOLD)
        labels = VGroup(eq(r'\vec v_1', 28, CYAN).move_to([-5.75, 1.45, 0]),
                        eq(r'\vec v_2', 28, CYAN).move_to([-5.75, .2, 0]),
                        eq(r'\vec v_1', 28, CYAN).move_to([-4.6, -1.7, 0]))
        delta_label = eq(r'\Delta\vec v', 28, GOLD).move_to([-3.15, -1.7, 0])
        panel = _panel('Среднее ускорение', 'Изменение вектора скорости за время',
                       formula=r'\vec a_{\text{ср}}=\frac{\vec v_2-\vec v_1}{\Delta t}')
        self.show(initial, final, sum_first, labels, panel, run_time=1.6)
        self.intro(0)
        self.act(0, Create(delta), rate_func=linear)
        self.show(delta_label, _conclusion(r'\Delta\vec v=\vec v_2-\vec v_1'), run_time=1.0)
        self.result(0)

        self.beat(1)
        ax, frame = chart(center=(-3.2, -.1, 0), width=4.8, height=3.6,
                          x_range=(0, 5, 1), y_range=(0, 4, 1), y_label='v_x')
        f = lambda t: .45+.09*t*t
        path = ax.plot(f, x_range=(0, 4.5), color=CYAN)
        panel = _panel('Мгновенное ускорение', 'Быстрота изменения скорости',
                       formula=r'a_x=\frac{dv_x}{dt}')
        units = eq(r'[a]=\frac{\text{м}}{\text{с}^{2}}', 33, GOLD).move_to([3.25, -.65, 0])
        self.show(frame, panel, units, run_time=1.6)
        self.intro(1)
        self.act(1, Create(path), rate_func=linear)
        t = 3.7
        tangent = ax.plot(lambda s: f(t)+.18*t*(s-t), x_range=(2.5, 4.6), color=GOLD)
        point = Dot(ax.c2p(t, f(t)), radius=.075, color=GOLD)
        self.show(tangent, point, _conclusion(r'\vec a=\lim_{\Delta t\to0}\frac{\Delta\vec v}{\Delta t}'), run_time=1.0)
        self.result(1)

        self.beat(2)
        p = ValueTracker(0)
        position = lambda: np.array([-5.25+2*p.get_value()+p.get_value()**2, .2, 0])
        rail = Line([-5.75, -.05, 0], [-.65, -.05, 0], color=GRID, stroke_width=2)
        body = always_redraw(lambda: car().move_to(position()))
        velocity = always_redraw(lambda: arrow(position()+UP*.65,
            [.8+.8*p.get_value(), 0, 0], CYAN))
        acceleration = always_redraw(lambda: arrow(position()+DOWN*.65, [.95, 0, 0], GOLD))
        panel = _panel('Разгон', 'Скорость и ускорение направлены одинаково',
                       formula=r'v_x>0,\qquad a_x>0')
        legend = VGroup(eq(r'\vec v', 28, CYAN).move_to([-5.65, .85, 0]),
                        eq(r'\vec a', 28, GOLD).move_to([-5.65, -.45, 0]))
        self.show(rail, body, velocity, acceleration, panel, legend, run_time=1.6)
        self.intro(2)
        self.act(2, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'|\vec v_2|>|\vec v_1|'), run_time=1.0)
        self.result(2)

        self.beat(3)
        p = ValueTracker(0)
        position = lambda: np.array([-2.25-4*p.get_value()+p.get_value()**2, .2, 0])
        rail = Line([-5.75, -.05, 0], [-.65, -.05, 0], color=GRID, stroke_width=2)
        body = always_redraw(lambda: car().move_to(position()))
        velocity = always_redraw(lambda: arrow(position()+UP*.65,
            [-1.6+.8*p.get_value(), 0, 0], CYAN))
        acceleration = always_redraw(lambda: arrow(position()+DOWN*.65, [.95, 0, 0], GOLD))
        panel = _panel('Торможение', 'Ускорение направлено против скорости',
                       formula=r'v_x<0,\qquad a_x>0')
        legend = VGroup(eq(r'\vec v', 28, CYAN).move_to([-5.9, 1.4, 0]),
                        eq(r'\vec a', 28, GOLD).move_to([-5.9, -1.1, 0]))
        # The acceleration arrow begins at x=-5.25 and extends to -6.2,
        # inside the stated stage; the label is to its left above its line.
        self.show(rail, body, velocity, acceleration, panel, legend, run_time=1.6)
        self.intro(3)
        self.act(3, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'0<|\vec v_2|<|\vec v_1|'), run_time=1.0)
        self.result(3)

        self.beat(4)
        center, radius = np.array([-3.3, 0, 0]), 1.6
        p = ValueTracker(0)
        angle = lambda: -PI/2+PI*p.get_value()
        radial = lambda: np.array([np.cos(angle()), np.sin(angle()), 0])
        position = lambda: center+radius*radial()
        guide = Circle(radius=radius, color=GRID, stroke_width=2).move_to(center)
        semicircle = ParametricFunction(lambda u: center+radius*np.array([
            np.cos(-PI/2+PI*u), np.sin(-PI/2+PI*u), 0]), t_range=(0, 1))
        trace = _trace(semicircle, p)
        dot = always_redraw(lambda: Dot(position(), radius=.075, color=INK))
        velocity = always_redraw(lambda: arrow(position(),
            [-np.sin(angle()), np.cos(angle()), 0], CYAN))
        acceleration = always_redraw(lambda: arrow(position(), -.85*radial(), GOLD))
        panel = _panel('Поворот при постоянном модуле скорости', 'Скорость направлена по касательной',
                       'Ускорение направлено к центру', formula=r'|\vec v|=\mathrm{const}')
        self.show(guide, trace, dot, velocity, acceleration, panel, run_time=1.6)
        self.intro(4)
        self.act(4, p.animate.set_value(1), rate_func=linear)
        self.show(_conclusion(r'\Delta\vec v\ne\vec0,\qquad\vec a\ne\vec0'), run_time=1.0)
        self.result(4)
