# Russian Piper mirror notice

Mirror release: `russian-voices-2026-09-15-r2`  
Scope: Russian Piper voice artifacts only  
Initial retrieval date: 2026-09-15 (UTC); April420 added 2026-10-08 (UTC)

This file documents provenance and license declarations supplied by the
upstream repositories. The mirror preserves those terms; it does not grant
additional rights. The model files are separate artifacts from the Piper
runtime and from this repository's documentation.

| Model | Upstream source and pinned revision | Upstream license declaration | Mirror status |
| --- | --- | --- | --- |
| `ru_RU-denis-medium` | [rhasspy/piper-voices](https://huggingface.co/rhasspy/piper-voices/tree/1162a9173d0ce503555aed757976b7a9912eae4c/ru/ru_RU/denis/medium) at `1162a9173d0ce503555aed757976b7a9912eae4c` | CC0 in the upstream `MODEL_CARD` | Included |
| `ru_RU-dmitri-medium` | [rhasspy/piper-voices](https://huggingface.co/rhasspy/piper-voices/tree/1162a9173d0ce503555aed757976b7a9912eae4c/ru/ru_RU/dmitri/medium) at `1162a9173d0ce503555aed757976b7a9912eae4c` | CC0 in the upstream `MODEL_CARD` | Included |
| `ru_RU-luka-medium` | [superkeka/piper-tts-luka](https://huggingface.co/superkeka/piper-tts-luka/tree/a1a78dd5e1f32fb859e338509cc76012ff42c624/ru/ru_RU/luka/medium) at `a1a78dd5e1f32fb859e338509cc76012ff42c624` | Apache-2.0 in the upstream repository metadata and model card | Included |
| `ru_RU-dict-medium_epoch3874` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-fr6800-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-igm3500-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-igm3602-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-igm3804-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-kat580-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-mari-medium_epoch5699` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-nara426-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-pvo240-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-sova200-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-sushkov_v4-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-terra-medium_epoch5319` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-terra-medium_epoch5839` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-terra5862-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-terra5871-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/f340fe24a52e696bdacbc457d242ac2b0e3bb9ac) at `f340fe24a52e696bdacbc457d242ac2b0e3bb9ac` | Apache-2.0 in the upstream repository metadata | Included |
| `ru_RU-irina-medium` | [rhasspy/piper-voices](https://huggingface.co/rhasspy/piper-voices/tree/1162a9173d0ce503555aed757976b7a9912eae4c/ru/ru_RU/irina/medium) at `1162a9173d0ce503555aed757976b7a9912eae4c` | `Unknown` in the upstream `MODEL_CARD` | Included; upstream declaration preserved |
| `ru_RU-ruslan-medium` | [rhasspy/piper-voices](https://huggingface.co/rhasspy/piper-voices/tree/1162a9173d0ce503555aed757976b7a9912eae4c/ru/ru_RU/ruslan/medium) at `1162a9173d0ce503555aed757976b7a9912eae4c` | CC BY-NC-SA 4.0 in the upstream `MODEL_CARD` | Included; license terms apply |
| `ru_RU-april420-medium` | [rraaww/ru_piper](https://huggingface.co/rraaww/ru_piper/tree/3077e02a3c253db294b1b02dd6680d8296c7a348) at `3077e02a3c253db294b1b02dd6680d8296c7a348` | Apache-2.0 in upstream Hugging Face repository metadata; no standalone license file observed at this revision | Included; added 2026-10-08 |

For `rraaww/ru_piper`, the repository metadata declares Apache-2.0 but does
not publish a separate per-voice model card. The mirror therefore preserves
the repository declaration and records the exact source revision; it does not
infer a broader license from the voice names or from the Piper runtime.

The upstream `rhasspy/piper-voices` repository metadata is MIT-licensed. The
voice-specific cards above remain the controlling provenance record for the
mirrored model artifacts.

The mirror preserves the declarations above and does not add rights. The
`Unknown` declaration for `ru_RU-irina-medium` remains unresolved, and
`ru_RU-ruslan-medium` remains subject to the CC BY-NC-SA 4.0 terms.

For April420, the pinned upstream repository declares Apache-2.0 in model metadata but does not publish a standalone LICENSE file. The mirror records that declaration and does not make a separate voice-identity or recording-rights determination.
