# License files

These files are included beside the mirror artifacts so a downloaded voice
retains the upstream license text. The model-specific terms are listed in
`../NOTICE.md`; this directory does not create a single license for all voices.

