"""Check complete video/audio decode, visible timing, labels and narration slots."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import subprocess
import wave

import numpy as np

from render_lecture import PREFIX, ROOT, chapter_sources, load_plan, probe


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def raw_frames(path, start, duration, filters):
    return subprocess.check_output([
        "ffmpeg", "-v", "error", "-ss", str(start), "-t", str(duration), "-i", str(path),
        "-map", "0:v:0", "-an", "-vf", filters, "-f", "rawvideo", "pipe:1",
    ])


def wav_info(path):
    with wave.open(str(path), "rb") as source:
        assert source.getcomptype() == "NONE", path
        return {"channels": source.getnchannels(), "sample_width": source.getsampwidth(),
                "sample_rate": source.getframerate(), "frames": source.getnframes(),
                "duration": source.getnframes() / source.getframerate()}


def check_timing(plan):
    slots, chapters = [], []
    tolerance = .085
    for chapter in plan["chapters"]:
        number = chapter["id"]
        path = ROOT / "output/sync_checks" / f"{number:02d}.json"
        report = json.loads(path.read_text(encoding="utf-8"))
        assert report["chapter"] == number
        assert path.stat().st_mtime >= max(p.stat().st_mtime for p in chapter_sources(chapter)), path
        assert abs(report["duration"] - chapter["duration"]) <= tolerance, (number, report["duration"])
        events = report["events"]
        assert len(events) == 20, (number, "Incomplete sync report", len(events))
        event_map = {(event["beat"], event["event"]): event for event in events}
        assert len(event_map) == 20, (number, "Duplicate sync events")
        previous_end = 0
        for beat in chapter["beats"]:
            index = beat["index"] + 1
            assert beat["start"] >= previous_end - tolerance, (number, index, "Overlapping visual beats")
            assert beat["start"] <= beat["intro_at"]
            assert beat["intro_at"] + beat["intro_duration"] <= beat["action_at"] + tolerance
            assert beat["action_at"] + beat["action_seconds"] <= beat["result_at"] + tolerance
            assert beat["result_at"] + beat["result_duration"] <= beat["end"] + tolerance
            for kind in ("intro", "result"):
                source = ROOT / beat[f"{kind}_file"]
                audio = wav_info(source)
                assert (audio["channels"], audio["sample_width"], audio["sample_rate"]) == (1, 2, 48000), source
                assert abs(audio["duration"] - beat[f"{kind}_duration"]) <= 1 / 48000 + 1e-7, source
                start = chapter["start"] + beat[f"{kind}_at"]
                end = start + audio["duration"]
                slots.append({"chapter": number, "beat": index, "part": kind,
                              "start": start, "end": end, "file": str(source.relative_to(ROOT))})
                event = event_map[(index, f"{kind}_ready")]
                assert event["time"] <= beat[f"{kind}_at"] + tolerance, (number, index, kind, event)
                assert event["time"] >= beat["start"] - tolerance, (number, index, kind, event)
                if "speech_at" in event:
                    assert abs(event["speech_at"] - beat[f"{kind}_at"]) < 1e-6
            start = event_map[(index, "action_start")]["time"]
            end = event_map[(index, "action_end")]["time"]
            assert abs(start - beat["action_at"]) <= tolerance, (number, index, "action_start", start)
            assert abs(end - (beat["action_at"] + beat["action_seconds"])) <= tolerance, (number, index, "action_end", end)
            assert abs(end - start - beat["action_seconds"]) <= tolerance
            assert end <= beat["result_at"] + tolerance, (number, index, "Result spoken during action")
            assert event_map[(index, "result_ready")]["time"] >= end - tolerance
            previous_end = beat["end"]
        last_voice = max(s["end"] for s in slots if s["chapter"] == number)
        assert last_voice <= chapter["start"] + chapter["duration"] - 1.2 + 1 / 48000, number
        chapter_audio = wav_info(ROOT / chapter["audio_file"])
        assert (chapter_audio["channels"], chapter_audio["sample_width"], chapter_audio["sample_rate"]) == (1, 2, 48000)
        assert chapter_audio["frames"] == chapter["duration"] * 48000
        chapters.append({"chapter": number, "beats": 5, "events_checked": 20,
                         "last_speech_end": round(last_voice, 6), "ready_tolerance_seconds": tolerance})
    slots.sort(key=lambda entry: entry["start"])
    assert len(slots) == 120
    for left, right in zip(slots, slots[1:]):
        assert left["end"] <= right["start"] + 1 / 48000, (left, right)
    master = ROOT / "output/audio/narration.wav"
    audio = wav_info(master)
    assert (audio["channels"], audio["sample_width"], audio["sample_rate"]) == (1, 2, 48000)
    assert audio["frames"] == plan["duration"] * 48000
    # The master must actually contain the declared speech at each declared slot.
    # Compare exact PCM frames, rather than trusting timestamps in JSON alone.
    with wave.open(str(master), "rb") as stream:
        for slot in slots:
            source = ROOT / slot["file"]
            with wave.open(str(source), "rb") as part:
                expected = part.readframes(part.getnframes())
                stream.setpos(round(slot["start"] * 48000))
                actual = stream.readframes(len(expected) // 2)
                assert actual == expected, (slot["chapter"], slot["beat"], slot["part"], "Master audio differs from scheduled speech")
    return chapters, slots, {"sha256": digest(master), **audio}


def audio_statistics(movie):
    process = subprocess.Popen([
        "ffmpeg", "-v", "error", "-i", str(movie), "-map", "0:a:0", "-vn",
        "-ac", "1", "-ar", "48000", "-c:a", "pcm_f32le", "-f", "f32le", "pipe:1",
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    count, squares, peak, clipped, active, blocks = 0, 0.0, 0.0, 0, 0, 0
    while True:
        block = process.stdout.read(48000 * 4)
        if not block:
            break
        samples = np.frombuffer(block, dtype="<f4").astype(np.float64)
        assert np.isfinite(samples).all()
        count += len(samples)
        squares += float(np.dot(samples, samples))
        peak = max(peak, float(np.abs(samples).max(initial=0)))
        clipped += int((np.abs(samples) >= .9999).sum())
        active += bool(np.sqrt(np.mean(samples * samples)) > .003)
        blocks += 1
    errors = process.stderr.read()
    assert process.wait() == 0 and not errors, errors.decode(errors="replace")
    rms = math.sqrt(squares / max(count, 1))
    assert count > 0 and rms > .003, ("Missing or practically inaudible narration", rms)
    assert peak < 1.15 and clipped / count < .001, ("Substantial audio clipping", peak, clipped / count)
    assert active / max(blocks, 1) > .04, "Narration absent from most of the film"
    return {"decoded_samples": count, "rms_dbfs": round(20 * math.log10(rms), 3),
            "sample_peak_dbfs": round(20 * math.log10(max(peak, 1e-12)), 3),
            "near_full_scale_fraction": round(clipped / count, 8),
            "active_one_second_blocks_fraction": round(active / blocks, 5)}


def main():
    plan = load_plan()
    movie = ROOT / "output" / f"{PREFIX}_1080p60.mp4"
    report = probe(movie)
    videos = [s for s in report["streams"] if s["codec_type"] == "video"]
    audios = [s for s in report["streams"] if s["codec_type"] == "audio"]
    assert len(videos) == len(audios) == 1
    video, audio = videos[0], audios[0]
    assert (video["width"], video["height"], video["avg_frame_rate"]) == (1920, 1080, "60/1")
    assert int(video["nb_frames"]) == plan["duration"] * 60
    assert (audio["codec_name"], int(audio["sample_rate"]), audio["channels"]) == ("aac", 48000, 1)
    assert abs(float(report["format"]["duration"]) - plan["duration"]) <= .06
    assert abs(float(audio["duration"]) - plan["duration"]) <= .06
    assert len(report["chapters"]) == len(plan["chapters"])
    for actual, planned in zip(report["chapters"], plan["chapters"]):
        assert abs(float(actual["start_time"]) - planned["start"]) <= .001
        assert abs(float(actual["end_time"]) - planned["start"] - planned["duration"]) <= .001
    sync, slots, master = check_timing(plan)
    fades, layouts = [], []
    for chapter in plan["chapters"]:
        number = chapter["id"]
        layout_path = ROOT / "output/layout_checks" / f"{number:02d}.json"
        layout = json.loads(layout_path.read_text(encoding="utf-8"))
        assert layout["chapter"] == number
        assert layout["samples"] and layout["samples"][-1]["time"] >= chapter["duration"] - 1, number
        assert not any(sample["issues"] for sample in layout["samples"]), (number, layout_path)
        preview = ROOT / "output/preview_chapters" / f"{number:02d}_{chapter['class']}.mp4"
        source_time = max(path.stat().st_mtime for path in chapter_sources(chapter))
        assert preview.stat().st_mtime > source_time and layout_path.stat().st_mtime > source_time, number
        layouts.append({"chapter": number, "snapshots_checked": len(layout["samples"]),
                        "text_overlaps": 0, "text_outside_frame": 0})
        clip = ROOT / "output/chapters" / f"{number:02d}_{chapter['class']}.mp4"
        assert clip.stat().st_mtime > source_time, number
        data = raw_frames(clip, chapter["duration"] - 1.2, 1.2,
                          "fps=10,scale=160:90,format=rgb24")
        frames = np.frombuffer(data, dtype=np.uint8).reshape(-1, 90, 160, 3)
        assert len(frames) >= 10, number
        energy = frames.mean(axis=(1, 2, 3))
        assert energy[-1] / max(energy[0], .001) < .05, number
        assert max(np.diff(energy)) < .05, number
        corner = raw_frames(movie, chapter["start"] + 3, .05, "crop=16:16:0:0,format=rgb24")
        assert corner and max(corner) == 0, number
        fades.append({"chapter": number, "end_fade_rgb_mean": [round(float(v), 4) for v in energy],
                      "black_corner": True})
    print("Timing, text layout and chapter checks passed. Decoding complete video and audio...", flush=True)
    log = ROOT / "output/decode_check.log"
    with log.open("w", encoding="utf-8") as errors:
        result = subprocess.run([
            "ffmpeg", "-v", "error", "-i", str(movie), "-map", "0:v:0", "-map", "0:a:0",
            "-f", "null", "-",
        ], stderr=errors)
    assert result.returncode == 0 and log.stat().st_size == 0, log
    statistics = audio_statistics(movie)
    summary = {
        "duration_seconds": plan["duration"], "resolution": [1920, 1080], "fps": 60,
        "frames": int(video["nb_frames"]), "video_streams": 1, "audio_streams": 1,
        "audio_codec": audio["codec_name"], "audio_sample_rate": int(audio["sample_rate"]),
        "audio_channels": audio["channels"], "chapters": len(plan["chapters"]),
        "narration_parts": len(slots), "bytes": movie.stat().st_size, "sha256": digest(movie),
        "full_decode_passed": True, "chapter_fades": fades, "label_layout_checks": layouts,
        "speech_sync_checks": sync, "master_audio": master, "audio_statistics": statistics,
        "voice": plan.get("voice", {}),
    }
    (ROOT / "output/quality_validation.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"VERIFIED {movie.name}: {summary['bytes']} bytes, SHA256 {summary['sha256']}", flush=True)


if __name__ == "__main__":
    main()
