"""Extract both spoken states of every beat for visual review."""
import argparse
import io
import json
from pathlib import Path
import subprocess
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parent
plan=json.loads((ROOT/'plan.json').read_text())
parser=argparse.ArgumentParser()
parser.add_argument('--chapters',nargs='*',type=int)
parser.add_argument('--motion',action='store_true')
args=parser.parse_args()
out=ROOT/'output'/('motion_contacts' if args.motion else 'contacts');out.mkdir(exist_ok=True)
for c in plan['chapters']:
    if args.chapters and c['id'] not in args.chapters:continue
    movie=ROOT/'output/preview_chapters'/f"{c['id']:02d}_{c['class']}.mp4"
    if not movie.exists():continue
    sheet=Image.new('RGB',(1280,5*386),'#202020');draw=ImageDraw.Draw(sheet)
    for i,b in enumerate(c['beats']):
        for col,kind in enumerate(('intro','result')):
            t=(b['action_at']+b['action_seconds']*(.3 if col==0 else .7)) if args.motion else b[f'{kind}_at']+min(1,b[f'{kind}_duration']/2)
            blob=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(movie),'-frames:v','1','-vf','scale=640:360','-f','image2pipe','-vcodec','png','pipe:1'])
            sheet.paste(Image.open(io.BytesIO(blob)),(col*640,i*386+26))
            draw.text((col*640+10,i*386+7),f"{c['id']:02d}.{i+1} {kind} {t:.2f}s",fill='white')
    dest=out/f"{c['id']:02d}.jpg";sheet.save(dest,quality=94)
    print(dest,flush=True)
