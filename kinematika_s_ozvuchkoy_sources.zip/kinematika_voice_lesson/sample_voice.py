"""Reproducible, isolated Piper voice preparation and short theory samples.

This script never modifies the installed Piper/espeak files. Each synthesis
invocation is a separate process because Piper caches its phonemizer globally.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path, PurePosixPath
import shutil
import urllib.request
import wave
import zipfile

ROOT = Path(__file__).resolve().parent
MODELS = ROOT / "voice_models"
SAMPLES = ROOT / "output" / "voice_samples"
RELEASE = "https://github.com/Rotem12/piper-russian-voices/releases/download/russian-voices-2026-09-15-r2"
SOURCE = "https://raw.githubusercontent.com/Rotem12/piper-russian-voices/main"
VOICES = {
    "mari": {
        "key": "ru_RU-mari-medium_epoch5699",
        "archive_sha256": "9b729a70b059781636fdda3c313c6569a5d83a46c6eeffc39f5680b4832da631",
        "model_sha256": "8f1b7a19d42d564f7e4951bf828a9e910d85e8f9e78cb495b31db9f29f580112",
        "config_sha256": "ebb1740b93370d90a74587a38b4827958522497ad026849339f9d1e414f965e9",
    },
    "terra": {
        "key": "ru_RU-terra5871-medium",
        "archive_sha256": "35ef3a7b78cf814b99f191744fcff5ec9888b6f041bc53ff555ce9f4b2b7ee34",
        "model_sha256": "edf8010bf52550896347b074eaee969dc8efec72cf116cdb10db7d54a84473e8",
        "config_sha256": "67f1ea8d21a2ddcb7cf60a4f60f8e35a613cc33f0378dff093a7aa8c2b85c13e",
    },
}
DATA_REVISIONS = {
    "legacy": "73f339ecd170d35975ef57ee2b22a57ca7456fe3",
    "current": "68fa929628d0818dff86d4ee7eb976d584158829",
}
SAMPLE_TEXT = (
    "Кинематика описывает движение тел. Положение точки задают координаты. "
    "Чтобы определить перемещение, соединим начальное положение с конечным. "
    "Путь измеряет длину всей траектории, а перемещение зависит только от двух её концов."
)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def fetch(url: str, path: Path, sha: str | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and (sha is None or digest(path) == sha):
        return
    partial = path.with_suffix(path.suffix + ".partial")
    with urllib.request.urlopen(url, timeout=90) as response, partial.open("wb") as out:
        shutil.copyfileobj(response, out, length=1024 * 1024)
    if sha is not None and digest(partial) != sha:
        raise ValueError(f"SHA256 mismatch: {url}")
    partial.replace(path)


def prepare_voice(name: str) -> None:
    spec = VOICES[name]
    key = spec["key"]
    archive = MODELS / f"{key}.zip"
    fetch(f"{RELEASE}/{archive.name}", archive, spec["archive_sha256"])
    target = MODELS / name
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            parts = PurePosixPath(item.filename).parts
            if item.filename.startswith("/") or ".." in parts or "\\" in item.filename:
                raise ValueError(f"Unsafe archive member: {item.filename}")
            # No symlinks, devices, executables, or extraction outside target.
            mode = item.external_attr >> 16
            if (mode & 0o170000) == 0o120000:
                raise ValueError(f"Archive symlink: {item.filename}")
            if item.is_dir():
                continue
            destination = target.joinpath(*parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with z.open(item) as src, destination.open("wb") as out:
                shutil.copyfileobj(src, out)
    models = list(target.rglob("*.onnx"))
    if len(models) != 1:
        raise ValueError(f"Expected one ONNX in {archive.name}")
    model = models[0]
    config = Path(str(model) + ".json")
    assert digest(model) == spec["model_sha256"], model
    assert digest(config) == spec["config_sha256"], config
    license_path = target / "LICENSE.txt"
    notice_path = target / "NOTICE.md"
    license_text = license_path.read_text()
    notice_text = notice_path.read_text()
    assert "Apache License" in license_text and "Version 2.0" in license_text
    assert key in notice_text and "f340fe24a52e696bdacbc457d242ac2b0e3bb9ac" in notice_text
    manifest = {
        **spec,
        "archive_url": f"{RELEASE}/{archive.name}",
        "archive_bytes": archive.stat().st_size,
        "model": str(model.relative_to(ROOT)),
        "model_bytes": model.stat().st_size,
        "config": str(config.relative_to(ROOT)),
        "license": "Apache-2.0 as declared in upstream repository metadata",
        "license_file_sha256": digest(license_path),
        "notice_file_sha256": digest(notice_path),
        "upstream_repository": "rraaww/ru_piper",
        "upstream_revision": "f340fe24a52e696bdacbc457d242ac2b0e3bb9ac",
        "recording_provenance": "Not documented by the mirror; no human-recording claim is made.",
        "extracted_files": [str(p.relative_to(target)) for p in sorted(target.rglob("*")) if p.is_file()],
    }
    (target / "verified_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"voice": name, "archive_sha_verified": True, "onnx_sha_verified": True, "config_sha_verified": True, "files": manifest["extracted_files"]}, ensure_ascii=False), flush=True)


def prepare_data(variant: str) -> None:
    from piper.voice import ESPEAK_DATA_DIR

    revision = DATA_REVISIONS[variant]
    destination = MODELS / f"espeak-ng-data-{variant}"
    shutil.copytree(ESPEAK_DATA_DIR, destination, dirs_exist_ok=True)
    records = []
    for name in ("phondata", "phondata-manifest", "phonindex", "phontab", "ru_dict"):
        url = f"https://raw.githubusercontent.com/mitrokun/espeak-ng-data/{revision}/espeak-ng-data/{name}"
        path = destination / name
        # The base copy is intentionally replaced by the pinned custom file.
        with urllib.request.urlopen(url, timeout=45) as response:
            path.write_bytes(response.read())
        records.append({"name": name, "url": url, "sha256": digest(path), "bytes": path.stat().st_size})
    record = {
        "variant": variant,
        "repository": "mitrokun/espeak-ng-data",
        "revision": revision,
        "base_runtime": "piper-tts " + importlib.metadata.version("piper-tts"),
        "base_espeak_data_dir": str(ESPEAK_DATA_DIR),
        "custom_files": records,
        "compatibility": "Both variants are preserved for listening comparison; upstream does not pin the voice revision to an espeak revision.",
    }
    (destination / "custom_manifest.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"prepared_data": variant, "revision": revision, "path": str(destination)}), flush=True)


def prepare() -> None:
    MODELS.mkdir(parents=True, exist_ok=True)
    for name in ("NOTICE.md", "MODEL_MANIFEST.json", "LICENSES/README.md", "LICENSES/Apache-2.0.txt"):
        fetch(f"{SOURCE}/{name}", MODELS / "mirror_documents" / name)
    for name in VOICES:
        prepare_voice(name)
    for variant in DATA_REVISIONS:
        prepare_data(variant)


def sample(name: str, data_variant: str, output: Path | None = None) -> None:
    from piper import PiperVoice, SynthesisConfig

    spec = VOICES[name]
    model = next((MODELS / name).rglob("*.onnx"))
    data_dir = MODELS / f"espeak-ng-data-{data_variant}"
    voice = PiperVoice.load(model, espeak_data_dir=data_dir, use_cuda=False)
    settings = SynthesisConfig(length_scale=1.05, noise_scale=0.4, noise_w_scale=0.45, normalize_audio=True, volume=0.9)
    output = output or SAMPLES / f"{name}{'' if data_variant == 'legacy' else '_current'}.wav"
    output.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(output), "wb") as out:
        voice.synthesize_wav(SAMPLE_TEXT, out, syn_config=settings)
    with wave.open(str(output), "rb") as recorded:
        duration = recorded.getnframes() / recorded.getframerate()
        sample_rate = recorded.getframerate()
    result = {
        "voice": name,
        "model_key": spec["key"],
        "model_sha256": digest(model),
        "espeak_data_dir": str(data_dir.relative_to(ROOT)),
        "espeak_revision": DATA_REVISIONS[data_variant],
        "length_scale": 1.05,
        "noise_scale": 0.4,
        "noise_w_scale": 0.45,
        "volume": 0.9,
        "pitch_shift": False,
        "text": SAMPLE_TEXT,
        "sample_rate": sample_rate,
        "duration_seconds": duration,
        "output": str(output.relative_to(ROOT)),
        "sha256": digest(output),
    }
    output.with_suffix(".json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "mari", "terra"))
    parser.add_argument("--data", choices=tuple(DATA_REVISIONS), default="legacy")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.action == "prepare":
        prepare()
    else:
        sample(args.action, args.data, args.output)
