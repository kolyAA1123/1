#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname -- "$PROJECT_DIR")"
export UV_CACHE_DIR="${UV_CACHE_DIR:-$REPO_DIR/.cache/uv}"
uv venv --allow-existing --python 3.12 "$REPO_DIR/.venv-speech"
uv pip install --python "$REPO_DIR/.venv-speech/bin/python" 'piper-tts==1.8.0' 'onnxruntime==1.31.0'
cd "$PROJECT_DIR"
"$REPO_DIR/.venv-speech/bin/python" - <<'PY'
import json
from pathlib import Path
from sample_voice import prepare_voice, prepare_data, digest
expected = json.loads(Path('phonemizer_checksums.json').read_text())
prepare_voice('mari')
prepare_data('legacy')
for name, checksum in expected.items():
    path = Path('voice_models/espeak-ng-data-legacy') / name
    assert digest(path) == checksum, f'Phonemizer checksum mismatch: {name}'
print('Selected voice and phonemizer verified.')
PY
