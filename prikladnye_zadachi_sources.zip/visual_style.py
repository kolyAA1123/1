from hashlib import sha256
from pathlib import Path

from manim import SVGMobject, Text
from matplotlib import rc_context
from matplotlib.mathtext import math_to_image

BLACK_BG='#000000'
INK='#EDF2FA'
MUTED='#9AAAC0'
CYAN='#58DCE6'
GOLD='#FFD071'
ROSE='#F17C95'
LAVENDER='#A394FA'
GRID='#28354A'
FONT='DejaVu Sans'

def txt(text,size=25,color=INK,**kwargs):
    return Text(text,font=FONT,font_size=size,color=color,**kwargs)

def equation(tex, color, center, height=.53):
    directory = Path(__file__).resolve().parent / "math_svg"
    directory.mkdir(exist_ok=True)
    target = directory / (sha256((tex + color + "-transparent").encode()).hexdigest()[:12] + ".svg")
    if not target.is_file():
        with rc_context({"mathtext.fontset": "cm", "svg.fonttype": "path", "savefig.transparent": True}):
            math_to_image(f"${tex}$", target, format="svg", color=color)
    return SVGMobject(target, height=height).move_to(center)

