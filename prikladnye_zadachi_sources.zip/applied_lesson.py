from pathlib import Path
import math
import json

import numpy as np
from manim import Arrow, Axes, Circle, Create, DashedLine, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Прикладные задачи"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



def graph(kind):
    if kind=="meeting":
        road=Line([-6.03,0,0],[-1.25,0,0],color=MUTED,stroke_width=2.1)
        a=np.array([-5.83,0,0])
        b=np.array([-1.44,0,0])
        return VGroup(road),VGroup(Dot(a,color=CYAN),Dot(b,color=GOLD),
                Arrow(a+[0,.33,0],a+[1.4,.33,0],buff=0,color=CYAN,stroke_width=3.0),
                Arrow(b+[0,.33,0],b+[-1.7,.33,0],buff=0,color=GOLD,stroke_width=3.0))
    if kind=="round":
        c=np.array([-3.68,-.19,0])
        return (VGroup(Circle(radius=1.56,color=MUTED,stroke_width=2.3).move_to(c)),
                VGroup(Dot(c+[1.56,0,0],color=CYAN),Dot(c+[0,1.56,0],color=GOLD),
                       Arrow(c+[1.56,.06,0],c+[1.56,.69,0],buff=0,color=CYAN,stroke_width=3.0),
                       Arrow(c+[-.06,1.56,0],c+[-.72,1.56,0],buff=0,color=GOLD,stroke_width=3.0)))
    if kind=="river":
        a=np.array([-5.96,-.16,0]); b=np.array([-1.34,-.16,0])
        return (VGroup(Line(a,b,color=MUTED,stroke_width=1.6)),
                VGroup(Arrow(a+[.10,.45,0],b+[0,.45,0],buff=0,color=CYAN,stroke_width=3),
                       Arrow(b+[0,-.45,0],a+[.10,-.45,0],buff=0,color=GOLD,stroke_width=3)))
    if kind=="brake":
        ax=Axes(x_range=[0,6.7,1],y_range=[0,36,10],x_length=5.14,y_length=3.5,
                axis_config={"color":MUTED,"stroke_width":1.6,"include_ticks":False}).move_to([-3.6,-.22,0])
        defined=ax.plot(lambda t:16*t-2*t*t,x_range=[0,4,.05],color=CYAN,stroke_width=3)
        extension=ax.plot(lambda t:16*t-2*t*t,x_range=[4,6.53,.05],color=MUTED,stroke_width=1.7)
        return (VGroup(ax,defined),
                VGroup(extension,Line(ax.c2p(0,24),ax.c2p(6.4,24),color=GOLD,stroke_width=2),
                       Dot(ax.c2p(2,24),color=CYAN),Dot(ax.c2p(6,24),color=ROSE)))
    if kind=="loan":
        x=[-6.07,-3.65,-1.24]
        y=[1.1,-.05,-1.37]
        p=[np.array([a,b,0]) for a,b in zip(x,y)]
        return (VGroup(Line([-6.05,-1.39,0],[-1.15,-1.39,0],color=GRID,stroke_width=1.8)),
                VGroup(*[Dot(dot,radius=.068,color=CYAN) for dot in p],
                       Line(p[0],p[1],color=CYAN,stroke_width=4),Line(p[1],p[2],color=GOLD,stroke_width=4),
                      *[equation(form,INK,dot+[0,.30,0],.31) for dot,form in zip(p,("S","S/2","0"))]))
    return VGroup(),VGroup()


class AppliedLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind=="loan" else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
