from queue import Queue
from threading import Thread

import av
from manim import config
from manim.scene.scene_file_writer import SceneFileWriter


def open_cairo_segment(self, file_path=None):
    """Create a segment with each sample in presentation order."""
    path = file_path if file_path is not None else self.partial_movie_files[self.renderer.num_plays]
    self.partial_movie_file_path = path
    self.video_container = av.open(path, "w")
    self.video_stream = self.video_container.add_stream(
        "libx264", rate=int(config.frame_rate),
        options={"preset":"veryfast","crf":"20","bf":"0","threads":"2","tune":"animation"},
    )
    self.video_stream.width = config.pixel_width
    self.video_stream.height = config.pixel_height
    self.video_stream.pix_fmt = "yuv420p"
    self.queue = Queue(maxsize=32)
    self.writer_thread = Thread(target=self.listen_and_write)
    self.writer_thread.start()


def enable():
    SceneFileWriter.open_partial_movie_stream = open_cairo_segment
