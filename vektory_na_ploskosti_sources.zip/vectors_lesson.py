from pathlib import Path
import math

from manim import *
from lesson_data import BEATS

from visual_style import equation, BLACK_BG, INK, MUTED, CYAN, GOLD, ROSE, LAVENDER, GRID, txt

config.background_color = BLACK_BG
config.pixel_width, config.pixel_height, config.frame_rate = 1920, 1080, 60

LEFT_CENTER = np.array([-3.48, -.32, 0])
TITLE = "Векторы на плоскости"

def vector(a,b,color):
    return Arrow(a,b,buff=0,color=color,stroke_width=4,max_tip_length_to_length_ratio=.23)

def diagram(kind):
    if kind == "tangent":
        scale = .133
        def point(x,y):
            return LEFT_CENTER + scale*np.array([x-22,y,0])
        n,o,m = point(0,0),point(33.8,0),point(28.8,0)
        a,b,c = point(28.8,12),point(28.8,-12),point(38.8,12)
        base = VGroup(Circle(radius=13*scale,color=MUTED,stroke_width=2.4).move_to(o),
                      Line(n,a,color=CYAN,stroke_width=3.1),Line(n,b,color=CYAN,stroke_width=3.1),
                      Line(b,c,color=LAVENDER,stroke_width=2.4))
        steps = [
            VGroup(Line(a,c,color=GOLD,stroke_width=3.4),Line(a,b,color=MUTED,stroke_width=2.6),
                   *[Dot(q,radius=.041,color=INK) for q in (n,o,m,a,b,c)],
                   *[txt(t,19).next_to(q,v,buff=.1) for t,q,v in
                     (("N",n,LEFT),("O",o,RIGHT),("M",m,UL),("A",a,UP),("B",b,DOWN),("C",c,UP))]),
            VGroup(DashedLine(n,o,color=GOLD,stroke_width=2.3)),
            VGroup(Line(m,b,color=ROSE,stroke_width=3.4),Line(o,m,color=GOLD,stroke_width=3.4)),
        ]
        return base,steps
    basis = VGroup(
        Arrow(LEFT_CENTER+LEFT*2.85,LEFT_CENTER+RIGHT*2.85,buff=0,color=GRID,stroke_width=2),
        Arrow(LEFT_CENTER+DOWN*2.12,LEFT_CENTER+UP*2.12,buff=0,color=GRID,stroke_width=2),
        txt("x",17,MUTED).move_to(LEFT_CENTER+[2.8,-.23,0]),
        txt("y",17,MUTED).move_to(LEFT_CENTER+[-.2,2.07,0]),
    )
    def p(a):
        return LEFT_CENTER+.43*np.array([*a,0])
    o = p((0,0))
    if kind == "displacement":
        a,b,t = p((-1,1)),p((2,3)),p((2,1))
        return basis,[VGroup(vector(a,b,CYAN),txt("A",19).next_to(a,LEFT,buff=.12),
                             txt("B",19).next_to(b,UP,buff=.12)),
                      VGroup(DashedLine(a,t,color=GOLD),DashedLine(t,b,color=LAVENDER)),
                      VGroup(vector(b,a,ROSE).shift(UP*.12))]
    if kind == "length":
        a,b,t=o,p((-3,4)),p((-3,0))
        return basis,[VGroup(vector(a,b,CYAN)),VGroup(Line(a,t,color=GOLD),Line(t,b,color=LAVENDER)),
                      VGroup(txt("5",20,CYAN).move_to((a+b)/2+np.array([.27,.18,0])))]
    if kind == "scale":
        return basis,[VGroup(vector(o,p((1,2)),CYAN)),VGroup(vector(o,p((-2,-4)),GOLD))]
    if kind == "sum":
        a,b,s=p((3,1)),p((-1,2)),p((2,3))
        return basis,[VGroup(vector(o,a,CYAN),vector(a,s,LAVENDER)),
                      VGroup(DashedLine(o,b,color=LAVENDER),DashedLine(b,s,color=CYAN)),
                      VGroup(vector(o,s,GOLD))]
    if kind == "difference":
        a,b=p((3,1)),p((-1,2))
        return basis,[VGroup(vector(o,a,CYAN),vector(o,b,LAVENDER)),
                      VGroup(txt("P",19).next_to(a,RIGHT,buff=.11),txt("Q",19).next_to(b,UP,buff=.11)),
                      VGroup(vector(b,a,GOLD))]
    if kind=="combo":
        a,b=p((4,-2)),p((3,-5))
        return basis,[VGroup(vector(o,a,CYAN)),VGroup(vector(a,b,LAVENDER)),VGroup(vector(o,b,GOLD))]
    if kind=="dot_example":
        a,b,c,d=[o+(p(coordinates)-o)*.72 for coordinates in
                 [(2,-1),(1,4),(-2,3),(4,7)]]
        return basis,[VGroup(vector(o,a,CYAN),
                             txt("a",18,CYAN).next_to(a,DOWN,buff=.10)),
                      VGroup(vector(o,b,LAVENDER),vector(o,c,ROSE),
                             txt("b",18,LAVENDER).next_to(b,UL,buff=.09),
                             txt("c",18,ROSE).next_to(c,LEFT,buff=.10)),
                      VGroup(DashedLine(a,d,color=LAVENDER),
                             vector(o,d,GOLD),
                             txt("a + 2b",19,GOLD).next_to(d,RIGHT,buff=.08))]
    if kind=="cos_case" or kind=="perp":
        if kind=="cos_case":
            grid = VGroup(*[
                Line(p((v,-4)),p((v,4)),color=GRID,stroke_width=.8)
                for v in range(-5,6) if v
            ], *[
                Line(p((-5,v)),p((5,v)),color=GRID,stroke_width=.8)
                for v in range(-4,5) if v
            ])
            basis.add(grid)
        a,b = ((4,3),(-3,4)) if kind=="cos_case" else ((3,4),(4,-3))
        return basis,[VGroup(vector(o,p(a),CYAN),vector(o,p(b),LAVENDER)),
                      VGroup(DashedLine(p((a[0],0)),p(a),color=CYAN),
                             DashedLine(p((b[0],0)),p(b),color=LAVENDER)),VGroup()]
    if kind=="angle":
        a,b=p((4,0)),p((2.5,math.sqrt(3)*2.5))
        return basis,[VGroup(vector(o,a,CYAN),vector(o,b,LAVENDER)),
                      VGroup(Arc(start_angle=0,angle=PI/3,radius=.43,arc_center=o,color=GOLD)),VGroup()]
    a,b=p((4,1)),p((1,4))
    return basis,[VGroup(vector(o,a,CYAN),vector(o,b,LAVENDER)),
                  VGroup(Line(a,b,color=GOLD,stroke_width=3)),
                  VGroup(Arc(start_angle=np.arctan(.25),angle=np.arctan(4)-np.arctan(.25),
                             radius=.43,arc_center=o,color=ROSE))]

class VectorsLesson(Scene):
    def construct(self):
        script_lines=[TITLE,"Сценарий для озвучки"]
        head=txt(TITLE,27).to_edge(LEFT,buff=.55).to_edge(UP,buff=.28)
        rule=Line([-6.55,2.79,0],[6.55,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(head),Create(rule),run_time=1.3)
        for chapter,(name,kind,steps) in enumerate(BEATS,1):
            sub=txt(name,23,MUTED).move_to([0,2.4,0])
            count=txt(f"{chapter:02d} / {len(BEATS):02d}",16,MUTED).move_to([6.1,3.55,0])
            base,builds=diagram(kind)
            self.play(FadeIn(sub),FadeIn(count),Create(base),run_time=1.2,rate_func=smootherstep)
            stage=[sub,count,base]
            script_lines.extend(["", name])
            steps_y=[1.25,.18,-1.06] if len(steps)==3 else [1.1,-.2]
            for i,(formula,speech) in enumerate(steps):
                color=(INK,CYAN,GOLD)[i]
                height=.77 if chapter==9 and i==0 else (.40 if chapter==12 and i==0 else .47)
                visual=equation(formula,color,[3.31,steps_y[i],0],height)
                if visual.width>6.37:
                    visual.scale_to_fit_width(6.37)
                animations=[FadeIn(visual,shift=UP*.09)]
                stage.append(visual)
                if i<len(builds) and builds[i].submobjects:
                    animations.append(FadeIn(builds[i],shift=UP*.04))
                    stage.append(builds[i])
                self.play(*animations,run_time=.8,rate_func=smootherstep)
                start=round(self.time)
                self.wait(math.ceil(len(speech.split())/2.0)+1)
                end=round(self.time)
                clock=lambda t:f"{t//60:02d}:{t%60:02d}"
                script_lines.extend([f"[{clock(start)}–{clock(end)}]",speech])
            self.play(*[FadeOut(m) for m in stage],run_time=.85,rate_func=smootherstep)
        self.play(FadeOut(head),FadeOut(rule),run_time=1)
        Path("vectors_narration.txt").write_text("\n".join(script_lines)+"\n",encoding="utf-8-sig")
