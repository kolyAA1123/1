from pathlib import Path
import math
import json

import numpy as np
from manim import Circle, Create, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Комбинаторика и вероятность"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



def graph(kind):
    if kind=="dice":
        grid=VGroup()
        points=VGroup()
        for j in range(1,7):
            for i in range(1,7):
                pos=[-5.7+.61*(i-1),-1.62+.58*(j-1),0]
                choose=i+j==7
                grid.add(Dot(pos,radius=.033,color=MUTED))
                if choose:
                    points.add(Dot(pos,radius=.083,color=CYAN))
        for i in range(1,7):
            grid.add(equation(str(i),MUTED,[-5.7+.61*(i-1),-2.04,0],.235))
            grid.add(equation(str(i),MUTED,[-6.08,-1.62+.58*(i-1),0],.235))
        return grid,points
    if kind=="venn":
        a=Circle(radius=1.43,stroke_width=2.7,color=CYAN).move_to([-4.35,-.09,0])
        b=Circle(radius=1.43,stroke_width=2.7,color=GOLD).move_to([-2.96,-.09,0])
        return VGroup(a,b),VGroup(txt("A",24,CYAN).move_to([-4.83,.42,0]),
                                   txt("B",24,GOLD).move_to([-2.53,.42,0]),
                                   equation(r"A\cap B",INK,[-3.65,-.30,0],.26))
    if kind=="tree":
        node=np.array([-5.91,0,0])
        mid=np.array([-4.03,1.03,0])
        low=np.array([-4.03,-1.03,0])
        stem=VGroup(*[Dot(p,radius=.052,color=INK) for p in (node,mid,low)],
                    Line(node,mid,color=CYAN,stroke_width=3),Line(node,low,color=LAVENDER,stroke_width=3))
        for p,label in ((mid,r"B_1"),(low,r"B_2")):
            stem.add(equation(label,INK,p+[0,.26,0],.23))
        leaves=VGroup()
        for node,col in ((mid,CYAN),(low,LAVENDER)):
            for side,letter in ((1,r"A"),(-1,r"\overline{A}")):
                end=node+[1.75,.40*side,0]
                leaves.add(Line(node,end,color=col,stroke_width=3),Dot(end,radius=.046,color=col),
                           equation(letter,col,end+[.34,0,0],.22))
        return stem,leaves
    if kind=="cards":
        red=VGroup(txt("Красные",22,ROSE).move_to([-3.72,1.03,0]))
        blue=VGroup(txt("Синие",22,CYAN).move_to([-3.72,-.58,0]))
        labels=VGroup(equation(r"-118,-116,\ldots,90",ROSE,[-3.72,.4,0],.33),
                      equation(r"-115,-110,\ldots,105",CYAN,[-3.72,-1.24,0],.33))
        return VGroup(red,blue),labels
    return VGroup(),VGroup()


class ProbabilityLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind in ("cards",) else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
