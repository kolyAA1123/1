from pathlib import Path
import math
import json

import numpy as np
from manim import Circle, Create, DashedLine, Dot, Ellipse, FadeIn, FadeOut, Line, Polygon, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Стереометрия"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



PROJECTION=np.array([[5,-4,0],[-24,-30,41]],dtype=float)
PROJECTION/=np.linalg.norm(PROJECTION,axis=1)[:,None]

def space_struct(points, edges, accents=(), face=(), labels=()):
    model={name:PROJECTION@np.array(value) for name,value in points.items()}
    values=np.array(list(model.values()))
    middle=(values.max(axis=0)+values.min(axis=0))/2
    extent=values.max(axis=0)-values.min(axis=0)
    scale=min(4.93/max(extent[0],.05),3.76/max(extent[1],.05))
    pos={name:np.r_[(location-middle)*scale+[-3.63,-.24],0] for name,location in model.items()}
    surfaces=VGroup()
    base=VGroup()
    if face:
        surfaces.add(Polygon(*[pos[name] for name in face],color=GOLD,stroke_width=2.7,fill_opacity=.12))
    for sequence,group,color in ((edges,base,CYAN),(accents,surfaces,LAVENDER)):
        for a,b in sequence:
            cls=DashedLine if color==LAVENDER else Line
            group.add(cls(pos[a],pos[b],color=color,stroke_width=2.8))
    for name in labels:
        target=base if name in "ABCDS" else surfaces
        point=pos[name]
        normal=point-np.array([-3.63,-.24,0])
        shift=.18*normal/max(.25,np.linalg.norm(normal))
        if abs(shift[1])<.07:
            shift[1] += .13
        target.add(Dot(point,radius=.04,color=INK),
                   txt(name,18,INK).move_to(point+shift))
    return base,surfaces


def graph(kind):
    if kind is None:
        return VGroup(),VGroup()
    if kind in ("tetra","tetra_section","tetra_normal"):
        s=math.sqrt(3)
        point={"A":(0,0,0),"B":(6,0,0),"C":(3,s,2*math.sqrt(6)),"D":(3,3*s,0),
               "M":(4,0,0),"K":(2,2*s,0)}
        edge=[("A","B"),("B","D"),("D","A"),("C","A"),("C","B"),("C","D")]
        if kind=="tetra":
            return space_struct(point,edge,labels="ABCD")
        if kind=="tetra_normal":
            point["Q"]=(2,0,0)
            point["N"]=(4,2/s,0)
            return space_struct(point,edge,accents=[("A","C"),("Q","N")],face="MCK",labels="ABCDMK")
        return space_struct(point,edge,face="MCK",labels="ABCDMK")
    if kind=="dihedral":
        point={"A":(0,0,0),"B":(3,0,0),"C":(3,2,0),"D":(0,2,0),
               "E":(3,1,math.sqrt(3)),"F":(0,1,math.sqrt(3)),
               "O":(1.5,0,0),"H":(1.5,1.8,0),"K":(1.5,.9,.9*math.sqrt(3))}
        return space_struct(point,[("A","B"),("B","C"),("C","D"),("D","A")],
                            accents=[("O","H"),("O","K")],face="ABEF",labels="OHK")
    if kind in ("prism","pyramid","section_parallel"):
        if kind=="prism":
            point={"A":(0,0,0),"B":(2.5,0,0),"C":(1.65,2.,0),
                   "A₁":(.5,.1,2),"B₁":(3,.1,2),"C₁":(2.15,2.1,2)}
            return space_struct(point,[("A","B"),("B","C"),("C","A"),("A₁","B₁"),("B₁","C₁"),
                 ("C₁","A₁"),("A","A₁"),("B","B₁"),("C","C₁")],labels=point)
        point={"A":(0,0,0),"B":(2.4,0,0),"C":(2.4,2.4,0),"D":(0,2.4,0),
               "S":(1.2,1.2,3.1),"O":(1.2,1.2,0),"M":(1.2,0,0)}
        if kind=="section_parallel":
            for source,new in zip("ABCD","EFGK"):
                point[new]=tuple(.5*(np.array(point[source])+np.array(point["S"])))
        edge=[("A","B"),("B","C"),("C","D"),("D","A")]+[("S",x) for x in "ABCD"]
        return space_struct(point,edge,accents=[("O","S"),("M","S")] if kind=="pyramid" else [],
                 face="EFGK" if kind=="section_parallel" else (), labels="ABCDSOM" if kind=="pyramid" else "ABCDS")
    if kind in ("cube","hex_section","point_plane"):
        base=np.array([(0,0,0),(1,0,0),(1,1,0),(0,1,0)])
        point=dict(zip("ABCD",base))
        for name,pos in zip("ABCD",base):
            point[name+"₁"]=pos+[0,0,1]
        edge=[(a,b) for a,b in zip("ABCD","BCDA")]+[(a+"₁",b+"₁") for a,b in zip("ABCD","BCDA")]
        edge += [(a,a+"₁") for a in "ABCD"]
        if kind=="hex_section":
            six=np.array([(1,.5,0),(.5,1,0),(0,1,.5),(0,.5,1),(.5,0,1),(1,0,.5)])
            point.update(dict(zip("MNKPQT",six)))
            return space_struct(point,edge,face="MNKPQT",labels="MNKPQT")
        if kind=="point_plane":
            point.update({"P":(.55,.4,1),"H":(.55,.4,0)})
            return space_struct(point,edge,accents=[("P","H"),("P","A"),("H","A")],labels="PH")
        return space_struct(point,edge,accents=[("A","C₁")],labels=point)
    if kind in ("cylinder","cone","sphere"):
        if kind=="sphere":
            center=np.array([-3.67,-.16,0])
            outer=Circle(radius=1.62,color=CYAN,stroke_width=2.7).move_to(center)
            cross=Ellipse(width=2.94,height=.65,color=GOLD,stroke_width=2.8).move_to(center+[0,.68,0])
            return VGroup(outer),VGroup(cross,Dot(center,color=INK,radius=.049),
                                      DashedLine(center,center+[0,.68,0],color=LAVENDER))
        x=-3.67
        lower=Ellipse(width=3.5,height=.62,color=CYAN,stroke_width=2.7).move_to([x,-1.46,0])
        high=[x,1.52,0]
        mid=[x,-1.46,0]
        if kind=="cone":
            base=VGroup(lower,*[Line(high,[x+horizontal,-1.46,0],color=CYAN,stroke_width=2.7) for horizontal in (-1.75,1.75)])
            return base,VGroup(DashedLine(high,mid,color=LAVENDER),Line(mid,[x+1.75,-1.46,0],color=GOLD,stroke_width=3))
        upper=lower.copy().move_to(high)
        base=VGroup(lower,upper,*[Line([x+h,-1.46,0],[x+h,1.52,0],color=CYAN,stroke_width=2.7) for h in (-1.75,1.75)])
        return base,VGroup(DashedLine(high,mid,color=LAVENDER),Line(mid,[x+1.75,-1.46,0],color=GOLD,stroke_width=3))
    raise ValueError(kind)


class StereometryLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind=="tetra_section" else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
