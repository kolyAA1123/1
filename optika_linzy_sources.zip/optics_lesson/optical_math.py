"""Signed paraxial geometry, independent of rendering and physical units."""
import math


def image_solution(F, d, h=.6):
    """Real object at x=-d; F>0 converging, f<0 virtual, H is a size."""
    if not math.isfinite(F) or F == 0 or d <= 0 or h <= 0:
        raise ValueError('Need finite nonzero F and positive d,h')
    if math.isclose(d, F, abs_tol=1e-10, rel_tol=1e-10):
        return dict(F=F, d=d, h=h, f=math.inf, m=None, H=None, y=None, finite=False)
    f = F*d/(d-F)
    m = -f/d
    return dict(F=F, d=d, h=h, f=f, m=m, H=abs(m*h), y=m*h, finite=True)


def refracted_slope(y, k, F):
    """Slope after a thin lens at x=0 for left-to-right propagation."""
    return k-y/F


def viewport_end(y, slope, right=5.4, low=-2.2, high=2.0):
    """Clip an outgoing ray to the content rectangle, never to the title."""
    x = right
    if slope > 1e-12:
        x = min(x, (high-y)/slope)
    elif slope < -1e-12:
        x = min(x, (low-y)/slope)
    if x <= 0:
        raise ValueError('Ray starts outside the viewport')
    return x, y+slope*x
