"""Thin converging lenses, focal geometry and principal rays: PDF pp1–8."""
from optics_style import *
from optical_geometry import lens_symbol,ray_segment,refracted_slope


LA_O=np.array([-3.4,0.,0.])
LA_F=1.7


def la_body(kind='double',center=(-3.4,0,0),height=2.8,width=.65):
    h=height/2;w=width
    body=VMobject(color=LAVENDER,stroke_width=2.2)
    body.start_new_path(np.array([0,h,0]))
    body.add_cubic_bezier_curve_to(np.array([.9*w,.55*h,0]),np.array([.9*w,-.55*h,0]),np.array([0,-h,0]))
    if kind=='plano':
        body.add_line_to(np.array([0,h,0]))
    elif kind=='meniscus':
        body.add_cubic_bezier_curve_to(np.array([.45*w,-.55*h,0]),np.array([.45*w,.55*h,0]),np.array([0,h,0]))
    else:
        body.add_cubic_bezier_curve_to(np.array([-.9*w,-.55*h,0]),np.array([-.9*w,.55*h,0]),np.array([0,h,0]))
    body.close_path();body.set_fill(LAVENDER,opacity=.15)
    # Centre asymmetric form icons about the schematic refraction plane.
    if kind=='plano':body.shift(LEFT*.3375*w)
    elif kind=='meniscus':body.shift(LEFT*.50625*w)
    return body.shift(np.array(center,dtype=float))


def la_symbol(center=(-3.4,0,0),height=3.0):
    return lens_symbol(F=LA_F,center=center,height=height)


def la_base(foci='both',plane=False):
    axis=Line([-6.15,0,0],[-.3,0,0],color=GRID,stroke_width=1.5)
    center=Dot(LA_O,radius=.035,color=INK)
    labels=VGroup(formula('O',[-3.73,-1.03,0],24,MUTED,width=.5))
    marks=VGroup(center)
    if foci in ('both','left'):
        marks.add(Dot(LA_O+LEFT*LA_F,radius=.035,color=GOLD))
        labels.add(formula('F_1',[-5.4,-.4,0],24,GOLD,width=.65))
    if foci in ('both','right'):
        marks.add(Dot(LA_O+RIGHT*LA_F,radius=.035,color=GOLD))
        labels.add(formula('F_2',[-1.4,-.45,0],24,GOLD,width=.65))
    parts=VGroup(axis,la_symbol(),marks,labels)
    if plane:parts.add(DashedLine([-1.7,-1.7,0],[-1.7,1.9,0],color=LAVENDER,stroke_width=1.5,dash_length=.09))
    return parts


def la_ray(p,q,color=CYAN):
    return ray_segment(p,q,color=color)


def la_bundle(slope=0,heights=(-.65,0,.65),reverse=False):
    """One fixed paraxial bundle: k_out=k_in-y/F, with exact common focus."""
    incoming=VGroup();outgoing=VGroup()
    for h in heights:
        hit=LA_O+UP*h
        left=np.array([-6.,h+slope*(-6-LA_O[0]),0])
        k_out=refracted_slope(h,slope,LA_F)
        right=np.array([-.4,h+k_out*(-.4-LA_O[0]),0])
        if reverse:
            focus=LA_O+np.array([LA_F,slope*LA_F,0])
            incoming.add(la_ray(focus,hit))
            outgoing.add(la_ray(hit,left))
        else:
            incoming.add(la_ray(left,hit))
            outgoing.add(la_ray(hit,right))
    return incoming,outgoing


class LensGeometry(OpticsScene):
    chapter_id=7
    def chapter(self):
        self.beat(0)
        c1=Circle(radius=1.5,color=GRID).move_to([-4.5,0,0])
        c2=Circle(radius=1.5,color=GRID).move_to([-2.1,0,0])
        circles=VGroup(DashedVMobject(c1,num_dashes=30),DashedVMobject(c2,num_dashes=30))
        names=VGroup(Dot(c1.get_center(),radius=.035),Dot(c2.get_center(),radius=.035),
                     formula('O_1',[-4.5,-.4,0],25,MUTED,width=.65),formula('O_2',[-2.1,-.4,0],25,MUTED,width=.65))
        body=Intersection(c1,c2,color=LAVENDER,fill_color=LAVENDER,fill_opacity=.17,stroke_width=2)
        axis=Line([-6,0,0],[-.5,0,0],color=INK,stroke_width=1.5)
        self.show(circles,names,words(['Сферические поверхности','Линза — прозрачное тело'],[3.1,1.2,0],26),run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(FadeIn(body),Create(axis),lag_ratio=.3))
        self.show(words(['Прямая через центры кривизны','Главная оптическая ось'],[3.1,-.9,0],25,GOLD),
                  words('На рисунке показано сечение линзы',[0,-2.5,0],23,MUTED,width=11.8),run_time=1.2)
        self.result(0)

        self.beat(1)
        body=la_body(width=.45)
        axis=Line([-6.1,0,0],[-.3,0,0],color=GRID,stroke_width=1.5)
        point=VGroup(Dot(LA_O,radius=.045,color=GOLD),formula('O',[-3.75,-.4,0],28,GOLD,width=.6))
        self.show(body,axis,words(['Толщина мала по сравнению','с радиусами кривизны'],[3.1,1.5,0],25),run_time=1.2)
        self.intro(1)
        self.act(1,Succession(FadeOut(body),FadeIn(la_symbol())),FadeIn(point))
        self.show(words(['O — оптический центр','Пересечение плоскости линзы с осью'],[3.1,-.45,0],24,GOLD),
                  words(['Тонкая параксиальная модель','Одинаковая среда с двух сторон'],[3.1,-2.0,0],22,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        base=la_base(foci=False)
        start=np.array([-6,-1.,0]);end=np.array([-.4,3/2.6,0])
        ray_in=la_ray(start,LA_O,GOLD);ray_out=la_ray(LA_O,end,GOLD)
        self.show(base,ray_in,words(['Луч направлен через O','Тонкая линза'],[3.1,1.4,0],26),run_time=1.2)
        self.intro(2)
        self.act(2,Create(ray_out),rate_func=linear)
        self.show(words(['В модели направление не меняется','Входящий и вышедший участки','лежат на одной прямой'],[3.1,-.5,0],25,GOLD),
                  words('Применяем тонкую параксиальную модель',[0,-2.55,0],23,MUTED,width=11.8),run_time=1.2)
        self.result(2)


class ConvergingLensFocus(OpticsScene):
    chapter_id=8
    def chapter(self):
        self.beat(0)
        xs=(-4.4,0,4.4)
        names=['Двояковыпуклая','Плоско-выпуклая','Вогнуто-выпуклая']
        bodies=VGroup(*[la_body(kind,(x,0,0),height=1.8,width=.45) for x,kind in zip(xs,['double','plano','meniscus'])])
        labels=VGroup(*[words(name,[x,-1.45,0],24,width=3.6) for x,name in zip(xs,names)])
        rays=VGroup()
        for x in xs:
            for h in (-.32,.32):
                rays.add(la_ray([x-1.35,h,0],[x,h,0]),la_ray([x,h,0],[x+1.4,h*(1-1.4/.9),0]))
        self.show(bodies,labels,words('Показатель преломления линзы больше, чем у среды',[0,2.1,0],25,MUTED,width=12),run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(*[Create(r) for r in rays],lag_ratio=.06),rate_func=linear)
        self.show(words(['Тип определяется преломлением в данной среде','Одна форма сама по себе ещё не задаёт тип линзы'],[0,-2.5,0],23,GOLD,width=12),run_time=1.2)
        self.result(0)

        self.beat(1)
        incoming,outgoing=la_bundle()
        self.show(la_base(),incoming,words(['Пучок параллелен главной оси','Собирающая тонкая линза'],[3.1,1.35,0],26),run_time=1.2)
        self.intro(1)
        self.act(1,LaggedStart(*[Create(r) for r in outgoing],lag_ratio=.2),rate_func=linear)
        self.show(words(['Вышедшие лучи пересекаются','в заднем фокусе F₂'],[3.1,-.7,0],26,GOLD),
                  words('Далее лучи продолжают распространяться',[0,-2.55,0],23,MUTED,width=11.8),run_time=1.2)
        self.result(1)

        self.beat(2)
        measurements=VGroup(DoubleArrow([-5.1,-1.6,0],[-3.4,-1.6,0],buff=0,color=GOLD,stroke_width=1.8),
                            DoubleArrow([-3.4,-1.6,0],[-1.7,-1.6,0],buff=0,color=GOLD,stroke_width=1.8),
                            formula('F',[-4.25,-2.0,0],27,GOLD,width=.5),formula('F',[-2.55,-2.0,0],27,GOLD,width=.5))
        self.show(la_base(),words(['Для света слева направо','F₁ — передний, F₂ — задний фокус'],[3.1,1.4,0],25),run_time=1.2)
        self.intro(2)
        self.act(2,Create(measurements),rate_func=linear)
        self.show(formula(r'OF_1=OF_2=F',[3.1,-.15,0],36,GOLD),
                  words(['Одинаковая среда по обе стороны','Фокусы симметричны в тонкой модели'],[3.1,-1.9,0],23,MUTED),run_time=1.2)
        self.result(2)


class FocalLengthPowerReversibility(OpticsScene):
    chapter_id=9
    def chapter(self):
        self.beat(0)
        distance=VGroup(DoubleArrow([-3.4,-1.6,0],[-1.7,-1.6,0],buff=0,color=GOLD,stroke_width=2),
                        formula('F',[-2.55,-2.03,0],30,GOLD,width=.5))
        self.show(la_base(),words(['Фокусное расстояние F','От оптического центра до фокуса'],[3.1,1.4,0],25),run_time=1.2)
        self.intro(0)
        self.act(0,Create(distance))
        self.show(formula(r'D=\frac{1}{F}',[3.1,-.3,0],47,GOLD),
                  words('Оптическая сила характеризует преломление',[3.1,-2.0,0],23,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        bases=VGroup();rays=VGroup()
        for y,f in ((1.05,1.05),(-1.15,1.9)):
            bases.add(Line([-6.1,y,0],[-.4,y,0],color=GRID,stroke_width=1.3),la_symbol((-4.1,y,0),height=1.2),Dot([-4.1+f,y,0],radius=.035,color=GOLD))
            for h in (-.25,.25):
                rays.add(la_ray([-6,y+h,0],[-4.1,y+h,0]),la_ray([-4.1,y+h,0],[-.5,y+h-h*3.6/f,0]))
        labels=VGroup(words('Меньше F — больше D',[-3.2,2.15,0],23,GOLD,width=5.4),
                      words('Больше F — меньше D',[-3.2,-2.2,0],23,MUTED,width=5.4))
        self.show(bases,labels,formula(r'1\,\mathrm{дптр}=1\,\mathrm{м}^{-1}',[3.1,1.5,0],36),
                  words('F подставляют в метрах',[3.1,.4,0],25,GOLD),run_time=1.2)
        self.intro(1)
        self.act(1,LaggedStart(*[Create(r) for r in rays],lag_ratio=.08),rate_func=linear)
        self.show(formula(r'F>0,\qquad D>0',[3.1,-.9,0],34,GOLD),
                  words('Собирающая линза в принятой модели',[3.1,-2.05,0],23,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        incoming,outgoing=la_bundle(reverse=True)
        source=VGroup(Dot(LA_O+RIGHT*LA_F,radius=.07,color=GOLD),formula('S',[-1.65,.45,0],28,GOLD,width=.5))
        self.show(la_base(),source,words(['Точечный источник справа в фокусе','Обратимость хода лучей'],[3.1,1.35,0],25),run_time=1.2)
        self.intro(2)
        self.act(2,Succession(LaggedStart(*[Create(r) for r in incoming],lag_ratio=.1),
                              LaggedStart(*[Create(r) for r in outgoing],lag_ratio=.1)),rate_func=linear)
        self.show(words(['Свет идёт справа налево','После линзы пучок параллелен оси'],[3.1,-.8,0],25,GOLD),
                  words('Линза направляет свет источника, а не создаёт его',[0,-2.55,0],23,MUTED,width=11.8),run_time=1.2)
        self.result(2)


class FocalPlanePrincipalRays(OpticsScene):
    chapter_id=10
    def chapter(self):
        self.beat(0)
        incoming,outgoing=la_bundle(slope=.28)
        focus=LA_O+np.array([LA_F,.28*LA_F,0])
        label=VGroup(Dot(focus,radius=.045,color=GOLD),formula(r"F^{\prime}",[-1.25,1.1,0],29,GOLD,width=.7))
        self.show(la_base(foci='right'),incoming,words(['Параллельный пучок наклонён','к главной оптической оси'],[3.1,1.45,0],26),run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(*[Create(r) for r in outgoing],lag_ratio=.15),rate_func=linear)
        self.show(label,words(['Лучи собираются в побочном фокусе','Он не лежит на главной оси'],[3.1,-.65,0],25,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        plane=DashedLine([-1.7,-1.7,0],[-1.7,1.9,0],color=LAVENDER,stroke_width=1.5,dash_length=.09)
        secondary=Line([-6,-.728,0],[-.4,.84,0],color=GOLD,stroke_width=2)
        focus=LA_O+np.array([LA_F,.28*LA_F,0])
        dot=VGroup(Dot(focus,radius=.05,color=GOLD),formula(r"F^{\prime}",[-1.25,1.1,0],29,GOLD,width=.7))
        self.show(la_base(foci='right'),plane,words(['Фокальная плоскость проходит через F₂','и перпендикулярна главной оси'],[3.1,1.55,0],24),run_time=1.2)
        self.intro(1)
        self.act(1,Create(secondary),FadeIn(dot),rate_func=linear)
        self.show(words(['Побочная ось проходит через O','Её пересечение с плоскостью — F′'],[3.1,-.45,0],25,GOLD),
                  words('На плоском рисунке плоскость показана линией',[0,-2.55,0],23,MUTED,width=11.8),run_time=1.2)
        self.result(1)

        self.beat(2)
        incoming,outgoing=la_bundle(slope=.28,reverse=True)
        focus=LA_O+np.array([LA_F,.28*LA_F,0])
        source=VGroup(Dot(focus,radius=.07,color=GOLD),formula(r"S=F^{\prime}",[-1.13,1.13,0],27,GOLD,width=1.2))
        self.show(la_base(foci='right',plane=True),source,words(['Источник в побочном фокусе','Обращаем ход лучей'],[3.1,1.4,0],26),run_time=1.2)
        self.intro(2)
        self.act(2,Succession(LaggedStart(*[Create(r) for r in incoming],lag_ratio=.1),
                              LaggedStart(*[Create(r) for r in outgoing],lag_ratio=.1)),rate_func=linear)
        self.show(words(['Вышедший пучок снова параллелен','и наклонён к главной оси','Все стрелки направлены справа налево'],[3.1,-.65,0],24,GOLD),run_time=1.2)
        self.result(2)

        self.beat(3)
        # A full-width schematic keeps all angles modest and includes the
        # common intersection of the three completed outgoing paths.
        o=np.array([0,.8,0]);start=np.array([-5,.3,0])
        hit_focus=o+UP*(.5*LA_F/(5-LA_F))
        hit_center=o;hit_parallel=o+DOWN*.5
        incoming=VGroup(la_ray(start,hit_focus,GOLD),la_ray(start,hit_center,CYAN),la_ray(start,hit_parallel,ROSE))
        outgoing=VGroup(la_ray(hit_focus,[5,hit_focus[1],0],GOLD),
                        la_ray(hit_center,[5,1.3,0],CYAN),
                        la_ray(hit_parallel,[5,.3+5*.5/LA_F,0],ROSE))
        base=VGroup(Line([-5.4,.8,0],[5.4,.8,0],color=GRID,stroke_width=1.4),la_symbol(o,height=2.6),
                    Dot(o,radius=.035),formula('O',[-.35,-.15,0],24,MUTED,width=.5),
                    Dot(o+LEFT*LA_F,radius=.035,color=GOLD),formula('F_1',[-1.7,1.2,0],24,GOLD,width=.6),
                    Dot(o+RIGHT*LA_F,radius=.035,color=GOLD),formula('F_2',[1.7,.4,0],24,GOLD,width=.6))
        source=VGroup(Dot(start,radius=.06,color=GOLD),formula('S',[-5,-.2,0],26,GOLD,width=.5))
        self.show(base,source,incoming,words('Три правила собирающей тонкой линзы',[0,2.35,0],24,MUTED,width=11.8),run_time=1.2)
        self.intro(3)
        self.act(3,LaggedStart(*[Create(r) for r in outgoing],lag_ratio=.2),rate_func=linear)
        self.show(words(['Через передний фокус → параллельно оси'],[0,-.9,0],23,GOLD,width=11.8),
                  words(['Через O → без изменения направления'],[0,-1.7,0],23,CYAN,width=11.8),
                  words(['Параллельно оси → через задний фокус'],[0,-2.5,0],23,ROSE,width=11.8),run_time=1.2)
        self.result(3)
