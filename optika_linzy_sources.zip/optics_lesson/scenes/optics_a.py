"""Geometrical optics from all seven source pages; exact ray constructions."""
from optics_style import *


def oa_ray(a, b, color=CYAN, width=2.5, tip=.13):
    return Arrow(np.array(a, float), np.array(b, float), buff=0, color=color,
                 stroke_width=width, tip_length=tip,
                 max_tip_length_to_length_ratio=.18)


def oa_reflection():
    p=np.array([-3.2,-.35,0.])
    surface=Line([-5.9,-.35,0],[-.55,-.35,0],color=INK,stroke_width=2)
    hatch=VGroup(*[Line([x,-.35,0],[x-.18,-.62,0],color=GRID,stroke_width=1.3)
                    for x in np.arange(-5.65,-.6,.32)])
    normal=DashedLine(p+DOWN*1.45,p+UP*2.45,color=MUTED,dash_length=.09)
    inc=oa_ray(p+[-1.75,1.75,0],p,CYAN)
    out=oa_ray(p,p+[1.75,1.75,0],GOLD)
    arcs=VGroup(Arc(radius=.62,start_angle=PI/2,angle=PI/4,color=CYAN).shift(p),
                Arc(radius=.8,start_angle=PI/4,angle=PI/4,color=GOLD).shift(p),
                formula(r'\alpha',p+[-.48,1.03,0],28,CYAN,width=.5),
                formula(r'\beta',p+[.48,1.03,0],28,GOLD,width=.5))
    return VGroup(surface,hatch,normal),inc,out,arcs


def oa_tangencies(source, center, radius):
    source=np.array(source,float);center=np.array(center,float)
    v=source-center;d2=np.dot(v,v)
    assert d2>radius**2
    perp=np.array([-v[1],v[0],0.])
    return [center+radius**2/d2*v+sign*radius*np.sqrt(d2-radius**2)/d2*perp
            for sign in (-1,1)]


def oa_shadows(extended=False):
    xs,xc,xe=-5.65,-3.2,-.75
    c=np.array([xc,0,0.]);r=.57;a=.34 if extended else 0.
    source=(Line([xs,-a,0],[xs,a,0],color=GOLD,stroke_width=6) if extended
            else Dot([xs,0,0],radius=.07,color=GOLD))
    obstacle=Circle(radius=r,color=INK,stroke_width=2,fill_color=GRID,fill_opacity=1).move_to(c)
    screen=Line([xe,-2.25,0],[xe,2.25,0],color=INK,stroke_width=3)
    labels=VGroup(words('Источник',[xs,-1.05,0],20,GOLD,width=1.7),
                  words('Непрозрачное тело',[xc,-1.75,0],20,MUTED,width=3.3),
                  words('Экран',[xe,2.45,0],20,MUTED,width=1.3))
    bounds=[];rays=VGroup()
    for sy in ([-a,a] if extended else [0.]):
        s=np.array([xs,sy,0.]);ends=[]
        for t in oa_tangencies(s,c,r):
            end=s+(t-s)*(xe-xs)/(t[0]-xs)
            ends.append(end[1])
            rays.add(oa_ray(s,t,GOLD,2),oa_ray(t,end,GOLD,2))
        bounds.append((min(ends),max(ends)))
    low=max(b[0] for b in bounds);high=min(b[1] for b in bounds)
    union_low=min(b[0] for b in bounds);union_high=max(b[1] for b in bounds)
    assert low<high
    umbra=Line([xe,low,0],[xe,high,0],color=GRID,stroke_width=18)
    penumbra=VGroup()
    if extended:
        penumbra.add(Line([xe,union_low,0],[xe,low,0],color=MUTED,stroke_width=18,stroke_opacity=.5),
                     Line([xe,high,0],[xe,union_high,0],color=MUTED,stroke_width=18,stroke_opacity=.5))
    return VGroup(source,obstacle,screen,labels),rays,umbra,penumbra


def oa_refract(n1=1.,n2=1.33,alpha=PI/4):
    p=np.array([-3.2,.1,0.]);beta=np.arcsin(n1*np.sin(alpha)/n2)
    edge=Line([-5.95,.1,0],[-.5,.1,0],color=INK,stroke_width=1.6)
    normal=DashedLine(p+DOWN*2.25,p+UP*2.15,color=MUTED,dash_length=.08)
    names=VGroup(formula('n_1',[-5.6,1.8,0],28,CYAN,width=.7),
                 formula('n_2',[-5.6,-1.65,0],28,GOLD,width=.7))
    incident=oa_ray(p+[-2.1*np.sin(alpha),2.1*np.cos(alpha),0],p,CYAN)
    transmitted=oa_ray(p,p+[2.1*np.sin(beta),-2.1*np.cos(beta),0],GOLD)
    angles=VGroup(Arc(radius=.62,start_angle=PI/2,angle=alpha,color=CYAN).shift(p),
                  Arc(radius=.72,start_angle=-PI/2,angle=beta,color=GOLD).shift(p),
                  formula(r'\alpha',p+[-1.17*np.sin(alpha/2),1.17*np.cos(alpha/2),0],27,CYAN,width=.45),
                  formula(r'\beta',p+[1.2*np.sin(beta/2),-1.2*np.cos(beta/2),0],27,GOLD,width=.45))
    return VGroup(edge,normal,names),incident,transmitted,angles


def oa_mirror():
    mirror_x=-3.;s=np.array([-4.9,.65,0.]);image=np.array([-1.1,.65,0.])
    mirror=VGroup(Line([mirror_x,-2.25,0],[mirror_x,2.3,0],color=INK,stroke_width=2.5),
                  *[Line([mirror_x,y,0],[mirror_x+.22,y+.16,0],color=GRID,stroke_width=1.3)
                    for y in np.arange(-2.1,2.2,.3)])
    points=VGroup(Dot(s,radius=.065,color=CYAN),formula('S',s+[-.18,.43,0],28,CYAN,width=.5))
    image_point=VGroup(Dot(image,radius=.065,color=GOLD),formula("S'",image+[.1,.43,0],28,GOLD,width=.6))
    incident=VGroup();reflected=VGroup();extensions=VGroup()
    for p,rx in [(np.array([-3.,-.42,0]),-5.2),(np.array([-3.,1.55,0]),-4.35)]:
        d=p-s;out_direction=np.array([-d[0],d[1],0.])
        end=p+out_direction*((rx-p[0])/out_direction[0])
        incident.add(oa_ray(s,p,CYAN,2.2))
        reflected.add(oa_ray(p,end,GOLD,2.2))
        extensions.add(DashedLine(p,image,color=GOLD,dash_length=.08,stroke_width=1.6))
    return VGroup(mirror,points),incident,reflected,extensions,image_point,s,image


def oa_tir(alpha, mode):
    n1,n2=1.33,1.;p=np.array([-3.2,0.,0.])
    edge=Line([-5.95,0,0],[-.45,0,0],color=INK,stroke_width=1.6)
    normal=DashedLine(p+DOWN*2.25,p+UP*2.15,color=MUTED,dash_length=.09)
    names=VGroup(words('Воздух',[-5.25,1.7,0],21,MUTED,width=1.8),
                 words('Вода',[-5.4,-1.95,0],21,MUTED,width=1.6))
    incident=oa_ray(p+[-2.12*np.sin(alpha),-2.12*np.cos(alpha),0],p,CYAN)
    reflected=oa_ray(p,p+[2.12*np.sin(alpha),-2.12*np.cos(alpha),0],CYAN)
    angle=VGroup(Arc(radius=.65,start_angle=-PI/2-alpha,angle=alpha,color=CYAN).shift(p),
                 formula(r'\alpha',p+[-1.16*np.sin(alpha/2),-1.16*np.cos(alpha/2),0],27,CYAN,width=.5))
    transmitted=VGroup()
    if mode=='critical':transmitted.add(oa_ray(p,p+[2.5,0,0],GOLD))
    elif mode=='below':
        beta=np.arcsin(n1*np.sin(alpha)/n2)
        transmitted.add(oa_ray(p,p+[2.1*np.sin(beta),2.1*np.cos(beta),0],GOLD))
    return VGroup(edge,normal,names,angle),incident,reflected,transmitted


def oa_plate():
    alpha=PI/4;beta=np.arcsin(np.sin(alpha)/1.5)
    p=np.array([-4.1,.65,0.]);q=p+[1.3*np.tan(beta),-1.3,0]
    u=np.array([np.sin(alpha),-np.cos(alpha),0.])
    slab=VGroup(Line([-5.95,.65,0],[-.45,.65,0],color=INK,stroke_width=1.5),
                Line([-5.95,-.65,0],[-.45,-.65,0],color=INK,stroke_width=1.5),
                DashedLine(p+DOWN*.8,p+UP*1.5,color=MUTED,dash_length=.08),
                DashedLine(q+DOWN*1.5,q+UP*.8,color=MUTED,dash_length=.08),
                words('Воздух',[-1.25,1.8,0],20,MUTED,width=1.6),
                words('Стекло',[-1.25,0,0],20,MUTED,width=1.6),
                words('Воздух',[-5.35,-1.8,0],20,MUTED,width=1.6))
    incident=oa_ray(p-u*1.7,p,CYAN)
    inside=oa_ray(p,q,GOLD)
    outgoing=oa_ray(q,q+u*2.2,CYAN)
    original=DashedLine(p,p+u*3.7,color=MUTED,dash_length=.08,stroke_width=1.4)
    a=q+u*.9;b=p+u*np.dot(a-p,u)
    displacement=DoubleArrow(a,b,buff=0,color=ROSE,stroke_width=2,tip_length=.07)
    name=formula('d',(a+b)/2+u*.45,28,ROSE,width=.4)
    assert abs(np.dot(b-a,u))<1e-10
    return slab,incident,inside,outgoing,original,VGroup(displacement,name)


class GeometricRaysAndReflection(OpticsScene):
    chapter_id=1
    def chapter(self):
        self.beat(0)
        start=np.array([-5.6,-.8,0.]);end=np.array([-.75,1.45,0.])
        self.show(Dot(start,radius=.07,color=GOLD),words('Световой луч',[-3.1,2.1,0],27,CYAN),
                  words(['Однородная прозрачная среда','Линия переноса световой энергии'],[3.1,1.0,0],25),run_time=1.2)
        self.intro(0);self.act(0,Create(oa_ray(start,end,CYAN)))
        self.show(words(['В этой модели путь прямолинеен','Стрелка показывает перенос энергии'],[3.1,-1.0,0],25,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        base,inc,out,angles=oa_reflection()
        self.show(base,inc,words(['Нормаль восстановлена','в точке падения'],[3.1,1.25,0],25),
                  words('Углы отсчитываются от нормали',[3.1,.1,0],24,MUTED),run_time=1.2)
        self.intro(1);self.act(1,Create(out),FadeIn(angles))
        self.show(formula(r'\alpha=\beta',[3.1,-1.05,0],43,GOLD),
                  words('Оба луча и нормаль лежат в одной плоскости',[3.1,-2.2,0],23,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        a=np.array([-5.5,-.65,0.]);b=np.array([-1.,-1.8,0.])
        forward=oa_ray(a,b,GOLD);reverse=oa_ray(b,a,GOLD)
        crossing=VGroup(oa_ray([-5.5,.6,0],[-1.,1.8,0],CYAN),oa_ray([-5.5,1.8,0],[-1.,.6,0],ROSE))
        self.show(forward,words('Независимость',[-3.2,2.25,0],23,MUTED),
                  words('Обратимость',[-3.2,-2.35,0],23,MUTED),
                  words(['Пересекающиеся лучи','не изменяют друг друга'],[3.1,1.1,0],25),run_time=1.2)
        self.intro(2);self.act(2,Succession(Create(crossing),FadeOut(forward),Create(reverse)))
        self.show(words(['Путь допускает обратное прохождение','Направление задаёт выбранный источник'],[3.1,-1.15,0],24,MUTED),run_time=1.2);self.result(2)


class PointAndExtendedShadows(OpticsScene):
    chapter_id=2
    def chapter(self):
        self.beat(0)
        base,_,_,_=oa_shadows()
        rays=VGroup(oa_ray([-5.65,0,0],[-3.77,0,0],GOLD),
                    oa_ray([-5.65,0,0],[-.75,2.05,0],GOLD,2),
                    oa_ray([-5.65,0,0],[-.75,-2.05,0],GOLD,2))
        self.show(base,words(['Точечный источник','Размеры малы в масштабе схемы'],[3.1,1.25,0],25),run_time=1.2)
        self.intro(0);self.act(0,Create(rays))
        self.show(words(['Непрозрачное тело задерживает свет','Центральный луч за телом не продолжается'],[3.1,-.8,0],24,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        base,rays,umbra,_=oa_shadows()
        self.show(base,words(['Граничные лучи касаются тела','За ним есть область без прямого света'],[3.1,1.0,0],25),run_time=1.2)
        self.intro(1);self.act(1,Create(rays))
        self.show(umbra,words(['Полная тень','Источник из неё не виден'],[3.1,-1.1,0],26,GOLD),run_time=1.2);self.result(1)

        self.beat(2)
        base,rays,umbra,penumbra=oa_shadows(True)
        self.show(base,words(['Протяжённый источник','Граничные лучи от его краёв'],[3.1,1.3,0],25),run_time=1.2)
        self.intro(2);self.act(2,Create(rays))
        self.show(umbra,penumbra,words(['Тень: источник закрыт целиком','Полутень: видна часть источника'],[3.1,-.6,0],24,GOLD),
                  words('Вне полутени источник виден полностью',[3.1,-2.1,0],23,MUTED),run_time=1.2);self.result(2)


class RefractionAndWaves(OpticsScene):
    chapter_id=3
    def chapter(self):
        self.beat(0)
        self.show(formula(r'c\approx3\cdot10^8\ \mathrm{м/с}',[-3.1,1.55,0],35,CYAN),
                  words('Скорость света в вакууме',[-3.1,.6,0],24,MUTED),
                  formula(r'n=\frac{c}{v}',[3.1,1.2,0],48,GOLD),
                  words('Абсолютный показатель преломления',[3.1,.0,0],24),run_time=1.2)
        self.intro(0)
        values=VGroup(formula(r'n_{\mathrm{воды}}\approx1{,}33',[-3.1,-.6,0],34),
                      formula(r'n_{\mathrm{воздуха}}\approx1{,}00029\approx1',[-3.1,-1.9,0],31))
        self.act(0,FadeIn(values))
        self.show(formula(r'v=\frac{c}{n}',[3.1,-1.5,0],43,CYAN),run_time=1.2);self.result(0)

        self.beat(1)
        base,inc,out,angles=oa_refract()
        self.show(base,inc,words(['Граница двух сред','Оба луча и нормаль в одной плоскости'],[3.1,1.4,0],24),run_time=1.2)
        self.intro(1);self.act(1,Create(out),FadeIn(angles))
        self.show(formula(r'n_1\sin\alpha=n_2\sin\beta',[3.1,.0,0],35,GOLD),
                  words(['n₂ > n₁: луч ближе к нормали','Оптическая плотность определяется n'],[3.1,-1.6,0],24,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        self.show(formula(r'n_1=\frac{c}{v_1}',[-3.1,1.4,0],39,CYAN),
                  formula(r'n_2=\frac{c}{v_2}',[3.1,1.4,0],39,GOLD),
                  words('Относительный показатель второй среды к первой',[0,2.3,0],24,MUTED,width=11.6),run_time=1.2)
        self.intro(2)
        ratio=formula(r'n_{21}=\frac{n_2}{n_1}=\frac{v_1}{v_2}',[0,.0,0],43,width=11.6)
        self.act(2,Write(ratio))
        self.show(formula(r'n_{21}=\frac{\sin\alpha}{\sin\beta}',[0,-1.5,0],40,GOLD,width=11.6),
                  words('Отношение синусов используют при ненулевом знаменателе',[0,-2.7,0],22,MUTED,width=11.8),run_time=1.2);self.result(2)

        self.beat(3)
        waves=VGroup()
        for y,wavelength,color in [(1.,1.55,CYAN),(-.65,1.55/1.33,GOLD)]:
            wave=VMobject(color=color,stroke_width=2.5)
            wave.set_points_smoothly([[-5.8+x,y+.23*np.sin(TAU*x/wavelength),0] for x in np.linspace(0,5.,170)])
            waves.add(wave)
        self.show(words('Воздух',[-3.3,1.8,0],23,CYAN),words('Вода',[-3.3,.15,0],23,GOLD),
                  formula(r'v=\lambda\nu',[3.1,1.65,0],39),
                  formula(r'n_1\lambda_1=n_2\lambda_2',[3.1,.55,0],34),run_time=1.2)
        self.intro(3);self.act(3,Create(waves),rate_func=linear)
        self.show(formula(r'\nu_1=\nu_2',[3.1,-.55,0],37,GOLD),
                  words(['Из воздуха в воду:','Свет: v ↓, λ ↓, ν постоянна','Звук: v ↑, λ ↑, ν постоянна'],[3.1,-1.95,0],21,MUTED),run_time=1.2);self.result(3)


class PlaneMirrorImage(OpticsScene):
    chapter_id=4
    def chapter(self):
        self.beat(0)
        base,inc,out,_,_,_,_=oa_mirror()
        self.show(base,inc,words(['Лучи исходят из точки предмета','Отражение подчиняется α = β'],[3.1,1.2,0],25),run_time=1.2)
        self.intro(0);self.act(0,Create(out))
        self.show(words(['Перед зеркалом лучи расходятся','Отражённый свет может попасть в глаз'],[3.1,-1.0,0],25,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        base,inc,out,extensions,image,_,_=oa_mirror()
        self.show(base,inc,out,words(['Продолжим отражённые лучи назад','Пунктир не изображает перенос энергии'],[3.1,1.2,0],24),run_time=1.2)
        self.intro(1);self.act(1,Create(extensions),FadeIn(image))
        self.show(words(['Изображение мнимое','За зеркалом реальные лучи не сходятся'],[3.1,-1.1,0],25,GOLD),run_time=1.2);self.result(1)

        self.beat(2)
        base,_,_,_,image,s,sp=oa_mirror()
        a=DoubleArrow([s[0],-.55,0],[-3.,-.55,0],buff=0,color=CYAN,stroke_width=2,tip_length=.1)
        b=DoubleArrow([-3.,-.55,0],[sp[0],-.55,0],buff=0,color=GOLD,stroke_width=2,tip_length=.1)
        labels=VGroup(formula('a',[-3.95,-1.05,0],29,CYAN,width=.5),formula('b',[-2.05,-1.05,0],29,GOLD,width=.5))
        guides=VGroup(DashedLine(s,[s[0],-.8,0],color=GRID,dash_length=.08),
                      DashedLine(sp,[sp[0],-.8,0],color=GRID,dash_length=.08))
        self.show(base,image,guides,words('Расстояния измеряют перпендикулярно зеркалу',[3.1,1.3,0],25),run_time=1.2)
        self.intro(2);self.act(2,Create(a),Create(b),FadeIn(labels))
        self.show(formula('a=b',[3.1,-.3,0],46,GOLD),
                  words('Точка изображения симметрична точке предмета',[3.1,-1.8,0],24,MUTED),run_time=1.2);self.result(2)


class TotalInternalReflection(OpticsScene):
    chapter_id=5
    def chapter(self):
        self.beat(0)
        base,inc,reflected,out=oa_tir(PI/6,'below')
        self.show(base,inc,words(['Из воды в воздух','n₁ > n₂, угол пока меньше критического'],[3.1,1.2,0],24),run_time=1.2)
        self.intro(0);self.act(0,Create(out),Create(reflected))
        self.show(words(['Преломлённый луч удаляется от нормали','Есть также отражённый луч'],[3.1,-1.0,0],24,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        critical=np.arcsin(1/1.33)
        base,inc,reflected,out=oa_tir(critical,'critical')
        self.show(base,inc,reflected,formula(r'n_1\sin\alpha_{\mathrm{кр}}=n_2\sin90^\circ',[3.1,1.5,0],32),
                  words('Предельный случай: угол преломления 90°',[3.1,.35,0],23,MUTED),run_time=1.2)
        self.intro(1);self.act(1,Create(out),Write(formula(r'\sin\alpha_{\mathrm{кр}}=\frac{n_2}{n_1}',[3.1,-.7,0],37,GOLD)))
        self.show(formula(r'\alpha_{\mathrm{кр}}\approx\arcsin(0{,}75)\approx49^\circ',[3.1,-2.0,0],30,GOLD),run_time=1.2);self.result(1)

        self.beat(2)
        base,inc,reflected,_=oa_tir(1.1,'above')
        self.show(base,inc,formula(r'n_1>n_2,\qquad\alpha>\alpha_{\mathrm{кр}}',[3.1,1.3,0],34),
                  words('Полное внутреннее отражение',[3.1,.2,0],25),run_time=1.2)
        self.intro(2);self.act(2,Create(reflected))
        self.show(words(['Преломлённого распространяющегося луча нет','Свет отражается обратно в первую среду'],[3.1,-1.4,0],23,GOLD),run_time=1.2);self.result(2)


class ParallelPlateAndDispersion(OpticsScene):
    chapter_id=6
    def chapter(self):
        self.beat(0)
        slab,inc,inside,out,_,_=oa_plate()
        self.show(slab,inc,words(['Параллельные грани стеклянной пластинки','С обеих сторон один и тот же воздух'],[3.1,1.2,0],24),run_time=1.2)
        self.intro(0);self.act(0,Succession(Create(inside),Create(out)))
        self.show(formula(r'n_{\mathrm{возд}}\sin\alpha=n_{\mathrm{ст}}\sin\beta=n_{\mathrm{возд}}\sin\alpha^{\prime}',[3.1,-.6,0],29,width=5.8),
                  words('На каждой границе действует закон Снеллиуса',[3.1,-2.0,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        slab,inc,inside,out,original,measure=oa_plate()
        self.show(slab,inc,inside,out,words('Пунктир — продолжение исходного направления',[3.1,1.2,0],24),run_time=1.2)
        self.intro(1);self.act(1,Create(original),FadeIn(measure))
        self.show(formula(r'\alpha=\alpha^{\prime}',[3.1,-.2,0],43,GOLD),
                  words(['Выходящий луч параллелен падающему','d измерено перпендикулярно лучам'],[3.1,-1.8,0],24,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        waves=VGroup()
        for y,wavelength,color in [(1.,1.9,RED),(-.8,1.15,PURPLE)]:
            wave=VMobject(color=color,stroke_width=2.6).set_points_smoothly(
                [[-5.8+x,y+.24*np.sin(TAU*x/wavelength),0] for x in np.linspace(0,4.8,160)])
            waves.add(wave)
        self.show(formula(r'n=n(\lambda)',[3.1,1.3,0],43,GOLD),
                  words('Дисперсия: показатель зависит от длины волны',[3.1,.1,0],24),
                  words('Красный',[-3.4,1.8,0],23,RED),words('Фиолетовый',[-3.4,0,0],23,PURPLE),run_time=1.2)
        self.intro(2);self.act(2,Create(waves),rate_func=linear)
        self.show(formula(r'\lambda_{\mathrm{кр}}>\lambda_{\mathrm{фиол}}',[3.1,-1.1,0],35),
                  words('Для обычной дисперсии прозрачного стекла',[3.1,-2.2,0],22,MUTED),run_time=1.2);self.result(2)

        self.beat(3)
        p=np.array([-4.7,-.85,0.]);alpha=PI/3
        border=Line([-4.7,-2.45,0],[-4.7,2.2,0],color=INK,stroke_width=1.5)
        normal=DashedLine([-5.95,-.85,0],[-.6,-.85,0],color=MUTED,dash_length=.08)
        inc=oa_ray(p+[-1.8*np.cos(alpha),-1.8*np.sin(alpha),0],p,INK)
        colors=[RED,ORANGE,YELLOW,GREEN,TEAL,BLUE,PURPLE]
        fan=VGroup()
        for index,color in zip(np.linspace(1.50,1.62,7),colors):
            beta=np.arcsin(np.sin(alpha)/index)
            fan.add(oa_ray(p,p+4.1*np.array([np.cos(beta),np.sin(beta),0]),color,1.8,tip=.045))
        self.show(border,normal,inc,words('Воздух',[-5.7,1.7,0],21,MUTED,width=1.5),
                  words('Стекло',[-1.25,-1.65,0],21,MUTED,width=1.5),
                  words(['Белый свет содержит разные цвета','Для них показатели преломления различны'],[3.1,1.2,0],24),run_time=1.2)
        self.intro(3);self.act(3,Create(fan))
        self.show(words(['Фиолетовый ближе к нормали','Красный отклоняется слабее'],[3.1,-.7,0],25,GOLD),
                  formula(r'\beta_{\mathrm{фиол}}<\beta_{\mathrm{кр}}',[3.1,-2.1,0],34),run_time=1.2);self.result(3)
