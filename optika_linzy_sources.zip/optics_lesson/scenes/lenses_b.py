"""Converging-lens images, signed distances and size magnification: pp9–12."""
from optics_style import *
from optical_geometry import image_construction


LB_F = 1.4
LB_H = .6


def lb_trace(construction):
    """Physical rays first; only then the imaginary backward extensions."""
    groups = [construction['incident'], construction['emergent'],
              construction['extensions']]
    return Succession(*[Create(group) for group in groups if len(group)])


def lb_image_objects(construction):
    return [construction[k] for k in ('image', 'image_labels') if len(construction[k])]


def lb_condition(tex):
    return formula(tex, (-3.6, 2.18, 0), 34, GOLD, width=4.4)


def lb_result(construction, note, location=None):
    result = lb_image_objects(construction)
    result.append(words(note, (0, -2.75, 0), 25, INK, width=11.8))
    if location:
        result.append(words(location, (3.6, 2.18, 0), 25, ROSE, width=4.4))
    return result


def lb_distance_dimensions(solution, level=-1.75):
    d, f = solution['d'], solution['f']
    return VGroup(
        DoubleArrow([-d, level, 0], [0, level, 0], buff=0,
                    color=MUTED, stroke_width=1.8,
                    max_tip_length_to_length_ratio=.08),
        DoubleArrow([0, level, 0], [f, level, 0], buff=0,
                    color=MUTED, stroke_width=1.8,
                    max_tip_length_to_length_ratio=.08),
        formula('d', (-d/2, level-.33, 0), 28, GOLD, width=.5),
        formula('f', (f/2, level-.33, 0), 28, ROSE, width=.5))


def lb_height_dimensions(solution):
    d, f, h, y = (solution[k] for k in ('d', 'f', 'h', 'y'))
    return VGroup(
        DoubleArrow([-d-.5, 0, 0], [-d-.5, h, 0], buff=0,
                    color=GOLD, stroke_width=1.7,
                    max_tip_length_to_length_ratio=.16),
        DoubleArrow([f+.5, 0, 0], [f+.5, y, 0], buff=0,
                    color=ROSE, stroke_width=1.7,
                    max_tip_length_to_length_ratio=.16),
        formula('h', (-d-.9, h/2, 0), 29, GOLD, width=.5),
        formula('H', (f+.95, y/2, 0), 29, ROSE, width=.6))


class ConvergingRealImages(OpticsScene):
    chapter_id = 11

    def chapter(self):
        cases = [
            (3.5, r'd>2F', 'Между F и 2F',
             'Действительное · перевёрнутое · уменьшенное'),
            (2.8, r'd=2F', 'В 2F',
             'Действительное · перевёрнутое · равное по размеру'),
            (2.1, r'F<d<2F', 'Дальше 2F',
             'Действительное · перевёрнутое · увеличенное'),
        ]
        for i, (distance, condition, location, note) in enumerate(cases):
            self.beat(i)
            drawing = image_construction(LB_F, distance, LB_H)
            self.show(drawing['base'], lb_condition(condition), run_time=1.2)
            self.intro(i)
            self.act(i, lb_trace(drawing), rate_func=linear)
            self.show(*lb_result(drawing, note, location), run_time=1.2)
            self.result(i)


class ConvergingVirtualAndFocus(OpticsScene):
    chapter_id = 12

    def chapter(self):
        self.beat(0)
        drawing = image_construction(LB_F, .84, LB_H)
        self.show(drawing['base'], lb_condition(r'0<d<F'), run_time=1.2)
        self.intro(0)
        self.act(0, lb_trace(drawing), rate_func=linear)
        self.show(*lb_result(drawing, 'Мнимое · прямое · увеличенное'),
                  words('Пунктир — обратные продолжения', (3.5, 1.9, 0),
                        23, MUTED, width=5.2), run_time=1.2)
        self.result(0)

        self.beat(1)
        drawing = image_construction(LB_F, LB_F, LB_H)
        self.show(drawing['base'], lb_condition(r'd=F'), run_time=1.2)
        self.intro(1)
        self.act(1, lb_trace(drawing), rate_func=linear)
        self.show(words(['Выходящие лучи параллельны',
                         'Конечного изображения нет'], (3.3, 1.9, 0),
                        24, INK, width=5.2),
                  words('Изображение на бесконечности в идеальной модели',
                        (0, -2.75, 0), 24, MUTED, width=11.8), run_time=1.2)
        self.result(1)

        self.beat(2)
        centers = (-4.95, -1.75, 1.45, 4.7)
        headings = VGroup(
            words('Предмет', (centers[0], 2.25, 0), 24, MUTED, width=2.5),
            words('Изображение', (centers[1], 2.25, 0), 24, MUTED, width=2.7),
            words('Характер', (centers[2], 2.25, 0), 24, MUTED, width=2.5),
            words(['Размер и', 'ориентация'], (centers[3], 2.25, 0),
                  21, MUTED, width=2.7))
        row_data = [
            (r'd>2F', ['Между F и 2F'], ['Действительное'],
             ['Уменьшенное', 'перевёрнутое']),
            (r'd=2F', ['В 2F'], ['Действительное'],
             ['Равное', 'перевёрнутое']),
            (r'F<d<2F', ['Дальше 2F'], ['Действительное'],
             ['Увеличенное', 'перевёрнутое']),
            (r'0<d<F', ['На стороне', 'предмета'], ['Мнимое'],
             ['Увеличенное', 'прямое']),
            (r'd=F', ['Параллельные', 'лучи'], ['Конечного нет'], ['—']),
        ]
        rows = VGroup()
        for row_y, (condition, position, kind, size) in zip(
                (1.3, .5, -.3, -1.1, -1.9), row_data):
            rows.add(VGroup(
                formula(condition, (centers[0], row_y, 0), 28, GOLD, width=2.5),
                words(position, (centers[1], row_y, 0), 20, INK, width=2.7),
                words(kind, (centers[2], row_y, 0), 20, ROSE, width=2.7),
                words(size, (centers[3], row_y, 0), 19, INK, width=2.8)))
        rules = VGroup(*[Line([-6.35, y, 0], [6.25, y, 0], color=GRID,
                             stroke_width=1) for y in (1.75, .9, .1, -.7, -1.5, -2.3)])
        self.show(headings, rules, run_time=1.2)
        self.intro(2)
        self.act(2, LaggedStart(*[FadeIn(row) for row in rows], lag_ratio=.16))
        self.show(words('Свойства изображения определяет положение предмета',
                        (0, -2.85, 0), 23, GOLD, width=11.8), run_time=1.2)
        self.result(2)


class LensDistancesMagnification(OpticsScene):
    chapter_id = 13

    def chapter(self):
        self.beat(0)
        drawing = image_construction(LB_F, 2.1, LB_H)
        self.show(drawing['base'], *lb_image_objects(drawing),
                  lb_condition(r'd>0,\quad F>0'), run_time=1.2)
        self.intro(0)
        self.act(0, FadeIn(lb_distance_dimensions(drawing['solution'])))
        self.show(words(['f > 0 — действительное', 'f < 0 — мнимое'],
                        (3.45, 1.9, 0), 24, ROSE, width=5.2),
                  words('Знак f указывает сторону; длина измеряется положительно',
                        (0, -2.75, 0), 23, MUTED, width=11.8), run_time=1.2)
        self.result(0)

        self.beat(1)
        drawing = image_construction(LB_F, 2.1, LB_H)
        self.show(drawing['base'], *lb_image_objects(drawing),
                  lb_condition(r'h>0,\quad H>0'), run_time=1.2)
        self.intro(1)
        self.act(1, FadeIn(lb_height_dimensions(drawing['solution'])))
        classification = VGroup()
        for x, tex, label in [(-3.8, r'\Gamma>1', 'увеличено'),
                              (0, r'\Gamma=1', 'равные размеры'),
                              (3.8, r'\Gamma<1', 'уменьшено')]:
            classification.add(formula(tex, (x, -2.45, 0), 30, GOLD, width=2.7),
                               words(label, (x, -2.95, 0), 21, MUTED, width=3.2))
        self.show(formula(r'\Gamma=\frac{H}{h}', (3.5, 1.95, 0),
                          42, ROSE, width=4.8), classification, run_time=1.2)
        self.result(1)

        self.beat(2)
        drawing = image_construction(LB_F, 3.5, LB_H)
        solution = drawing['solution']
        d, f, h, y = (solution[k] for k in ('d', 'f', 'h', 'y'))
        self.show(drawing['base'], *lb_image_objects(drawing),
                  formula(r'\Gamma=\frac{H}{h}', (-3.6, 2.15, 0),
                          37, GOLD, width=4.5), run_time=1.2)
        self.intro(2)
        triangles = VGroup(
            Polygon([-d, 0, 0], [-d, h, 0], [0, 0, 0],
                    color=GOLD, stroke_width=1.3, fill_color=GOLD, fill_opacity=.07),
            Polygon([0, 0, 0], [f, 0, 0], [f, y, 0],
                    color=ROSE, stroke_width=1.3, fill_color=ROSE, fill_opacity=.07))
        central = Line([-d, h, 0], [f, y, 0], color=CYAN, stroke_width=2.2)
        dimensions = lb_distance_dimensions(solution, level=-1.65)
        sizes = VGroup(formula('h', (-d-.52, h/2, 0), 28, GOLD, width=.4),
                       formula('H', (f+.95, y/2, 0), 28, ROSE, width=.5))
        self.act(2, Create(triangles), Create(central), FadeIn(dimensions), FadeIn(sizes))
        self.show(formula(r'\Gamma=\frac{|f|}{d}', (3.5, 2.15, 0),
                          42, ROSE, width=4.8),
                  words('Увеличение сравнивает размеры; ориентация описывается отдельно',
                        (0, -2.75, 0), 23, MUTED, width=11.8), run_time=1.2)
        self.result(2)
