"""Diverging lenses, thin-lens equation and vision: source pp13–19."""
from optics_style import *
from optical_geometry import lens_symbol, ray_segment, image_construction
from optical_math import refracted_slope, viewport_end


def c_shape(kind, center):
    ys = np.linspace(-1.05, 1.05, 60)
    z = 1-(ys/1.05)**2
    if kind == 'double':
        left = -.48+.33*z
        right = .48-.33*z
    elif kind == 'plane':
        left = -.48+.33*z
        right = np.full_like(ys, .32)
    else:
        left = -.55+.7*z
        right = .1+.3*z
    x, y, _ = center
    points = [np.array([x+a, y+b, 0]) for a,b in zip(left,ys)]
    points += [np.array([x+a, y+b, 0]) for a,b in zip(right[::-1],ys[::-1])]
    return Polygon(*points, color=LAVENDER, stroke_width=2.5,
                   fill_color=LAVENDER, fill_opacity=.14)


def c_bundle(k=0, reverse=False):
    """F<0; real rays point along travel, extensions have no direction tips."""
    F = -2.0
    oy = .1
    axis = Line([-5.8,oy,0],[5.8,oy,0],color=GRID,stroke_width=1.4)
    symbol = lens_symbol(F,center=(0,oy,0),height=3.3)
    center = formula('O',[.28,oy-.35,0],22,MUTED,width=.5)
    heights = [-.75,0,.75] if abs(k)<1e-8 else [-.8,0,.8]
    incident, emergent, extensions = VGroup(), VGroup(), VGroup()
    focus = np.array([F,oy+F*k,0])
    for y in heights:
        p = np.array([0,oy+y,0])
        left = np.array([-5.2,oy+y-5.2*k,0])
        slope = refracted_slope(y,k,F)
        xr, yr = viewport_end(y,slope,right=5.2,low=-2.1,high=2.0)
        right = np.array([xr,oy+yr,0])
        incident.add(ray_segment(left,p,CYAN,reverse=reverse))
        emergent.add(ray_segment(p,right,GOLD,reverse=reverse))
        if abs(y)>1e-8:
            extensions.add(ray_segment(focus,p,GOLD,dashed=True))
    point = Dot(focus,radius=.055,color=ROSE)
    if abs(k)<1e-8:
        name = formula('F',[F-.35,oy-.35,0],27,ROSE,width=.7)
        background = VGroup(axis,symbol,center)
    else:
        name = formula(r'F_{\mathrm{поб}}',[F-.7,oy-.2,0],27,ROSE,width=1.1)
        plane = DashedLine([F,-2.1,0],[F,1.9,0],color=LAVENDER,
                           stroke_width=1.3,dash_length=.1)
        label = words('Фокальная плоскость',[F,2.15,0],22,LAVENDER,width=3.8)
        background = VGroup(axis,symbol,center,plane,label)
    return dict(base=background,incident=incident,emergent=emergent,
                extensions=extensions,focus=VGroup(point,name))


def c_equation_figure():
    F,d,h = 1.4,2.1,.5
    drawing = image_construction(F,d,h,show_2f=False)
    f,H = drawing['solution']['f'],drawing['solution']['H']
    focal = drawing['base'][1]
    old = [focal[1],focal[3]]
    focal.remove(*old)
    focal.add(formula('F_1',[-F,-.3,0],22,MUTED,width=.8),
              formula('F_2',[F,.35,0],22,MUTED,width=.8))
    drawing['image_labels'][1].move_to([f+.3,-H-.5,0])
    distances = VGroup(
        DoubleArrow([-d,-1.95,0],[0,-1.95,0],buff=0,color=MUTED,
                    stroke_width=1.4,tip_length=.1),
        DoubleArrow([0,-1.95,0],[f,-1.95,0],buff=0,color=MUTED,
                    stroke_width=1.4,tip_length=.1),
        formula('d',[-d/2,-2.17,0],26,MUTED,width=.6),
        formula('f',[f/2,-2.17,0],26,MUTED,width=.6),
        formula('h',[-d-.6,.25,0],28,GOLD,width=.5),
        formula('H',[f+.65,-H/2,0],28,ROSE,width=.5))
    all_paths = VGroup(drawing['base'],drawing['incident'],drawing['emergent'],
                       drawing['image'],drawing['image_labels'],distances)
    return drawing,all_paths,F,d,h,f,H


def c_eye_base(F, show_object=False):
    R=2.3
    outline=Circle(radius=1.45,color=MUTED,stroke_width=1.8).move_to([1.1,0,0])
    lens=lens_symbol(F,center=(0,0,0),height=1.5,color=LAVENDER)
    retina=DashedLine([R,-.72,0],[R,.72,0],color=CYAN,stroke_width=2,dash_length=.08)
    axis=Line([-5.5,0,0],[3.1,0,0],color=GRID,stroke_width=1.2)
    names=VGroup(words('Сетчатка',[3.5,1.85,0],23,CYAN,width=2.5),
                 Line([R,.72,0],[3.2,1.58,0],color=MUTED,stroke_width=1.2),
                 words('Оптическая система глаза',[.4,-1.85,0],23,LAVENDER,width=4.9))
    result=VGroup(axis,outline,lens,retina,names)
    if show_object:
        result.add(Arrow([-4.8,0,0],[-4.8,.7,0],buff=0,color=GOLD,
                         stroke_width=3,max_tip_length_to_length_ratio=.25),
                   words('Предмет',[-4.8,-.65,0],23,GOLD,width=2))
    return result


def c_uncorrected_eye(Fe):
    R=2.3
    rays=VGroup();continuations=VGroup()
    for y in [-.5,0,.5]:
        end=y*(1-R/Fe)
        rays.add(ray_segment([-5.2,y,0],[0,y,0],GOLD),
                 ray_segment([0,y,0],[R,end,0],GOLD))
        if Fe>R and abs(y)>1e-8:
            continuations.add(ray_segment([R,end,0],[Fe,0,0],ROSE,dashed=True))
    focus=VGroup(Dot([Fe,0,0],radius=.055,color=ROSE),
                 formula(r'F_{\mathrm{гл}}',[Fe+.15,-.45,0],25,ROSE,width=1.1))
    return VGroup(rays,continuations,focus)


def c_corrected_eye(Fe):
    a,R=1.1,2.3
    Fg=a+R/(1-R/Fe)
    glass=lens_symbol(Fg,center=(-a,0,0),height=1.55,color=CYAN)
    entry,between,inside=VGroup(),VGroup(),VGroup()
    for y in [-.5,0,.5]:
        slope1=-y/Fg
        ye=y+a*slope1
        slope2=slope1-ye/Fe
        target=ye+R*slope2
        assert abs(target)<1e-12
        entry.add(ray_segment([-5.2,y,0],[-a,y,0],GOLD))
        between.add(ray_segment([-a,y,0],[0,ye,0],CYAN))
        inside.add(ray_segment([0,ye,0],[R,target,0],CYAN))
    return glass,entry,between,inside


class DivergingLensBundles(OpticsScene):
    chapter_id=14

    def chapter(self):
        self.beat(0)
        shapes=VGroup(*[c_shape(kind,(x,.3,0)) for kind,x in
                        zip(['double','plane','meniscus'],[-4.5,0,4.5])])
        names=VGroup(*[words(name,[x,-1.3,0],24,MUTED,width=3.7) for x,name in
                       zip([-4.5,0,4.5],['Двояковогнутая','Плоско-вогнутая','Выпукло-вогнутая'])])
        self.show(shapes,names,words('Формы рассеивающих линз в принятой среде',
                                    [0,2.2,0],25,width=12),run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(formula('F<0',[0,-2.2,0],43,CYAN,width=3)))
        self.show(words('Определяющий признак — ход лучей',[0,-2.85,0],23,MUTED,width=12),run_time=1.2)
        self.result(0)

        for i,k,reverse in [(1,0,False),(2,0,True),(3,.25,False),(4,.25,True)]:
            self.beat(i)
            b=c_bundle(k,reverse)
            first=b['emergent'] if reverse else b['incident']
            last=b['incident'] if reverse else b['emergent']
            self.show(b['base'],first,run_time=1.2)
            self.intro(i)
            self.act(i,Succession(Create(last),Create(b['extensions'])),rate_func=linear)
            self.show(b['focus'],words(
                'Обратные продолжения показаны пунктиром' if not reverse
                else 'Направления всех реальных лучей обращены',
                [0,-2.7,0],23,MUTED,width=12),run_time=1.2)
            self.result(i)


class DivergingImages(OpticsScene):
    chapter_id=15

    def chapter(self):
        for i,d in enumerate([3.5,.84]):
            self.beat(i)
            g=image_construction(-1.4,d,h=.6,origin=(0,.15,0),show_2f=False)
            title=r'd>|F|' if i==0 else r'0<d<|F|'
            self.show(g['base'],formula(title,[3.5,2.25,0],32,width=3.8),run_time=1.2)
            self.intro(i)
            self.act(i,Succession(Create(g['incident']),Create(g['emergent']),
                                  Create(g['extensions'])),rate_func=linear)
            self.show(g['image'],g['image_labels'],
                      words('Прямое, уменьшенное, мнимое',[0,-2.8,0],25,ROSE,width=12),run_time=1.2)
            self.result(i)
        self.beat(2)
        left=words(['Реальный предмет перед линзой','Дальше или ближе фокуса'],[-3.2,1.55,0],25)
        right=words(['Изображение на стороне предмета','Между предметом и линзой'],[3.2,1.55,0],25)
        self.show(left,right,formula('d>0',[0,.2,0],40,width=3),run_time=1.2)
        self.intro(2)
        common=words(['Прямое','Уменьшенное','Мнимое'],[0,-1.1,0],29,ROSE,width=10)
        self.act(2,FadeIn(common))
        self.show(formula(r'F<0,\qquad f<0',[0,-2.6,0],36,CYAN,width=8),run_time=1.2)
        self.result(2)


class ThinLensEquation(OpticsScene):
    chapter_id=16

    def chapter(self):
        self.beat(0)
        g,paths,F,d,h,f,H=c_equation_figure()
        self.show(paths,words('Высоты h и H — положительные длины',[0,2.25,0],23,MUTED,width=12),run_time=1.2)
        self.intro(0)
        triangles=VGroup(Polygon([-d,0,0],[-d,h,0],[0,0,0],color=GOLD,
                                  stroke_width=1.6,fill_color=GOLD,fill_opacity=.07),
                         Polygon([f,0,0],[f,-H,0],[0,0,0],color=ROSE,
                                  stroke_width=1.6,fill_color=ROSE,fill_opacity=.07))
        self.act(0,FadeIn(triangles))
        self.show(formula(r'\frac{H}{h}=\frac{f}{d}',[0,-2.8,0],39,width=10),run_time=1.2)
        self.result(0)

        self.beat(1)
        g,paths,F,d,h,f,H=c_equation_figure()
        self.show(paths,formula('C',[-.35,h+.28,0],26,GOLD,width=.5),run_time=1.2)
        self.intro(1)
        triangles=VGroup(Polygon([0,h,0],[0,0,0],[F,0,0],color=GOLD,
                                  stroke_width=1.6,fill_color=GOLD,fill_opacity=.07),
                         Polygon([f,-H,0],[f,0,0],[F,0,0],color=ROSE,
                                  stroke_width=1.6,fill_color=ROSE,fill_opacity=.07))
        self.act(1,FadeIn(triangles))
        self.show(formula(r'\frac{h}{F}=\frac{H}{f-F}\quad\Longrightarrow\quad\frac{H}{h}=\frac{f-F}{F}',
                          [0,-2.8,0],34,width=12),run_time=1.2)
        self.result(1)

        self.beat(2)
        self.show(words('Исходное действительное построение: d, f, F > 0',[0,2.2,0],24,MUTED,width=12),
                  formula(r'\frac{H}{h}=\frac{f}{d}',[-3.2,1.15,0],40),
                  formula(r'\frac{H}{h}=\frac{f-F}{F}',[3.2,1.15,0],40),run_time=1.2)
        self.intro(2)
        first=formula(r'\frac{f}{d}=\frac{f-F}{F}=\frac{f}{F}-1',[0,-.1,0],39,width=12)
        second=formula(r'\frac{1}{d}=\frac{1}{F}-\frac{1}{f}',[0,-1.25,0],39,width=12)
        self.act(2,Succession(Write(first),Write(second)))
        self.show(formula(r'\frac{1}{F}=\frac{1}{d}+\frac{1}{f}',[0,-2.6,0],43,GOLD,width=12),run_time=1.2)
        self.result(2)

        self.beat(3)
        self.show(words('Единое соглашение знаков',[0,2.2,0],27,width=12),
                  formula(r'\frac{1}{F}=\frac{1}{d}+\frac{1}{f}',[0,1.1,0],42,GOLD,width=10),
                  words('Мнимое изображение',[-3.2,-.05,0],25),
                  words('Рассеивающая линза',[3.2,-.05,0],25),run_time=1.2)
        self.intro(3)
        left=formula(r'\frac{1}{F}=\frac{1}{d}-\frac{1}{|f|}',[-3.2,-1.15,0],38)
        right=formula(r'-\frac{1}{|F|}=\frac{1}{d}-\frac{1}{|f|}',[3.2,-1.15,0],38)
        self.act(3,Write(left),Write(right))
        self.show(words(['Для реального предмета d > 0','Мнимое изображение: f < 0; рассеивающая линза: F < 0'],
                        [0,-2.55,0],23,MUTED,width=12),run_time=1.2)
        self.result(3)


class EyeAndCorrection(OpticsScene):
    chapter_id=17

    def chapter(self):
        self.beat(0)
        R,d,h=2.3,4.8,.7
        Fe=1/(1/R+1/d)
        base=c_eye_base(Fe,show_object=True)
        incident,inside=VGroup(),VGroup()
        target=-R*h/d
        for y in [-.5,0,.5]:
            k=(y-h)/d
            end=y+R*refracted_slope(y,k,Fe)
            assert abs(end-target)<1e-12
            incident.add(ray_segment([-d,h,0],[0,y,0],GOLD))
            inside.add(ray_segment([0,y,0],[R,end,0],CYAN))
        meaning=words(['Роговица и хрусталик','преломляют свет'],[4.65,.85,0],23,width=3.6)
        aperture=words('Зрачок — отверстие',[4.65,-.45,0],23,MUTED,width=3.6)
        self.show(base,meaning,aperture,run_time=1.2)
        self.intro(0)
        self.act(0,Succession(Create(incident),Create(inside)),rate_func=linear)
        image=Arrow([R,0,0],[R,target,0],buff=0,color=ROSE,stroke_width=3,
                    max_tip_length_to_length_ratio=.3)
        self.show(image,words('Действительное перевёрнутое изображение на сетчатке',
                              [0,-2.7,0],24,ROSE,width=12),run_time=1.2)
        self.result(0)

        for i,Fe,condition,correction in [(1,3.0,'Дальнозоркость','Собирающая линза'),
                                        (2,1.6,'Близорукость','Рассеивающая линза')]:
            self.beat(i)
            base=c_eye_base(Fe)
            before=c_uncorrected_eye(Fe)
            where='Фокус за сетчаткой' if i==1 else 'Фокус перед сетчаткой'
            status=words([condition,'Без коррекции:',where],[4.65,.45,0],24,width=3.7)
            glass,entry,between,inside=c_corrected_eye(Fe)
            self.show(base,before,status,run_time=1.2)
            self.intro(i)
            self.act(i,Succession(FadeOut(before),FadeOut(status),FadeIn(glass),
                                  Create(entry),Create(between),Create(inside)),rate_func=linear)
            self.show(words([correction,'Фокус на сетчатке'],[4.65,.6,0],25,CYAN,width=3.7),
                      words('Корректирующая линза',[-2.7,1.85,0],23,CYAN,width=3.5),
                      Line([-1.1,1.55,0],[-1.1,.9,0],color=MUTED,stroke_width=1.2),
                      words('Коррекция меняет ход лучей до их попадания в глаз',
                            [0,-2.7,0],23,MUTED,width=12),run_time=1.2)
            self.result(i)
