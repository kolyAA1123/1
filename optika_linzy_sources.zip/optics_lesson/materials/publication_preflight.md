# Publication preflight: optics and lenses

Status: passed; no open findings. This is a preparation check, not approval
of the finished movie, its rendered frames or remote download availability.
No Manim render, heavy FFmpeg job, publication or source mutation was performed.
The only file written by this reviewer is this report.

## Text and shared clock

- plan.json and narration.json agree exactly:17 chapters,57 beats,114 passages,
  4627 words,3188 seconds (53:08),60 fps and audio=false. Chapter starts are
  contiguous. Each result window follows its completed action.
- All 114 passage texts and all 114 cue intervals agree exactly between the
  plan, narration.json, UTF-8 TXT and exported Word document. DOCX ZIP CRC
  integrity was checked. Times in reading copies use the same stamp function
  as the visual plan.
- This check uses estimated reading windows, not measured recorded speech.

## Source files and coverage

The two available attachment PDFs were checked against source_manifest.json
using byte counts, SHA256 and pdfinfo page counts:

- ОПТИКА.pdf:7 pages, 2549003 bytes,
  SHA256 18a3a84d518e339fb0139bc7235fb4d83150d140c7519a06deae4afbd828b8ae.
- ЛИНЗЫ.pdf:19 pages, 6526504 bytes,
  SHA256 c189ec0bc2ac2e33c3f877fe353ff23fbb12a78e83c8c31a2d4438a4383accba.

source_coverage.json maps every page 1–7 and 1–19, including the lens title.
The project contains the four source audits and independent editorial records.
This preflight does not replace their physical/source review.

## Publication descriptions and retained material

- Root README has the four intended main-branch download links using
  optika_linzy_1080p60.mp4, optika_linzy_tekst.docx,
  optika_linzy_tekst.txt and optika_linzy_sources.zip. Its duration, format,
  chapter/episode/text counts and silent-film description match the plan.
- The previous committed README is retained byte-for-byte as a suffix.
  The previous committed AGENTS.md is retained byte-for-byte as a prefix.
  No prior film or narration artifact was modified.
- git diff --check is clean. Local HEAD and remote main matched at this check:
  614550b89f6597c58202661c6999220a41763523.

## Reproduction and source packaging

- Project README installs requirements-export.txt with uv into the selected
  virtual environment and runs export_docx.py before package_sources.py.
- Both optical_math.py and optical_geometry.py are actual freshness dependencies
  in render_optics.py and verify_delivery.py.
- The package selection includes all eight authored files, both geometry modules,
  shared style, plan, narration, setup/export/render/verification scripts, source
  manifest/coverage and supporting records. Root setup_env.sh, install.sh,
  requirements.lock and AGENTS.md exist for the explicit archive inclusion.
- Temporary output/media/cache files and binary PDF/raster/movie/audio files are
  excluded from the source ZIP. Quality, layout, sync and alignment JSON reports
  are explicitly included when ready. Packaging checks full decode, movie SHA
  and the GitHub 100 MiB per-file limit before copying delivery artifacts.
- No LC-circuit, magnetism or direct-current output prefixes, project paths or
  filenames were found in the new project's textual sources and records.

## Remaining release checks

The parent still needs to complete all visual reviews, final FullHD rendering,
full decode/quality verification, actual archive CRC check and explicit staging
of the six intended root files. After push, verify remote commit and the four
download URLs. This preflight deliberately did not query unpublished artifacts.
