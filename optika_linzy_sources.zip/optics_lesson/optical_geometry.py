"""Reusable ray diagrams with exact intersections and separated labels."""
from optics_style import *
from optical_math import image_solution, refracted_slope, viewport_end


def lens_symbol(F=1.4, center=(0,0,0), height=3.6, color=LAVENDER):
    x,y,_=center
    shaft=Line([x,y-height/2,0],[x,y+height/2,0],color=color,stroke_width=2.2)
    tips=VGroup()
    s=1 if F>0 else -1
    for end in (-1,1):
        apex=np.array([x,y+end*height/2,0])
        for dx in (-.14,.14):
            tips.add(Line(apex,apex+np.array([dx,-end*s*.22,0]),color=color,stroke_width=2.2))
    return VGroup(shaft,tips)


def ray_segment(start,end,color=GOLD,dashed=False,reverse=False):
    p=np.asarray(start,dtype=float);q=np.asarray(end,dtype=float)
    if reverse:p,q=q,p
    if np.linalg.norm(q-p)<1e-7:return VGroup()
    if dashed:
        return VGroup(DashedLine(p,q,color=color,stroke_width=2,dash_length=.09))
    line=Line(p,q,color=color,stroke_width=2.3)
    direction=Arrow(p+.52*(q-p),p+.72*(q-p),buff=0,color=color,tip_length=.13,
                    stroke_width=2.3,max_tip_length_to_length_ratio=.48,
                    max_stroke_width_to_length_ratio=8)
    return VGroup(line,direction)


def image_construction(F=1.4,d=3.5,h=.6,origin=(0,0,0),show_2f=True):
    """Full-width two-ray construction; reveal returned groups in order.

    O=(0,0), object A=(-d,0), B=(-d,h). Image A'=(f,0), B'=(f,mh).
    A central backward extension coinciding with a real incident ray is not
    painted a second time; its extra segment is drawn only beyond the object.
    """
    o=np.asarray(origin,dtype=float)
    def p(x,y):return o+np.array([x,y,0.])
    s=image_solution(F,d,h)
    axis=Line(p(-5.8,0),p(5.8,0),color=GRID,stroke_width=1.4)
    focal=VGroup()
    for factor in (-2,-1,1,2):
        if abs(factor)==2 and not show_2f:continue
        x=factor*abs(F)
        label_x=x
        # At d=2F the image arrow stands on the 2F tick. Keep the label
        # beside that arrow rather than painting letters across its shaft.
        if factor==2 and s['finite'] and abs(s['f']-x)<.12:
            label_x+=.48
        focal.add(Line(p(x,-.06),p(x,.06),color=MUTED,stroke_width=1.3),
                  formula('F' if abs(factor)==1 else '2F',p(label_x,.3 if factor==1 else -.3),22,MUTED,width=.8))
    symbol=lens_symbol(F,center=tuple(o),height=3.6)
    object_arrow=Arrow(p(-d,0),p(-d,h),buff=0,color=GOLD,stroke_width=3,
                       max_tip_length_to_length_ratio=.24)
    object_names=VGroup(formula('A',p(-d,-.72),24,GOLD,width=.5),
                        formula('B',p(-d+.28,h+.24),24,GOLD,width=.5))
    center_name=formula('O',p(-.24,-.3),22,MUTED,width=.4)
    base=VGroup(axis,focal,symbol,object_arrow,object_names,center_name)
    incident=VGroup(ray_segment(p(-d,h),p(0,h),GOLD),
                    ray_segment(p(-d,h),p(0,0),CYAN))
    xp,yp=viewport_end(h,-h/F)
    xc,yc=viewport_end(0,-h/d)
    emergent=VGroup(ray_segment(p(0,h),p(xp,yp),GOLD),
                    ray_segment(p(0,0),p(xc,yc),CYAN))
    extensions=VGroup();image=VGroup();image_labels=VGroup()
    if s['finite']:
        f,y=s['f'],s['y']
        if not (-5.65<f<5.65 and -2.05<y<1.95):
            raise ValueError('Choose a schematic scale that contains the full image')
        if f<0:
            extensions.add(ray_segment(p(0,h),p(f,y),GOLD,dashed=True))
            if f < -d-1e-8:
                extensions.add(ray_segment(p(-d,h),p(f,y),CYAN,dashed=True))
            image_line=DashedLine(p(f,0),p(f,y),color=ROSE,stroke_width=2.4,dash_length=.07)
            image_line.add_tip(tip_length=.12,tip_width=.11)
            image.add(image_line)
            a_pos=p(f,-.72);b_pos=p(f-.28,y+.24)
            if F<0 and y>.3:
                b_pos=p(f+.27,h+.45)
        else:
            image.add(Arrow(p(f,0),p(f,y),buff=0,color=ROSE,stroke_width=3,
                            max_tip_length_to_length_ratio=.24))
            a_pos=p(f+.18,.28);b_pos=p(f+.28,y-.44)
        image_labels.add(formula(r"A^{\prime}",a_pos,24,ROSE,width=.6),
                         formula(r"B^{\prime}",b_pos,24,ROSE,width=.6))
    return dict(base=base,incident=incident,emergent=emergent,extensions=extensions,
                image=image,image_labels=image_labels,solution=s)
