"""Theory scenes for every page of the user's thermodynamics notes."""
from thermal_style import *


def piston(position=-3.15, fill=CYAN):
    """Horizontal gas cylinder; labels are separate, never move with forces."""
    left=-5.65; bottom=-1.15; top=1.0
    vessel=VGroup(Line([left,bottom,0],[left,top,0],color=INK),
                  Line([left,top,0],[-.6,top,0],color=INK),
                  Line([left,bottom,0],[-.6,bottom,0],color=INK))
    gas=Rectangle(width=position-left,height=top-bottom,stroke_width=0,
                  fill_color=fill,fill_opacity=.15).move_to([(left+position)/2,(bottom+top)/2,0])
    plate=Line([position,bottom,0],[position,top,0],color=GOLD,stroke_width=9)
    return vessel,gas,plate


def gas_cloud(center=(-3.1,0,0), color=CYAN):
    box=RoundedRectangle(width=4.8,height=3.4,corner_radius=.12,color=MUTED)
    box.move_to(center)
    pts=[(-1.6,-.9),(-.8,.6),(.1,-.3),(1.25,.9),(1.6,-.8),(-1.5,.95),(.6,1.2),(.7,-1.1)]
    dots=VGroup(*[Dot(np.array(center)+[x,y,0],radius=.065,color=color) for x,y in pts])
    return box,dots


class InternalEnergy(ThermoScene):
    chapter_id=6
    def chapter(self):
        self.beat(0)
        box,dots=gas_cloud()
        first=formula(r'U=N\overline{E}',(3.1,.8,0),42)
        note=words(['Энергия всех молекул','одноатомного идеального газа'],(3.1,-.35,0),23)
        self.show(box,dots,first,note)
        self.intro(0)
        final=formula(r'\overline{E}=\frac32kT',(3.1,-1.5,0),38,CYAN)
        moves=[dot.animate.shift([.16*(-1)**j,.13*(-1)**(j//2),0]) for j,dot in enumerate(dots)]
        self.act(0,*moves,FadeIn(final))
        self.show(words('Межмолекулярной потенциальной\nэнергией пренебрегаем'.split('\n'),(-3.1,-2.15,0),19,MUTED),run_time=.8)
        self.result(0)

        self.beat(1)
        initial=formula(r'U=\frac32NkT',(-3.1,.9,0),43)
        bridge=words(['N = ν Nₐ','R = Nₐ k'],(-3.1,-.6,0),30,MUTED)
        target=formula(r'U=\frac32\nu RT',(3.1,.9,0),43,CYAN)
        eos=formula(r'pV=\nu RT',(3.1,-.15,0),35)
        result=formula(r'U=\frac32pV',(3.1,-1.4,0),43,GOLD)
        self.show(initial,bridge)
        self.intro(1)
        self.act(1,Succession(FadeIn(target),FadeIn(eos),FadeIn(result)))
        self.show(words('Одноатомный газ',(-3.1,-1.85,0),22,MUTED),run_time=.8)
        self.result(1)

        self.beat(2)
        initial=formula(r'\Delta U=U_2-U_1',(0,1.25,0),42)
        states=VGroup(formula(r'U_1=\frac32\nu RT_1',(-3.1,-.05,0),38),formula(r'U_2=\frac32\nu RT_2',(3.1,-.05,0),38))
        final=formula(r'\Delta U=\frac32\nu R(T_2-T_1)=\frac32\nu R\Delta T',(0,-1.35,0),40,CYAN,11.4)
        self.show(initial,states)
        self.intro(2)
        self.act(2,Write(final))
        self.show(words('ν = const: знак ΔU определяется знаком ΔT',(0,-2.25,0),23,GOLD,11.5),run_time=.8)
        self.result(2)

        self.beat(3)
        title=formula(r'U=\frac{i}{2}\nu RT',(0,1.55,0),45,CYAN)
        rows=VGroup(words(['Одноатомный','i = 3'],(-4.25,.05,0),27),words(['Двухатомный','i = 5'],(0,.05,0),27),words(['Многоатомный','i = 5 или 6'],(4.25,.05,0),27))
        self.show(title,words('i — число активных степеней свободы',(0,.75,0),23,MUTED,11.5))
        self.intro(3)
        self.act(3,LaggedStart(*[FadeIn(row) for row in rows],lag_ratio=.3))
        self.show(words(['В модели жёстких молекул','Поступательная энергия: 3kT/2 для любого газа'],(0,-1.65,0),23,GOLD,11.5),run_time=.9)
        self.result(3)


class PistonWork(ThermoScene):
    chapter_id=7
    def chapter(self):
        self.beat(0)
        vessel,gas,plate=piston()
        forces=VGroup(arrow([-4.65,-.65,0],[1.3,0,0],CYAN),arrow([-1.5,.5,0],[-1.3,0,0],ROSE),arrow([-3.5,.55,0],[-1.25,0,0],LAVENDER))
        labels=VGroup(eq('F',27,CYAN).move_to([-4.05,-.95,0]),eq(r'F_{\rm atm}',27,ROSE).move_to([-1.95,.85,0]),eq(r'F_{\rm fr}',27,LAVENDER).move_to([-4.3,.9,0]))
        balance=formula(r'F-F_{\rm atm}-F_{\rm fr}=0',(3.1,.8,0),34,INK)
        self.show(vessel,gas,plate,words('Равномерное движение вправо',(-3.1,1.85,0),23,MUTED))
        self.intro(0)
        self.act(0,LaggedStart(*[FadeIn(x) for x in [forces,labels,balance]],lag_ratio=.25))
        self.show(words(['Сила газа — вправо','Атмосфера и трение — влево'],(3.1,-.65,0),23),run_time=.8)
        self.result(0)

        self.beat(1)
        vessel,gas,plate=piston(-3.8)
        final_vessel,newgas,newplate=piston(-1.6)
        pressure=formula(r'p=p_0+\frac{F_{\rm fr}}{S}=\mathrm{const}',(3.1,1.1,0),34)
        geom=formula(r'\Delta V=S\,l',(3.1,-.05,0),38)
        work=formula(r'A=Fl=pSl=p\Delta V',(3.1,-1.35,0),35,CYAN)
        mark=DoubleArrow([-3.8,-1.7,0],[-1.6,-1.7,0],buff=0,color=GOLD)
        label=eq('l',27,GOLD).move_to([-2.7,-2.05,0])
        self.show(vessel,gas,plate,pressure)
        self.intro(1)
        self.act(1,Transform(gas,newgas),Transform(plate,newplate),Create(mark),FadeIn(label))
        self.show(geom,work,run_time=1.2)
        self.result(1)

        self.beat(2)
        gaswork=formula(r'A_{\rm gas}=Fl>0',(-3.1,.9,0),38,CYAN)
        extwork=formula(r'A_{\rm ext}=-(F_{\rm atm}+F_{\rm fr})l',(3.1,.9,0),33,ROSE)
        motion=arrow([-5.5,-.55,0],[4.6,0,0],GOLD)
        motiontext=words('Перемещение поршня',(-3.1,-1.15,0),23,MUTED)
        final=formula(r'A_{\rm ext}=-Fl=-A_{\rm gas}',(3.1,-.85,0),36,GOLD)
        self.show(gaswork,extwork,motion,motiontext)
        self.intro(2)
        self.act(2,Write(final))
        self.show(words('Кинетическая энергия поршня не меняется',(0,-2.25,0),23,MUTED,11.5),run_time=.8)
        self.result(2)


class WorkGraphSigns(ThermoScene):
    chapter_id=8
    def chapter(self):
        self.beat(0)
        ax,g=chart(center=(-3.1,-.1,0))
        start=ax.c2p(1,2.6);end=ax.c2p(4,2.6)
        segment=Line(start,end,color=CYAN,stroke_width=4)
        area=Polygon(ax.c2p(1,0),ax.c2p(4,0),end,start,stroke_width=0,fill_color=CYAN,fill_opacity=.25)
        labels=VGroup(eq('V_1',25).next_to(ax.c2p(1,0),DOWN,buff=.15),eq('V_2',25).next_to(ax.c2p(4,0),DOWN,buff=.15),eq('p_0',25).next_to(ax.c2p(0,2.6),LEFT,buff=.12))
        self.show(g,labels,formula(r'p=p_0=\mathrm{const}',(3.1,.9,0),36))
        self.intro(0)
        self.act(0,Succession(Create(segment),FadeIn(area)))
        self.show(formula(r'A=p_0(V_2-V_1)',(3.1,-.3,0),40,CYAN),words('Площадь прямоугольника',(3.1,-1.5,0),25),run_time=1.0)
        self.result(0)

        self.beat(1)
        ax,g=chart(center=(-3.1,-.1,0))
        a=ax.c2p(1,1.2);b=ax.c2p(4,3.1)
        line=Line(a,b,color=CYAN,stroke_width=4)
        area=Polygon(ax.c2p(1,0),ax.c2p(4,0),b,a,stroke_width=0,fill_color=GOLD,fill_opacity=.23)
        labels=VGroup(eq('V_1',25).next_to(ax.c2p(1,0),DOWN,buff=.15),eq('V_2',25).next_to(ax.c2p(4,0),DOWN,buff=.15),eq('p_1',25).next_to(ax.c2p(0,1.2),LEFT,buff=.12),eq('p_2',25).next_to(ax.c2p(0,3.1),LEFT,buff=.12))
        guides=VGroup(DashedLine(ax.c2p(0,1.2),a,color=GRID),DashedLine(ax.c2p(0,3.1),b,color=GRID))
        self.show(g,labels,guides,words(['Давление меняется','Работа — площадь под p(V)'],(3.1,.8,0),25))
        self.intro(1)
        self.act(1,Succession(Create(line),FadeIn(area)))
        self.show(formula(r'A=\frac{p_1+p_2}{2}(V_2-V_1)',(3.1,-.75,0),36,GOLD),words('Для прямолинейного участка',(3.1,-1.9,0),21,MUTED),run_time=1.0)
        self.result(1)

        self.beat(2)
        headers=VGroup(words('Теплота',(-4.3,1.55,0),28),words('Работа газа',(0,1.55,0),28),words('Внутренняя энергия',(4.3,1.55,0),26))
        positive=VGroup(words(['Получает тепло','Q > 0'],(-4.3,.35,0),25,CYAN),words(['Расширяется','A > 0'],(0,.35,0),25,CYAN),words(['Нагревается','ΔU > 0'],(4.3,.35,0),25,CYAN))
        negative=VGroup(words(['Отдаёт тепло','Q < 0'],(-4.3,-1.25,0),25,ROSE),words(['Сжимается','A < 0'],(0,-1.25,0),25,ROSE),words(['Охлаждается','ΔU < 0'],(4.3,-1.25,0),25,ROSE))
        self.show(headers,positive)
        self.intro(2)
        self.act(2,LaggedStart(*[FadeIn(x) for x in negative],lag_ratio=.3))
        self.show(words('ΔU = U₂ − U₁; состав и количество идеального газа постоянны',(0,-2.4,0),22,MUTED,11.7),run_time=.8)
        self.result(2)


class FirstLaw(ThermoScene):
    chapter_id=9
    def chapter(self):
        self.beat(0)
        box,dots=gas_cloud()
        q=arrow([-6.3,0,0],[1.2,0,0],GOLD)
        qlabel=eq('Q',30,GOLD).move_to([-5.95,.55,0])
        initial=formula(r'\Delta U=Q-A',(3.1,1.2,0),43)
        final=formula(r'Q=\Delta U+A',(3.1,-.1,0),45,CYAN)
        self.show(box,dots,q,qlabel,initial)
        self.intro(0)
        self.act(0,Write(final))
        self.show(words(['Изменение энергии + работа газа','A — работа, совершённая газом'],(3.1,-1.6,0),22,MUTED),run_time=.9)
        self.result(0)

        self.beat(1)
        box,dots=gas_cloud()
        first=formula(r'V=\mathrm{const}\quad\Rightarrow\quad A=0',(3.1,1.1,0),37)
        final=formula(r'Q=\Delta U',(3.1,-.25,0),47,CYAN)
        self.show(box,dots,first,words('Жёсткий сосуд',(-3.1,-2.2,0),23,MUTED))
        self.intro(1)
        self.act(1,*[d.animate.set_color(GOLD) for d in dots],Write(final))
        self.show(words('Вся теплота изменяет внутреннюю энергию',(3.1,-1.6,0),23,INK,5.7),run_time=.9)
        self.result(1)

        self.beat(2)
        ax,g=chart(center=(-3.1,-.1,0),x_range=(0,5,1),y_range=(0,4,1))
        curve=ax.plot(lambda x:3.6/x,x_range=[1.1,4.5],color=CYAN)
        first=formula(r'T=\mathrm{const}\quad\Rightarrow\quad\Delta U=0',(3.1,1.1,0),35)
        final=formula(r'Q=A',(3.1,-.25,0),48,CYAN)
        self.show(g,first)
        self.intro(2)
        self.act(2,Create(curve),Write(final))
        self.show(words(['Идеальный газ, ν = const','Расширение требует подвода теплоты'],(3.1,-1.65,0),22,MUTED),run_time=.9)
        self.result(2)


class IsobaricBalance(ThermoScene):
    chapter_id=10
    def chapter(self):
        self.beat(0)
        ax,g=chart(center=(-3.1,-.1,0))
        path=Line(ax.c2p(1,2.2),ax.c2p(4,2.2),color=CYAN,stroke_width=4)
        first=formula(r'p=\mathrm{const},\quad\nu=\mathrm{const}',(3.1,1.3,0),34)
        work=formula(r'A=p\Delta V',(3.1,.1,0),43,CYAN)
        eos=formula(r'p\Delta V=\nu R\Delta T',(3.1,-1.25,0),38,GOLD)
        self.show(g,first,words('Изобарное расширение',(-3.1,-2.4,0),23,MUTED))
        self.intro(0)
        self.act(0,Create(path),Write(work))
        self.show(eos,run_time=.9)
        self.result(0)

        self.beat(1)
        first=formula(r'U=\frac32pV',(-3.1,1,0),43)
        delta=formula(r'\Delta U=\frac32pV_2-\frac32pV_1',(3.1,.9,0),38)
        final=formula(r'\Delta U=\frac32p\Delta V=\frac32\nu R\Delta T',(0,-1.4,0),43,CYAN,11.5)
        self.show(first,words(['Одноатомный идеальный газ','Давление постоянно'],(-3.1,-.35,0),23,MUTED))
        self.intro(1)
        self.act(1,Succession(Write(delta),Write(final)))
        self.show(words('Нагревание увеличивает U, охлаждение уменьшает U',(0,-2.25,0),23,MUTED,11.5),run_time=.8)
        self.result(1)

        self.beat(2)
        first=formula(r'Q=A+\Delta U',(0,1.4,0),43)
        parts=VGroup(formula(r'A=p\Delta V',(-3.1,.05,0),39,CYAN),formula(r'\Delta U=\frac32p\Delta V',(3.1,.05,0),39,LAVENDER))
        final=formula(r'Q=p\Delta V+\frac32p\Delta V=\frac52\nu R\Delta T',(0,-1.4,0),42,GOLD,11.7)
        self.show(first,parts)
        self.intro(2)
        self.act(2,Write(final))
        self.show(words('Коэффициент 5/2 здесь относится к теплоте одноатомного газа',(0,-2.4,0),21,MUTED,11.7),run_time=.8)
        self.result(2)


class AdiabaticProcesses(ThermoScene):
    chapter_id=11
    def chapter(self):
        self.beat(0)
        vessel,gas,plate=piston(-3.8)
        _,newgas,newplate=piston(-1.6,fill=LAVENDER)
        first=formula(r'Q=0\quad\Rightarrow\quad\Delta U=-A',(3.1,1.1,0),37)
        final=words(['Расширение: A > 0','ΔU < 0, температура падает'],(3.1,-.65,0),26,CYAN)
        self.show(vessel,gas,plate,first,words('Теплообмена нет',(-3.1,1.9,0),25,GOLD))
        self.intro(0)
        self.act(0,Transform(gas,newgas),Transform(plate,newplate))
        self.show(final,run_time=.9)
        self.result(0)

        self.beat(1)
        vessel,gas,plate=piston(-1.6,fill=LAVENDER)
        _,newgas,newplate=piston(-3.8,fill=GOLD)
        first=formula(r'Q=0\quad\Rightarrow\quad\Delta U=-A',(3.1,1.1,0),37)
        final=words(['Сжатие: A < 0','ΔU > 0, температура растёт'],(3.1,-.65,0),26,GOLD)
        self.show(vessel,gas,plate,first,words('Новый опыт: сжатие',(-3.1,1.9,0),24,MUTED))
        self.intro(1)
        self.act(1,Transform(gas,newgas),Transform(plate,newplate))
        self.show(final,run_time=.9)
        self.result(1)

        self.beat(2)
        ax,g=chart(center=(-3.1,-.1,0))
        iso=ax.plot(lambda v:4/v,x_range=[1.15,4.6],color=CYAN)
        adi=ax.plot(lambda v:2*(2/v)**1.5,x_range=[1.35,4.6],color=ROSE)
        dot=Dot(ax.c2p(2,2),color=GOLD,radius=.07)
        label=words('Общее начальное состояние',(3.1,1.55,0),24,MUTED)
        names=words(['Изотерма: T = const','Адиабата: Q = 0'],(3.1,.25,0),27)
        names[0].set_color(CYAN);names[1].set_color(ROSE)
        self.show(g,dot,label)
        self.intro(2)
        self.act(2,Create(iso),Create(adi))
        self.show(names,words('Через одно состояние адиабата круче',(3.1,-1.65,0),24,GOLD,5.6),run_time=1.0)
        self.result(2)

        self.beat(3)
        # A finite, finished rise in two source-defined limiting models.
        fast=VGroup(Circle(radius=.48,color=LAVENDER,fill_color=LAVENDER,fill_opacity=.18),Line([0,-.48,0],[0,-.85,0],color=MUTED)).move_to([-4.6,-1.1,0])
        slow=VGroup(Circle(radius=.48,color=CYAN,fill_color=CYAN,fill_opacity=.18),Line([0,-.48,0],[0,-.85,0],color=MUTED)).move_to([-1.6,-1.1,0])
        labels=VGroup(words('Быстро',(-4.6,-2.2,0),24,LAVENDER),words('Медленно',(-1.6,-2.2,0),24,CYAN))
        first=words(['При подъёме внешнее давление падает','Оба шара расширяются'],(3.1,1.25,0),24)
        final=words(['Быстро: Q ≈ 0, T уменьшается','Медленно: T = T среды = const'],(3.1,-.4,0),24,GOLD)
        self.show(fast,slow,labels,first)
        self.intro(3)
        self.act(3,fast.animate.shift(UP*2).scale(1.28),slow.animate.shift(UP*2).scale(1.48))
        self.show(final,words('Модель: температура среды постоянна',(3.1,-1.8,0),21,MUTED),run_time=1.0)
        self.result(3)
