"""Theory and completed demonstrations from the seven-page thermal-balance notes.

Source corrections are documented in materials/equilibrium/source_audit.md.
All Q_out/Q_in values in the calorimeter are positive magnitudes.
"""
from thermal_style import *


def bead_chain(center=(-3.1, .25, 0), count=9):
    x,y,_=center
    shell=RoundedRectangle(width=5,height=.9,corner_radius=.07,color=MUTED,stroke_width=2).move_to(center)
    beads=VGroup(*[Dot([x-2.12+i*.53,y,0],radius=.105,color=CYAN) for i in range(count)])
    return shell,beads


def vessel(center=(-3.1, -.2, 0), width=3.5, height=3.2):
    x,y,_=center
    wall=VMobject(color=MUTED,stroke_width=3).set_points_as_corners([
        [x-width/2,y+height/2,0],[x-width/2,y-height/2,0],
        [x+width/2,y-height/2,0],[x+width/2,y+height/2,0]])
    water=Rectangle(width=width-.09,height=height*.58,stroke_width=0,
                    fill_color=CYAN,fill_opacity=.22).move_to([x,y-height*.21,0])
    return VGroup(water,wall)


class EquilibriumTransfer(ThermoScene):
    chapter_id=1

    def chapter(self):
        self.beat(0)
        hot=Circle(.65,color=ROSE,fill_opacity=.28).move_to([-4.5,.45,0])
        cold=Circle(.65,color=CYAN,fill_opacity=.28).move_to([-1.7,.45,0])
        temperatures=VGroup(formula('T_1',[-4.5,-.65,0],30,ROSE),
                            formula('T_2',[-1.7,-.65,0],30,CYAN),
                            formula('T_1>T_2',[-3.1,1.7,0],34))
        energy=Dot([-3.8,.45,0],radius=.09,color=GOLD)
        u=formula(r'U=E_{\rm kin}+E_{\rm pot}',[3.1,.85,0],36)
        description=words(['Хаотическое движение','и взаимодействие частиц'],[3.1,-.1,0],24)
        self.show(hot,cold,temperatures,energy,u,description,run_time=1.2)
        self.intro(0)
        common=VGroup(formula(r'T_{\rm eq}',[-4.5,-.65,0],30,LAVENDER),
                      formula(r'T_{\rm eq}',[-1.7,-.65,0],30,LAVENDER),
                      formula(r'T_1=T_2=T_{\rm eq}',[-3.1,1.7,0],32))
        self.act(0,energy.animate.move_to([-2.4,.45,0]).set_opacity(0),
                 hot.animate.set_color(LAVENDER),cold.animate.set_color(LAVENDER),
                 Transform(temperatures,common))
        self.show(words(['Идеальный газ:','взаимодействием пренебрегаем'],[3.1,-1.25,0],23),
                  formula(r'U=E_{\rm kin}',[3.1,-2.15,0],34,CYAN),run_time=1.2)
        self.result(0)

        self.beat(1)
        rod,beads=bead_chain()
        heater=Rectangle(width=.5,height=.9,color=ROSE,fill_opacity=.35).move_to([-5.85,.25,0])
        top=words(['Горячий конец'],[-4.65,1.55,0],24,ROSE)
        initial=words(['Теплопроводность','Нет потока вещества'],[3.1,.8,0],27)
        self.show(rod,beads,heater,top,initial,run_time=1.2)
        self.intro(1)
        self.act(1,LaggedStart(*[b.animate.set_color(GOLD) for b in beads],lag_ratio=.3))
        self.show(words(['Энергия передаётся','соседним частицам'],[3.1,-.6,0],25,GOLD),
                  words(['Нагрев распространяется постепенно'],[-3.1,-1.45,0],22),run_time=1.2)
        self.result(1)

        self.beat(2)
        room=Rectangle(width=4.8,height=3.9,color=GRID).move_to([-3.1,.05,0])
        radiator=RoundedRectangle(width=1,height=.45,corner_radius=.05,color=ROSE,
                                  fill_opacity=.3).move_to([-4.25,-1.65,0])
        path=Ellipse(width=3.0,height=2.8,color=MUTED,stroke_width=1.5).move_to([-3.1,.15,0])
        # Counterclockwise path: the left branch moves down. Reverse it so warm rises left.
        path.reverse_points()
        flow=Dot(path.get_start(),radius=.1,color=GOLD)
        warm=arrow([-4.8,-.7,0],[0,1.7,0],ROSE)
        cool=arrow([-1.4,1.0,0],[0,-1.7,0],CYAN)
        notes=words(['Нагретый воздух:','меньшая плотность','Холодный воздух опускается'],[3.1,.65,0],24)
        self.show(room,radiator,path,flow,warm,cool,notes,run_time=1.2)
        self.intro(2)
        self.act(2,MoveAlongPath(flow,path),rate_func=linear)
        self.show(words(['Полный круг циркуляции','Жидкости и газы'],[3.1,-1.3,0],25,GOLD),run_time=1.2)
        self.result(2)

        self.beat(3)
        sun=Circle(.7,color=GOLD,fill_opacity=.3).move_to([-4.9,.3,0])
        earth=Circle(.43,color=CYAN,fill_opacity=.3).move_to([-1.35,.3,0])
        names=VGroup(words(['Солнце'],[-4.9,-.8,0],23,GOLD),words(['Земля'],[-1.35,-.8,0],23,CYAN))
        vacuum=words(['Вакуум'],[-3.1,1.65,0],25,MUTED)
        wave=VMobject(color=GOLD,stroke_width=2).set_points_smoothly([
            [-4.15+i*.055,.3+.11*np.sin(i*.35),0] for i in range(44)])
        packet=Dot([-4.15,.3,0],radius=.07,color=GOLD)
        self.show(sun,earth,names,vacuum,packet,
                  words(['Электромагнитные волны','Среда не требуется'],[3.1,.8,0],26),run_time=1.2)
        self.intro(3)
        self.act(3,Create(wave),packet.animate.move_to([-1.82,.3,0]).set_opacity(0),
                 earth.animate.set_color(GOLD))
        self.show(words(['Энергия достигает Земли'],[3.1,-.8,0],25,GOLD),run_time=1.2)
        self.result(3)


class StatesAndCapacity(ThermoScene):
    chapter_id=2

    def chapter(self):
        self.beat(0)
        names=['Твёрдое','Жидкое','Газ']
        positions=[-4.65,-.15,4.4]
        state_names=VGroup(*[words([name],[x,1.8,0],26) for name,x in zip(names,positions)])
        # Distinct positions make all four transition names readable.
        arrows=VGroup(arrow([-3.35,.65,0],[1.8,0,0],GOLD),arrow([-1.55,-.35,0],[-1.8,0,0],CYAN),
                      arrow([1.15,.65,0],[1.8,0,0],GOLD),arrow([2.95,-.35,0],[-1.8,0,0],CYAN))
        transition=VGroup(words(['Плавление'],[-2.45,1.05,0],21,GOLD,width=2.9),
                          words(['Кристаллизация'],[-2.45,-.85,0],20,CYAN,width=3.3),
                          words(['Парообразование'],[2.05,1.05,0],20,GOLD,width=3.5),
                          words(['Конденсация'],[2.05,-.85,0],21,CYAN,width=3.2))
        self.show(state_names,run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(*[Create(a) for a in arrows],lag_ratio=.3),FadeIn(transition))
        self.show(words(['Чистое вещество, постоянное давление','При фазовом переходе температура постоянна'],[0,-2.05,0],24,LAVENDER,width=11.5),run_time=1.2)
        self.result(0)

        self.beat(1)
        body=RoundedRectangle(width=3.6,height=2.1,corner_radius=.12,color=CYAN,fill_opacity=.22).move_to([-3.1,.35,0])
        temp=formula(r't_{\rm initial}',[-3.1,.35,0],33,CYAN)
        first=formula(r'Q=cm\Delta t',[3.1,1.1,0],42)
        definitions=words(['m — масса, кг','c — удельная теплоёмкость','Δt — конечная минус начальная'],[3.1,-.2,0],23)
        self.show(body,temp,first,definitions,run_time=1.2)
        self.intro(1)
        self.act(1,body.animate.set_color(ROSE),Transform(temp,formula(r't_{\rm final}>t_{\rm initial}',[-3.1,.35,0],30,ROSE)))
        self.show(formula(r'Q>0,\quad\Delta t>0',[-3.1,-1.45,0],32,GOLD),
                  words(['При охлаждении: Q < 0 и Δt < 0'],[3.1,-1.65,0],22),run_time=1.2)
        self.result(1)

        self.beat(2)
        main=formula(r'c=\frac{Q}{m\Delta T}',[-3.1,1.1,0],39)
        unit=formula(r'[c]=\frac{\mathrm{J}}{\mathrm{kg}\cdot\mathrm{K}}',[-3.1,-.1,0],34)
        values=VGroup(words(['Вода: 4200 Дж/(кг·К)'],[3.1,1.15,0],25,CYAN),
                      words(['Лёд: 2100 Дж/(кг·К)'],[3.1,.2,0],25,LAVENDER))
        self.show(main,unit,values,run_time=1.2)
        self.intro(2)
        conclusion=formula(r'1\ \mathrm{kg},\quad1\ \mathrm{K}\quad\Rightarrow\quad4200\ \mathrm{J}',[0,-1.15,0],34,GOLD,width=11)
        self.act(2,Write(conclusion))
        self.show(formula(r'100-20=80\ ^\circ\mathrm{C}\qquad373-293=80\ \mathrm{K}',[0,-2.35,0],30,width=11.7),run_time=1.2)
        self.result(2)

        self.beat(3)
        small=formula(r'c\quad\left[\frac{\mathrm{J}}{\mathrm{kg}\cdot\mathrm{K}}\right]',[-3.1,.9,0],36,CYAN)
        explanation=words(['Характеристика вещества','На единицу массы'],[-3.1,-.3,0],24)
        definition=formula('C=cm',[3.1,.9,0],42,GOLD)
        self.show(small,explanation,definition,run_time=1.2)
        self.intro(3)
        body_capacity=formula(r'Q=C\Delta t',[3.1,-.3,0],39,GOLD)
        self.act(3,Write(body_capacity))
        self.show(words(['Теплоёмкость всего тела'],[3.1,-1.25,0],25),
                  formula(r'[C]=\mathrm{J}/\mathrm{K}',[3.1,-2.2,0],32),run_time=1.2)
        self.result(3)


class PhaseHeatCombustion(ThermoScene):
    chapter_id=3

    def chapter(self):
        self.beat(0)
        tank=vessel()
        # Start with a solid block; finish with all material represented by liquid.
        solid=Rectangle(width=2.5,height=1.7,color=LAVENDER,fill_opacity=.55).move_to([-3.1,-.55,0])
        liquid=Rectangle(width=3.35,height=1.28,color=CYAN,fill_opacity=.35).move_to([-3.1,-.89,0])
        # Only the vessel walls are used; there is no extra liquid before melting.
        wall=tank[1]
        condition=words(['Температура плавления'],[-3.1,1.9,0],24)
        law=formula(r'Q=\lambda m',[3.1,1,0],43)
        self.show(wall,solid,condition,law,
                  words(['λ — удельная теплота плавления','Единица: Дж/кг'],[3.1,-.2,0],23),run_time=1.2)
        self.intro(0)
        self.act(0,Transform(solid,liquid))
        self.show(words(['Лёд: 330 000 Дж/кг','При кристаллизации энергия выделяется'],[3.1,-1.7,0],23,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        tank=vessel()
        positions=[[-4.25,-1.2,0],[-3.5,-1.2,0],[-2.75,-1.2,0],[-2,-1.2,0],
                   [-4.25,-.65,0],[-3.5,-.65,0],[-2.75,-.65,0],[-2,-.65,0]]
        gas_positions=[[-4.45,1.05,0],[-3.55,1.65,0],[-2.55,.95,0],[-1.8,1.55,0],
                       [-4.4,.15,0],[-3.55,.55,0],[-2.65,-.1,0],[-1.75,.35,0]]
        molecules=VGroup(*[Dot(p,radius=.075,color=CYAN) for p in positions])
        self.show(tank,molecules,formula('Q=Lm',[3.1,1.1,0],43),
                  words(['L — удельная теплота','парообразования, Дж/кг'],[3.1,-.1,0],24),run_time=1.2)
        self.intro(1)
        self.act(1,*[m.animate.move_to(p).set_color(GOLD) for m,p in zip(molecules,gas_positions)],
                 tank[0].animate.set_opacity(0))
        self.show(words(['Вода: 2,3·10⁶ Дж/кг','При конденсации энергия выделяется'],[3.1,-1.65,0],23,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        fuel=RoundedRectangle(width=2,height=1.2,corner_radius=.1,color=GOLD,fill_opacity=.3).move_to([-3.1,-.4,0])
        label=words(['Топливо + кислород'],[-3.1,1.3,0],25)
        products=VGroup(*[Dot([-4.4+i*.52,.1+(.35 if i%2 else -.25),0],radius=.12,color=MUTED) for i in range(6)])
        product_label=words(['Продукты сгорания'],[-3.1,1.3,0],25)
        q=formula('Q=qm',[3.1,1.1,0],44)
        self.show(fuel,label,q,words(['q — удельная теплота сгорания','Полное сгорание 1 кг: q Дж'],[3.1,-.1,0],24),run_time=1.2)
        self.intro(2)
        rays=VGroup(*[arrow([-3.1,-.5,0],v,GOLD) for v in [[-1.7,-1.0,0],[0,-1.7,0],[1.7,-1,0]]])
        self.act(2,Transform(fuel,products),Transform(label,product_label),LaggedStart(*[Create(a) for a in rays],lag_ratio=.2))
        self.show(words(['Энергия выделяется','λ, L и q описывают разные процессы'],[3.1,-1.65,0],23,GOLD),run_time=1.2)
        self.result(2)


class HeatingCurve(ThermoScene):
    chapter_id=4

    def chapter(self):
        ax,frame=chart(center=(-3.25,-.15,0),width=5.1,height=3.9,
                       x_range=(0,10,2),y_range=(0,6,1),x_label='Q',y_label='T')
        coordinates=[(0,0),(2,1.65),(3.5,1.65),(6,3.65),(7.5,3.65),(9.5,5.5)]
        point=Dot(ax.c2p(*coordinates[0]),radius=.075,color=GOLD)
        condition=words(['Чистое вещество, p = const'],[0,2.3,0],21,MUTED,width=10)
        t_positions=[(0,'T_1'),(1.65,'T_2'),(3.65,'T_3'),(5.5,'T_4')]
        temps=VGroup(*[formula(name,ax.c2p(0,y)+LEFT*.35,23,MUTED) for y,name in t_positions])
        intros=[['Твёрдое вещество','Температура растёт'],['Плавление','Сосуществуют две фазы'],
                ['Жидкость','Температура растёт'],['Парообразование','Сосуществуют две фазы'],
                ['Газ','Температура растёт']]
        laws=[r'Q_1=c_{\rm solid}m(T_2-T_1)',
              r'Q_2-Q_1=\lambda m',
              r'Q_3-Q_2=c_{\rm liquid}m(T_3-T_2)',
              'Q_4-Q_3=Lm',
              r'Q_5-Q_4=c_{\rm gas}m(T_4-T_3)']
        panel=None;law=None
        for i in range(5):
            self.beat(i,clear=(i==0))
            new=words(intros[i],[3.25,1.25,0],26,color=CYAN if i%2==0 else LAVENDER)
            if i==0:
                self.show(frame,temps,point,new,condition,run_time=1.2)
            else:
                self.play(FadeOut(panel),FadeOut(law),FadeIn(new),run_time=1.2)
            panel=new
            self.intro(i)
            segment=Line(ax.c2p(*coordinates[i]),ax.c2p(*coordinates[i+1]),color=CYAN if i%2==0 else LAVENDER,stroke_width=3)
            self.act(i,Create(segment),MoveAlongPath(point,segment),rate_func=linear)
            x,y=coordinates[i+1]
            qlabel=formula(f'Q_{i+1}',ax.c2p(x,0)+DOWN*.34,23,MUTED)
            guide=DashedLine(ax.c2p(x,0),ax.c2p(x,y),color=GRID,stroke_width=1.3)
            law=formula(laws[i],[3.25,-.35,0],32,width=5.5,color=GOLD)
            self.show(guide,qlabel,law,run_time=1.2)
            self.result(i)


class CalorimeterBalance(ThermoScene):
    chapter_id=5

    def chapter(self):
        self.beat(0)
        positive=formula(r'Q_{\rm out}=Q_{\rm in}',[-3.1,.95,0],40,GOLD)
        note=words(['Положительные модули','отданной и полученной теплоты'],[-3.1,-.35,0],23)
        signed=formula(r'Q_1+Q_2+Q_3+\ldots=0',[3.1,.95,0],35,CYAN)
        self.show(positive,note,run_time=1.2)
        self.intro(0)
        self.act(0,Write(signed))
        self.show(words(['Получение: Qᵢ > 0','Отдача: Qᵢ < 0'],[3.1,-.35,0],25),
                  words(['Теплоизолированная система'],[0,-2.1,0],26,LAVENDER,width=10),run_time=1.2)
        self.result(0)

        self.beat(1)
        tank=vessel()
        ball=Circle(.43,color=CYAN,fill_opacity=.55).move_to([-3.1,2.05,0])
        initial=words(['Вода: m₁, t₁','Шар: m₂, t₂','t₁ > t₂'],[3.1,.8,0],27)
        water_name=words(['Вода'],[-3.1,-1.25,0],22,CYAN)
        self.show(tank,ball,initial,water_name,run_time=1.2)
        self.intro(1)
        final=words(['Вода и шар: t₃','Общая конечная температура','t₂ < t₃ < t₁'],[3.1,.8,0],25,LAVENDER)
        self.act(1,Succession(
            ball.animate.move_to([-3.1,-.5,0]),
            AnimationGroup(Transform(ball,ball.copy().move_to([-3.1,-.5,0]).set_color(LAVENDER)),
                           tank[0].animate.set_color(LAVENDER),Transform(initial,final))))
        self.show(words(['Потерями и теплоёмкостью','сосуда пренебрегаем'],[3.1,-1.5,0],23,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        received=formula(r'Q_{\rm in}=c_{\mathrm{ш}}m_2(t_3-t_2)',[-3.1,1,0],34,CYAN)
        given=formula(r'Q_{\rm out}=c_{\mathrm{в}}m_1(t_1-t_3)',[3.1,1,0],34,ROSE)
        labels=VGroup(words(['Шар нагревается'],[-3.1,.0,0],25,CYAN),
                      words(['Вода охлаждается'],[3.1,.0,0],25,ROSE))
        self.show(received,given,labels,run_time=1.2)
        self.intro(2)
        equality=formula(r'c_{\mathrm{ш}}m_2(t_3-t_2)=c_{\mathrm{в}}m_1(t_1-t_3)',[0,-1.45,0],35,GOLD,width=11.5)
        self.act(2,Write(equality))
        self.show(words(['t₃ — конечная температура обоих тел'],[0,-2.45,0],23,MUTED,width=11),run_time=1.2)
        self.result(2)

        self.beat(3)
        balance=formula(r'c_{\mathrm{ш}}m_2(t_3-t_2)=c_{\mathrm{в}}m_1(t_1-t_3)',[0,.9,0],40,width=11.3)
        self.show(balance,words(['Известны: c воды, обе массы, три температуры'],[0,-.35,0],25,width=11.5),run_time=1.2)
        self.intro(3)
        measured=formula(r'c_{\mathrm{ш}}=c_{\mathrm{в}}\frac{m_1}{m_2}\frac{t_1-t_3}{t_3-t_2}',[0,.9,0],43,GOLD,width=11.3)
        self.act(3,Succession(FadeOut(balance),FadeIn(measured)))
        self.show(words(['Удельная теплоёмкость материала шара'],[0,-1.4,0],27,CYAN,width=11.5),
                  formula(r'[c_{\mathrm{ш}}]=\frac{\mathrm{J}}{\mathrm{kg}\cdot\mathrm{K}}',[0,-2.4,0],31),run_time=1.2)
        self.result(3)
