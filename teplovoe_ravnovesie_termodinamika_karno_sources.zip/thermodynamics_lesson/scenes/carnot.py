"""Heat engines and a physically closed Carnot cycle; source PDF pages 1–3."""
from thermal_style import *


def block(name, center, color, width=2.7, height=.78, size=22):
    box=RoundedRectangle(width=width,height=height,corner_radius=.12,
                         color=color,stroke_width=2).move_to(center)
    return VGroup(box,txt(name,size,color).move_to(center))


def engine_diagram():
    hot=block('Нагреватель',(-3.8,1.75,0),GOLD)
    gas=block('Рабочее тело',(-3.8,0,0),INK)
    cold=block('Холодильник',(-3.8,-1.75,0),CYAN)
    heat=arrow((-3.8,1.26,0),(0,-.77,0),GOLD)
    loss=arrow((-3.8,-.49,0),(0,-.77,0),CYAN)
    work=arrow((-2.32,0,0),(1.45,0,0),ROSE)
    qn=eq(r'Q_{\mathrm{н}}',29,GOLD).move_to([-4.5,.85,0])
    qx=eq(r'Q_{\mathrm{х}}',29,CYAN).move_to([-4.5,-.87,0])
    a=eq('A',31,ROSE).move_to([-1.57,.43,0])
    return VGroup(hot,gas,cold),VGroup(heat,loss,work,qn,qx,a)


class HeatEngine(ThermoScene):
    chapter_id=12

    def chapter(self):
        self.beat(0)
        blocks,flows=engine_diagram()
        theory=words(['Тепловой двигатель','Энергия топлива → работа'],(3.0,1.0,0),25)
        self.show(blocks,theory,run_time=1.2)
        self.intro(0)
        self.act(0,Create(flows))
        self.show(words(['Рабочее тело получает тепло,','совершает работу','и отдаёт часть теплоты'],(3.0,-1.0,0),23),run_time=1.2)
        self.result(0)

        self.beat(1)
        centers=[(-4.8,1.0,0),(-1.5,1.0,0),(-1.5,-1.2,0),(-4.8,-1.2,0)]
        names=['Котёл','Турбина','Конденсатор','Насос']
        boxes=VGroup(*[RoundedRectangle(width=2.25,height=.7,corner_radius=.12,
                    color=c,stroke_width=2).move_to(p)
                    for p,c in zip(centers,[GOLD,ROSE,CYAN,MUTED])])
        labels=VGroup(*[txt(name,21).move_to([p[0],p[1]+(.65 if i<2 else -.65),0])
                    for i,(name,p) in enumerate(zip(names,centers))])
        pipes=VGroup(
            arrow((-3.65,1,0),(1,0,0),MUTED),
            arrow((-1.5,.55,0),(0,-1.3,0),MUTED),
            arrow((-2.65,-1.2,0),(-1,0,0),MUTED),
            arrow((-4.8,-.75,0),(0,1.3,0),MUTED))
        path=Polygon(*map(np.array,centers)).round_corners(.18)
        start=Dot(path.get_start(),radius=.07,color=CYAN)
        intro=words(['Вода и пар —','одно рабочее тело'],(3.1,1.15,0),26)
        self.show(boxes,labels,pipes,start,intro,run_time=1.2)
        self.intro(1)
        self.act(1,MoveAlongPath(start,path),rate_func=linear)
        self.show(words(['Нагрев → пар','Работа турбины','Конденсация → вода','Возвращение в котёл'],(3.1,-.95,0),23),run_time=1.2)
        self.result(1)

        self.beat(2)
        blocks,flows=engine_diagram()
        condition=formula(r'\Delta U_{\mathrm{цикл}}=0',(3.0,1.35,0),37)
        self.show(blocks,condition,run_time=1.2)
        self.intro(2)
        self.act(2,Create(flows))
        self.show(formula(r'A=Q_{\mathrm{н}}-Q_{\mathrm{х}}',(3.0,-.05,0),39),
                  words(['Qн и Qх — положительные','количества переданной теплоты'],(3.0,-1.5,0),22),run_time=1.2)
        self.result(2)

        self.beat(3)
        definition=words(['КПД — доля полученной теплоты,','превращённая в работу'],(-3.1,1.2,0),24)
        fraction=formula(r'\eta=\frac{A}{Q_{\mathrm{н}}}',(-3.1,-.5,0),49)
        derived=formula(r'\eta=\frac{Q_{\mathrm{н}}-Q_{\mathrm{х}}}{Q_{\mathrm{н}}}'
                        r'=1-\frac{Q_{\mathrm{х}}}{Q_{\mathrm{н}}}',(3.0,.5,0),39)
        self.show(definition,fraction,run_time=1.2)
        self.intro(3)
        self.act(3,FadeIn(derived))
        self.show(formula(r'0<\eta<1',(-3.1,-2.1,0),35),
                  formula(r'\eta_{\%}=\eta\cdot100\%',(3.0,-1.55,0),34),run_time=1.2)
        self.result(3)


class CarnotCycle(ThermoScene):
    chapter_id=13

    def chapter(self):
        # Unlabelled coordinates only set the geometry, not a numerical example.
        gamma=1.4; hot=3.0; cold=2.4; v1=1.0; v2=2.5
        ratio=(hot/cold)**(1/(gamma-1))
        v3=v2*ratio;v4=v1*ratio
        ax,frame=chart(center=(-3.25,-.15,0),width=4.7,height=3.6,
                       x_range=(0,5.2,1),y_range=(0,3.7,1))
        pts=[ax.c2p(v1,hot/v1),ax.c2p(v2,hot/v2),
             ax.c2p(v3,cold/v3),ax.c2p(v4,cold/v4)]
        offsets=[UP*.25,UP*.25,RIGHT*.24+DOWN*.12,LEFT*.28]
        marks=[VGroup(Dot(p,radius=.045,color=INK),
                      eq(str(i+1),26).move_to(p+offsets[i])) for i,p in enumerate(pts)]
        curves=[
            ParametricFunction(lambda t:ax.c2p(t,hot/t),t_range=[v1,v2],color=GOLD,stroke_width=3),
            ParametricFunction(lambda t:ax.c2p(t,hot/v2*(v2/t)**gamma),t_range=[v2,v3],color=ROSE,stroke_width=3),
            ParametricFunction(lambda s:ax.c2p(v3+(v4-v3)*s,cold/(v3+(v4-v3)*s)),t_range=[0,1],color=CYAN,stroke_width=3),
            ParametricFunction(lambda s:ax.c2p(v4+(v1-v4)*s,cold/v4*(v4/(v4+(v1-v4)*s))**gamma),t_range=[0,1],color=LAVENDER,stroke_width=3)]
        directions=[arrow(c.point_from_proportion(.43),c.point_from_proportion(.61)-c.point_from_proportion(.43),c.get_color(),3)
                    for c in curves]
        traveler=Dot(pts[0],radius=.07,color=INK)
        headings=[
            ('1 → 2 · Изотермическое расширение',r'T=T_{\mathrm{н}}=\mathrm{const}',GOLD),
            ('2 → 3 · Адиабатное расширение',r'Q=0',ROSE),
            ('3 → 4 · Изотермическое сжатие',r'T=T_{\mathrm{х}}=\mathrm{const}',CYAN),
            ('4 → 1 · Адиабатное сжатие',r'Q=0',LAVENDER)]
        results=[
            (r'\Delta U=0,\quad A=Q_{\mathrm{н}}>0',['Газ получает тепло','и совершает работу']),
            (r'A>0,\quad\Delta U=-A<0',['Температура уменьшается:','от Tн до Tх']),
            (r'\Delta U=0,\quad A=-Q_{\mathrm{х}}<0',['Газ отдаёт тепло','холодильнику']),
            (r'A<0,\quad\Delta U=-A>0',['Возврат в состояние 1','ΔU за полный цикл равно нулю'])]
        previous=[]
        for i in range(4):
            self.beat(i,clear=(i==0))
            heading,condition,color=headings[i]
            title=words([heading],(3.0,1.85,0),23,color)
            given=formula(condition,(3.0,.8,0),36,color)
            if i==0:
                self.show(frame,marks[0],traveler,title,given,run_time=1.2)
            else:
                self.play(*[FadeOut(m) for m in previous],FadeIn(title),FadeIn(given),run_time=1.2)
            self.intro(i)
            extra=[] if i==3 else [FadeIn(marks[i+1])]
            self.act(i,Create(curves[i]),MoveAlongPath(traveler,curves[i]),
                     FadeIn(directions[i]),*extra)
            statement,explanation=results[i]
            result_eq=formula(statement,(3.0,-.55,0),33,color)
            result_words=words(explanation,(3.0,-1.85,0),23)
            self.show(result_eq,result_words,run_time=1.2)
            self.result(i)
            previous=[title,given,result_eq,result_words]


class CarnotEfficiency(ThermoScene):
    chapter_id=14

    def chapter(self):
        self.beat(0)
        blocks,flows=engine_diagram()
        initial=words(['Идеальный цикл Карно','Две изотермы','Две адиабаты'],(3.0,1.2,0),25)
        self.show(blocks,initial,run_time=1.2)
        self.intro(0)
        self.act(0,Create(flows))
        self.show(words(['Обратимый цикл','при заданных Tн и Tх'],(3.0,-.5,0),23),
                  formula(r'\eta_{\mathrm{реал}}\leq\eta_{\mathrm{Карно}}',(3.0,-1.85,0),35),run_time=1.2)
        self.result(0)

        self.beat(1)
        temperatures=formula(r'T_{\mathrm{н}}>T_{\mathrm{х}}>0',(-3.1,1.15,0),40)
        units=words(['Обе температуры','в кельвинах'],(-3.1,-.45,0),27,CYAN)
        eta=formula(r'\eta_{\mathrm{К}}=\frac{T_{\mathrm{н}}-T_{\mathrm{х}}}{T_{\mathrm{н}}}',(3.0,.8,0),43)
        eta_final=formula(r'\eta_{\mathrm{К}}=1-\frac{T_{\mathrm{х}}}{T_{\mathrm{н}}}',(3.0,.8,0),43)
        self.show(temperatures,units,eta,run_time=1.2)
        self.intro(1)
        self.act(1,Succession(FadeOut(eta),FadeIn(eta_final)))
        self.show(words(['Градусы Цельсия','в это отношение не подставляют'],(-3.1,-2.0,0),22),
                  formula(r'\eta_{\%}=\eta_{\mathrm{К}}\cdot100\%',(3.0,-1.5,0),34),run_time=1.2)
        self.result(1)

        self.beat(2)
        baseline=-1.65
        def bar(x,height,color):
            return Rectangle(width=.72,height=height,stroke_width=1.5,
                             color=color,fill_color=color,fill_opacity=.32).move_to([x,baseline+height/2,0])
        hot1=bar(-4.0,1.55,GOLD);cold1=bar(-2.5,.9,CYAN)
        hot2=bar(2.5,2.4,GOLD);cold2=bar(4.0,1.55,CYAN)
        headings=VGroup(formula(r'T_{\mathrm{н}}\uparrow,\quad T_{\mathrm{х}}=\mathrm{const}',(-3.25,2.05,0),29),
                        formula(r'T_{\mathrm{х}}\downarrow,\quad T_{\mathrm{н}}=\mathrm{const}',(3.25,2.05,0),29))
        bar_labels=VGroup(*[eq(tex,27,c).move_to([x,-2.15,0]) for x,tex,c in
                    [(-4,r'T_{\mathrm{н}}',GOLD),(-2.5,r'T_{\mathrm{х}}',CYAN),
                     (2.5,r'T_{\mathrm{н}}',GOLD),(4,r'T_{\mathrm{х}}',CYAN)]])
        bases=VGroup(Line([-4.7,baseline,0],[-1.8,baseline,0],color=MUTED),
                     Line([1.8,baseline,0],[4.7,baseline,0],color=MUTED))
        self.show(hot1,cold1,hot2,cold2,headings,bar_labels,bases,run_time=1.2)
        self.intro(2)
        self.act(2,Transform(hot1,bar(-4,2.4,GOLD)),Transform(cold2,bar(4,.75,CYAN)))
        self.show(formula(r'\eta_{\mathrm{К}}\uparrow',(-3.25,1.25,0),35),
                  formula(r'\eta_{\mathrm{К}}\uparrow',(3.25,1.25,0),35),run_time=1.2)
        self.result(2)

        self.beat(3)
        condition=formula(r'\eta_{\mathrm{К}}=1-\frac{T_{\mathrm{х}}}{T_{\mathrm{н}}}',(-3.1,.8,0),43)
        wish=words(['Что потребовалось бы','для КПД 100 %?'],(3.0,1.15,0),26)
        final=formula(r'\eta_{\mathrm{К}}=1\ \Longrightarrow\ T_{\mathrm{х}}=0\,\mathrm{K}',(-3.1,.8,0),37)
        self.show(condition,wish,run_time=1.2)
        self.intro(3)
        self.act(3,Succession(FadeOut(condition),FadeIn(final)))
        self.show(words(['Абсолютный нуль','недостижим'],(3.0,-.4,0),27,CYAN),
                  formula(r'T_{\mathrm{х}}>0\quad\Longrightarrow\quad\eta_{\mathrm{К}}<1',(-3.1,-1.35,0),34),
                  words(['Часть теплоты передаётся','холодильнику'],(3.0,-2.0,0),23),run_time=1.2)
        self.result(3)
