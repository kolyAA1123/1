"""Pure-black visual system with controlled, completed transitions."""
from pathlib import Path
import json
import re
import os
import numpy as np
from manim import *

ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'plan.json').read_text())
BLACK_BG='#000000'
INK='#EDF2FA'
MUTED='#9AAAC0'
CYAN='#58DCE6'
GOLD='#FFD071'
ROSE='#F17C95'
LAVENDER='#A394FA'
GRID='#28354A'
FONT='DejaVu Sans'
CYRILLIC_TEX=TexTemplate(tex_compiler='xelatex',output_format='.xdv',
    preamble=r'\usepackage{amsmath}\usepackage{amssymb}\usepackage{fontspec}\setmainfont{DejaVu Sans}')

def txt(text,size=25,color=INK,**kwargs):
    return Text(text,font=FONT,font_size=size,color=color,**kwargs)

def eq(tex,size=35,color=INK,**kwargs):
    if re.search('[А-Яа-яЁё]',tex):
        tex=re.sub(r'\\mathrm\{([^{}]*[А-Яа-яЁё][^{}]*)\}',r'\\text{\1}',tex)
        kwargs.setdefault('tex_template',CYRILLIC_TEX)
    return MathTex(tex,font_size=size,color=color,**kwargs)

def axes(x_range=(0,5,1),y_range=(0,4,1),width=5.8,height=3.7,center=LEFT*2.8+DOWN*.15):
    a=Axes(x_range=x_range,y_range=y_range,x_length=width,y_length=height,
        axis_config={'color':MUTED,'stroke_width':1.4,'include_tip':True,
                     'tip_width':.1,'tip_height':.11},tips=True)
    return a.move_to(center)

def arrow(start,vector,color=CYAN,width=3):
    start=np.asarray(start,dtype=float);vector=np.asarray(vector,dtype=float)
    norm=np.linalg.norm(vector)
    if norm<1e-6:
        return Arrow(start,start+RIGHT*.001,buff=0,color=color,stroke_width=width).set_opacity(0)
    result=Arrow(start,start+vector,buff=0,color=color,stroke_width=width,
                 max_tip_length_to_length_ratio=.22)
    if norm<.08:result.set_opacity(norm/.08)
    return result

def car(color=CYAN):
    body=RoundedRectangle(width=.7,height=.24,corner_radius=.05,color=color,stroke_width=2)
    roof=VMobject(color=color,stroke_width=2).set_points_as_corners([[-.24,.12,0],[-.12,.28,0],[.13,.28,0],[.25,.12,0]])
    wheels=VGroup(*[Circle(radius=.065,color=INK,stroke_width=1.7).move_to([x,-.15,0]) for x in [-.22,.22]])
    return VGroup(body,roof,wheels)

def freeze(*objects):
    for obj in objects:obj.clear_updaters(recursive=True)

def _suspend(objects):
    saved=[];seen=set()
    for obj in objects:
        obj.update(0)
        for mob in obj.get_family():
            if id(mob) not in seen:
                seen.add(id(mob));saved.append((mob,list(mob.updaters)))
                mob.clear_updaters(recursive=False)
    return saved

def _resume(saved):
    for obj,updaters in saved:
        for updater in updaters:obj.add_updater(updater)

class ChapterScene(MovingCameraScene):
    chapter_id=1

    def play(self,*animations,**kwargs):
        result=super().play(*animations,**kwargs)
        if os.environ.get('LESSON_LAYOUT_AUDIT')=='1' and hasattr(self,'meta'):
            self.audit_layout()
        return result

    def audit_layout(self):
        """Measure distinct text blocks after transitions; glyphs stay grouped."""
        labels=[];seen=set()
        def visit(mob):
            if id(mob) in seen:return
            seen.add(id(mob))
            if isinstance(mob,(Text,MathTex,Tex)):
                if mob.width>.005 and mob.height>.005:
                    content=getattr(mob,'text',None) or getattr(mob,'tex_string',None) or str(type(mob).__name__)
                    labels.append((str(content),[float(mob.get_left()[0]),float(mob.get_bottom()[1]),float(mob.get_right()[0]),float(mob.get_top()[1])]))
                return
            for child in mob.submobjects:visit(child)
        for mob in self.mobjects:visit(mob)
        issues=[]
        for i,(text_a,a) in enumerate(labels):
            if a[0]<-7.10 or a[2]>7.10 or a[1]<-3.98 or a[3]>3.98:
                issues.append({'kind':'outside_frame','text':text_a,'bounds':a})
            for text_b,b in labels[i+1:]:
                dx=min(a[2],b[2])-max(a[0],b[0]);dy=min(a[3],b[3])-max(a[1],b[1])
                if dx>.025 and dy>.025:
                    issues.append({'kind':'text_overlap','a':text_a,'b':text_b,'intersection':[round(dx,4),round(dy,4)],'bounds_a':a,'bounds_b':b})
        self.layout_samples.append({'time':round(self.time-self.started,3),'labels':len(labels),'issues':issues})
        path=ROOT/'output'/'layout_checks'/f'{self.chapter_id:02d}.json'
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({'chapter':self.chapter_id,'samples':self.layout_samples},ensure_ascii=False,indent=2))

    def show(self,*objects,run_time=1.0,create=False):
        """Do not let always_redraw override FadeIn/Create opacity."""
        saved=_suspend(objects)
        try:
            self.play(*[(Create(m) if create else FadeIn(m)) for m in objects],run_time=run_time)
        finally:_resume(saved)

    def clear_stage(self,keep=(),run_time=1.0):
        protected=[self.header,self.caption,*keep]
        protected_ids={id(m) for p in protected if p is not None for m in p.get_family()}
        stage=[m for m in list(self.mobjects)
               if not any(id(member) in protected_ids for member in m.get_family())]
        freeze(*stage)
        if stage:self.play(*[FadeOut(m) for m in stage],run_time=run_time)

    def chapter(self):raise NotImplementedError


def formula(tex, center=(3,0,0), size=36, color=INK, width=5.6):
    mob=eq(tex,size,color)
    if mob.width>width:mob.scale_to_fit_width(width)
    return mob.move_to(center)


def words(strings, center=(3,0,0), size=25, color=INK, width=5.6):
    if isinstance(strings,str):strings=[strings]
    mob=VGroup(*[txt(line,size,color) for line in strings]).arrange(DOWN,buff=.24)
    if mob.width>width:mob.scale_to_fit_width(width)
    return mob.move_to(center)


def chart(center=(-3.1,0,0),width=4.8,height=3.5,x_range=(0,5,1),y_range=(0,4,1),x_label='V',y_label='p'):
    ax=axes(x_range,y_range,width,height,np.array(center,dtype=float))
    ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
    names=VGroup(eq(x_label,27,MUTED).next_to(ax.x_axis,RIGHT,buff=.16),
                 eq(y_label,27,MUTED).next_to(ax.y_axis,UP,buff=.15))
    return ax,VGroup(ax,names)


class ThermoScene(ChapterScene):
    """Initial theory, a completed action, then the explained result on one clock."""
    def construct(self):
        self.camera.background_color=BLACK_BG
        self.meta=PLAN['chapters'][self.chapter_id-1]
        self.chapter_duration=self.meta['duration']
        self.started=self.time;self.layout_samples=[];self.sync_events=[];self.caption=None
        title=txt(self.meta['title'],27).to_edge(LEFT,buff=.55).to_edge(UP,buff=.28)
        if title.width>11:title.scale_to_fit_width(11).to_edge(LEFT,buff=.55)
        count=txt(f"{self.chapter_id:02d} / {len(PLAN['chapters'])}",16,MUTED).move_to([6.1,3.55,0])
        citation=txt(f"{self.meta['short']} · с. {self.meta['pages']}",14,MUTED).move_to([0,3.03,0])
        rule=Line([-6.55,2.75,0],[6.55,2.75,0],color=GRID,stroke_width=1)
        self.header=VGroup(title,count,citation,rule)
        self.play(FadeIn(self.header),run_time=.8)
        self.chapter()
        remaining=self.chapter_duration-(self.time-self.started)
        if remaining<1.18:raise RuntimeError(f'No final fade in chapter {self.chapter_id}: {remaining}')
        self.wait(max(0,remaining-1.2));freeze(*self.mobjects)
        self.play(*[FadeOut(m) for m in list(self.mobjects)],run_time=1.2)
        path=ROOT/'output/sync_checks'/f'{self.chapter_id:02d}.json'
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({'chapter':self.chapter_id,'events':self.sync_events,'duration':self.time-self.started},ensure_ascii=False,indent=2))

    def wait_until(self,stamp,phase):
        actual=self.time-self.started
        if actual>stamp+.085:raise RuntimeError(f'Chapter {self.chapter_id} {phase}: {actual:.3f} > {stamp:.3f}')
        if stamp>actual+1e-6:self.wait(stamp-actual)

    def beat(self,index,note=None,clear=True):
        beat=self.meta['beats'][index]
        self.wait_until(beat['start'],f'beat {index+1}')
        if clear:self.clear_stage(run_time=.6)
        new=txt(note or beat['caption'],23,MUTED).move_to([0,-3.48,0])
        if new.width>12.4:new.scale_to_fit_width(12.4)
        animations=[FadeIn(new)]
        if self.caption is not None:animations.append(FadeOut(self.caption))
        self.play(*animations,run_time=.4);self.caption=new

    def intro(self,index):
        beat=self.meta['beats'][index]
        self.sync_events.append({'beat':index+1,'event':'intro_ready','time':self.time-self.started,'speech_at':beat['intro_at']})
        self.wait_until(beat['intro_at'],f'intro {index+1}');self.wait(beat['intro_duration'])

    def act(self,index,*animations,rate_func=smooth):
        beat=self.meta['beats'][index]
        self.wait_until(beat['action_at'],f'action {index+1}')
        self.sync_events.append({'beat':index+1,'event':'action_start','time':self.time-self.started})
        if animations:self.play(*animations,run_time=beat['action_seconds'],rate_func=rate_func)
        else:self.wait(beat['action_seconds'])
        self.sync_events.append({'beat':index+1,'event':'action_end','time':self.time-self.started})

    def result(self,index):
        beat=self.meta['beats'][index]
        self.sync_events.append({'beat':index+1,'event':'result_ready','time':self.time-self.started,'speech_at':beat['result_at']})
        self.wait_until(beat['result_at'],f'result {index+1}');self.wait(beat['result_duration'])
