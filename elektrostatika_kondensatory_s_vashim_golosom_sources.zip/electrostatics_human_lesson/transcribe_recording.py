"""Local Russian ASR with pause-based chunks, cached independently."""
from pathlib import Path
import argparse,hashlib,json,os,time,wave
import numpy as np
from concurrent.futures import ProcessPoolExecutor,as_completed
ROOT=Path(__file__).resolve().parent
MODEL=Path(os.environ.get('ELECTROSTATICS_ASR_MODEL',str(ROOT.parent.parent/'asr_models/sherpa-onnx-whisper-small')))

def chunks_from_audio(a):
 hop=160;n=len(a)//hop
 rms=np.sqrt((a[:n*hop].reshape(n,hop).astype(float)**2).mean(1))
 quiet=rms<10**(-45/20)
 changes=np.diff(np.r_[False,quiet,False].astype(int))
 pauses=[(int(s)*.01,int(e)*.01) for s,e in zip(np.flatnonzero(changes==1),np.flatnonzero(changes==-1)) if(e-s)*.01>=.65]
 boundaries=[0]+[(s+e)/2 for s,e in pauses if .5<(s+e)/2<len(a)/16000-.5]+[len(a)/16000]
 pieces=[]
 for left,right in zip(boundaries,boundaries[1:]):
  # Long paragraphs are cut at the quietest nearby frame, with 0.2s handles.
  while right-left>26:
   lo=int((left+16)*100);hi=int((left+24)*100)
   k=lo+int(np.argmin(np.convolve(rms[lo:hi],np.ones(20)/20,mode='same')))
   split=k*.01;pieces.append((left,split+.2));left=split-.2
  pieces.append((left,right))
 return [{'index':i,'start':round(s,4),'end':round(e,4)} for i,(s,e) in enumerate(pieces) if e-s>.25]

def init_worker():
 global RECOGNIZER,AUDIO
 os.environ['OMP_NUM_THREADS']='1'
 import sherpa_onnx
 RECOGNIZER=sherpa_onnx.OfflineRecognizer.from_whisper(
  encoder=str(MODEL/'small-encoder.int8.onnx'),decoder=str(MODEL/'small-decoder.int8.onnx'),
  tokens=str(MODEL/'small-tokens.txt'),language='ru',task='transcribe',num_threads=2,
  provider='cpu',enable_segment_timestamps=True)
 with wave.open(str(ROOT/'materials/recording_16k.wav')) as w:
  AUDIO=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768

def run(item):
 dest=ROOT/'output/asr_chunks'/f"{item['index']:03d}.json"
 if dest.exists():
  cached=json.loads(dest.read_text())
  if cached.get('recording_sha256')==item.get('recording_sha256') and item.get('recording_sha256'):return cached
 t=time.monotonic();s=RECOGNIZER.create_stream()
 s.accept_waveform(16000,AUDIO[round(item['start']*16000):round(item['end']*16000)])
 RECOGNIZER.decode_stream(s)
 r=s.result;segments=[]
 for at,dur,txt in zip(r.segment_timestamps,r.segment_durations,r.segment_texts):
  segments.append({'start':round(item['start']+float(at),4),'end':round(item['start']+float(at)+float(dur),4),'text':txt})
 result={**item,'text':r.text,'segments':segments,'elapsed':round(time.monotonic()-t,3)}
 dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 return result

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--jobs',type=int,default=4);parser.add_argument('--first',type=int);args=parser.parse_args()
 (ROOT/'output/asr_chunks').mkdir(exist_ok=True)
 with wave.open(str(ROOT/'materials/recording_16k.wav')) as w:a=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
 chunks=chunks_from_audio(a)
 with (ROOT/'materials/recording_16k.wav').open('rb') as source:signature=hashlib.file_digest(source,'sha256').hexdigest()
 for chunk in chunks:chunk['recording_sha256']=signature
 (ROOT/'output/asr_chunks_plan.json').write_text(json.dumps(chunks,indent=2)+'\n')
 if args.first:chunks=chunks[:args.first]
 print('CHUNKS',len(chunks),flush=True)
 with ProcessPoolExecutor(max_workers=args.jobs,initializer=init_worker) as pool:
  for f in as_completed([pool.submit(run,c) for c in chunks]):
   r=f.result();print(f"{r['index']:03d} {r['start']:.2f}–{r['end']:.2f} [{r['elapsed']:.1f}s] {r['text']}",flush=True)
 results=[json.loads((ROOT/'output/asr_chunks'/f"{c['index']:03d}.json").read_text()) for c in chunks]
 (ROOT/'output/transcription.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'output/transcription.txt').write_text('\n'.join(f"[{r['index']:03d} {r['start']:.2f}–{r['end']:.2f}] {r['text']}" for r in results)+'\n')
if __name__=='__main__':main()
