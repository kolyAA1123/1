"""Expose actual readiness/action markers from the audited exact event timeline.

This supports cached audits created before the convenience beat fields existed;
it does not execute geometry, change source media, or estimate any time.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent

def enrich(c):
    for b in c['beats']:
        n=b['index']+1
        intro=next(w for w in c['windows'] if w['beat']==n and w['phase']=='intro')
        result=next(w for w in c['windows'] if w['beat']==n and w['phase']=='result')
        action=next(a for a in c['actions'] if a['beat']==n)
        b.update(beat=n,intro_ready_frame=intro['ready_event_frame'],
                 action_start_frame=action['old_start_frame'],action_end_frame=action['old_end_frame'],
                 result_ready_frame=result['ready_event_frame'])
        assert b['intro_ready_frame']<=intro['old_start_frame']<intro['old_end_frame']<=b['action_start_frame']
        assert b['action_end_frame']<=b['result_ready_frame']<=result['old_start_frame']
    return c

def main():
    files=sorted((ROOT/'output').glob('source_timeline_chapter_*.json'))
    full=ROOT/'output/source_timeline.json'
    if full.exists():files.append(full)
    for p in files:
        data=json.loads(p.read_text())
        data['chapters']=[enrich(c) for c in data['chapters']]
        p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        if p==full:
            windows={'fps':60,'chapters':[{k:c[k] for k in ('id','class','source','source_frames','windows','beats','actions')} for c in data['chapters']]}
            (ROOT/'source_windows.json').write_text(json.dumps(windows,ensure_ascii=False,indent=2)+'\n')
    print(f'Enriched{len(files)}cachedtimelinefiles',flush=True)
if __name__=='__main__':main()
