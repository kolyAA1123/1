from pathlib import Path
import math
import json

import numpy as np
from manim import Axes, Create, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Алгебраические выражения и уравнения"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



def graph(kind):
    if kind == "radical":
        axes = Axes(x_range=[-4.2, 5, 1], y_range=[-4.3, 4.3, 1], x_length=5.15, y_length=3.9,
                    axis_config={"color": MUTED, "stroke_width": 1.6, "include_ticks": False}).move_to([-3.55,-.15,0])
        root = axes.plot(lambda x: np.sqrt(x + 3), x_range=[-3,4.4,.05], color=CYAN, stroke_width=3)
        line = axes.plot(lambda x: x - 1, x_range=[-3,4.3,.05], color=GOLD, stroke_width=3)
        hit = (3 + np.sqrt(17)) / 2
        return VGroup(axes), VGroup(root, line, Dot(axes.c2p(hit,hit-1),color=CYAN))
    if kind == "interval":
        knots = [-5.85,-4.95,-4.00,-2.50,-1.29]
        axis = Line([knots[0],0,0],[knots[-1],0,0],color=MUTED,stroke_width=2)
        positions = [(knots[1],"-1",ROSE),(knots[2],"0",CYAN),(knots[3],"2",ROSE)]
        markers = [VGroup(Dot([x,0,0],color=color,radius=.065),
                          equation(form,INK,[x,-.30,0],.26)) for x,form,color in positions]
        return VGroup(axis), VGroup(*markers)
    return VGroup(), VGroup()


class EquationsLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==0 and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
