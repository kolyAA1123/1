# Publication preflight

Read-only publication review of the magnetism project during the final render.
No scene, style, plan, narration, timing, README or AGENTS files were changed.
The final assembled movie and its full-decode report remain a separate delivery
gate after rendering.

- Root README and AGENTS agree with the plan: 3517 seconds (58:37), 19 chapters,
  60 beats, 120 narration passages and 22 PDF pages. Narration has 5172 words.
- All 120 passages agree exactly between plan.json and narration.json and are
  present in both the UTF-8 TXT and Word DOCX (checked with system Python/docx).
- The four new README links use the intended magnetizm_magnitnyy_potok prefix
  and MP4/TXT/DOCX/source-ZIP names. The complete previous README is preserved
  as an exact suffix of the new file.
- source_manifest.json lists both 11-page PDFs. source_coverage.json includes
  every page 1–11 for each source and agrees with chapter beat counts.
  SOURCE_NOTES.md documents model conditions and corrections; page audits and
  the separate editorial/visual review reports are present.
- package_sources.py includes frame_alignment.py and the layout, preview/final
  sync, frame-alignment and final quality reports. It excludes the original
  PDFs, page images, caches and intermediate media. It gates the MP4 on matching
  verified SHA256, full decode and size below 100 MiB.
- No direct-current project filenames, imports or artifact paths were found in
  the new project or its source-package file enumeration. Mentions of steady
  current in the magnetism theory are appropriate content.
- git diff --check passed. Local HEAD and remote main both resolved to
  bf54529df609140b92471e7d36c70837eb214d71 at review time.

## Reproduction documentation finding — resolved

The initial project README ran package_sources.py before its later Word export
instruction, although a freshly unpacked source ZIP does not contain the
generated project DOCX required by packaging. The parent agent corrected the
instructions. Reinspection confirms that the main command block now installs
requirements-export.txt and runs export_docx.py immediately after
prepare_lesson.py, before rendering and package_sources.py. The following prose
also explicitly requires exporting Word before packaging. This documentation
ordering issue is resolved; no open publication-preflight findings remain.
Only this report was changed by the preflight reviewer.

## Intended publication set

Only these six root files need staging for the new film:

1. AGENTS.md
2. README.md
3. magnetizm_magnitnyy_potok_1080p60.mp4
4. magnetizm_magnitnyy_potok_tekst.txt
5. magnetizm_magnitnyy_potok_tekst.docx
6. magnetizm_magnitnyy_potok_sources.zip

The Word installation command also uses `uv pip --python ../.venv/bin/python`:
install.sh creates a uv virtual environment without requiring the pip module.
This keeps the documented export command compatible with that environment.
