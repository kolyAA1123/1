# Visual review: magnetism B, chapters 6–9

Reviewed all four preview contact sheets, `output/contacts/06.jpg` through
`09.jpg`: 13 beats with theory, action and result samples, **39 frames total**.
This is a review of preview frames; it does not replace final video decoding
or review at the final export resolution.

**Result: no must-fix findings in the reviewed frames.** No overlapping labels,
clipped formulas, wrong force directions or incomplete result states were
observed. All 147 recorded layout-check samples for these four chapters also
report zero issues (34 + 34 + 34 + 45).

| Chapter | Frames | Checks and findings |
| --- | ---: | --- |
| 6 | 9 | Dot/cross convention is correct. Counterclockwise current in the face-on loop gives a field towards the viewer. The projected loop and compass show a coil field to the right and a north pole turning almost along that axis while retaining the small Earth-field component. Labels remain separate. The initial compass-condition note explicitly says “До включения катушки”, so its presence in the result does not assert that the current is still off. |
| 7 | 9 | With current right and field into the screen, the Ampère force points up. With current up and field right, it points into the screen. In the rotation sample the conductor and current arrow retain their lengths, rotate together and end parallel to the field; the force disappears. The formulas for the perpendicular and parallel cases are explicitly conditional. No label collisions. |
| 8 | 9 | Equal current directions give inward forces; opposite directions give outward forces. The foreign-wire fields have the correct dot/cross directions at both wires. The comparison result agrees with the examples. |
| 9 | 12 | For a field into the screen: positive charge moving right has force up; negative charge moving right has force down; negative charge moving left has force up. The particle positions are fixed and the frame explicitly identifies the directions as instantaneous. The magnitude formula uses the absolute value of charge, and its zero/maximum cases are correct. |

The action sample in 6.1 shows an unfinished cross while its strokes are being
drawn; the result sample completes both strokes. This is a normal intermediate
animation state, not an incomplete final symbol.

Reviewed authored inputs:

- `scenes/magnetism_b.py`: SHA-256 `d38b69219d9786efd26cdd5eea273aa70083ad1a8999e3f5d378e92085eb2f84`
- `scenes/magnetism_b_beats.json`: SHA-256 `04fb98139d4e1cd7620c761793133ae0ac876455245f6c692f5d76614084abe6`

No scene code, narration text or rendering outputs were changed during this
visual review.
