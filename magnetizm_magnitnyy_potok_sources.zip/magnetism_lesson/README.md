# Магнетизм и магнитный поток

Разбор теории по двум пользовательским конспектам, 22 страницы, включая титулы.
Длительность — 58:37; 19 глав, 60 эпизодов, 120 фрагментов текста.
Чёрный фон, 1920×1080, 60 кадров/с, без звуковой дорожки. Текст для озвучки
отдельно в TXT и Word; начальные условия объясняются перед действием,
результат — после его завершения. Времена чтения оценены ориентировочно;
после получения записи можно подстроить удержания кадров под голос.

## Повторная сборка

Среда — Linux/Debian 13 с Python, uv, FFmpeg/ffprobe, LaTeX/XeLaTeX
и шрифтом DejaVu Sans. Версии текущей среды — в toolchain.json.
Распакуйте архив с сохранением структуры. Из его корня выполните
`bash install.sh`, затем `source setup_env.sh` и перейдите в magnetism_lesson.

```bash
python prepare_lesson.py
uv pip install --python ../.venv/bin/python -r requirements-export.txt
python export_docx.py
python render_magnetic.py --preview --jobs 3 --no-assemble
python make_contacts.py
python render_magnetic.py --jobs 3
python verify_delivery.py
python package_sources.py
```

Перед финальной сборкой просмотрите все theory/action/result кадры
в output/contacts и актуальные отчёты расположения подписей. Word-файл
нужно экспортировать до запуска package_sources.py, как показано выше.

plan.json задаёт общий визуальный план; narration.json — текст и таймкоды.
Постраничная сверка: materials/audit_*.md. Уточнения исходных рисунков
и условий формул: SOURCE_NOTES.md. Сами PDF, растры страниц и временные
видеофайлы в архив не включены.

Последние 1–5 уже чёрных кадров могут дополняться с сохранением исходных
H.264-пакетов и их временных меток, только при точном совпадении SPS/PPS.
Иначе используется полное перекодирование чёрного окончания. Проверки
фактически применённого метода находятся в output/frame_alignment.
