"""Loop fields, Ampere forces, parallel currents and magnetic Lorentz force."""
from magnetic_style import *


# Coordinates: +x right, +y up, +z toward the viewer.
# I/v=(1,0,0), B=(0,0,-1) => I/v cross B=(0,1,0).
assert np.allclose(np.cross(RIGHT,IN),UP)
assert np.allclose(np.cross(UP,OUT),RIGHT)
assert np.allclose(np.cross(UP,IN),LEFT)


def b_normal(center=(-3.1,0,0),toward=True,radius=.25,color=GOLD):
    c=np.array(center,dtype=float)
    ring=Circle(radius=radius,color=color,stroke_width=2).move_to(c)
    if toward:
        inside=Dot(c,radius=radius*.21,color=color)
    else:
        d=radius*.55
        inside=VGroup(Line(c+[-d,-d,0],c+[d,d,0],color=color,stroke_width=2),
                      Line(c+[-d,d,0],c+[d,-d,0],color=color,stroke_width=2))
    return VGroup(ring,inside)


def b_field_grid():
    return VGroup(*[b_normal((x,y,0),toward=False,radius=.13)
                    for x in (-5.1,-3.5,-1.9) for y in (-1.25,-.65)])


def b_wire_pair(opposite=False):
    leftx,rightx=-4.6,-1.8
    wires=VGroup(Line([leftx,-1.35,0],[leftx,1.35,0],color=INK,stroke_width=3),
                 Line([rightx,-1.35,0],[rightx,1.35,0],color=INK,stroke_width=3))
    currents=VGroup(arrow([leftx,.55 if not opposite else 1.2,0],[0,.65 if not opposite else -.65,0],CYAN),
                    arrow([rightx,.55,0],[0,.65,0],CYAN),
                    formula('I_1',[leftx-.55,1.5,0],29,CYAN,width=.8),
                    formula('I_2',[rightx+.55,1.5,0],29,CYAN,width=.8))
    fields=VGroup(b_normal((leftx,-.95,0),True,.2),
                  b_normal((rightx,-.95,0),opposite,.2),
                  formula('B_2',[leftx-.58,-.95,0],26,GOLD,width=.7),
                  formula('B_1',[rightx+.58,-.95,0],26,GOLD,width=.7))
    if opposite:
        # I1=-y, B2=+z => F1=-x; I2=+y, B1=+z => F2=+x.
        forces=VGroup(arrow([leftx,-.1,0],[-.85,0,0],ROSE),
                      arrow([rightx,-.1,0],[.85,0,0],ROSE))
        force_names=VGroup(formula('F_{A1}',[leftx-.42,.3,0],28,ROSE,width=1),
                           formula('F_{A2}',[rightx+.42,.3,0],28,ROSE,width=1))
    else:
        forces=VGroup(arrow([leftx,-.1,0],[.85,0,0],ROSE),
                      arrow([rightx,-.1,0],[-.85,0,0],ROSE))
        force_names=VGroup(formula('F_{A1}',[leftx+.42,.3,0],28,ROSE,width=1),
                           formula('F_{A2}',[rightx-.42,.3,0],28,ROSE,width=1))
    return wires,currents,fields,forces,force_names


def b_particle(sign='+',velocity_right=True):
    c=np.array([-3.1,0,0])
    particle=charge(sign,c,.25)
    field=VGroup(*[b_normal((x,y,0),False,.15) for x in (-5,-1.2) for y in (-1.0,1.0)])
    if velocity_right:
        velocity=arrow(c+[.38,0,0],[1.65,0,0],CYAN)
        v_name=formula(r'\vec v',[-1.7,-.48,0],30,CYAN,width=.9)
    else:
        velocity=arrow(c+[-.38,0,0],[-1.65,0,0],CYAN)
        v_name=formula(r'\vec v',[-4.55,-.48,0],30,CYAN,width=.9)
    force_up=(sign=='+' and velocity_right) or (sign=='−' and not velocity_right)
    force=arrow(c+[0,.33 if force_up else -.33,0],[0,1.3 if force_up else -1.3,0],ROSE)
    force_name=formula(r'\vec F_{\mathrm{л}}',[-2.45,1.6 if force_up else -1.6,0],30,ROSE,width=1)
    return particle,field,velocity,v_name,force,force_name


class LoopFieldAndCompass(MagneticScene):
    chapter_id=6
    def chapter(self):
        self.beat(0)
        toward=b_normal((-4.6,0,0),True,.4)
        away=b_normal((-1.6,0,0),False,.4)
        rings=VGroup(toward[0],away[0])
        given=words(['Вектор перпендикулярен','плоскости рисунка'],[3.1,1.15,0],27)
        self.show(rings,given,run_time=1.2);self.intro(0)
        self.act(0,FadeIn(toward[1]),Create(away[1]))
        self.show(words('К наблюдателю',[-4.6,-1.0,0],22,GOLD,width=2.6),
                  words('От наблюдателя',[-1.6,-1.0,0],22,GOLD,width=2.6),
                  words(['Точка — наконечник стрелы','Крест — её оперение'],[3.1,-.65,0],25,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        loop=Circle(radius=1.3,color=CYAN,stroke_width=3).move_to([-3.1,0,0])
        currents=VGroup(arrow([-3.65,-1.3,0],[1.1,0,0],CYAN),
                        arrow([-2.55,1.3,0],[-1.1,0,0],CYAN),
                        formula('I',[-4.85,0,0],32,CYAN,width=.8))
        field=b_normal((-3.1,0,0),True,.34)
        self.show(loop,currents,words(['Правило правой руки','Четыре пальца — по току'],[3.1,1.1,0],26),run_time=1.2);self.intro(1)
        self.act(1,FadeIn(field))
        self.show(words(['Большой палец — по B на оси','Здесь B направлен к наблюдателю'],[3.1,-.75,0],24,GOLD),
                  words('Вид на виток спереди',[-3.1,-2.1,0],23,MUTED,width=5.4),run_time=1.2);self.result(1)

        self.beat(2)
        # A genuine yz-loop projected by (x,y,z)->(x+.32z,y+.15z).
        # r=(0,cos t,sin t), tangent=(0,-sin t,cos t), r cross tangent=+x.
        project=lambda t:np.array([-4.5+.32*1.25*np.sin(t),1.25*np.cos(t)+.15*1.25*np.sin(t),0])
        coil=ParametricFunction(project,t_range=[0,TAU],color=MUTED,stroke_width=3)
        current=arrow(project(.35),project(.8)-project(.35),CYAN)
        center=np.array([-1.85,0,0])
        case=Circle(radius=.77,color=GRID,stroke_width=2).move_to(center)
        north=Polygon(center+[-.11,0,0],center+[.11,0,0],center+[0,.64,0],color=ROSE,fill_color=ROSE,fill_opacity=1)
        south=Polygon(center+[-.11,0,0],center+[.11,0,0],center+[0,-.64,0],color=CYAN,fill_color=CYAN,fill_opacity=1)
        needle=VGroup(north,south,Dot(center,radius=.05,color=INK))
        state=words('Тока нет',[-4.5,-1.7,0],23,MUTED,width=2)
        switched=words('Ток включён',[-4.5,-1.7,0],23,CYAN,width=2.4)
        axis=DashedLine([-5.15,0,0],[-.7,0,0],color=GRID)
        field=arrow([-4.0,-1.95,0],[2.65,0,0],GOLD)
        self.show(coil,axis,case,needle,state,words(['До включения катушки','Стрелка по полю Земли'],[3.1,1.1,0],25),run_time=1.2);self.intro(2)
        angle=np.arctan2(.12,1.8)-PI/2
        self.act(2,Rotate(needle,angle=angle,about_point=center),coil.animate.set_stroke(CYAN),FadeIn(current),Create(field),Succession(FadeOut(state),FadeIn(switched)))
        self.show(words(['Поле катушки доминирует','Стрелка почти вдоль её оси'],[3.1,-.6,0],25,GOLD),
                  words('Направление задаёт результирующее поле',[0,-2.55,0],22,MUTED,width=11.5),run_time=1.2);self.result(2)


class AmpereForce(MagneticScene):
    chapter_id=7
    def chapter(self):
        self.beat(0)
        wire=Line([-5.5,0,0],[-.9,0,0],color=INK,stroke_width=4)
        current=arrow([-4.9,.55,0],[1.6,0,0],CYAN)
        i=formula('I',[-4.1,1.05,0],32,CYAN,width=.8)
        field=b_field_grid()
        force=arrow([-2.25,.1,0],[0,1.4,0],ROSE)
        f=formula(r'\vec F_A',[-1.3,1.5,0],32,ROSE,width=1)
        self.show(wire,current,i,field,words('B от наблюдателя',[-3.1,-2.05,0],24,GOLD,width=5.4),
                  words(['Сила Ампера','Действие поля на проводник с током'],[3.1,1.35,0],25),run_time=1.2);self.intro(0)
        self.act(0,GrowArrow(force),FadeIn(f))
        self.show(words(['B входит в ладонь левой руки','Пальцы — по условному току I','Большой палец — по силе'],[3.1,-.85,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        wire=Line([-5.3,.2,0],[-.9,.2,0],color=INK,stroke_width=4)
        length=DoubleArrow([-5.3,-.65,0],[-.9,-.65,0],buff=0,color=LAVENDER)
        l=formula('l',[-3.1,-1.13,0],32,LAVENDER,width=.8)
        current=VGroup(arrow([-4.9,.75,0],[1.6,0,0],CYAN),formula('I',[-4.1,1.25,0],31,CYAN,width=.8))
        b=VGroup(b_normal((-1.6,1.15,0),False,.22),formula('B',[-1.6,1.83,0],31,GOLD,width=.8))
        law=formula(r'F_A=BIl\sin\alpha',[3.1,.35,0],45,ROSE)
        self.show(wire,length,l,current,b,words(['Прямой участок длины l','Однородное поле'],[3.1,1.85,0],25),run_time=1.2);self.intro(1)
        self.act(1,Write(law))
        self.show(words(['B — Тл; I — А; l — м','α — угол между током и B'],[3.1,-1.25,0],24,MUTED),
                  words('На схеме ток перпендикулярен B',[-3.1,-2.1,0],22,MUTED,width=5.4),run_time=1.2);self.result(1)

        self.beat(2)
        c=np.array([-3.1,0,0])
        wire=Line(c+DOWN*1.3,c+UP*1.3,color=INK,stroke_width=4)
        current=arrow(c+[-.55,-.8,0],[0,1.6,0],CYAN)
        i=formula('I',[-4.2,.6,0],30,CYAN,width=.8)
        i_end=formula('I',[-3.1,1.05,0],30,CYAN,width=.8)
        b=VGroup(arrow([-5.15,-1.85,0],[4.1,0,0],GOLD),formula('B',[-3.1,-2.28,0],30,GOLD,width=.8))
        force=b_normal(c,False,.25,ROSE)
        force_name=formula('F_A',[-4.45,-.9,0],29,ROSE,width=.9)
        arc=Arc(radius=.85,start_angle=0,angle=PI/2,arc_center=c,color=MUTED)
        alpha=formula(r'\alpha',[-2.25,.9,0],27,MUTED,width=.7)
        max_case=formula(r'\alpha=90^\circ:\quad F_A=BIl',[3.1,-.7,0],34,ROSE)
        self.show(wire,current,i,b,force,force_name,arc,alpha,formula(r'F_A=BIl\sin\alpha',[3.1,1.35,0],42),max_case,run_time=1.2);self.intro(2)
        self.act(2,Rotate(wire,-PI/2,about_point=c),Rotate(current,-PI/2,about_point=c),Transform(i,i_end),FadeOut(force),FadeOut(force_name),FadeOut(arc),FadeOut(alpha))
        self.show(formula(r'\alpha=0^\circ:\quad F_A=0',[3.1,-2.0,0],36,GOLD),run_time=1.2);self.result(2)


class ParallelCurrentForces(MagneticScene):
    chapter_id=8
    def chapter(self):
        for index,opposite in enumerate((False,True)):
            self.beat(index)
            wires,currents,fields,forces,names=b_wire_pair(opposite)
            given=words(['Параллельные проводники','Токи противоположны' if opposite else 'Токи в одном направлении'],[3.1,1.3,0],25)
            self.show(wires,currents,fields,given,words('Показаны поля другого проводника',[-3.1,-2.1,0],22,MUTED,width=5.4),run_time=1.2);self.intro(index)
            self.act(index,LaggedStart(*[GrowArrow(f) for f in forces],lag_ratio=.2),FadeIn(names))
            self.show(words('Проводники отталкиваются' if opposite else 'Проводники притягиваются',[3.1,-.4,0],28,ROSE),
                      words(['B₁ создан первым в точке второго','B₂ создан вторым в точке первого'],[3.1,-1.8,0],22,MUTED),run_time=1.2);self.result(index)

        self.beat(2)
        left=words(['Токи одинакового направления','Силы навстречу','Притяжение'],[-3.1,.25,0],27,CYAN,width=5.5)
        right=words(['Токи противоположного направления','Силы в разные стороны','Отталкивание'],[3.1,.25,0],27,ROSE,width=5.5)
        separator=Line([0,-1.9,0],[0,1.9,0],color=GRID)
        self.show(separator,words('Взаимодействие через магнитное поле',[0,2.15,0],27,width=11.5),run_time=1.2);self.intro(2)
        self.act(2,FadeIn(left),FadeIn(right))
        self.show(words('Каждая сила приложена к своему проводнику',[0,-2.5,0],25,MUTED,width=11.5),run_time=1.2);self.result(2)


class MagneticLorentzForce(MagneticScene):
    chapter_id=9
    def chapter(self):
        for index,sign,rightward in ((0,'+',True),(1,'−',True),(2,'−',False)):
            self.beat(index)
            particle,field,velocity,v_name,force,f_name=b_particle(sign,rightward)
            given=words(['Магнитная сила Лоренца','Положительный заряд' if sign=='+' else 'Отрицательный заряд'],[3.1,1.35,0],25)
            self.show(particle,field,velocity,v_name,given,words('B от наблюдателя',[-3.1,-2.3,0],23,GOLD,width=5.4),run_time=1.2);self.intro(index)
            self.act(index,GrowArrow(force),FadeIn(f_name))
            if index==0:lines=['Пальцы левой руки — по v','Большой палец — по силе']
            elif index==1:lines=['Пальцы — против v','При тех же v и B сила меняет направление']
            else:lines=['Изменены знак q и направление v','Две перемены сохраняют направление силы']
            self.show(words(lines,[3.1,-.7,0],24,MUTED),
                      words('Показаны направления в выбранный момент',[-3.1,2.18,0],20,MUTED,width=5.4),run_time=1.2);self.result(index)

        self.beat(3)
        initial=words(['Модуль магнитной силы','Угол α между v и B'],[-3.1,1.0,0],27)
        law=formula(r'F_{\mathrm{л}}=|q|Bv\sin\alpha',[3.1,1.0,0],44,ROSE)
        note=words('Для модуля берём |q|',[-3.1,-.7,0],27,CYAN)
        self.show(initial,note,run_time=1.2);self.intro(3)
        self.act(3,Write(law))
        self.show(formula(r'\alpha=0^\circ\ \Rightarrow\ F_{\mathrm{л}}=0',[3.1,-.45,0],34),
                  formula(r'\alpha=90^\circ\ \Rightarrow\ F_{\mathrm{л}}=|q|Bv',[3.1,-1.65,0],34,GOLD),
                  words('Сила перпендикулярна скорости и полю',[0,-2.65,0],24,MUTED,width=11.5),run_time=1.2);self.result(3)
