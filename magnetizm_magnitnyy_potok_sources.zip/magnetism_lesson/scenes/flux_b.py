"""Faraday law, inductance, self-induction and field energy: notes pp7–11."""
from magnetic_style import *


def fb_coil(center=(-3.1,0,0),length=2.4,turns=5,vertical=False):
    """Electrical symbol; semicircles do not imply a spatial winding view."""
    x,y,_=center;r=length/(2*turns)
    body=VGroup(*[Arc(radius=r,start_angle=PI,angle=-PI,color=CYAN,stroke_width=3)
                  .shift([x-length/2+r+2*r*i,y,0]) for i in range(turns)])
    leads=VGroup(Line([x-length/2-.4,y,0],[x-length/2,y,0],color=MUTED),
                 Line([x+length/2,y,0],[x+length/2+.4,y,0],color=MUTED))
    whole=VGroup(body,leads)
    if vertical:whole.rotate(PI/2,about_point=np.array(center,dtype=float))
    return whole


def fb_resistor(center=(-2.5,-1.4,0)):
    x,y,_=center
    return VGroup(Rectangle(width=1.2,height=.44,color=INK,stroke_width=2).move_to(center),
                  formula('R',(x,y-.66,0),28,MUTED,width=1))


def fb_circuit(closed=False):
    coil=fb_coil((-1.2,.25,0),length=1.4,turns=4,vertical=True)
    wires=VGroup(*[Line(a,b,color=MUTED,stroke_width=2) for a,b in [
        ([-5.1,1.4,0],[-1.2,1.4,0]),([-1.2,1.4,0],[-1.2,1.35,0]),
        ([-1.2,-.85,0],[-1.2,-1.4,0]),([-1.2,-1.4,0],[-1.9,-1.4,0]),
        ([-3.1,-1.4,0],[-3.8,-1.4,0]),([-4.65,-1.4,0],[-5.1,-1.4,0]),
        ([-5.1,-1.4,0],[-5.1,-.1,0]),([-5.1,.3,0],[-5.1,1.4,0])]])
    source=VGroup(Line([-5.5,.3,0],[-4.7,.3,0],color=ROSE,stroke_width=3),
                  Line([-5.34,-.1,0],[-4.86,-.1,0],color=CYAN,stroke_width=3),
                  formula(r'\varepsilon',[-5.8,.1,0],29,GOLD,width=.5))
    switch_angle=0 if closed else PI/6
    switch_start=np.array([-4.65,-1.4,0])
    switch_end=switch_start+.85*np.array([np.cos(switch_angle),np.sin(switch_angle),0])
    switch=Line(switch_start,switch_end,color=INK,stroke_width=3)
    dots=VGroup(Dot([-4.65,-1.4,0],radius=.045,color=INK),Dot([-3.8,-1.4,0],radius=.045,color=INK))
    labels=VGroup(formula('L',[-.63,.25,0],30,CYAN,width=.5),
                  words('Ключ',[-4.3,-2.1,0],20,MUTED,width=1.5))
    return VGroup(coil,wires,source,fb_resistor(),dots,labels),switch


class FaradayLaw(MagneticScene):
    chapter_id=14
    def chapter(self):
        self.beat(0)
        definition=words(['Меняется магнитный поток','Возникает ЭДС индукции'],[-3.1,1.1,0],27)
        condition=words(['Один виток','Выбраны нормаль и обход'],[-3.1,-.6,0],24,MUTED)
        law=formula(r'\varepsilon_i=-\Phi^{\prime}(t)',[3.1,1.0,0],47,GOLD)
        self.show(definition,condition,run_time=1.2);self.intro(0)
        self.act(0,Write(law))
        self.show(words(['Производная — скорость изменения','Минус соответствует правилу Ленца'],[3.1,-.55,0],23),
                  formula(r'[\varepsilon_i]=\mathrm{V}=\mathrm{Wb/s}',[3.1,-2.1,0],31,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        ax,frame=chart(center=(-3.1,.1,0),width=4.5,height=3.0,x_range=(0,5,1),y_range=(0,4,1),x_label='t',y_label=r'\Phi')
        p1=ax.c2p(.7,3.2);p2=ax.c2p(4.3,1.0)
        line=Line(p1,p2,color=CYAN,stroke_width=3)
        points=VGroup(Dot(p1,radius=.065,color=CYAN),Dot(p2,radius=.065,color=CYAN),
                      formula('1',p1+UP*.35,25,CYAN,width=.5),formula('2',p2+UP*.35,25,CYAN,width=.5))
        law=formula(r'\varepsilon_i=-\frac{\Delta\Phi}{\Delta t}',[3.1,1.15,0],43)
        self.show(frame,words('Постоянный наклон графика',[3.1,2.2,0],23),law,run_time=1.2);self.intro(1)
        self.act(1,Create(line),FadeIn(points))
        self.show(formula(r'\Delta\Phi<0\quad\Rightarrow\quad\varepsilon_i>0',[3.1,-.25,0],32,GOLD),
                  formula(r'|\varepsilon_i|=\frac{|\Delta\Phi|}{\Delta t}=|\Phi^{\prime}(t)|',[3.1,-1.65,0],32),run_time=1.2);self.result(1)

        self.beat(2)
        initial=formula(r'\Phi=BS\cos\omega t',[0,1.65,0],44,CYAN,width=11.5)
        condition=words('B, S и ω постоянны; α = ωt',[0,2.4,0],23,MUTED,width=11.5)
        step1=formula(r'\varepsilon_i=-BS(\cos\omega t)^{\prime}',[0,.35,0],43,width=11.5)
        step2=formula(r'\varepsilon_i=-BS(-\sin\omega t)\omega',[0,-.85,0],43,width=11.5)
        result=formula(r'\varepsilon_i=BS\omega\sin\omega t',[0,-2.1,0],46,GOLD,width=11.5)
        self.show(initial,condition,run_time=1.2);self.intro(2)
        self.act(2,Succession(Write(step1),Write(step2)))
        self.show(result,run_time=1.2);self.result(2)

        self.beat(3)
        ax=axes(x_range=(0,TAU,PI/2),y_range=(-1.25,1.25,.5),width=4.5,height=3.2,center=LEFT*3.1)
        ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
        tags=VGroup(formula(r'\omega t',ax.x_axis.get_end()+RIGHT*.32,25,MUTED,width=.65),
                    formula(r'2\pi',ax.c2p(TAU,0)+DOWN*.38,23,MUTED,width=.7))
        cosine=ax.plot(np.cos,x_range=(0,TAU,.035),color=CYAN,stroke_width=3)
        sine=ax.plot(np.sin,x_range=(0,TAU,.035),color=GOLD,stroke_width=3)
        definitions=VGroup(formula(r'\frac{\Phi}{BS}=\cos\omega t',[3.1,1.2,0],36,CYAN),
                           formula(r'\frac{\varepsilon_i}{BS\omega}=\sin\omega t',[3.1,-.3,0],36,GOLD))
        self.show(ax,tags,definitions,words('Относительные значения',[-3.1,2.1,0],23,MUTED),run_time=1.2);self.intro(3)
        self.act(3,Create(cosine),Create(sine),rate_func=linear)
        self.show(words(['Полный период изменения фазы','ЭДС задаётся наклоном потока'],[3.1,-1.9,0],24,MUTED),run_time=1.2);self.result(3)


class CoilInductance(MagneticScene):
    chapter_id=15
    def chapter(self):
        self.beat(0)
        coil=fb_coil()
        names=words(['Катушка — проводящая обмотка','Её ток создаёт магнитное поле'],[3.1,1.2,0],25)
        current=VGroup(arrow([-5.1,1.25,0],[1.5,0,0],GOLD),formula('I',[-4.35,1.8,0],29,GOLD,width=1))
        relation=formula(r'\Psi\propto I',[3.1,-.25,0],44,CYAN)
        self.show(coil,names,words('Условное обозначение',[-3.1,-1.3,0],23,MUTED),run_time=1.2);self.intro(0)
        self.act(0,FadeIn(current),Write(relation))
        self.show(words(['Собственное потокосцепление','Линейная среда, та же геометрия'],[3.1,-1.85,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        given=words(['Индуктивность L','Постоянный коэффициент связи'],[-3.1,1.0,0],26)
        law=formula(r'\Psi=LI',[3.1,1.0,0],48,CYAN)
        unit=formula(r'1\ \mathrm{H}=1\ \mathrm{Wb/A}',[3.1,-.4,0],34)
        self.show(given,law,words('Ψ — потокосцепление всей катушки',[-3.1,-.7,0],23,MUTED),run_time=1.2);self.intro(1)
        self.act(1,Write(unit))
        self.show(words(['L измеряют в генри','Не путать Ψ с потоком одного витка'],[3.1,-1.9,0],23,GOLD),run_time=1.2);self.result(1)

        self.beat(2)
        given=words(['Длинный соленоид','Линейная однородная среда','Краевые эффекты малы'],[-3.1,1.0,0],25)
        law=formula(r'L=\frac{\mu\mu_0N^2S}{l}',[3.1,1.1,0],46)
        depends=words(['N ↑ или S ↑  ⇒  L ↑','l ↑  ⇒  L ↓','Сердечник влияет через μ'],[3.1,-.8,0],24,GOLD)
        self.show(given,law,words('N — витки; S — сечение; l — длина',[-3.1,-1.45,0],22,MUTED),run_time=1.2);self.intro(2)
        self.act(2,LaggedStart(*[FadeIn(x) for x in depends],lag_ratio=.25))
        self.show(words('Постоянство L требует неизменных условий',[0,-2.45,0],23,MUTED,width=11.5),run_time=1.2);self.result(2)


class SelfInduction(MagneticScene):
    chapter_id=16
    def chapter(self):
        for index,increasing in enumerate((True,False)):
            self.beat(index)
            ax,frame=chart(center=(-3.1,.1,0),width=4.5,height=3.0,x_range=(0,5,1),y_range=(0,4,1),x_label='t',y_label='I')
            line=Line(ax.c2p(.5,1 if increasing else 3),ax.c2p(4.5,3 if increasing else 1),color=CYAN,stroke_width=3)
            equation=formula(r'\varepsilon_c=-\Psi^{\prime}(t)=-LI^{\prime}(t)',[3.1,1.35,0],34,GOLD)
            sign=formula(r'I^{\prime}>0\Rightarrow\varepsilon_c<0' if increasing else r'I^{\prime}<0\Rightarrow\varepsilon_c>0',[3.1,-.1,0],35)
            self.show(frame,equation,words('L постоянно; выбран положительный ток',[0,-2.45,0],22,MUTED,width=11.5),run_time=1.2);self.intro(index)
            self.act(index,Create(line),Write(sign))
            if increasing:
                result=formula(r'\varepsilon_c=-L\frac{\Delta I}{\Delta t}',[3.1,-1.6,0],36,CYAN)
            else:
                result=VGroup(formula(r'|\varepsilon_c|=L|I^{\prime}(t)|=L\frac{|\Delta I|}{\Delta t}',[3.1,-1.45,0],30,CYAN),
                              words('Дробь — при равномерном изменении',[3.1,-2.1,0],20,MUTED))
            self.show(result,run_time=1.2);self.result(index)

        self.beat(2)
        causes=VGroup(words(['Внешний магнит','Меняется внешний поток'],[-3.3,1.25,0],25),
                      words(['Реостат: R ↑, ток I ↓','Меняется собственное Ψ'],[-3.3,-.8,0],25))
        arrows=VGroup(arrow([-.4,1.25,0],[1.0,0,0],GOLD),arrow([-.4,-.8,0],[1.0,0,0],GOLD))
        outcomes=VGroup(words('Внешняя индукция',[3.4,1.25,0],27,CYAN),words('Самоиндукция',[3.4,-.8,0],27,CYAN))
        self.show(causes,run_time=1.2);self.intro(2)
        self.act(2,Create(arrows),FadeIn(outcomes))
        self.show(words('Оба случая подчиняются одному закону Фарадея',[0,-2.4,0],24,MUTED,width=11.5),run_time=1.2);self.result(2)


class MultipleTurns(MagneticScene):
    chapter_id=17
    def chapter(self):
        self.beat(0)
        turns=VGroup(*[Ellipse(width=2.9,height=.55,color=CYAN,stroke_width=2).move_to([-3.5,y,0]) for y in [-.9,-.45,0,.45,.9]])
        field=arrow([-.95,-1.45,0],[0,2.9,0],GOLD)
        tags=VGroup(formula('N',[-5.45,0,0],35,CYAN,width=.7),formula('B',[-.95,1.95,0],30,GOLD,width=.6),
                    words('Одинаково пронизанные витки',[-3.3,-1.9,0],22,MUTED,width=5.5))
        initial=formula(r'\Phi_0=BS\cos\alpha',[3.1,1.2,0],40)
        total=formula(r'\Psi=N\Phi_0',[3.1,-.35,0],48,GOLD)
        self.show(turns,field,tags,initial,run_time=1.2);self.intro(0)
        self.act(0,Write(total))
        self.show(words('Ψ — сумма потоков через витки',[3.1,-1.85,0],24,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        initial=formula(r'\Psi=NBS\cos\omega t',[0,1.75,0],43,CYAN,width=11.5)
        condition=words('N, B, S, ω постоянны; α = ωt',[0,2.45,0],22,MUTED,width=11.5)
        middle1=formula(r'\varepsilon_i=-NBS(\cos\omega t)^{\prime}',[0,.45,0],42,width=11.5)
        middle2=formula(r'\varepsilon_i=-NBS(-\sin\omega t)\omega',[0,-.8,0],42,width=11.5)
        result=formula(r'\varepsilon_i=NBS\omega\sin\omega t',[0,-2.1,0],45,GOLD,width=11.5)
        self.show(initial,condition,run_time=1.2);self.intro(1)
        self.act(1,Succession(Write(middle1),Write(middle2)))
        self.show(result,run_time=1.2);self.result(1)

        self.beat(2)
        labels=VGroup(words('Поток одного витка',[-3.1,1.55,0],25),words('Потокосцепление катушки',[3.1,1.55,0],25))
        one=formula(r'\Phi_0',[-3.1,.35,0],51,CYAN)
        all_turns=formula(r'\Psi=N\Phi_0',[3.1,.35,0],44,GOLD)
        relation=formula(r'\varepsilon_i=-\Psi^{\prime}(t)',[0,-1.25,0],47,width=11.5)
        self.show(labels,one,all_turns,run_time=1.2);self.intro(2)
        self.act(2,Write(relation))
        self.show(words('Число витков уже учтено в Ψ',[0,-2.5,0],26,MUTED,width=11.5),run_time=1.2);self.result(2)


class CurrentSwitchOn(MagneticScene):
    chapter_id=18
    def chapter(self):
        self.beat(0)
        circuit,switch=fb_circuit(closed=False)
        current=VGroup(arrow([-3.9,1.85,0],[1.6,0,0],GOLD),formula('I',[-3.1,2.3,0],28,GOLD,width=.6))
        initial=words(['Начально катушка обесточена','I(0) = 0'],[3.1,1.2,0],25)
        start=formula(r'I(0^+)=0',[3.1,-.15,0],44)
        self.show(circuit,switch,initial,run_time=1.2);self.intro(0)
        self.act(0,Succession(Rotate(switch,angle=-PI/6,about_point=np.array([-4.65,-1.4,0]),run_time=.6),FadeIn(current,run_time=4.4)))
        self.show(start,words(['После замыкания ток растёт сразу','Без скачка и без мёртвой паузы'],[3.1,-1.65,0],23,GOLD),run_time=1.2);self.result(0)

        self.beat(1)
        ax,frame=chart(center=(-3.1,.1,0),width=4.4,height=3.0,x_range=(0,5,1),y_range=(0,3.3,1),x_label='t',y_label='I')
        graph=ax.plot(lambda x:2.7*(1-np.exp(-x)),x_range=(0,4.7,.03),color=CYAN,stroke_width=3)
        limit=DashedLine(ax.c2p(0,2.7),ax.c2p(4.8,2.7),color=MUTED)
        mark=formula(r'I_{\infty}',ax.c2p(0,2.7)+LEFT*.4,24,MUTED,width=.65)
        balance=formula(r'\varepsilon+\varepsilon_c=IR_\Sigma',[3.1,1.35,0],35)
        self.show(frame,limit,mark,balance,words('Условная шкала времени',[-3.1,-2.15,0],22,MUTED),run_time=1.2);self.intro(1)
        self.act(1,Create(graph),rate_func=linear)
        self.show(formula(r'\varepsilon_c=-LI^{\prime}(t)',[3.1,-.1,0],39,GOLD),
                  words(['Модуль противо-ЭДС уменьшается','Ток приближается к установившемуся'],[3.1,-1.65,0],22,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        circuit,switch=fb_circuit(closed=True)
        initial=words(['Установившийся режим','dI/dt = 0'],[3.1,1.65,0],26)
        law=formula(r'\varepsilon_c=0,\qquad I_\infty=\frac{\varepsilon}{R_\Sigma}',[3.1,.05,0],36,CYAN)
        self.show(circuit,switch,initial,run_time=1.2);self.intro(2)
        self.act(2,Write(law))
        self.show(words(['RΣ учитывает все омические сопротивления','Включая провод обмотки и источник'],[3.1,-1.75,0],21,MUTED),run_time=1.2);self.result(2)


class MagneticEnergy(MagneticScene):
    chapter_id=19
    def chapter(self):
        self.beat(0)
        coil=fb_coil()
        current=VGroup(arrow([-5.2,1.3,0],[1.6,0,0],GOLD),formula('I',[-4.4,1.85,0],30,GOLD,width=.7))
        law=formula(r'W_L=\frac{LI^2}{2}',[3.1,.8,0],53,CYAN)
        self.show(coil,current,words(['Энергия магнитного поля','Линейная катушка; L постоянно'],[3.1,2.1,0],25),run_time=1.2);self.intro(0)
        self.act(0,Write(law))
        self.show(formula(r'[W_L]=\mathrm{J}',[3.1,-.85,0],39),words('Энергия поля, не запас электрического заряда',[0,-2.3,0],24,MUTED,width=11.5),run_time=1.2);self.result(0)

        self.beat(1)
        ax,frame=chart(center=(-3.1,.05,0),width=4.5,height=3.0,x_range=(0,4.5,1),y_range=(0,4,1),x_label='I',y_label=r'W_L')
        graph=ax.plot(lambda x:.22*x*x,x_range=(0,4.0,.03),color=CYAN,stroke_width=3)
        given=formula(r'W_L=\frac L2I^2',[3.1,1.25,0],48)
        self.show(frame,given,words('Одна катушка: L постоянно',[3.1,-.15,0],24,MUTED),run_time=1.2);self.intro(1)
        self.act(1,Create(graph))
        self.show(words(['Энергия пропорциональна I²','При I = 0 собственная энергия равна 0'],[3.1,-1.65,0],23,CYAN),run_time=1.2);self.result(1)

        self.beat(2)
        base=Line([-5.4,-1.4,0],[-.8,-1.4,0],color=MUTED)
        labels=VGroup(formula('L_1',[-4.25,-1.95,0],31,CYAN,width=1),formula('L_2',[-1.95,-1.95,0],31,GOLD,width=1))
        bar1=Rectangle(width=.85,height=1.0,color=CYAN,fill_color=CYAN,fill_opacity=.3).move_to([-4.25,-.9,0])
        bar2=Rectangle(width=.85,height=2.0,color=GOLD,fill_color=GOLD,fill_opacity=.3).move_to([-1.95,-.4,0])
        tags=VGroup(formula('W_1',[-4.25,-.05,0],30,CYAN,width=1),formula('W_2',[-1.95,1.05,0],30,GOLD,width=1))
        condition=formula(r'I=\mathrm{const},\quad L_2>L_1',[3.1,1.25,0],35)
        conclusion=formula(r'W_2>W_1',[3.1,-.2,0],47,GOLD)
        self.show(base,labels,condition,words('Сравнение двух линейных катушек',[-3.1,2.15,0],23,MUTED),run_time=1.2);self.intro(2)
        self.act(2,GrowFromEdge(bar1,DOWN),GrowFromEdge(bar2,DOWN),FadeIn(tags),Write(conclusion))
        self.show(words(['Ток сравниваем при одном значении','Энергия зависит также от L'],[3.1,-1.7,0],24,MUTED),run_time=1.2);self.result(2)
