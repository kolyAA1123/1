"""Flux geometry and Lenz examples: supplied flux notes pp1–7 (upper)."""
from magnetic_style import *


def fa_basis(alpha=0, sign=1):
    return np.array([np.cos(alpha), -sign*np.sin(alpha), 0]), np.array([.25, sign*.35, 0]), np.array([np.sin(alpha), sign*np.cos(alpha), 0])


def fa_loop(alpha=0, sign=1, center=(-3.1,.35,0), radius=1.25, color=INK):
    u,v,n=fa_basis(alpha,sign);center=np.array(center,dtype=float)
    return ParametricFunction(lambda t:center+radius*(np.cos(t)*u+np.sin(t)*v),t_range=[0,TAU],color=color,stroke_width=2.5)


def fa_normal(alpha=0, sign=1, center=(-3.1,.35,0)):
    u,v,n=fa_basis(alpha,sign);c=np.array(center,dtype=float);base=c+u*.45
    return VGroup(arrow(base,n*1.55,LAVENDER),formula(r'\vec n',base+n*1.65+u*.35,29,LAVENDER,width=.65))


def fa_induced(alpha=0, sign=1, along=1, center=(-3.1,.35,0)):
    u,v,n=fa_basis(alpha,sign);c=np.array(center,dtype=float)
    tip=c+n*along*1.3
    label=c+n*along*1.5-u*.6
    return VGroup(arrow(c,n*along*1.3,ROSE),formula(r'\vec B_i',label,28,ROSE,width=.85))


def fa_turn_loop(loop,start,end,sign=1,run_time=1):
    # Rebuild the projected circle from its actual angle. Interpolating endpoint
    # curves instead would contract the generating unit vector mid-turn.
    return UpdateFromAlphaFunc(loop,lambda mob,a:mob.become(fa_loop(interpolate(start,end,a),sign=sign)),run_time=run_time)


def fa_turn_normal(normal,start,end,sign=1,run_time=1):
    def update(mob,a):
        u,v,n=fa_basis(interpolate(start,end,a),sign)
        base=np.array([-3.1,.35,0])+u*.45
        mob[0].become(arrow(base,n*1.55,LAVENDER))
        mob[1].move_to(base+n*1.65+u*.35)
    return UpdateFromAlphaFunc(normal,update,run_time=run_time)


def fa_turn_induced(induced,start,end,sign=1,along=1,fade_in=False,run_time=1):
    def update(mob,a):
        u,v,n=fa_basis(interpolate(start,end,a),sign)
        center=np.array([-3.1,.35,0])
        mob[0].become(arrow(center,n*along*1.3,ROSE))
        mob[1].move_to(center+n*along*1.5-u*.6)
        if fade_in:mob.set_opacity(a)
    return UpdateFromAlphaFunc(induced,update,run_time=run_time)


def fa_field(sign=1):
    if sign<0:
        result=VGroup(*[arrow([x,1.7,0],[0,-2.2,0],CYAN) for x in (-5.35,-4.65)])
        result.add(formula(r'\vec B',[-5.15,2.05,0],30,CYAN,width=.75))
        return result
    result=VGroup(*[arrow([x,-.8*sign,0],[0,2.35*sign,0],CYAN) for x in (-5.35,-4.65)])
    result.add(formula(r'\vec B',[-5.15,2.0*sign,0],30,CYAN,width=.75))
    return result


def fa_face_current(center=(-3.1,-2,0),positive=True,radius=.38,label=True):
    c=np.array(center,dtype=float)
    ring=Circle(radius=radius,color=ROSE,stroke_width=2).move_to(c)
    # Positive means counterclockwise when viewed from the chosen +normal.
    turn=1 if positive else -1
    top=arrow(c+np.array([turn*.6*radius,.8*radius,0]),[-turn*1.2*radius,0,0],ROSE,width=2)
    bottom=arrow(c+np.array([-turn*.6*radius,-.8*radius,0]),[turn*1.2*radius,0,0],ROSE,width=2)
    result=VGroup(ring,top,bottom)
    if label:result.add(formula('I_i',c+RIGHT*.85,25,ROSE,width=.6))
    return result


def fa_face_note(text='Ток во время изменения Φ',view='Вид со стороны +n'):
    return words([text,view],(-3.1,-1.15,0),17,MUTED,width=5.4)


def fa_magnet(center=(-3.1,1.35,0)):
    x,y,_=center
    return VGroup(Rectangle(width=.62,height=.6,color=CYAN,fill_color=CYAN,fill_opacity=.2).move_to([x,y+.3,0]),
                  Rectangle(width=.62,height=.6,color=ROSE,fill_color=ROSE,fill_opacity=.2).move_to([x,y-.3,0]),
                  formula('S',[x,y+.3,0],26,CYAN,width=.5),formula('N',[x,y-.3,0],26,ROSE,width=.5))


def fa_magnet_ring():
    return Ellipse(width=3.2,height=.75,color=INK,stroke_width=2.5).move_to([-3.1,-1.0,0])


def fa_magnet_current(clockwise=True):
    # View is explicitly from above, on the magnet side.
    back=arrow([-3.65,-.625,0],[1.1,0,0] if clockwise else [-1.1,0,0],ROSE,width=2.5)
    if not clockwise:back=arrow([-2.55,-.625,0],[-1.1,0,0],ROSE,width=2.5)
    front=arrow([-2.55,-1.375,0],[-1.1,0,0] if clockwise else [1.1,0,0],ROSE,width=2.5)
    if not clockwise:front=arrow([-3.65,-1.375,0],[1.1,0,0],ROSE,width=2.5)
    return VGroup(back,front,formula('I_i',[-1.0,-1.0,0],29,ROSE,width=.65))


class MagneticFluxGeometry(MagneticScene):
    chapter_id=10
    def chapter(self):
        self.beat(0)
        loop=fa_loop(center=(-3.1,-.15,0),radius=1.3)
        normal=VGroup(arrow([-3.1,-.15,0],[0,1.75,0],LAVENDER),formula(r'\vec n',[-3.5,1.95,0],29,LAVENDER,width=.6))
        beta=35*DEGREES
        field=VGroup(arrow([-3.1,-.15,0],[1.75*np.sin(beta),1.75*np.cos(beta),0],CYAN),formula(r'\vec B',[-1.55,1.55,0],30,CYAN,width=.75))
        angle=Arc(radius=.7,start_angle=PI/2-beta,angle=beta,color=GOLD).shift([-3.1,-.15,0])
        perpendicular=RightAngle(Line([-3.1,-.15,0],[-2.4,-.15,0]),Line([-3.1,-.15,0],[-3.1,.55,0]),length=.18,color=MUTED)
        alpha=formula(r'\alpha',[-2.77,.8,0],28,GOLD,width=.6)
        law=formula(r'\Phi=BS\cos\alpha',[3.1,.3,0],46,GOLD)
        self.show(loop,normal,field,angle,perpendicular,alpha,words(['Плоская рамка площади S','Однородное магнитное поле'],[3.1,1.65,0],25),words('α — угол между B и нормалью',[-3.1,-1.65,0],23,MUTED,width=5.4),run_time=1.2)
        self.intro(0)
        self.act(0,Write(law))
        self.show(formula(r'[\Phi]=\mathrm{Wb},\quad1\ \mathrm{Wb}=1\ \mathrm T\cdot\mathrm{m^2}',[3.1,-1.2,0],31),words('Нормаль перпендикулярна плоскости',[3.1,-2.2,0],22,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        loop=fa_loop(center=(-3.1,-.15,0),radius=1.3)
        field=VGroup(arrow([-5,-1,0],[0,2.35,0],CYAN),formula(r'\vec B',[-5,1.85,0],29,CYAN,width=.6))
        normal=VGroup(arrow([-3.1,-.15,0],[0,1.75,0],LAVENDER),formula(r'\vec n',[-2.65,1.85,0],29,LAVENDER,width=.6))
        self.show(loop,field,normal,formula(r'\alpha=0^\circ',[3.1,1.15,0],43),words('B перпендикулярен плоскости',[-3.1,-1.7,0],23,MUTED,width=5.4),run_time=1.2)
        self.intro(1)
        self.act(1,Write(formula(r'\Phi=BS\cos0^\circ=BS',[3.1,-.2,0],43,GOLD)))
        self.show(words('Максимальный положительный поток',[3.1,-1.7,0],24,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        loop=fa_loop(center=(-3.1,-.15,0),radius=1.3)
        field=VGroup(arrow([-5.25,-.15,0],[4.25,0,0],CYAN),formula(r'\vec B',[-1.1,.45,0],29,CYAN,width=.6))
        normal=VGroup(arrow([-3.1,-.15,0],[0,1.75,0],LAVENDER),formula(r'\vec n',[-2.7,1.85,0],29,LAVENDER,width=.6))
        angle=Arc(radius=.6,start_angle=0,angle=PI/2,color=GOLD).shift([-3.1,-.15,0])
        self.show(loop,field,normal,angle,formula(r'\alpha=90^\circ',[3.1,1.15,0],43),words('B направлен вдоль плоскости',[-3.1,-1.7,0],23,MUTED,width=5.4),run_time=1.2)
        self.intro(2)
        self.act(2,Write(formula(r'\Phi=BS\cos90^\circ=0',[3.1,-.2,0],42,GOLD)))
        self.show(words('Через выбранную поверхность поток нулевой',[3.1,-1.7,0],23,MUTED),run_time=1.2)
        self.result(2)

        self.beat(3)
        centers=[[-4.9,.25,0],[-3.1,.25,0],[-1.3,.25,0]]
        boxes=VGroup(*[Rectangle(width=1.4,height=1.05,color=GRID).move_to(c) for c in centers])
        symbols=VGroup(*[formula(s,c,40,color,width=1) for s,c,color in zip(('B','S',r'\alpha'),centers,(CYAN,GOLD,LAVENDER))])
        names=VGroup(*[words(s,[c[0],-.8,0],20,MUTED,width=1.6) for s,c in zip(('Поле','Площадь','Поворот'),centers)])
        changes=VGroup(*[words('Меняем',[c[0],1.4,0],22,color,width=1.6) for c,color in zip(centers,(CYAN,GOLD,LAVENDER))])
        self.show(boxes,symbols,names,formula(r'\Phi=BS\cos\alpha',[3.1,.85,0],45),words('Три способа изменить магнитный поток',[3.1,-.5,0],25),run_time=1.2)
        self.intro(3)
        self.act(3,LaggedStart(*[FadeIn(m) for m in changes],lag_ratio=.25))
        self.show(words('При сравнении фиксируем остальные величины',[0,-2.1,0],24,MUTED,width=11.5),run_time=1.2)
        self.result(3)


class LenzMovingMagnet(MagneticScene):
    chapter_id=11
    def chapter(self):
        self.beat(0)
        loop=fa_magnet_ring()
        field=VGroup(*[arrow([x,1.2,0],[0,-2.8,0],CYAN) for x in (-4.1,-3.1,-2.1)],formula(r'\vec B',[-4.8,.5,0],29,CYAN,width=.7))
        rule=words(['Поле индукционного тока','противодействует изменению','внешнего магнитного потока'],[3.1,.2,0],27,GOLD)
        self.show(loop,field,words('Замкнутый проводящий контур',[3.1,1.9,0],25),run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(rule))
        self.show(words('Направление определяем правилом правой руки',[0,-2.5,0],24,MUTED,width=11.5),run_time=1.2)
        self.result(0)

        for index,withdraw in ((1,True),(2,False)):
            self.beat(index)
            magnet=fa_magnet(center=(-3.1,1.25 if withdraw else 1.95,0))
            loop=fa_magnet_ring()
            field=VGroup(arrow([-3.1,.45,0],[0,-1.95,0],CYAN),formula(r'\vec B',[-3.7,-.05,0],29,CYAN,width=.65))
            flow=fa_magnet_current(clockwise=withdraw)
            bi=VGroup(arrow([-4.55,-.25 if withdraw else -1.65,0],[0,-1.35 if withdraw else 1.35,0],ROSE),formula(r'\vec B_i',[-5.15,-.9,0],29,ROSE,width=.7))
            title='Удаление магнита' if withdraw else 'Приближение магнита'
            self.show(magnet,loop,field,words(title,[3.1,1.75,0],28),words('Смотрим сверху, со стороны магнита',[-3.1,-2.25,0],21,MUTED,width=5.4),run_time=1.2)
            self.intro(index)
            moving=AnimationGroup(magnet.animate.shift(UP*.6 if withdraw else DOWN*.6),FadeIn(flow,run_time=.6),FadeIn(bi,run_time=.6),run_time=4)
            settling=AnimationGroup(FadeOut(flow),FadeOut(bi),run_time=1)
            self.act(index,Succession(moving,settling))
            during=['Во время удаления: |Φ| уменьшается','Bᵢ вниз; ток по часовой стрелке'] if withdraw else ['Во время приближения: |Φ| растёт','Bᵢ вверх; ток против часовой стрелки']
            self.show(words(during,[3.1,.1,0],23,ROSE),words(['После остановки изменение Φ прекращается','Постоянный индукционный ток не поддерживается'],[3.1,-1.65,0],21,MUTED),run_time=1.2)
            self.result(index)


class RotatingFluxDecrease(MagneticScene):
    chapter_id=12
    def chapter(self):
        target=50*DEGREES
        self.beat(0)
        loop=fa_loop();normal=fa_normal();field=fa_field()
        self.show(loop,normal,field,formula(r'\alpha_1=0,\quad\Phi_1=BS',[3.1,1.1,0],38),words('B и площадь S постоянны',[3.1,-.25,0],25),run_time=1.2)
        self.intro(0)
        self.act(0,fa_turn_loop(loop,0,target),fa_turn_normal(normal,0,target))
        self.show(formula(r'\Phi_2=BS\cos\alpha<\Phi_1',[3.1,-1.35,0],40,GOLD),words('Поворот от нормали, совпадавшей с B',[-3.1,-2.25,0],21,MUTED,width=5.4),run_time=1.2)
        self.result(0)

        self.beat(1)
        loop=fa_loop(target);normal=fa_normal(target);field=fa_field();bi=fa_induced(target)
        current=fa_face_current(positive=True)
        self.show(loop,normal,field,fa_face_note('Направления во время поворота'),words(['Внешний положительный поток убывает','Собственный поток поддерживает его'],[3.1,1.15,0],24),run_time=1.2)
        self.intro(1)
        self.act(1,FadeIn(bi),FadeIn(current))
        self.show(words(['Bᵢ направлено вдоль +n','Ток против часовой стрелки','при взгляде со стороны +n'],[3.1,-.85,0],24,ROSE),run_time=1.2)
        self.result(1)

        self.beat(2)
        start=35*DEGREES
        loop=fa_loop(start);normal=fa_normal(start);field=fa_field();bi=fa_induced(start);current=fa_face_current(positive=True)
        note=fa_face_note('Последний участок поворота')
        self.show(loop,normal,field,bi,current,note,words('Рамка завершает поворот',[3.1,1.4,0],27),run_time=1.2)
        self.intro(2)
        moving=AnimationGroup(fa_turn_loop(loop,start,target),fa_turn_normal(normal,start,target),fa_turn_induced(bi,start,target),run_time=4)
        settling=AnimationGroup(FadeOut(bi),FadeOut(current),FadeOut(note),run_time=1)
        self.act(2,Succession(moving,settling))
        self.show(words(['После остановки: B, S и α постоянны','Внешний поток больше не меняется','Индукционный ток затухает'],[3.1,-.35,0],25,GOLD),run_time=1.2)
        self.result(2)


class AreaAndAngleFluxGrowth(MagneticScene):
    chapter_id=13
    def chapter(self):
        self.beat(0)
        loop=fa_loop(sign=-1,radius=1.0)
        field=VGroup(*[arrow([x,1.8,0],[0,-2.3,0],CYAN) for x in (-4.1,-2.1)],formula(r'\vec B',[-5,1.4,0],29,CYAN,width=.7))
        initial=formula('S_1',[-3.1,-.6,0],30,GOLD,width=1)
        final=formula('S_2>S_1',[-3.1,-.6,0],30,GOLD,width=2.4)
        current=fa_face_current(positive=False)
        bi=VGroup(arrow([-3.1,.35,0],[0,1.3,0],ROSE),formula(r'\vec B_i',[-2.65,1.95,0],29,ROSE,width=.7))
        normal=VGroup(arrow([-1.1,.7,0],[0,-1.0,0],LAVENDER),formula(r'\vec n',[-.65,.8,0],25,LAVENDER,width=.55))
        note=fa_face_note('Направления во время роста S','Вид со стороны +n, снизу')
        self.show(loop,field,normal,initial,formula(r'\Phi=BS',[3.1,1.0,0],46),words('B постоянно; поле перпендикулярно рамке',[3.1,-.35,0],23),run_time=1.2)
        self.intro(0)
        moving=AnimationGroup(Transform(loop,fa_loop(sign=-1,radius=1.4),run_time=4),FadeIn(current,run_time=.5),FadeIn(bi,run_time=.5),FadeIn(note,run_time=.5),run_time=4)
        settling=AnimationGroup(FadeOut(current),FadeOut(bi),FadeOut(note),Succession(FadeOut(initial,run_time=.4),FadeIn(final,run_time=.4)),run_time=1)
        self.act(0,Succession(moving,settling))
        self.show(words(['При росте S поток увеличивался','Bᵢ было вверх, вдоль −n','Ток был по часовой со стороны +n'],[3.1,-1.5,0],23,ROSE),words('После остановки рост Φ прекращается',[-3.1,-2.3,0],21,MUTED,width=5.4),run_time=1.2)
        self.result(0)

        self.beat(1)
        target=35*DEGREES
        loop=fa_loop(PI/2,sign=-1);normal=fa_normal(PI/2,sign=-1);field=fa_field(sign=-1)
        self.show(loop,normal,field,formula(r'\alpha_1=90^\circ,\quad\Phi_1=0',[3.1,1.25,0],39),words('B и S постоянны',[3.1,-.1,0],26),run_time=1.2)
        self.intro(1)
        current=fa_face_current(positive=False);bi=fa_induced(PI/2,sign=-1,along=-1).set_opacity(0)
        note=fa_face_note('Направления во время поворота')
        moving=AnimationGroup(fa_turn_loop(loop,PI/2,target,sign=-1,run_time=4),fa_turn_normal(normal,PI/2,target,sign=-1,run_time=4),fa_turn_induced(bi,PI/2,target,sign=-1,along=-1,fade_in=True,run_time=4),FadeIn(current,run_time=.5),FadeIn(note,run_time=.5),run_time=4)
        settling=AnimationGroup(FadeOut(current),FadeOut(bi),FadeOut(note),run_time=1)
        self.act(1,Succession(moving,settling))
        self.show(words(['α ↓  ⇒  cos α ↑  ⇒  Φ ↑','Во время поворота Bᵢ было вдоль −n','Ток был по часовой со стороны +n'],[3.1,-1.5,0],23,ROSE),run_time=1.2)
        self.result(1)

        self.beat(2)
        titles=VGroup(words('Внешний поток растёт',[-3.1,1.85,0],27),words('Внешний поток уменьшается',[3.1,1.85,0],27))
        changes=VGroup(formula(r'\Delta\Phi>0',[-3.1,.95,0],38,CYAN),formula(r'\Delta\Phi<0',[3.1,.95,0],38,CYAN))
        left=fa_face_current(center=(-3.1,-.35,0),positive=False,radius=.65,label=False)
        right=fa_face_current(center=(3.1,-.35,0),positive=True,radius=.65,label=False)
        self.show(titles,changes,words('Смотрим со стороны выбранной нормали +n',[0,-2.6,0],24,MUTED,width=11.5),run_time=1.2)
        self.intro(2)
        self.act(2,FadeIn(left),FadeIn(right))
        self.show(formula(r'\Phi_i<0',[-3.1,-1.65,0],39,ROSE),formula(r'\Phi_i>0',[3.1,-1.65,0],39,ROSE),words('Направления относятся ко времени изменения внешнего потока',[0,2.45,0],20,MUTED,width=11.5),run_time=1.2)
        self.result(2)
