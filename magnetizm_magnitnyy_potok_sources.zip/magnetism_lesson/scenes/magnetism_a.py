"""Source-based field, poles, compass, filings, superposition and Oersted scenes."""
from magnetic_style import *


def a_bar(center=(-3.1,0,0),width=2.8,height=.7,n_right=True,labels=True):
    x,y,_=center
    left_color,right_color=(CYAN,ROSE) if n_right else (ROSE,CYAN)
    parts=VGroup(Rectangle(width=width/2,height=height,color=left_color,fill_color=left_color,fill_opacity=.18).move_to([x-width/4,y,0]),
                 Rectangle(width=width/2,height=height,color=right_color,fill_color=right_color,fill_opacity=.18).move_to([x+width/4,y,0]))
    names=VGroup(formula('S' if n_right else 'N',[x-width/4,y,0],28,left_color,width=.6),
                 formula('N' if n_right else 'S',[x+width/4,y,0],28,right_color,width=.6))
    return VGroup(parts,names) if labels else parts


def a_needle(center=(-3.1,0,0),radius=.8,angle=0):
    c=np.array(center,dtype=float)
    case=Circle(radius=radius,color=GRID,stroke_width=2).move_to(c)
    north=Polygon(c+[-.11,0,0],c+[.11,0,0],c+[0,radius*.78,0],color=ROSE,fill_color=ROSE,fill_opacity=1)
    south=Polygon(c+[-.11,0,0],c+[.11,0,0],c+[0,-radius*.78,0],color=CYAN,fill_color=CYAN,fill_opacity=1)
    needle=VGroup(north,south,Dot(c,radius=.045,color=INK)).rotate(angle,about_point=c)
    return case,needle


def a_normal(center=(-3.1,0,0),toward=True,radius=.25):
    c=np.array(center,dtype=float)
    ring=Circle(radius=radius,color=CYAN,stroke_width=2).move_to(c)
    if toward:mark=Dot(c,radius=.055,color=CYAN)
    else:
        d=radius*.55
        mark=VGroup(Line(c+[-d,-d,0],c+[d,d,0],color=CYAN,stroke_width=2),
                    Line(c+[-d,d,0],c+[d,-d,0],color=CYAN,stroke_width=2))
    return ring,mark


def a_ring_arrows(center=(-3.1,0,0),radii=(.85,1.4,1.95),ccw=True):
    c=np.array(center,dtype=float);heads=VGroup()
    for r in radii:
        start=c+np.array([.20,r,0]) if ccw else c+np.array([-.20,r,0])
        heads.add(arrow(start,[-.40 if ccw else .40,0,0],GOLD,width=2))
    return heads


def a_filings(points):
    result=VGroup()
    for i,(x,y) in enumerate(points):
        theta=(i*1.731+.37)%PI
        v=np.array([np.cos(theta),np.sin(theta),0])*.13
        result.add(Line(np.array([x,y,0])-v,np.array([x,y,0])+v,color=INK,stroke_width=1.8))
    return result


def a_orient(stroke,direction):
    target=np.arctan2(direction[1],direction[0]);delta=(target-stroke.get_angle()+PI/2)%PI-PI/2
    return Rotate(stroke,delta,about_point=stroke.get_center())


class MagneticPolesAndLines(MagneticScene):
    chapter_id=1
    def chapter(self):
        self.beat(0)
        body=a_bar(labels=False)
        names=VGroup(formula('S',[-3.8,0,0],34,CYAN,width=.8),formula('N',[-2.4,0,0],34,ROSE,width=.8))
        self.show(body,words(['Рассматриваемые источники поля','Постоянный магнит','Проводник с током','Движущийся заряд'],[3.1,.7,0],25),
                  words('Постоянный магнит',[-3.1,1.25,0],26),run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(names))
        self.show(words(['N — северный полюс','S — южный полюс'],[-3.1,-1.35,0],25,MUTED),
                  words('Магнитное поле взаимодействует с этими объектами',[0,-2.45,0],23,MUTED,width=11.8),run_time=1.2)
        self.result(0)

        self.beat(1)
        magnets=VGroup(a_bar((-4.45,1.0,0),1.65,.55),a_bar((-1.75,1.0,0),1.65,.55),
                       a_bar((-4.45,-1.1,0),1.65,.55),a_bar((-1.75,-1.1,0),1.65,.55,n_right=False))
        forces=VGroup(arrow([-4.45,1.8,0],[.75,0,0],GOLD),arrow([-1.75,1.8,0],[-.75,0,0],GOLD),
                       arrow([-4.45,-.3,0],[-.75,0,0],GOLD),arrow([-1.75,-.3,0],[.75,0,0],GOLD))
        self.show(magnets,words(['Взаимодействие полюсов','Сравниваем обращённые полюса'],[3.1,1.55,0],25),run_time=1.2)
        self.intro(1)
        self.act(1,LaggedStart(*[GrowArrow(f) for f in forces],lag_ratio=.16))
        self.show(words('Разноимённые — притяжение',[3.1,.0,0],25,GOLD),
                  words('Одноимённые — отталкивание',[3.1,-1.2,0],25,GOLD),
                  words('Стрелки показывают направления сил',[-3.1,-2.3,0],22,MUTED,width=5.5),run_time=1.2)
        self.result(1)

        self.beat(2)
        body=a_bar(width=3.0,height=.8,labels=False)
        pole_names=VGroup(formula('S',[-3.85,-.85,0],31,CYAN,width=.7),formula('N',[-2.35,-.85,0],31,ROSE,width=.7))
        p0=np.array([-1.6,0,0]);p3=np.array([-4.6,0,0])
        outer=CubicBezier(p0,[-1.1,2.2,0],[-5.1,2.2,0],p3,color=GOLD,stroke_width=2.5)
        closed=VMobject(color=GOLD,stroke_width=2.5)
        closed.set_points(outer.points.copy());closed.add_line_to(p0)
        heads=VGroup(arrow([-2.8,1.65,0],[-.6,0,0],GOLD,width=2),arrow([-3.65,0,0],[1.1,0,0],GOLD,width=2))
        self.show(body,pole_names,words(['Линии магнитной индукции','Продолжаются внутри магнита'],[3.1,1.2,0],26),run_time=1.2)
        self.intro(2)
        self.act(2,Create(closed),FadeIn(heads))
        self.show(words(['Снаружи: N → S','Внутри: S → N','Каждая линия замкнута'],[3.1,-.65,0],27,GOLD),
                  words('У линии нет начала и конца на полюсах',[-3.1,-2.25,0],22,MUTED,width=5.5),run_time=1.2)
        self.result(2)


class InductionAndMagnetization(MagneticScene):
    chapter_id=2
    def chapter(self):
        self.beat(0)
        curve=CubicBezier([-5.3,-1.1,0],[-4.4,1.2,0],[-2.4,1.4,0],[-1.0,-.3,0],color=GOLD,stroke_width=2.5)
        c=curve.point_from_proportion(.5);a=curve.point_from_proportion(.49);b=curve.point_from_proportion(.51)
        tangent=(b-a)/np.linalg.norm(b-a)
        field=arrow(c,tangent*1.6,CYAN)
        label=formula(r'\vec B',c+tangent*.8+UP*.55,33,CYAN,width=.8)
        self.show(curve,Dot(c,radius=.06,color=INK),words(['Магнитная индукция B','Векторная силовая характеристика'],[3.1,1.1,0],26),run_time=1.2)
        self.intro(0)
        self.act(0,GrowArrow(field),FadeIn(label))
        self.show(words(['B направлен по касательной','к линии в данной точке'],[3.1,-.45,0],25,GOLD),
                  words('Единица индукции — тесла (Тл)',[3.1,-1.9,0],24,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        case,needle=a_needle()
        field=arrow([-5.25,1.55,0],[4.3,0,0],GOLD)
        self.show(case,needle,field,formula(r'\vec B',[-3.1,2.1,0],32,GOLD,width=.8),
                  words(['Компас — магнитная стрелка','Реагирует на суммарное поле'],[3.1,1.0,0],26),
                  words('Красный конец — северный N',[-3.1,-1.6,0],23,ROSE,width=5.4),run_time=1.2)
        self.intro(1)
        self.act(1,Rotate(needle,-PI/2,about_point=np.array([-3.1,0,0])))
        self.show(words(['После установления равновесия','Северный конец направлен по B'],[3.1,-.75,0],25,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        magnet=a_bar((-4.6,1.0,0),2.0,.65)
        screw=VGroup(Line([-2.8,1.0,0],[-1.2,1.0,0],color=INK,stroke_width=5),
                     Line([-2.8,.72,0],[-2.8,1.28,0],color=INK,stroke_width=3),
                     *[Line([x,.9,0],[x+.1,1.1,0],color=MUTED,stroke_width=1.5) for x in [-2.5,-2.2,-1.9,-1.6]])
        case,needle=a_needle((-2.0,-.9,0),.65)
        names=VGroup(formula('S',[-2.55,1.65,0],25,CYAN,width=.5),formula('N',[-1.45,1.65,0],25,ROSE,width=.5))
        self.show(magnet,screw,words(['Намагничивание','Железо, никель, кобальт и сплавы'],[3.1,1.15,0],25),run_time=1.2)
        self.intro(2)
        contact=screw.copy().shift(LEFT*.8)
        magnetized=contact.copy().set_stroke(GOLD)
        returned=screw.copy().set_stroke(GOLD)
        self.act(2,Succession(Transform(screw,contact),Transform(screw,magnetized),
                             AnimationGroup(Transform(screw,returned),FadeOut(magnet)),
                             AnimationGroup(FadeIn(case),FadeIn(needle)),
                             AnimationGroup(Rotate(needle,PI/2,about_point=np.array([-2.0,-.9,0])),FadeIn(names))))
        self.show(words(['В данном опыте заметна намагниченность','Её сохранение зависит от материала','и условий'],[3.1,-.7,0],23,GOLD),
                  words('Компас проверяет саморез после удаления магнита',[-3.1,-2.3,0],21,MUTED,width=5.5),run_time=1.2)
        self.result(2)


class IronFilings(MagneticScene):
    chapter_id=3
    def chapter(self):
        self.beat(0)
        sheet=Rectangle(width=5.0,height=3.25,color=GRID).move_to([-3.1,0,0])
        points=[(x,y) for y in (-1.15,-.4,.4,1.15) for x in (-5.15,-4.3,-3.45,-2.6,-1.75,-.9)]
        filings=a_filings(points)
        self.show(sheet,words(['Железные опилки','Маленькие намагничиваемые частицы'],[3.1,1.1,0],25),run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(*[FadeIn(m) for m in filings],lag_ratio=.04))
        self.show(words(['Качественная картина ориентации','Случайный рисунок не доказывает B = 0'],[3.1,-.75,0],24,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        sheet=Rectangle(width=5.0,height=3.8,color=GRID).move_to([-3.1,0,0])
        magnet=a_bar(width=2.6)
        points=[(x,y) for y in (-1.25,-.65,.65,1.25) for x in (-5.3,-4.55,-3.8,-3.05,-2.3,-1.55,-.8)]
        filings=a_filings(points)
        def field(p):
            n=np.array([-1.8,0,0]);s=np.array([-4.4,0,0]);u=p-n;v=p-s
            return u/np.linalg.norm(u)**3-v/np.linalg.norm(v)**3
        self.show(sheet,magnet,filings,words(['Полосовой магнит под листом','Опилки могут свободно повернуться'],[3.1,1.0,0],25),run_time=1.2)
        self.intro(1)
        self.act(1,*[a_orient(m,field(m.get_center())) for m in filings])
        self.show(words(['Опилки ориентировались вдоль поля','Линии — способ описания поля','Это не траектории частиц'],[3.1,-.8,0],24,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        legs=VGroup(Rectangle(width=.65,height=2.0,color=ROSE,fill_color=ROSE,fill_opacity=.2).move_to([-4.6,0,0]),
                    Rectangle(width=.65,height=2.0,color=CYAN,fill_color=CYAN,fill_opacity=.2).move_to([-1.6,0,0]),
                    Arc(radius=1.5,start_angle=PI,angle=PI,color=MUTED,stroke_width=12).move_to([-3.1,-1.35,0]))
        names=VGroup(formula('N',[-4.6,1.35,0],31,ROSE,width=.6),formula('S',[-1.6,1.35,0],31,CYAN,width=.6))
        filings=a_filings([(x,y) for y in (-.45,.1,.65) for x in (-3.95,-3.35,-2.75,-2.15)])
        direction=arrow([-4.05,1.9,0],[1.9,0,0],GOLD)
        self.show(legs,names,filings,words(['U-образный магнит','Рассматриваем центральный зазор'],[3.1,1.1,0],25),run_time=1.2)
        self.intro(2)
        self.act(2,*[a_orient(m,RIGHT) for m in filings],GrowArrow(direction))
        self.show(words(['В зазоре: от N к S','Линии здесь примерно параллельны','Всё поле не обязано быть однородным'],[3.1,-.85,0],24,GOLD),run_time=1.2)
        self.result(2)


class MagneticSuperposition(MagneticScene):
    chapter_id=4
    def chapter(self):
        self.beat(0)
        p=np.array([-4.65,-.65,0]);b1=arrow(p,[2.3,0,0],CYAN);b2=arrow(p,[0,1.55,0],LAVENDER)
        n1=formula(r'\vec B_1',[-3.5,-1.2,0],29,CYAN,width=1)
        n2=formula(r'\vec B_2',[-5.25,.15,0],29,LAVENDER,width=1)
        result=arrow(p,[2.3,1.55,0],GOLD)
        self.show(Dot(p,radius=.055,color=INK),b1,b2,n1,n2,
                  words('Одна выбранная точка поля',[3.1,1.8,0],26),
                  formula(r'\vec B=\vec B_1+\vec B_2+\ldots',[3.1,.6,0],37),run_time=1.2)
        self.intro(0)
        self.act(0,b2.animate.shift(RIGHT*2.3),n2.animate.shift(RIGHT*2.3),GrowArrow(result))
        self.show(formula(r'\vec B',[-3.8,.65,0],31,GOLD,width=1),
                  words(['Складываем векторы','Переносим их параллельно себе','при геометрическом построении'],[3.1,-1.25,0],24,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        b1=arrow([-5.0,.2,0],[2.1,0,0],CYAN);b2=arrow([-2.9,.2,0],[1.5,0,0],LAVENDER)
        whole=arrow([-5.0,-1.0,0],[3.6,0,0],GOLD)
        self.show(b1,b2,formula('B_1',[-3.95,.8,0],31,CYAN,width=1),formula('B_2',[-2.15,.8,0],31,LAVENDER,width=1),
                  words(['Вклады сонаправлены','Стрелки имеют один масштаб'],[3.1,1.25,0],26),run_time=1.2)
        self.intro(1)
        self.act(1,GrowArrow(whole))
        self.show(formula('B',[-3.2,-1.55,0],32,GOLD,width=1),formula('B=B_1+B_2',[3.1,-.15,0],43,GOLD),
                  words('Модули складываются при сонаправленности',[3.1,-1.7,0],23,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        magnets=VGroup(a_bar((-5.0,0,0),1.2,.6),a_bar((-1.2,0,0),1.2,.6,n_right=False))
        p=np.array([-3.1,0,0]);b1=arrow(p,[1.0,0,0],CYAN);b2=arrow(p,[-1.0,0,0],LAVENDER)
        zero=formula(r'\vec B=\vec0',[3.1,-.15,0],45,GOLD)
        self.show(magnets,Dot(p,radius=.06,color=INK),b1,b2,
                  formula('B_1',[-2.55,.65,0],28,CYAN,width=.8),formula('B_2',[-3.65,.65,0],28,LAVENDER,width=.8),
                  formula('P',[-3.1,-.6,0],27,MUTED,width=.6),
                  words('Симметричная конфигурация',[-3.1,1.7,0],24,MUTED,width=5.5),
                  words(['В данной точке равные модули','Противоположные направления'],[3.1,1.3,0],24),run_time=1.2)
        self.intro(2)
        self.act(2,Write(zero))
        self.show(words(['Компенсация именно в точке P','Одна пустота в опилках её не доказывает'],[3.1,-1.65,0],23,MUTED),run_time=1.2)
        self.result(2)


class OerstedAndStraightWire(MagneticScene):
    chapter_id=5
    def chapter(self):
        self.beat(0)
        ring,mark=a_normal((-4.6,0,0),True,.28)
        case,needle=a_needle((-1.8,0,0),.7,angle=-PI/2)
        off=words('I = 0',[-4.6,-1.55,0],25,MUTED,width=2)
        on=words('I > 0',[-4.6,-1.55,0],25,CYAN,width=2)
        earth_length=1.6*np.tan(.12)
        earth=arrow([-1.8-earth_length/2,-1.5,0],[earth_length,0,0],LAVENDER)
        field=arrow([-3.05,-.8,0],[0,1.6,0],GOLD)
        rings=VGroup(*[Circle(radius=r,color=GOLD,stroke_width=1.6).move_to([-4.6,0,0]) for r in (.7,1.1)])
        self.show(ring,case,needle,off,earth,formula(r'B_{\mathrm{Земли}}',[-1.8,-2.1,0],25,LAVENDER,width=2.1),
                  words(['Опыт Эрстеда','Проводник подключают к питанию','Стрелки полей в одном масштабе'],[3.1,1.1,0],24),run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(mark),Create(rings),GrowArrow(field),Rotate(needle,PI/2-.12,about_point=np.array([-1.8,0,0])),
                 Succession(FadeOut(off),FadeIn(on)))
        self.show(formula(r'B_{\mathrm{провода}}',[-3.2,1.4,0],25,GOLD,width=2.1),
                  words(['Ток создаёт магнитное поле','Компас ориентируется по сумме полей'],[3.1,-.7,0],24,GOLD),
                  words('Поперечный вид: ток к наблюдателю',[-3.1,2.25,0],20,MUTED,width=5.4),run_time=1.2)
        self.result(0)

        self.beat(1)
        ring,mark=a_normal()
        circles=VGroup(*[Circle(radius=r,color=GOLD,stroke_width=2).move_to([-3.1,0,0]) for r in (.85,1.4,1.95)])
        heads=a_ring_arrows()
        self.show(ring,mark,formula('I',[-3.1,-.6,0],30,CYAN,width=.7),
                  words(['Длинный прямой проводник','Плоскость поперёк провода'],[3.1,1.2,0],26),run_time=1.2)
        self.intro(1)
        self.act(1,Create(circles),FadeIn(heads))
        self.show(words(['Линии — концентрические окружности','Они лежат перпендикулярно проводу'],[3.1,-.75,0],24,GOLD),
                  words('Ток к нам: обход против часовой стрелки',[-3.1,-2.45,0],22,MUTED,width=5.5),run_time=1.2)
        self.result(1)

        self.beat(2)
        ring,dot=a_normal();_,cross=a_normal(toward=False)
        circles=VGroup(*[Circle(radius=r,color=GOLD,stroke_width=2).move_to([-3.1,0,0]) for r in (.85,1.4,1.95)])
        ccw=a_ring_arrows();cw=a_ring_arrows(ccw=False)
        old=words('Ток к наблюдателю',[-3.1,-2.45,0],23,CYAN,width=5.4)
        new=words('Ток от наблюдателя',[-3.1,-2.45,0],23,CYAN,width=5.4)
        self.show(ring,dot,circles,ccw,old,
                  words(['Правило правой руки','Большой палец — по току','Согнутые пальцы — по обходу B'],[3.1,1.1,0],25),run_time=1.2)
        self.intro(2)
        self.act(2,Succession(AnimationGroup(FadeOut(dot),FadeOut(ccw),FadeOut(old)),
                             AnimationGroup(FadeIn(cross),FadeIn(cw),FadeIn(new))))
        self.show(words(['При обращении условного тока','направление обхода меняется'],[3.1,-1.0,0],25,GOLD),run_time=1.2)
        self.result(2)
