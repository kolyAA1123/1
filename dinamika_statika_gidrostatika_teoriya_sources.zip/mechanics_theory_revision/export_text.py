"""Assemble reviewed theory narration and export readable TXT/DOCX."""
from pathlib import Path
import hashlib,json,re,zipfile
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent
PREFIX='dinamika_statika_gidrostatika_teoriya'

def stamp(t):
 ms=round(t*1000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
 return f'{m:02d}:{s:02d}.{ms:03d}'
def count_words(t):return len(re.findall(r'[А-Яа-яЁё]+(?:[-‑][А-Яа-яЁё]+)*|\d+',t))
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def build():
 original=json.loads((ROOT/'reference_narration.json').read_text())
 drafts=[c for f in sorted((ROOT/'sections').glob('*.json')) for c in json.loads(f.read_text())]
 by_id={c['id']:c for c in drafts};assert len(by_id)==len(drafts)==22
 edits=json.loads((ROOT/'editorial_fixes.json').read_text())
 final={'title':'Динамика, статика и гидростатика: теория для озвучки',
        'reference_video':'dinamika_statika_gidrostatika_1080p60.mp4',
        'reference_duration_seconds':1680,
        'timing_kind':'visual_scene_anchors_not_measured_speech_slots',
        'note':'Таймкоды указывают соответствующие сцены существующего фильма. Читайте в естественном темпе; после записи длительности сцен подстраиваются под речь. Текст формул произносится словами.',
        'chapters':[]}
 used=set()
 for old in original['chapters']:
  source=by_id[old['id']];assert len(source['cues'])==5
  ch={k:old[k] for k in ('id','title','source','pages','start','duration','class')};ch['cues']=[]
  assert [c['beat'] for c in source['cues']]==[1,2,3,4,5]
  for new,previous in zip(source['cues'],old['cues']):
   key=f"{old['id']:02d}.{new['beat']}";text=edits.get(key,new['text']).strip()
   if key in edits:used.add(key)
   assert text and text[-1] in '.!?',key
   assert not re.search(r'[$\\_{}]|\b(?:TODO|FIXME|nan)\b',text),key
   assert 'отчёта' not in text and 'отчета' not in text,key
   assert not re.search(r'\b(?:ИИ|робот|анимация|рендер)\b',text),key
   ch['cues'].append({'key':key,'beat':new['beat'],'scene_anchor':previous['global_at'],
                     'visual_window_end':previous['global_until'],'text':text,'word_count':count_words(text),
                     'source_pages':new.get('source_pages',previous['source_pages']),
                     'visual':previous['visual'],'check_note':new['check_note'],
                     'editorial_revision':key in edits})
  final['chapters'].append(ch)
 assert used==set(edits),(set(edits)-used)
 assert sum(len(c['cues']) for c in final['chapters'])==110
 return final

def main():
 final=build();out=ROOT/'output';out.mkdir(exist_ok=True)
 (ROOT/'narration_theory.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
 instructions=[
 'Для записи читайте только основные абзацы. Названия глав и таймкоды произносить не нужно.',
 'Таймкоды — указатели сцен существующего 28-минутного фильма, а не ограничение скорости чтения. Не ускоряйтесь, чтобы уложиться в интервал: после записи длительность сцен подстраивается под речь.',
 'Между абзацами оставляйте паузу около двух секунд. Формулы в этом тексте объясняются словами; служебные подписи читать не нужно.'
 ]
 txt=[final['title'].upper(),'','ПОДСКАЗКИ ДЛЯ ЗАПИСИ — НЕ ОЗВУЧИВАТЬ','',*instructions,'']
 doc=Document();sec=doc.sections[0];sec.top_margin=sec.bottom_margin=Inches(.7);sec.left_margin=sec.right_margin=Inches(.75)
 normal=doc.styles['Normal'];normal.font.name='Arial';normal.font.size=Pt(12);normal.paragraph_format.space_after=Pt(8);normal.paragraph_format.line_spacing=1.15
 doc.add_heading(final['title'],0)
 doc.add_paragraph('Текст для самостоятельной записи · 22 главы · 110 фрагментов',style='Subtitle')
 doc.add_heading('Подсказки для записи — не озвучивать',1)
 for line in instructions:doc.add_paragraph(line)
 part_names={1:'ЧАСТЬ I. ДИНАМИКА',12:'ЧАСТЬ II. СТАТИКА',16:'ЧАСТЬ III. ГИДРОСТАТИКА'}
 for ch in final['chapters']:
  if ch['id'] in part_names:
   txt+=['',part_names[ch['id']],'']
   doc.add_heading(part_names[ch['id']],1)
  heading=f"{ch['id']:02d}. {ch['title']}"
  txt += [heading,''];doc.add_heading(heading,2)
  for c in ch['cues']:
   anchor=f"[{stamp(c['scene_anchor'])}] Фрагмент {c['key']}"
   txt += [anchor,c['text'],'']
   p=doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.paragraph_format.space_after=Pt(3)
   run=p.add_run(anchor);run.bold=True;run.font.size=Pt(10);run.font.color.rgb=RGBColor.from_string('526070')
   doc.add_paragraph(c['text'])
 footer=sec.footer.paragraphs[0];footer.alignment=2;footer.add_run('Страница ')
 field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
 textpath=REPO/f'{PREFIX}_tekst.txt';docpath=REPO/f'{PREFIX}_tekst.docx'
 textpath.write_text('\n'.join(txt).rstrip()+'\n',encoding='utf-8-sig',newline='\n');doc.save(docpath)
 # The familiar text filename now points to the corrected authoritative version.
 (REPO/'dinamika_statika_gidrostatika_ozvuchka.txt').write_bytes(textpath.read_bytes())
 expected=[c['text'] for ch in final['chapters'] for c in ch['cues']]
 actual=[p.text for p in Document(docpath).paragraphs]
 assert all(actual.count(t)==1 for t in expected)
 data=textpath.read_text(encoding='utf-8-sig');assert all(data.count(t)==1 for t in expected)
 with zipfile.ZipFile(docpath) as z:assert z.testzip() is None
 counts=[c['word_count'] for ch in final['chapters'] for c in ch['cues']]
 proof={'reference_video_sha256':sha(REPO/final['reference_video']) if (REPO/final['reference_video']).exists() else json.loads((ROOT/'reference_manifest.json').read_text())['reference_video_sha256'],
        'chapters':22,'cues':110,'total_words':sum(counts),'minimum_words':min(counts),'maximum_words':max(counts),
        'original_narration_sha256':sha(ROOT/'reference_narration.json'),
        'final_narration_sha256':sha(ROOT/'narration_theory.json'),
        'timing_kind':final['timing_kind'],'txt_sha256':sha(textpath),'docx_sha256':sha(docpath),
        'source_sections':[str(f.relative_to(ROOT)) for f in sorted((ROOT/'sections').glob('*.json'))],
        'validation':'22 chapters and110 cues in original order; visual anchors exactly match source narration; all texts exported once to TXT and DOCX; DOCX archive intact; formula-markup/placeholder checks passed.'}
 (out/'text_validation.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(proof,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
