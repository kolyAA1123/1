from pathlib import Path
import math
import json

import numpy as np
from manim import Axes, Create, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Целые числа и последовательности"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



def graph(kind):
    if kind=="progression":
        def point(i,a):
            return np.array([-5.7+.94*i,-1.36+.29*a,0])
        numbers=(2,5,8,11,14)
        points=VGroup(*[Dot(point(i,a/1.4),radius=.075,color=CYAN) for i,a in enumerate(numbers)])
        labels=VGroup(*[equation(str(a),GOLD,point(i,a/1.4)+[0,.26,0],.27) for i,a in enumerate(numbers)])
        arrow=Line([-6.02,-1.42,0],[-1.32,-1.42,0],color=MUTED,stroke_width=1.7)
        return VGroup(arrow),VGroup(points,labels)
    if kind=="intervals":
        def point(i,row):
            return np.array([-5.77+.53*i, .46-.49*row,0])
        base=VGroup(*[equation(str(i),MUTED,point(i,0)+[0,.47,0],.20) for i in range(9)])
        lines=VGroup()
        for row,offset in enumerate((0,2,4)):
            pts=[point(offset+j,row) for j in range(4)]
            lines.add(Line(pts[0],pts[-1],color=(CYAN,GOLD,LAVENDER)[row],stroke_width=2.4),
                      *[Dot(p,radius=.058,color=(CYAN,GOLD,LAVENDER)[row]) for p in pts])
        return base,lines
    return VGroup(),VGroup()


class IntegersLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind=="intervals" else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
