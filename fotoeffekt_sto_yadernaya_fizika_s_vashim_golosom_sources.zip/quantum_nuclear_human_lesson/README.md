# Кванты, фотоэффект, СТО и ядерная физика — монтаж с авторской озвучкой

Исходные анимации и сценарий опубликованы в
`fotoeffekt_sto_yadernaya_fizika_sources.zip` и
`fotoeffekt_sto_yadernaya_fizika_tekst.txt`. Этот проект использует
опубликованный MP4 и запись `compress.m4a`. В озвученной версии 17 глав,
108 реплик и 54 действия на экране.

Окна речи сопоставлены с исходным сценарием, границы проверены по
записанному сигналу и распознаванию фрагментов с обеих сторон переходов.
`boundaries.json` содержит проверенные границы пауз в записи в секундах.
`edit.json` описывает соответствие кадров и аудиоотсчётов.
`timeline.txt` содержит исходный сценарий с обновлёнными таймкодами.

## Повторная сборка

Запустите из папки `quantum_nuclear_human_lesson`. Нужны Python 3.11+
с NumPy и FFmpeg с libx264.

```sh
ffmpeg -v error -i /path/to/compress.m4a -map 0:a:0 -ac 1 -ar 48000 -c:a pcm_s16le recording.wav
python build_edit.py /path/to/fotoeffekt_sto_yadernaya_fizika_1080p60.mp4 recording.wav
bash render_audited.sh /path/to/fotoeffekt_sto_yadernaya_fizika_1080p60.mp4 fotoeffekt_sto_yadernaya_fizika_s_vashim_golosom_1080p60.mp4
mv source-audited.gray source.gray
python check_holds.py source.gray
ffmpeg -v error -xerror -threads 2 -i fotoeffekt_sto_yadernaya_fizika_s_vashim_golosom_1080p60.mp4 \
  -map 0:v:0 -vf scale=160:90,format=gray -filter_threads 1 -f rawvideo delivered.gray \
  -map 0:a:0 -f s16le audio_decode.s16
python verify_edit.py fotoeffekt_sto_yadernaya_fizika_s_vashim_golosom_1080p60.mp4
```

Монтаж меняет длительность статичных кадров и паузы между репликами.
Внутри реплик отсчёты идут непрерывно с исходным темпом и высотой.
Исходная запись используется локально. В архив включены план, сценарий,
монтажные решения и результаты проверок.
