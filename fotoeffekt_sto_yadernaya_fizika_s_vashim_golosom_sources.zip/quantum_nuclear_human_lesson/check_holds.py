"""Check every altered reading hold for movement in the delivered source."""
import json
from pathlib import Path
import sys
import numpy as np

plan_path = Path("quantum_nuclear_lesson/plan.json")
plan = json.loads(plan_path.read_text())
path = Path(sys.argv[1])
width, height = 160, 90
complete_frames = path.stat().st_size // (width * height)
frames = np.memmap(path, mode="r", dtype="uint8", shape=(complete_frames,height,width))
checks = []
for chapter in plan["chapters"]:
    for beat in chapter["beats"]:
        for phase in ("intro", "result"):
            begin = round((chapter["start"] + beat[phase+"_at"])*60)+15
            end = begin + beat[phase+"_duration"]*60-30
            if end > len(frames):
                continue
            reference = frames[begin].astype("int16")
            diff = np.abs(frames[begin:end].astype("int16")-reference)
            maximum = int(diff.max())
            mean = float(diff.mean(axis=(1,2)).max())
            checks.append(dict(chapter=chapter["id"],beat=beat["index"]+1,phase=phase,
                frames=[begin,end],max_difference=maximum,max_average_difference=round(mean,5)))
            print(chapter["id"],beat["index"]+1,phase,maximum,round(mean,5))
            assert mean < .30 and maximum <= 12, "Motion or compression anomaly inside a frozen window"
if len(frames) == plan["duration"]*60:
    assert len(checks)==108
    Path("hold_checks.json").write_text(json.dumps(checks,indent=2)+"\n")
