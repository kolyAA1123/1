"""Apertures, transverse polarization and coherent superposition: PDF pp1–3."""
from wave_style import *


def wa_ray(p,q,color=CYAN):
    return Arrow(p,q,buff=0,color=color,stroke_width=2.2,tip_length=.12,
                 max_tip_length_to_length_ratio=.15)


def wa_aperture(half_width=1.05):
    wall_x,screen_x=-3.35,-.7
    wall=VGroup(Line([wall_x,-2.0,0],[wall_x,-half_width,0],color=INK,stroke_width=4),
                Line([wall_x,half_width,0],[wall_x,2.0,0],color=INK,stroke_width=4))
    screen=Line([screen_x,-1.95,0],[screen_x,1.95,0],color=MUTED,stroke_width=3)
    names=VGroup(words('Преграда',[-3.35,2.3,0],20,MUTED,width=2),
                 words('Экран',[-.7,2.3,0],20,MUTED,width=1.4))
    incident=VGroup(*[wa_ray([-5.95,y,0],[wall_x,y,0])
                     for y in (-1.55,-.7,0,.7,1.55)])
    transmitted=VGroup(*[wa_ray([wall_x,y,0],[screen_x,y,0],GOLD)
                        for y in (-.7,0,.7) if abs(y)<half_width])
    return VGroup(wall,screen,names),incident,transmitted


def wa_diffraction_fronts():
    """Schematic phase fronts, clipped at the opaque observing screen."""
    center=np.array([-3.35,0,0]);distance=2.65
    fronts=VGroup()
    for radius in (.35,.75,1.15,1.55,1.95,2.35,2.75,3.15):
        theta_min=np.arccos(min(1.,distance/radius))
        theta_max=min(.62,np.arcsin(min(1.,1.8/radius)))
        if theta_min>=theta_max:continue
        if theta_min<1e-8:
            fronts.add(Arc(radius=radius,start_angle=-theta_max,
                           angle=2*theta_max,color=GOLD,stroke_width=2).shift(center))
        else:
            fronts.add(Arc(radius=radius,start_angle=theta_min,
                           angle=theta_max-theta_min,color=GOLD,stroke_width=2).shift(center),
                       Arc(radius=radius,start_angle=-theta_max,
                           angle=theta_max-theta_min,color=GOLD,stroke_width=2).shift(center))
    return fronts


def wa_section(center,radius=.43):
    return Circle(radius=radius,color=GRID,stroke_width=1.4).move_to(center)


def wa_field(center,theta,length=.38,color=CYAN):
    p=np.asarray(center,float)
    return wa_ray(p,p+length*np.array([np.cos(theta),np.sin(theta),0]),color)


def wa_curve(x0,x1,y,amplitude=.32,phase=0,color=CYAN):
    points=[np.array([x,y+amplitude*np.sin(TAU*(x-x0)/(x1-x0)+phase),0])
            for x in np.linspace(x0,x1,160)]
    return VMobject(color=color,stroke_width=2.7).set_points_smoothly(points)


def wa_plot_base(x0,x1,y,name,color):
    return VGroup(Line([x0,y,0],[x1,y,0],color=GRID,stroke_width=1.2),
                  formula(name,[x0-.6,y,0],24,color,width=.95))


class ApertureDiffraction(WaveScene):
    chapter_id=1

    def chapter(self):
        self.beat(0)
        base,incident,passed=wa_aperture(1.05)
        self.show(base,words(['Большое отверстие','Геометрическое приближение'],[3.1,1.35,0],26),
                  words(['На непрозрачной части','свет задерживается'],[3.1,-.1,0],24,MUTED),run_time=1.2)
        self.intro(0)
        lit=Line([-.7,-1.05,0],[-.7,1.05,0],color=GOLD,stroke_width=7)
        self.act(0,Succession(Create(incident),Create(passed),FadeIn(lit)))
        self.show(words(['За отверстием освещена','ограниченная область экрана'],[3.1,-1.75,0],24,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        base,incident,_=wa_aperture(.2)
        fronts=wa_diffraction_fronts()
        self.show(base,words(['Малое отверстие','Волновые фронты за преградой'],[3.1,1.35,0],26),
                  words('Схема установившегося распространения',[3.1,-.05,0],22,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,Succession(Create(incident),Create(fronts)))
        self.show(words(['Свет попадает в область','геометрической тени'],[3.1,-1.65,0],25,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        left=VGroup(Line([-4.2,-1.5,0],[-4.2,-.65,0],color=INK,stroke_width=3),
                    Line([-4.2,.65,0],[-4.2,1.5,0],color=INK,stroke_width=3),
                    Line([-1.5,-1.5,0],[-1.5,1.5,0],color=MUTED,stroke_width=2))
        right=VGroup(Line([2.0,-1.5,0],[2.0,-.16,0],color=INK,stroke_width=3),
                     Line([2.0,.16,0],[2.0,1.5,0],color=INK,stroke_width=3),
                     Line([4.7,-1.5,0],[4.7,1.5,0],color=MUTED,stroke_width=2))
        rays=VGroup(*[wa_ray([-4.2,y,0],[-1.5,y,0],CYAN) for y in (-.48,0,.48)])
        front=VGroup(*[Arc(radius=r,start_angle=-.5,angle=1,color=GOLD,
                           stroke_width=2).shift([2.,0,0]) for r in (.5,1.05,1.6,2.15,2.7)])
        self.show(left,right,words('Отверстие больше',[-3.1,2.1,0],26,CYAN),
                  words('Отверстие меньше',[3.1,2.1,0],26,GOLD),run_time=1.2)
        self.intro(2)
        self.act(2,Create(rays),Create(front))
        self.show(words(['Размер сравнивают с длиной волны','При сравнимых условиях волновое отклонение заметнее'],
                        [0,-2.3,0],24,INK,width=12.2),run_time=1.2)
        self.result(2)


class LightPolarization(WaveScene):
    chapter_id=2

    def chapter(self):
        self.beat(0)
        angles=np.deg2rad([20,105,-35,72,-12])
        centers=[np.array([x,.5,0]) for x in (-5.5,-4.3,-3.1,-1.9,-.7)]
        sections=VGroup(*[wa_section(p) for p in centers])
        fields=VGroup(*[wa_field(p,t) for p,t in zip(centers,angles)])
        direction=VGroup(Circle(radius=.16,color=GOLD,stroke_width=1.7).move_to([-3.1,-1.15,0]),
                         Dot([-3.1,-1.15,0],radius=.045,color=GOLD),
                         words('Свет направлен к наблюдателю',[-3.1,-1.85,0],21,MUTED,width=5.6))
        self.show(sections,direction,words('Поперечный вид: разные состояния E',[-3.1,1.7,0],22,MUTED),
                  words(['Естественный свет','Направления E меняются'],[3.1,1.3,0],26),
                  formula(r'\vec E\perp\vec k',[3.1,-.2,0],35,CYAN),run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(*[FadeIn(f) for f in fields],lag_ratio=.2))
        self.show(words('Нет одной устойчивой ориентации E',[3.1,-1.65,0],24,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        c=np.array([-3.3,-.6,0]);tip=c+np.array([.9,1.35,0])
        film=RoundedRectangle(width=2.8,height=3.2,corner_radius=.12,color=LAVENDER,
                              stroke_width=2,fill_color=LAVENDER,fill_opacity=.045).move_to([-3.3,0,0])
        axis=DashedLine([-3.3,-1.6,0],[-3.3,1.6,0],color=MUTED,dash_length=.09,stroke_width=1.3)
        incoming=wa_ray(c,tip,CYAN)
        projection=wa_ray(c,c+UP*1.35,GOLD)
        guide=DashedLine(tip,c+UP*1.35,color=MUTED,dash_length=.08,stroke_width=1.2)
        self.show(film,axis,incoming,formula('E',[-2.05,1.05,0],28,CYAN,width=.5),
                  words('Поперечное сечение плёнки',[-3.3,2.15,0],22,MUTED),
                  words(['Ось пропускания плёнки','Выделяем компоненту вдоль оси'],[3.1,1.1,0],25),run_time=1.2)
        self.intro(1)
        self.act(1,Create(guide),Create(projection))
        self.show(formula(r'E_{\parallel}',[-4.25,1.02,0],27,GOLD,width=1.2),
                  words('Ось пропускания',[-3.3,-2.05,0],22,LAVENDER),
                  words(['Перпендикулярная оси компонента','идеальной плёнкой не передаётся'],[3.1,-1.35,0],23,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        xs=(-4.8,-2.4,0,2.4,4.8);angles=np.deg2rad([20,105,-35,72,-12])
        before=[np.array([x,.95,0]) for x in xs];after=[np.array([x,-.85,0]) for x in xs]
        rings=VGroup(*[wa_section(p,.4) for p in before+after])
        original=VGroup(*[wa_field(p,t,.36,CYAN) for p,t in zip(before,angles)])
        projected=VGroup(*[wa_ray(p,p+UP*(.36*np.sin(t)),GOLD) for p,t in zip(after,angles)])
        self.show(rings,original,words('До плёнки: разные направления E',[0,2.05,0],26,CYAN,width=12),
                  words('После плёнки: одна ось поперечных колебаний',[0,-1.95,0],25,GOLD,width=12),run_time=1.2)
        self.intro(2)
        self.act(2,LaggedStart(*[FadeIn(f) for f in projected],lag_ratio=.2))
        self.show(words('Линейная поляризация; пучок сохраняет направление',[0,-2.75,0],24,INK,width=12),run_time=1.2)
        self.result(2)


class CoherenceAndInterference(WaveScene):
    chapter_id=3

    def chapter(self):
        self.beat(0)
        bases=VGroup(wa_plot_base(-5.55,-.85,.9,'E_1',CYAN),
                     wa_plot_base(-5.55,-.85,-.85,'E_2',ROSE),
                     formula('t',[-.55,.67,0],24,MUTED,width=.35),
                     formula('t',[-.55,-1.08,0],24,MUTED,width=.35))
        curves=VGroup(wa_curve(-5.55,-.85,.9,.34,0,CYAN),
                      wa_curve(-5.55,-.85,-.85,.34,PI/3,ROSE))
        self.show(bases,words(['Одинаковая частота','Постоянная разность фаз'],[3.1,1.2,0],26),
                  words(['Для отчётливого светового примера','выбираем одинаковую поляризацию'],[3.1,-.5,0],23,MUTED),run_time=1.2)
        self.intro(0)
        self.act(0,Create(curves),rate_func=linear)
        self.show(words('Условие устойчивого фазового соотношения',[3.1,-2.05,0],23,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        rows=(1.05,.0,-1.25)
        bases=VGroup();original=VGroup();sums=VGroup()
        for x0,x1,opposite in [(-5.3,-.8,False),(1.3,5.8,True)]:
            for y,name,color in zip(rows,['E_1','E_2',r'E_1+E_2'],[CYAN,ROSE,GOLD]):
                bases.add(wa_plot_base(x0,x1,y,name,color))
            original.add(wa_curve(x0,x1,rows[0],.3,0,CYAN),
                         wa_curve(x0,x1,rows[1],.3,PI if opposite else 0,ROSE))
            sums.add(Line([x0,rows[2],0],[x1,rows[2],0],color=GOLD,stroke_width=3)
                     if opposite else wa_curve(x0,x1,rows[2],.6,0,GOLD))
        self.show(bases,original,words('Совпадают по фазе',[-3.1,2.1,0],25,CYAN),
                  words('Противоположные фазы',[3.1,2.1,0],25,ROSE),run_time=1.2)
        self.intro(1)
        self.act(1,Create(sums),rate_func=linear)
        self.show(words('Усиление',[-3.1,-2.4,0],27,GOLD),
                  words(['Равные амплитуды','Полное ослабление'],[3.1,-2.35,0],22,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        s1=np.array([-4.7,0,0]);s2=np.array([-2.3,0,0]);wavelength=.8
        sources=VGroup(Dot(s1,radius=.065,color=CYAN),Dot(s2,radius=.065,color=ROSE))
        fronts=VGroup(*[Circle(radius=r,color=c,stroke_width=1.6).move_to(s)
                        for r in (.2,1.,1.8) for s,c in [(s1,CYAN),(s2,ROSE)]])
        maximum=np.array([-3.5,.9,0]);low,high=-3.5,-2.5
        for _ in range(60):
            x=(low+high)/2;p=np.array([x,-.75,0])
            if np.linalg.norm(p-s1)-np.linalg.norm(p-s2)<wavelength/2:low=x
            else:high=x
        minimum=np.array([(low+high)/2,-.75,0])
        assert abs(np.linalg.norm(minimum-s1)-np.linalg.norm(minimum-s2)-wavelength/2)<1e-12
        observation=VGroup(Dot(maximum,radius=.055,color=GOLD),Dot(minimum,radius=.055,color=LAVENDER),
                           DashedLine(maximum,[-3.5,1.85,0],color=MUTED,dash_length=.08,stroke_width=1),
                           DashedLine(minimum,[-3.25,-1.95,0],color=MUTED,dash_length=.08,stroke_width=1))
        self.show(sources,formula('S_1',[-5.3,2.15,0],25,CYAN,width=.6),
                  formula('S_2',[-1.7,2.15,0],25,ROSE,width=.6),
                  words(['Водная аналогия','Источники возбуждаются согласованно'],[3.1,1.3,0],25),
                  words('Участки усиления и ослабления устойчивы',[3.1,-.15,0],23,MUTED),run_time=1.2)
        self.intro(2)
        self.act(2,Create(fronts),FadeIn(observation))
        self.show(words('Усиление',[-3.5,2.15,0],22,GOLD,width=2.2),
                  words('Ослабление',[-3.25,-2.25,0],22,LAVENDER,width=2.5),
                  words(['Интерференция — устойчивый результат','наложения когерентных волн'],[3.1,-1.75,0],24,GOLD),run_time=1.2)
        self.result(2)
