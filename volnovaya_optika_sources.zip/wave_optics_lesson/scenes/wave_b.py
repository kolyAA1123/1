"""Two-source paths, interference extrema and the far-field construction: pp4–6."""
from wave_style import *
from wave_math import two_source_paths, phase_pair


WB_D = 1.1
WB_ELL = 4.6
WB_MAX_Y = 1.2
WB_LAMBDA = two_source_paths(WB_D, WB_ELL, WB_MAX_Y)['delta']


def wb_point_for_difference(delta):
    low, high = 0., WB_MAX_Y
    for _ in range(70):
        middle = (low+high)/2
        if two_source_paths(WB_D, WB_ELL, middle)['delta'] < delta:
            low = middle
        else:
            high = middle
    return (low+high)/2


def wb_ray(start, end, color):
    p=np.array(start,dtype=float);q=np.array(end,dtype=float)
    return VGroup(Line(p,q,color=color,stroke_width=2.3),
                  Arrow(p+.52*(q-p),p+.72*(q-p),buff=0,color=color,
                        stroke_width=2.3,tip_length=.12,
                        max_tip_length_to_length_ratio=.45))


def wb_paths(y=1.2):
    x0=-5.4;screen_x=x0+WB_ELL
    s1=np.array([x0,WB_D/2,0.]);s2=np.array([x0,-WB_D/2,0.]);p=np.array([screen_x,y,0.])
    base=VGroup(Dot(s1,radius=.055,color=CYAN),Dot(s2,radius=.055,color=GOLD),
                Dot(p,radius=.055,color=INK),
                Line([screen_x,-1.35,0],[screen_x,1.8,0],color=MUTED,stroke_width=1.5),
                formula('S_1',s1+[-.3,.35,0],27,CYAN,width=.7),
                formula('S_2',s2+[-.3,-.4,0],27,GOLD,width=.7),
                formula('P',p+[.3,.2,0],27,INK,width=.5))
    rays=VGroup(wb_ray(s1,p,CYAN),wb_ray(s2,p,GOLD))
    labels=VGroup(formula('L_1',(s1+p)/2+UP*.35,28,CYAN,width=.7),
                  formula('L_2',(s2+p)/2+DOWN*.4,28,GOLD,width=.7))
    return base,rays,labels,two_source_paths(WB_D,WB_ELL,y)


def wb_field_graphs(delay):
    """Three displaced baselines, one common time and field scale."""
    left,right=1.3,5.9
    bases=(1.25,.05,-1.2)
    drawings=VGroup()
    for row,name,color in zip(bases,('E_1','E_2','E_1+E_2'),(CYAN,GOLD,ROSE)):
        drawings.add(Line([left,row,0],[right,row,0],color=GRID,stroke_width=1.3),
                     formula(name,[.5,row,0],25,color,width=1.15))
        for x in (left,right):
            drawings.add(Line([x,row-.04,0],[x,row+.04,0],color=MUTED,stroke_width=1))
    drawings.add(words('Один период, общий масштаб поля',[3.5,2.15,0],22,MUTED,width=5.6),
                 formula('0',[left,-2.15,0],23,MUTED,width=.5),
                 formula('T',[right,-2.15,0],23,MUTED,width=.5))
    curves=VGroup()
    theta=np.linspace(0,TAU,180)
    values=[phase_pair(float(t),delay) for t in theta]
    for index,(row,color) in enumerate(zip(bases,(CYAN,GOLD,ROSE))):
        curve=VMobject(color=color,stroke_width=2.8,fill_opacity=0)
        curve.set_points_as_corners([
            [left+(right-left)*float(t)/TAU,row+.31*value[index],0]
            for t,value in zip(theta,values)])
        curves.add(curve)
    return drawings,curves


def wb_parallel_model():
    """An explicitly idealized parallel-direction diagram, not a finite common P."""
    phi=PI/6;d=2.4
    s1=np.array([-5.4,1.,0.]);s2=np.array([-5.4,-1.4,0.])
    direction=np.array([np.cos(phi),np.sin(phi),0.])
    h=s2+d*np.sin(phi)*direction
    perpendicular=(s1-h)/np.linalg.norm(s1-h)
    toward_s2=(s2-h)/np.linalg.norm(s2-h)
    base=VGroup(Dot(s1,radius=.055,color=CYAN),Dot(s2,radius=.055,color=GOLD),
                formula('S_1',s1+[-.3,.35,0],27,CYAN,width=.7),
                formula('S_2',s2+[-.3,-.45,0],27,GOLD,width=.7),
                Line(s1,s2,color=MUTED,stroke_width=1.4),
                formula('d',[-6.15,-.2,0],29,MUTED,width=.5),
                words('К далёкому P',[-1.85,1.25,0],20,MUTED,width=2.0))
    paths=VGroup(wb_ray(s1,s1+2.2*direction,CYAN),
                 wb_ray(s2,s2+4.4*direction,GOLD))
    corner=VGroup(Line(h+.14*perpendicular,h+.14*(perpendicular+toward_s2),color=ROSE,stroke_width=1.6),
                  Line(h+.14*(perpendicular+toward_s2),h+.14*toward_s2,color=ROSE,stroke_width=1.6))
    projection=VGroup(DashedLine(s1,h,color=ROSE,dash_length=.07,stroke_width=1.7),
                      Dot(h,radius=.045,color=ROSE),corner,
                      formula('H',h+[.35,-.34,0],27,ROSE,width=.6))
    arc=Arc(radius=.63,start_angle=-PI/2,angle=phi,color=LAVENDER,stroke_width=2).shift(s1)
    angle_name=formula(r'\varphi',s1+[.95*np.sin(phi/2),-.95*np.cos(phi/2),0],29,LAVENDER,width=.6)
    horizontal=DashedLine(s2,s2+RIGHT*2.2,color=GRID,dash_length=.08,stroke_width=1.2)
    lower_arc=Arc(radius=.75,start_angle=0,angle=phi,color=LAVENDER,stroke_width=2).shift(s2)
    lower_name=formula(r'\varphi',s2+[1.03,-.27,0],27,LAVENDER,width=.5)
    angle=VGroup(arc,angle_name,horizontal,lower_arc,lower_name)
    return base,paths,projection,angle


class PathsAndExtrema(WaveScene):
    chapter_id=4

    def chapter(self):
        self.beat(0)
        base,rays,labels,_=wb_paths(0)
        initial=words(['Одинаковая частота и поляризация',
                       'Начальные фазы одинаковы'],[3.1,1.2,0],25)
        self.show(base,initial,words('Два когерентных точечных источника',[0,2.2,0],24,MUTED,width=11.8),run_time=1.2)
        self.intro(0)
        self.act(0,Create(rays),rate_func=linear)
        self.show(words(['В центральной точке пути равны',
                         'Составляющие приходят синфазно'],[3.1,-.6,0],25,GOLD),
                  words('Поля складываются в одной и той же точке P',[0,-2.45,0],24,MUTED,width=11.8),run_time=1.2)
        self.result(0)

        self.beat(1)
        base,rays,labels,_=wb_paths(WB_MAX_Y)
        self.show(base,rays,labels,
                  formula(r'L_1=|S_1P|',[3.1,1.45,0],38,CYAN),
                  formula(r'L_2=|S_2P|',[3.1,.25,0],38,GOLD),run_time=1.2)
        self.intro(1)
        difference=formula(r'\Delta L=L_2-L_1',[3.1,-1.1,0],40,ROSE)
        self.act(1,Write(difference))
        self.show(words('В выбранной точке L₂ > L₁, поэтому ΔL > 0',[0,-2.45,0],24,MUTED,width=11.8),run_time=1.2)
        self.result(1)

        self.beat(2)
        base,rays,labels,geometry=wb_paths(WB_MAX_Y)
        delay=TAU*geometry['delta']/WB_LAMBDA
        drawing,curves=wb_field_graphs(delay)
        self.show(base,rays,formula(r'\Delta L=\lambda',[-3.1,2.05,0],35,GOLD),drawing,run_time=1.2)
        self.intro(2)
        self.act(2,*[Create(curve) for curve in curves],rate_func=linear)
        self.show(formula(r'\Delta L=k\lambda',[-3.1,-1.65,0],37,ROSE),
                  words('k — целое число; волны усиливаются',[-3.1,-2.45,0],23,MUTED,width=5.8),run_time=1.2)
        self.result(2)

        self.beat(3)
        target_y=wb_point_for_difference(WB_LAMBDA/2)
        base,rays,labels,geometry=wb_paths(target_y)
        delay=TAU*geometry['delta']/WB_LAMBDA
        drawing,curves=wb_field_graphs(delay)
        self.show(base,rays,formula(r'\Delta L=\lambda/2',[-3.1,2.05,0],35,GOLD),drawing,run_time=1.2)
        self.intro(3)
        self.act(3,*[Create(curve) for curve in curves],rate_func=linear)
        self.show(formula(r'\Delta L=(2k+1)\frac{\lambda}{2}',[-3.1,-1.65,0],33,ROSE),
                  words('Равные амплитуды: полное гашение',[-3.1,-2.55,0],23,MUTED,width=5.8),run_time=1.2)
        self.result(3)


class FarFieldDifference(WaveScene):
    chapter_id=5

    def chapter(self):
        self.beat(0)
        base,rays,labels,_=wb_paths(WB_MAX_Y)
        self.show(base,rays,labels,
                  words(['Одна наблюдаемая точка P',
                         'Каждый ход — длина своего отрезка'],[3.1,1.5,0],25),run_time=1.2)
        self.intro(0)
        exact=VGroup(formula(r'L_1=|S_1P|,\qquad L_2=|S_2P|',[3.1,.05,0],33),
                     formula(r'\Delta L=L_2-L_1',[3.1,-1.4,0],39,ROSE))
        self.act(0,FadeIn(exact))
        self.show(words('Это точное определение, без приближения',[0,-2.5,0],24,MUTED,width=11.8),run_time=1.2)
        self.result(0)

        self.beat(1)
        base,paths,projection,angle=wb_parallel_model()
        self.show(base,paths,
                  words(['Дальнепольная параллельная схема',
                         'Экран очень далеко от источников'],[3.1,1.55,0],24),
                  formula(r'd\ll R',[3.1,.45,0],38),run_time=1.2)
        self.intro(1)
        near_equal=formula(r'S_1P\approx HP',[3.1,-.7,0],37,GOLD)
        self.act(1,FadeIn(projection),Write(near_equal))
        self.show(formula(r'\Delta L\approx S_2H',[3.1,-1.9,0],38,ROSE),
                  words('R — расстояние до наблюдаемой области экрана',[0,2.35,0],22,MUTED,width=11.8),run_time=1.2)
        self.result(1)

        self.beat(2)
        base,paths,projection,angle=wb_parallel_model()
        self.show(base,paths,projection,
                  words('Общий угол направления — φ',[3.1,1.8,0],25),run_time=1.2)
        self.intro(2)
        ratio=formula(r'\sin\varphi=\frac{S_2H}{d}',[3.1,.65,0],40,LAVENDER)
        projection_formula=formula(r'S_2H=d\sin\varphi',[3.1,-.65,0],39,GOLD)
        self.act(2,FadeIn(angle),Succession(Write(ratio),Write(projection_formula)))
        self.show(formula(r'\Delta L\approx d\sin\varphi',[3.1,-1.95,0],39,ROSE),run_time=1.2)
        self.result(2)

        self.beat(3)
        base,paths,projection,angle=wb_parallel_model()
        self.show(base,paths,projection,angle,
                  formula(r'\Delta L\approx d\sin\varphi',[3.1,1.65,0],37,ROSE),
                  words('Источники синфазны; принято дальнее поле',[3.1,.65,0],23,MUTED),run_time=1.2)
        self.intro(3)
        maximum=formula(r'd\sin\varphi\approx k\lambda',[3.1,-.4,0],37,GOLD)
        minimum=formula(r'd\sin\varphi\approx(2k+1)\frac{\lambda}{2}',[3.1,-1.8,0],33,CYAN)
        self.act(3,Succession(Write(maximum),Write(minimum)))
        self.show(words('Условие дальнего поля не требует малого самого угла φ',[0,2.35,0],22,MUTED,width=11.8),run_time=1.2)
        self.result(3)
