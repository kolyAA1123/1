"""Grating maxima, finite-screen orders and thin-film reflection: pp6–9."""
from wave_style import *
from wave_math import grating_orders, screen_position, reflection_phase, thin_film_first_maximum


def wc_ray(start, end, color=CYAN, width=2.5):
    return Arrow(np.array(start, float), np.array(end, float), buff=0,
                 color=color, stroke_width=width, tip_length=.12,
                 max_tip_length_to_length_ratio=.18)


def wc_grating_cells():
    start, period, count = -5.5, .7, 6
    cells = VGroup()
    for j in range(count):
        x = start+j*period
        cells.add(Rectangle(width=period, height=1.6, color=GRID,
                            stroke_width=.7).move_to([x+period/2, .4, 0]),
                  Rectangle(width=.23, height=1.6, color=MUTED,
                            stroke_width=1, fill_color=MUTED,
                            fill_opacity=.45).move_to([x+.115, .4, 0]))
    return cells, start, period, count


def wc_screen_geometry(phi=.35):
    g = np.array([-5.2, -.6, 0.])
    ell = 4.4
    foot = g+RIGHT*ell
    point = foot+UP*(ell*np.tan(phi))
    plate = Line(g+DOWN*.7, g+UP*2.7, color=LAVENDER, stroke_width=3)
    screen = Line([foot[0], -1.5, 0], [foot[0], 2.1, 0], color=INK, stroke_width=2)
    normal = DashedLine(g, foot, color=MUTED, dash_length=.09, stroke_width=1.3)
    length = VGroup(DoubleArrow([g[0], -1.2, 0], [foot[0], -1.2, 0], buff=0,
                                color=MUTED, stroke_width=1.6,
                                max_tip_length_to_length_ratio=.06),
                    formula(r'\ell', [(g[0]+foot[0])/2, -1.55, 0], 28, MUTED, width=.5))
    labels = VGroup(words('Решётка', [g[0], 2.25, 0], 21, MUTED, width=1.8),
                    words('Экран', [foot[0], 2.3, 0], 21, MUTED, width=1.4),
                    formula('O', g+[-.22, -.3, 0], 24, MUTED, width=.5))
    ray = wc_ray(g, point, GOLD)
    height = VGroup(DoubleArrow(foot+RIGHT*.24, point+RIGHT*.24, buff=0,
                                color=CYAN, stroke_width=1.7,
                                max_tip_length_to_length_ratio=.16),
                    formula('x', [(point[0]+.65), (point[1]+foot[1])/2, 0], 29, CYAN, width=.5),
                    Dot(point, radius=.045, color=GOLD))
    angle = VGroup(Arc(radius=.75, start_angle=0, angle=phi,
                       color=GOLD, stroke_width=1.8).shift(g),
                   formula(r'\varphi', g+[1.05, .16, 0], 25, GOLD, width=.5))
    return VGroup(plate, screen, normal, length, labels), ray, height, angle


def wc_film():
    """One shared Snell/reflection geometry; E phase is taught separately."""
    n1, n, n2 = 1., 1.6, 1.33
    alpha = .18
    beta = np.arcsin(n1*np.sin(alpha)/n)
    top, bottom = .45, -.9
    A = np.array([-3.65, top, 0.])
    B = A+np.array([(top-bottom)*np.tan(beta), bottom-top, 0])
    C = B+np.array([(top-bottom)*np.tan(beta), top-bottom, 0])
    up = np.array([np.sin(alpha), np.cos(alpha), 0])
    region = Rectangle(width=5.15, height=top-bottom, color=LAVENDER,
                       stroke_width=0, fill_color=LAVENDER,
                       fill_opacity=.08).move_to([-3.2, (top+bottom)/2, 0])
    boundaries = VGroup(Line([-5.75, top, 0], [-.6, top, 0], color=INK, stroke_width=1.6),
                        Line([-5.75, bottom, 0], [-.6, bottom, 0], color=INK, stroke_width=1.6))
    normal = DashedLine([A[0], -1.45, 0], [A[0], 2.2, 0], color=GRID,
                        dash_length=.08, stroke_width=1.2)
    media = VGroup(words('Воздух', [-5.15, 1.75, 0], 21, MUTED, width=1.6),
                   formula('n', [-1.2, -.2, 0], 31, LAVENDER, width=.5),
                   words('Вода', [-5.15, -1.5, 0], 21, MUTED, width=1.6))
    thickness = VGroup(DoubleArrow([-5.48, bottom, 0], [-5.48, top, 0], buff=0,
                                   color=MUTED, stroke_width=1.5,
                                   max_tip_length_to_length_ratio=.12),
                       formula('d', [-5.9, (top+bottom)/2, 0], 27, MUTED, width=.5))
    points = VGroup(Dot(A, radius=.04, color=GOLD), Dot(B, radius=.04, color=GOLD),
                    Dot(C, radius=.04, color=GOLD),
                    formula('A', A+[-.28, .38, 0], 24, GOLD, width=.5),
                    formula('B', B+[.28, -.32, 0], 24, GOLD, width=.5),
                    formula('C', C+[.36, .38, 0], 24, GOLD, width=.5))
    incident = wc_ray(A+[-1.8*np.sin(alpha), 1.8*np.cos(alpha), 0], A, INK)
    first = wc_ray(A, A+up*1.8, ROSE)
    inward = wc_ray(A, B, CYAN)
    upward = wc_ray(B, C, CYAN)
    second = wc_ray(C, C+up*1.8, CYAN)
    ray_names = VGroup(formula('1', first.get_end()+[-.12, .22, 0], 24, ROSE, width=.4),
                       formula('2', second.get_end()+[.12, .22, 0], 24, CYAN, width=.4))
    assert np.allclose((first.get_end()-first.get_start())/1.8, up)
    assert np.allclose((second.get_end()-second.get_start())/1.8, up)
    return dict(base=VGroup(region, boundaries, normal, media, thickness),
                points=points, incident=incident, first=first, inward=inward,
                upward=upward, second=second, names=ray_names)


def wc_field_plot(center_y, y_name=r'E/E_{\max}'):
    ax = axes((0, TAU, PI/2), (-1.25, 1.25, .5), 4.7, 1.05,
              np.array([-3.2, center_y, 0.]))
    ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
    names = VGroup(formula(y_name, [-5.3, center_y+.68, 0], 22, MUTED, width=2.0),
                   formula('t', ax.x_axis.get_end()+RIGHT*.24, 22, MUTED, width=.35))
    return ax, VGroup(ax, names)


class GratingPeriodAndMaxima(WaveScene):
    chapter_id = 6

    def chapter(self):
        self.beat(0)
        cells, start, period, _ = wc_grating_cells()
        cell = Rectangle(width=period, height=1.9, color=GOLD,
                          stroke_width=2).move_to([start+2.5*period, .4, 0])
        dim = VGroup(DoubleArrow([start+2*period, -1.05, 0],
                                 [start+3*period, -1.05, 0], buff=0,
                                 color=GOLD, stroke_width=1.8,
                                 max_tip_length_to_length_ratio=.2),
                     formula('d', [start+2.5*period, -1.55, 0], 31, GOLD, width=.5))
        self.show(cells, words('Вид на решётку', [-3.3, 1.95, 0], 23, MUTED),
                  words(['Прозрачные промежутки', 'Непрозрачные полосы'], [3.1, 1.1, 0], 27), run_time=1.2)
        self.intro(0)
        self.act(0, Create(cell), FadeIn(dim))
        self.show(words(['Период d — одна повторяющаяся ячейка',
                         'Прозрачная и непрозрачная части вместе'], [3.1, -1.2, 0], 24, GOLD), run_time=1.2)
        self.result(0)

        self.beat(1)
        cells, start, period, count = wc_grating_cells()
        end = start+count*period
        length = VGroup(DoubleArrow([start, -1.1, 0], [end, -1.1, 0], buff=0,
                                    color=MUTED, stroke_width=1.8,
                                    max_tip_length_to_length_ratio=.06),
                        formula('L', [(start+end)/2, -1.6, 0], 31, MUTED, width=.6))
        self.show(cells, length, words(['N полных одинаковых периодов',
                                       'L — их общая длина'], [3.1, 1.4, 0], 26), run_time=1.2)
        self.intro(1)
        self.act(1, Write(formula('L=Nd', [3.1, -.1, 0], 44)))
        self.show(formula(r'd=\frac{L}{N}', [3.1, -1.55, 0], 46, GOLD), run_time=1.2)
        self.result(1)

        self.beat(2)
        g = np.array([-4.7, -.2, 0.]);phi=.35
        plate = Line(g+DOWN*1.6, g+UP*1.7, color=LAVENDER, stroke_width=2.5)
        normal = DashedLine(g, g+RIGHT*3.7, color=MUTED, dash_length=.08, stroke_width=1.2)
        incoming = VGroup(*[wc_ray(g+[-1.15,y,0], g+[0,y,0], CYAN, 2)
                            for y in (-.6,0,.6)])
        outgoing = VGroup(*[wc_ray(g+[0,y,0], g+[0,y,0]+3.5*np.array([np.cos(phi),np.sin(phi),0]), GOLD, 2)
                            for y in (-.6,0,.6)])
        angle = VGroup(Arc(radius=.7,start_angle=0,angle=phi,color=GOLD,stroke_width=1.7).shift(g),
                       formula(r'\varphi',g+[.94,.15,0],24,GOLD,width=.45))
        self.show(plate, normal, incoming,
                  words(['Нормальное падение', 'Свет одной длины волны'], [3.1, 1.5, 0], 26), run_time=1.2)
        self.intro(2)
        self.act(2, Create(outgoing), FadeIn(angle),
                 Write(formula(r'\Delta L=d\sin\varphi', [3.1, .0, 0], 37)))
        self.show(formula(r'd\sin\varphi=k\lambda', [3.1, -1.4, 0], 39, GOLD),
                  formula(r'k=0,\ \pm1,\ \pm2,\ldots', [3.1, -2.3, 0], 29, MUTED), run_time=1.2)
        self.result(2)


class ScreenPositionsAndOrders(WaveScene):
    chapter_id = 7

    def chapter(self):
        self.beat(0)
        base, ray, height, angle = wc_screen_geometry(.35)
        self.show(base, words(['Плоский экран перпендикулярен оси',
                               'x — отклонение от центра'], [3.1, 1.3, 0], 25), run_time=1.2)
        self.intro(0)
        self.act(0, Create(ray), FadeIn(height), FadeIn(angle))
        self.show(formula(r'\tan\varphi=\frac{x}{\ell}', [3.1, -.65, 0], 43, GOLD),
                  words('Геометрическое соотношение', [3.1, -2.0, 0], 24, MUTED), run_time=1.2)
        self.result(0)

        self.beat(1)
        phi = np.arcsin(.12)
        base, ray, height, angle = wc_screen_geometry(phi)
        assert np.isclose(screen_position(1, 1/.12, 1, 4.4), 4.4*np.tan(phi))
        self.show(base, ray, height,
                  formula(r'd\sin\varphi=k\lambda', [3.1, 1.6, 0], 36),
                  words('Малые углы к оси', [3.1, .6, 0], 25, MUTED), run_time=1.2)
        self.intro(1)
        approx = formula(r'\sin\varphi\approx\tan\varphi=\frac{x}{\ell}', [3.1, -.45, 0], 34)
        self.act(1, Write(approx))
        self.show(formula(r'x_k\approx\frac{k\lambda\ell}{d}', [3.1, -1.85, 0], 43, GOLD), run_time=1.2)
        self.result(1)

        self.beat(2)
        gx, sx, ell = -4.5, -2.55, 1.95
        orders = grating_orders(3., 1.)['orders']
        plate = Line([gx,-2,0], [gx,2,0],color=LAVENDER,stroke_width=2.5)
        screen = Line([sx,-2.1,0],[sx,2.1,0],color=INK,stroke_width=2)
        normal = DashedLine([gx,0,0],[sx,0,0],color=MUTED,dash_length=.08)
        rays=VGroup();spots=VGroup()
        for order in orders:
            y=screen_position(order,3.,1.,ell)
            rays.add(wc_ray([gx,0,0],[sx,y,0],GOLD,1.8))
            spots.add(Dot([sx,y,0],radius=.055,color=GOLD),
                      formula(str(order),[sx+.48,y,0],24,GOLD,width=.7))
        self.show(plate,screen,normal,
                  words('Схема симметричных порядков',[-3.3,2.4,0],21,MUTED,width=5.2),
                  formula(r'|k|\lambda<d',[3.1,1.6,0],41),run_time=1.2)
        self.intro(2)
        self.act(2,Create(rays),FadeIn(spots),
                 Write(formula(r'k_{\max}=\left\lceil\frac{d}{\lambda}\right\rceil-1',[3.1,.35,0],36,GOLD)))
        self.show(formula(r'N_{\max}=2k_{\max}+1',[3.1,-.85,0],35),
                  words(['Равенство даёт направление 90°',
                         'На конечный экран оно не попадает'],[3.1,-2.1,0],22,MUTED),run_time=1.2)
        self.result(2)


class ThinFilmPathsAndPhase(WaveScene):
    chapter_id = 8

    def chapter(self):
        self.beat(0)
        f=wc_film()
        self.show(f['base'],f['incident'],f['points'],
                  words(['Плёнка на поверхности воды','d — толщина плёнки'],[3.1,1.6,0],26),
                  formula(r'n_1<n,\qquad n_2<n',[3.1,.2,0],34),run_time=1.2)
        self.intro(0)
        self.act(0,Succession(Create(f['first']),Create(f['inward']),
                             Create(f['upward']),Create(f['second'])),FadeIn(f['names']),rate_func=linear)
        self.show(words(['Два отражённых вклада','Выходящие лучи параллельны'],[3.1,-1.6,0],25,CYAN),run_time=1.2)
        self.result(0)

        self.beat(1)
        assert np.isclose(reflection_phase(1,1.6),PI)
        assert np.isclose(reflection_phase(1.6,1.33),0)
        upper,ubase=wc_field_plot(1.05)
        lower,lbase=wc_field_plot(-1.45)
        reference=VGroup(upper.plot(np.sin,x_range=[0,TAU,.025],color=MUTED,stroke_width=1.1),
                         lower.plot(np.sin,x_range=[0,TAU,.025],color=MUTED,stroke_width=1.1))
        reflected=VGroup(upper.plot(lambda t:-np.sin(t),x_range=[0,TAU,.025],color=ROSE,stroke_width=2.7),
                         lower.plot(np.sin,x_range=[0,TAU,.025],color=CYAN,stroke_width=2.7))
        self.show(ubase,lbase,reference,
                  words('Меньший n → больший n',[-3.1,2.2,0],22,ROSE,width=5),
                  words('Больший n → меньший n',[-3.1,-.25,0],22,CYAN,width=5),
                  words(['Серый — падающее поле','Цвет — отражённое поле'],[3.1,1.9,0],23,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,Create(reflected),
                 FadeIn(formula(r'\Delta\phi=\pi',[3.1,.75,0],40,ROSE)),
                 FadeIn(formula(r'\Delta\phi=0',[3.1,-.45,0],40,CYAN)),rate_func=linear)
        self.show(words(['«Потеря полуволны» — сдвиг фазы',
                         'Это не потеря половины энергии'],[3.1,-1.9,0],23,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        f=wc_film()
        paths=VGroup(f['first'],f['inward'],f['upward'],f['second'],f['names'])
        self.show(f['base'],f['incident'],f['points'],paths,
                  words(['Почти нормальное падение','λ₀ — длина волны в воздухе'],[3.1,1.7,0],24),
                  formula(r'AB+BC\approx2d',[3.1,.5,0],35),run_time=1.2)
        self.intro(2)
        self.act(2,Write(formula(r'n(AB+BC)\approx2nd',[3.1,-.65,0],35)))
        self.show(formula(r'\Delta L_{\mathrm{эфф}}\approx2nd+\frac{\lambda_0}{2}',[3.1,-1.95,0],35,GOLD),run_time=1.2)
        self.result(2)


class ThinFilmRedMaximum(WaveScene):
    chapter_id = 9

    def chapter(self):
        self.beat(0)
        ax=axes((0,TAU,PI/2),(-1.8,1.8,.6),4.8,2.8,np.array([-3.25,-.1,0]))
        ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
        names=VGroup(formula('E',[-5.55,1.65,0],27,MUTED,width=.5),
                     formula('t',ax.x_axis.get_end()+RIGHT*.25,25,MUTED,width=.4))
        first=ax.plot(np.sin,x_range=[0,TAU,.025],color=ROSE,stroke_width=1.8)
        second=ax.plot(lambda t:.6*np.sin(t),x_range=[0,TAU,.025],color=CYAN,stroke_width=1.8)
        total=ax.plot(lambda t:1.6*np.sin(t),x_range=[0,TAU,.025],color=GOLD,stroke_width=3)
        self.show(ax,names,first,second,
                  words('Схема колебаний поля',[-3.25,2.2,0],23,MUTED),
                  words(['Первый ненулевой максимум','Одна инверсия при отражении'],[3.1,1.6,0],25),
                  formula(r'\Delta L_{\mathrm{эфф}}=\lambda_0',[3.1,.25,0],37),run_time=1.2)
        self.intro(0)
        self.act(0,Create(total),rate_func=linear)
        self.show(formula(r'2nd+\frac{\lambda_0}{2}\approx\lambda_0',[3.1,-1.2,0],37,GOLD),
                  words('Вклады могут иметь разные амплитуды',[3.1,-2.35,0],21,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        self.show(words('Одно отражение меняет фазу; падение почти нормальное',[0,2.3,0],23,MUTED,width=12),
                  formula(r'2nd+\frac{\lambda_0}{2}\approx\lambda_0',[0,1.15,0],43,width=11.8),run_time=1.2)
        self.intro(1)
        middle=formula(r'2nd\approx\frac{\lambda_0}{2}',[0,-.2,0],44,width=11.8)
        result=formula(r'd\approx\frac{\lambda_0}{4n}',[0,-1.55,0],47,GOLD,width=11.8)
        self.act(1,Succession(Write(middle),Write(result)))
        self.show(words('Первый максимум отражённого света',[0,-2.6,0],25,MUTED,width=11.8),run_time=1.2)
        self.result(1)

        self.beat(2)
        value=thin_film_first_maximum(760.,1.6)
        assert np.isclose(value,118.75)
        self.show(formula(r'\lambda_0=760\ \mathrm{нм}',[-3.1,1.5,0],39,ROSE),
                  formula(r'n=1{,}6',[-3.1,.1,0],39),
                  formula(r'd\approx\frac{\lambda_0}{4n}',[3.1,1.5,0],43),run_time=1.2)
        self.intro(2)
        red=Rectangle(width=3.3,height=.3,color=RED,fill_color=RED,fill_opacity=.65).move_to([-3.1,-1.45,0])
        substitution=formula(r'd\approx\frac{760}{4\cdot1{,}6}\ \mathrm{нм}',[3.1,.05,0],38)
        self.act(2,Write(substitution),FadeIn(red))
        self.show(formula(r'd\approx118{,}75\ \mathrm{нм}\approx119\ \mathrm{нм}',[3.1,-1.4,0],35,GOLD),
                  words('Усиленный красный компонент',[-3.1,-2.05,0],22,ROSE),
                  words('Другие составляющие отражённого света не обязаны исчезать',[0,-2.8,0],23,MUTED,width=12),run_time=1.2)
        self.result(2)
