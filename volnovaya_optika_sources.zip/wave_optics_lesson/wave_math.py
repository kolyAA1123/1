"""Scalar wave geometry and the source's stated model conditions."""
import math


def two_source_paths(d, ell, y):
    """S1=(0,+d/2),S2=(0,-d/2),P=(ell,y); delta=L2-L1."""
    if d<=0 or ell<=0:raise ValueError('Positive separation and screen distance required')
    L1=math.hypot(ell,y-d/2)
    L2=math.hypot(ell,y+d/2)
    angle=math.atan2(y,ell)
    delta=2*d*y/(L1+L2)
    return dict(d=d,ell=ell,y=y,L1=L1,L2=L2,delta=delta,angle=angle,
                far_field=d*math.sin(angle),far_field_ratio=d/math.hypot(ell,y))


def phase_pair(theta,delay):
    """Fields for equal-amplitude sources: E1=cos(theta),E2=cos(theta-delay).

    delay=2*pi*delta/lambda is the propagation lag of path2, not E2's
    signed phase minus E1's phase. Returns E1,E2 and their sum.
    """
    a=math.cos(theta);b=math.cos(theta-delay)
    return a,b,a+b


def grating_orders(d,wavelength):
    """Directions reaching a forward flat screen require abs(k)*lambda<d."""
    if d<=0 or wavelength<=0:raise ValueError('Positive d and wavelength required')
    ratio=d/wavelength
    nearest=round(ratio)
    if abs(ratio-nearest)<=8*math.ulp(ratio):ratio=float(nearest)
    maximum=max(0,math.ceil(ratio)-1)
    orders=list(range(-maximum,maximum+1))
    return dict(ratio=ratio,max_order=maximum,orders=orders,count=len(orders))


def screen_position(order,d,wavelength,ell,small_angle=False):
    """Exact screen geometry; the approximate position must be chosen explicitly."""
    if d<=0 or wavelength<=0 or ell<=0:raise ValueError('Positive lengths required')
    sine=order*wavelength/d
    if abs(sine)>=1:raise ValueError('No finite forward-screen position')
    return ell*sine if small_angle else ell*math.tan(math.asin(sine))


def reflection_phase(n_from,n_to):
    """Dielectric reflection at small incidence; equal indices give no reflected wave."""
    if min(n_from,n_to)<=0 or n_from==n_to:raise ValueError('Distinct positive indices required')
    return math.pi if n_to>n_from else 0.


def thin_film_first_maximum(wavelength0,n):
    """First reflected maximum: one phase inversion, nearly normal incidence."""
    if wavelength0<=0 or n<=0:raise ValueError('Positive wavelength and index required')
    return wavelength0/(4*n)
