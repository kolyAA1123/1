from pathlib import Path
import math

import numpy as np
from manim import (
    Axes, Create, DashedLine, Dot, FadeIn, FadeOut, Line, Polygon,
    Scene, VGroup, config, smootherstep,
)

from lesson_data import SECTIONS
from visual_style import (
    BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt,
)

config.background_color = BLACK_BG
config.pixel_width = 1920
config.pixel_height = 1080
config.frame_rate = 60

CENTER = np.array([-3.62, -0.33, 0])
TITLE = "Производная и первообразная"



def chart(xmin,xmax,ymin,ymax):
    return Axes(
        x_range=[xmin,xmax,1], y_range=[ymin,ymax,1], x_length=5.22, y_length=3.5,
        axis_config={"stroke_width": 1.55, "color": MUTED, "include_ticks": False},
        tips=True,
    ).move_to(CENTER)


def diagram(spec):
    if spec is None:
        return VGroup(), VGroup()
    if spec in ("tangent","secant"):
        axes=chart(-.7,2.75,-1.3,5.2)
        graph=axes.plot(lambda x:x*x,x_range=[-.57,2.22],color=CYAN,stroke_width=3.3)
        tangent=axes.plot(lambda x:2*x-1,x_range=[.0,2.47],color=GOLD,stroke_width=3)
        if spec=="secant":
            secant=axes.plot(lambda x:3*x-2,x_range=[.27,2.36],color=LAVENDER,stroke_width=2.5)
            marker=VGroup(Dot(axes.c2p(2,4),color=LAVENDER,radius=.061),secant,tangent)
        else:
            marker=VGroup(tangent,
                DashedLine(axes.c2p(1,1),axes.c2p(2,1),color=GOLD,stroke_width=2),
                DashedLine(axes.c2p(2,1),axes.c2p(2,3),color=GOLD,stroke_width=2))
        return VGroup(axes,graph,Dot(axes.c2p(1,1),color=INK,radius=.066)),marker
    if spec in ("sign","extrema"):
        axes=chart(-2.4,2.4,-3.35,3.35)
        if spec=="sign":
            curve=axes.plot(lambda x:3*x*x-3,x_range=[-1.43,1.43],color=CYAN,stroke_width=3)
        else:
            curve=axes.plot(lambda x:x**3-3*x,x_range=[-2.12,2.12],color=CYAN,stroke_width=3)
        ys=(0,0) if spec=="sign" else (2,-2)
        markers=VGroup(*[Dot(axes.c2p(x,y),color=GOLD,radius=.07) for x,y in zip((-1,1),ys)])
        if spec=="sign":
            for x in (-1,1):
                markers.add(equation(str(x),INK,axes.c2p(x,0)+[0,-.3,0],.23))
        return VGroup(axes,curve),markers
    if spec=="integral":
        axes=chart(-.55,3.45,-.65,3.5)
        curve=axes.plot(lambda x:x,x_range=[-.44,3.21],color=CYAN,stroke_width=3.1)
        fill=Polygon(axes.c2p(0,0),axes.c2p(2,0),axes.c2p(2,2),
                     color=GOLD,stroke_width=2,fill_opacity=.18)
        marks=VGroup(fill, equation("2",INK,axes.c2p(2,0)+[0,-.24,0],.22))
        return VGroup(axes,curve), marks
    if spec=="parameters":
        axes=chart(-7,13,-23,13)
        plus=lambda x:.5*x*x-6*x
        minus=lambda x:-.5*x*x-2*x
        both=VGroup(*[
            axes.plot(fn,x_range=[lo,hi,.07],color=color,stroke_width=3.2)
            for fn,color,ranges in [(plus,CYAN,[(-1.8,0),(4,12.25)]),
                                   (minus,LAVENDER,[(-6.9,0),(4,5.07)])]
            for lo,hi in ranges
        ])
        marks=VGroup(
            *[Dot(axes.c2p(x,y),color=GOLD,radius=.055) for x,y in [(-2,2),(6,-18),(0,0),(4,-16)]],
            *[equation(value, color, axes.c2p(x,y)+[dx,dy,0],.23)
              for value,color,x,y,dx,dy in [('2',LAVENDER,-2,2,0,.24),('-18',CYAN,6,-18,0,-.25),
                                           ('-16',INK,4,-16,-.37,.04)]]
        )
        return VGroup(axes,both),marks
    raise ValueError(spec)


def timestamp(seconds):
    point = round(seconds)
    return f"{point // 60:02d}:{point % 60:02d}"


class DerivativeLesson(Scene):
    def construct(self):
        heading = txt(TITLE, 27).to_corner(np.array([-1,1,0]), buff=.38)
        rule = Line([-6.57, 2.79, 0], [6.57, 2.79, 0], color=GRID, stroke_width=1.3)
        self.play(FadeIn(heading), Create(rule), run_time=1.2, rate_func=smootherstep)
        script = [TITLE, "Сценарий для озвучки"]
        for number, (title, spec, beats) in enumerate(SECTIONS, 1):
            subtitle = txt(title, 25, MUTED).move_to([0,2.37,0])
            count = txt(f"{number:02d} / {len(SECTIONS):02d}", 16, MUTED).move_to([6.06,3.51,0])
            base, marks = diagram(spec)
            before = [subtitle, count]
            if len(base):
                before.append(base)
            self.play(*[FadeIn(mob) for mob in before], run_time=.88, rate_func=smootherstep)
            script.extend(["", title])
            centers = np.linspace(1.2,-1.56,len(beats))
            center_x = 3.28 if spec is not None else 0
            limit = 6.65 if spec is not None else 12.25
            for i, ((formula, text), y) in enumerate(zip(beats, centers)):
                color = (INK, CYAN, GOLD, LAVENDER)[i]
                height = .67 if "\\frac" in formula else .49
                visual = equation(formula, color, [center_x,y,0], height)
                if visual.width > limit:
                    visual.scale_to_fit_width(limit)
                add = [visual]
                if i==0 and len(marks):
                    add.append(marks)
                self.play(*[FadeIn(mob, shift=np.array([0,.04,0])) for mob in add],
                          run_time=.65, rate_func=smootherstep)
                before.extend(add)
                start = timestamp(self.time)
                self.wait(math.ceil(len(text.split())/2.15)+1)
                script.extend([f"[{start}–{timestamp(self.time)}]", text])
            self.play(*[FadeOut(mob) for mob in before], run_time=.70, rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        Path("derivative_narration.txt").write_text("\n".join(script)+"\n", encoding="utf-8-sig")
