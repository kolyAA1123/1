#!/usr/bin/env bash
# Source this file before installing or rendering this Manim project.
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TOOLCHAIN_DIR="$(dirname -- "$PROJECT_DIR")/toolchain"
export PROJECT_DIR TOOLCHAIN_DIR
export UV_CACHE_DIR="$TOOLCHAIN_DIR/cache/uv"
export XDG_CACHE_HOME="$TOOLCHAIN_DIR/cache"
export MPLCONFIGDIR="$TOOLCHAIN_DIR/cache/matplotlib"
export TEXMFVAR="$TOOLCHAIN_DIR/cache/texmf-var"
export TEXMFCONFIG="$TOOLCHAIN_DIR/cache/texmf-config"
export ESPEAK_DATA_PATH="$TOOLCHAIN_DIR/root/usr/lib/x86_64-linux-gnu/espeak-ng-data"
export PATH="$PROJECT_DIR/.venv/bin:$TOOLCHAIN_DIR/root/usr/bin:$PATH"
export PKG_CONFIG_PATH="$TOOLCHAIN_DIR/root/usr/lib/x86_64-linux-gnu/pkgconfig:$TOOLCHAIN_DIR/root/usr/share/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"
export PKG_CONFIG_SYSROOT_DIR="$TOOLCHAIN_DIR/root"
export LD_LIBRARY_PATH="$TOOLCHAIN_DIR/root/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
