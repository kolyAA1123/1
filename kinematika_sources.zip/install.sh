#!/usr/bin/env bash
# Debian 13 user-local dependencies; no sudo or system package changes.
set -euo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TOOLCHAIN_DIR="$(dirname -- "$PROJECT_DIR")/toolchain"
mkdir -p "$TOOLCHAIN_DIR"/{apt/lists/partial,apt/archives/partial,apt/sourceparts,apt/apt.conf.d,root,cache,tmp}
cat > "$TOOLCHAIN_DIR/apt/sources.list" <<'SOURCES'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://security.debian.org/debian-security trixie-security main
SOURCES
cat > "$TOOLCHAIN_DIR/apt/apt.conf" <<CONFIG
Dir::Etc::sourcelist "$TOOLCHAIN_DIR/apt/sources.list";
Dir::Etc::sourceparts "$TOOLCHAIN_DIR/apt/sourceparts";
Dir::Etc::parts "$TOOLCHAIN_DIR/apt/apt.conf.d";
Dir::State::lists "$TOOLCHAIN_DIR/apt/lists";
Dir::State::status "$TOOLCHAIN_DIR/apt/status";
Dir::Cache::archives "$TOOLCHAIN_DIR/apt/archives";
Dir::Cache::pkgcache "$TOOLCHAIN_DIR/apt/pkgcache.bin";
Dir::Cache::srcpkgcache "$TOOLCHAIN_DIR/apt/srcpkgcache.bin";
APT::Sandbox::User "$(id -un)";
Acquire::Retries "3";
APT::Install-Recommends "false";
APT::Install-Suggests "false";
CONFIG
cp /var/lib/dpkg/status "$TOOLCHAIN_DIR/apt/status"
export APT_CONFIG="$TOOLCHAIN_DIR/apt/apt.conf"
/usr/bin/apt-get update
/usr/bin/apt-get --download-only --no-install-recommends -y install \
  libcairo2-dev libpango1.0-dev libglib2.0-dev libharfbuzz-dev libffi-dev dvisvgm espeak-ng
# These runtime packages supply the targets of the development symlinks.
/usr/bin/apt-get --download-only --no-install-recommends --reinstall -y install \
  libcairo2 libpango-1.0-0 libpangocairo-1.0-0 libpangoft2-1.0-0 \
  libglib2.0-0t64 libharfbuzz0b libfontconfig1 libfreetype6
for deb in "$TOOLCHAIN_DIR"/apt/archives/*.deb; do
  dpkg-deb --extract "$deb" "$TOOLCHAIN_DIR/root"
done
source "$PROJECT_DIR/setup_env.sh"
export TMPDIR="$TOOLCHAIN_DIR/tmp"
export CC=gcc CXX=g++
if [[ ! -x "$PROJECT_DIR/.venv/bin/python" ]]; then
  uv venv --python python3 "$PROJECT_DIR/.venv"
fi
if [[ -f "$PROJECT_DIR/requirements.lock" ]]; then
  uv pip install --python "$PROJECT_DIR/.venv/bin/python" -r "$PROJECT_DIR/requirements.lock"
else
  uv pip install --python "$PROJECT_DIR/.venv/bin/python" 'manim==0.21.0'
fi
python -m manim --version
dvisvgm --version
printf 'Ready. Source %s/setup_env.sh before rendering.\n' "$PROJECT_DIR"
