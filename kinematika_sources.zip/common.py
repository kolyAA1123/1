"""Shared visual system and narration clock for the kinematics film."""
from pathlib import Path
import json
import numpy as np
from manim import *

ROOT = Path(__file__).resolve().parent
BG = "#000000"
INK = "#EDF2FA"
MUTED = "#9AAAC0"
CYAN = "#58DCE6"
GOLD = "#FFD071"
ROSE = "#F17C95"
LAVENDER = "#A394FA"
GRID = "#28354A"
FONT = "DejaVu Sans"
DURATIONS = [45, 65, 55, 55, 55, 60, 60, 70, 65, 45, 50, 35]
TITLES = ["Язык движения", "Путь и перемещение", "Скорость", "Ускорение", "Постоянное ускорение", "Читаем графики", "Свободное падение", "Полёт по параболе", "Движение по окружности", "Относительное движение", "Решаем задачу", "Одна картина движения"]

def label(text, size=26, color=INK, **kwargs):
    return Text(text, font=FONT, font_size=size, color=color, **kwargs)

def equation(tex, size=36, color=INK, **kwargs):
    return MathTex(tex, font_size=size, color=color, **kwargs)

def axes_2d(x_range=(0, 6, 1), y_range=(0, 4, 1), width=6.0, height=3.6, center=LEFT*2.4+DOWN*.2):
    ax = Axes(x_range=x_range, y_range=y_range, x_length=width, y_length=height,
              axis_config={"color": MUTED, "stroke_width": 1.4, "include_tip": True,
                           "tip_width": .12, "tip_height": .12}, tips=True)
    ax.move_to(center)
    return ax

def velocity_arrow(start, vector, color=CYAN, width=3):
    vector = np.asarray(vector, dtype=float)
    if np.linalg.norm(vector) < .025:
        vector = np.array([.025, 0, 0])
    return Arrow(start, np.asarray(start)+vector, buff=0, color=color, stroke_width=width,
                 max_tip_length_to_length_ratio=.22)

def car(color=CYAN):
    body = RoundedRectangle(width=.75, height=.25, corner_radius=.06, stroke_width=2, color=color)
    roof = VMobject(color=color, stroke_width=2).set_points_as_corners([
        [-.23,.13,0],[-.13,.3,0],[.14,.3,0],[.27,.13,0]])
    wheels = VGroup(*[Circle(radius=.075, color=INK, stroke_width=2).move_to([x,-.16,0]) for x in [-.23,.23]])
    return VGroup(body,roof,wheels)

class LessonScene(MovingCameraScene):
    chapter_id = 1

    def construct(self):
        self.camera.background_color = BG
        self.chapter_duration = DURATIONS[self.chapter_id-1]
        self.chapter_start = self.time
        self.note_mob = None
        self.header = label(TITLES[self.chapter_id-1], size=27).to_edge(UP, buff=.28).to_edge(LEFT, buff=.52)
        self.number = label(f"{self.chapter_id:02d} / 12", size=18, color=MUTED).to_edge(UP, buff=.34).to_edge(RIGHT, buff=.52)
        self.rule = Line([-6.55,2.97,0],[6.55,2.97,0],color=GRID,stroke_width=1)
        self.add(self.header, self.number, self.rule)
        self.chapter()
        remaining = self.chapter_duration - (self.time-self.chapter_start)
        if remaining < -.12:
            raise RuntimeError(f"Chapter {self.chapter_id} overran by {-remaining:.2f}s")
        if remaining >= .6:
            self.wait(remaining-.6)
            self.play(*[FadeOut(m) for m in list(self.mobjects)],run_time=.6)
        elif remaining > 0:
            self.wait(remaining)

    def cue(self, index, note=None):
        target = self.chapter_duration*index/5
        elapsed = self.time-self.chapter_start
        if elapsed < target:
            self.wait(target-elapsed)
        elif elapsed > target+.3:
            raise RuntimeError(f"Chapter {self.chapter_id} cue {index} late: {elapsed:.2f}>{target:.2f}")
        if note is not None:
            new = label(note, size=23, color=MUTED).move_to([0,-3.36,0])
            if new.width > 12.5:
                new.scale_to_fit_width(12.5)
            if self.note_mob is not None:
                self.play(FadeOut(self.note_mob), FadeIn(new), run_time=.35)
            else:
                self.play(FadeIn(new),run_time=.35)
            self.note_mob=new

    def clear_stage(self, keep=()):
        protected = [self.header,self.number,self.rule,self.note_mob,*keep]
        fading = [m for m in list(self.mobjects) if all(m is not x for x in protected)]
        if fading:
            self.play(*[FadeOut(m) for m in fading],run_time=.6)

    def chapter(self):
        raise NotImplementedError
