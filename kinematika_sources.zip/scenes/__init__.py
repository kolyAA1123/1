"""Narrated chapters of the kinematics lesson."""
