"""Circular and relative motion, a worked example, and the closing synthesis."""
from common import *


class CircularMotionScene(LessonScene):
    chapter_id = 9

    def chapter(self):
        self.cue(0, "Радиус-вектор идёт от центра к точке, а скорость направлена по касательной")
        center = np.array([-2.8, -.15, 0.])
        radius = 1.9
        theta = ValueTracker(.35)
        theta.add_updater(lambda m, dt: m.increment_value(.58 * dt))
        self.add(theta)
        position = lambda: center + radius * np.array([
            np.cos(theta.get_value()), np.sin(theta.get_value()), 0.])
        tangent = lambda: np.array([-np.sin(theta.get_value()), np.cos(theta.get_value()), 0.])
        inward = lambda: -np.array([np.cos(theta.get_value()), np.sin(theta.get_value()), 0.])
        orbit = Circle(radius=radius, color=GRID, stroke_width=2).move_to(center)
        cross = VGroup(Line(center + LEFT*.13, center + RIGHT*.13, color=MUTED, stroke_width=1.5),
                       Line(center + DOWN*.13, center + UP*.13, color=MUTED, stroke_width=1.5))
        point = Dot(position(), radius=.085, color=INK)
        point.add_updater(lambda m: m.move_to(position()))
        radial = always_redraw(lambda: Line(center, position(), color=GOLD, stroke_width=2))
        r_label = equation("R", size=31, color=GOLD)
        r_label.add_updater(lambda m: m.move_to((center + position())/2 + .19*tangent()))
        origin_label = equation("O", size=24, color=MUTED).move_to(center + DL*.25)
        geometry = VGroup(orbit, cross, radial, point, r_label, origin_label)
        v_arrow = always_redraw(lambda: velocity_arrow(position(), 1.12*tangent(), CYAN, 3))
        self.play(Create(orbit), FadeIn(cross, origin_label), Create(radial), FadeIn(point, r_label, v_arrow), run_time=1.8)
        constant = label("Равномерное движение", size=26).move_to([2.9, 2.05, 0])
        speed_const = equation(r"|\vec v|=\mathrm{const}", size=37, color=CYAN).move_to([2.9, 1.25, 0])
        self.play(FadeIn(constant, speed_const), run_time=.8)
        self.wait(6)

        self.cue(1, "Период — время оборота; частота — число оборотов за секунду")
        definitions = VGroup(
            equation(r"T\;:\;\Delta\varphi=2\pi", size=37, color=GOLD),
            equation(r"\nu=\frac{1}{T}", size=43, color=LAVENDER),
            equation(r"[\nu]=\mathrm{Hz}", size=30, color=MUTED),
        ).arrange(DOWN, buff=.5).move_to([2.9,.15,0])
        self.play(FadeOut(speed_const), FadeIn(definitions), run_time=1)
        self.wait(9)

        self.cue(2, "За период радиус-вектор поворачивается на два пи радиан")
        angular = VGroup(
            equation(r"\omega=\frac{\Delta\varphi}{\Delta t}", size=43, color=CYAN),
            equation(r"\omega=\frac{2\pi}{T}=2\pi\nu", size=40, color=CYAN),
            equation(r"[\omega]=\mathrm{rad/s}", size=29, color=MUTED),
        ).arrange(DOWN, buff=.5).move_to([2.9,.15,0])
        self.play(ReplacementTransform(definitions, angular), run_time=1)
        self.wait(8.5)

        self.cue(3, "При одинаковой угловой скорости линейная скорость пропорциональна радиусу")
        relationships = VGroup(
            equation(r"v=\omega R", size=44, color=CYAN),
            equation(r"s=R\varphi", size=39, color=GOLD),
            label("Одинаковый угол — разная длина дуги", size=20, color=MUTED),
        ).arrange(DOWN, buff=.5).move_to([2.9,.12,0])
        self.play(ReplacementTransform(angular, relationships), run_time=1)
        self.wait(8.5)

        self.cue(4, "Модуль скорости постоянен, но изменение направления даёт ускорение")
        a_arrow = always_redraw(lambda: velocity_arrow(position(), .9*inward(), ROSE, 3))
        self.add(a_arrow)
        comparison_origin = np.array([3.0,-1.35,0.])
        one = np.array([.57,1.42,0.])
        two = np.array([-.57,1.42,0.])
        comparison = VGroup(
            velocity_arrow(comparison_origin, one, CYAN),
            velocity_arrow(comparison_origin, two, LAVENDER),
            velocity_arrow(comparison_origin+one, two-one, ROSE),
            equation(r"\vec v_1", size=25, color=CYAN).move_to(comparison_origin+one+RIGHT*.31),
            equation(r"\vec v_2", size=25, color=LAVENDER).move_to(comparison_origin+two+LEFT*.31),
            equation(r"\Delta\vec v", size=26, color=ROSE).move_to(comparison_origin+UP*1.7),
            equation(r"a=\frac{v^2}{R}=\omega^2R", size=35, color=ROSE).move_to([3,-2.35,0]),
        )
        unchanged = equation(r"|\vec v_1|=|\vec v_2|,\quad \vec v_1\ne\vec v_2", size=31).move_to([2.9,1.3,0])
        self.play(FadeOut(relationships), FadeIn(comparison, unchanged), run_time=1.2)
        self.wait(9)
        theta.clear_updaters()


class RelativeMotionScene(LessonScene):
    chapter_id = 10

    def chapter(self):
        self.cue(0, "Два тела движутся вдоль одной прямой: A быстрее, B медленнее")
        road_y = .2
        sf = .32
        t = ValueTracker(0)
        model = {"a": -5., "b": 2., "va": 3., "vb": 1., "frame": 0.}
        position_a = lambda: np.array([model["a"]+sf*(model["va"]-model["frame"])*t.get_value(),road_y,0.])
        position_b = lambda: np.array([model["b"]+sf*(model["vb"]-model["frame"])*t.get_value(),road_y,0.])

        def new_model(va, vb, frame):
            model["a"], model["b"] = float(position_a()[0]), float(position_b()[0])
            model["va"], model["vb"], model["frame"] = va, vb, frame
            t.set_value(0)

        road = Line([-5.9,road_y-.23,0],[5.9,road_y-.23,0],color=MUTED,stroke_width=1.5)
        ticks = VGroup(*[Line([x,road_y-.23,0],[x,road_y-.36,0],color=GRID,stroke_width=1) for x in np.arange(-5.6,5.7,.7)])
        base_tick_positions = [m.get_center().copy() for m in ticks]
        for tick, base in zip(ticks, base_tick_positions):
            tick.add_updater(lambda m, base=base: m.move_to(base- sf*model["frame"]*t.get_value()*RIGHT))
        auto_a, auto_b = car(CYAN), car(GOLD)
        auto_a.add_updater(lambda m: m.move_to(position_a()))
        auto_b.add_updater(lambda m: m.move_to(position_b()))
        name_a, name_b = equation("A",size=27,color=CYAN), equation("B",size=27,color=GOLD)
        name_a.add_updater(lambda m: m.move_to(position_a()+DOWN*.7))
        name_b.add_updater(lambda m: m.move_to(position_b()+DOWN*.7))
        a_arrow = always_redraw(lambda: velocity_arrow(position_a()+UP*.55, RIGHT*.45*(model["va"]-model["frame"]), CYAN))
        b_arrow = always_redraw(lambda: velocity_arrow(position_b()+UP*.55, RIGHT*.45*(model["vb"]-model["frame"]), GOLD).set_opacity(0 if model["vb"]==model["frame"] else 1))
        speeds = equation(r"v_A=+3\,\mathrm{m/s},\qquad v_B=+1\,\mathrm{m/s}",size=34).move_to([0,1.95,0])
        frame_label = label("Система отсчёта: Земля",size=23,color=MUTED).move_to([0,-1.55,0])
        self.add(t)
        self.play(Create(road), FadeIn(ticks,auto_a,auto_b,name_a,name_b,a_arrow,b_arrow,speeds,frame_label),run_time=1.1)
        self.play(t.animate.set_value(1.5),run_time=4.5,rate_func=linear)

        self.cue(1, "В системе B второй автомобиль покоится, а скорость A равна разности скоростей")
        subtraction = equation(r"v_{A/B}=v_A-v_B=3-1=2\,\mathrm{m/s}",size=39,color=CYAN).move_to([0,-2.35,0])
        new_model(3,1,1)
        b_frame = label("Система отсчёта: тело B",size=23,color=GOLD).move_to(frame_label)
        new_speeds = equation(r"v'_{A}=+2\,\mathrm{m/s},\qquad v'_{B}=0",size=34).move_to(speeds)
        self.play(ReplacementTransform(frame_label,b_frame),ReplacementTransform(speeds,new_speeds),Write(subtraction),run_time=1.1)
        self.play(t.animate.set_value(2.2),run_time=5,rate_func=linear)

        self.cue(2, "В одну сторону вычитаем модули; навстречу — учитываем отрицательную скорость B")
        new_model(3,-1,0)
        earth_frame = label("Система отсчёта: Земля",size=23,color=MUTED).move_to(b_frame)
        opposing = equation(r"v_A=+3\,\mathrm{m/s},\qquad v_B=-1\,\mathrm{m/s}",size=34).move_to(new_speeds)
        relative_four = equation(r"v_{A/B}=3-(-1)=4\,\mathrm{m/s}",size=39,color=CYAN).move_to(subtraction)
        self.play(ReplacementTransform(b_frame,earth_frame),ReplacementTransform(new_speeds,opposing),ReplacementTransform(subtraction,relative_four),run_time=1)
        self.play(t.animate.set_value(1.2),run_time=4.6,rate_func=linear)

        self.cue(3, "На плоскости вычитание выполняется для векторов: от конца B к концу A")
        for mob in (auto_a,auto_b,name_a,name_b,a_arrow,b_arrow):
            mob.clear_updaters()
        self.play(FadeOut(road,ticks,auto_a,auto_b,name_a,name_b,a_arrow,b_arrow,earth_frame,opposing,relative_four),run_time=.7)
        planar_origin=np.array([-3.5,-1.5,0.])
        va=np.array([3.5,2.6,0.])
        vb=np.array([1.5,.4,0.])
        planar=VGroup(
            velocity_arrow(planar_origin,va,CYAN),
            velocity_arrow(planar_origin,vb,GOLD),
            velocity_arrow(planar_origin+vb,va-vb,LAVENDER),
            equation(r"\vec v_A",size=30,color=CYAN).move_to(planar_origin+va+UL*.3),
            equation(r"\vec v_B",size=30,color=GOLD).move_to(planar_origin+vb+DOWN*.35),
            equation(r"\vec v_{A/B}",size=30,color=LAVENDER).move_to(planar_origin+vb+(va-vb)/2+RIGHT*.55),
            equation(r"\vec v_{A/B}=\vec v_A-\vec v_B",size=39).move_to([2.5,1.5,0]),
            label("Одна точка начала\nДве скорости\nИх векторная разность",size=24,color=MUTED,line_spacing=1.4).move_to([3,-.7,0]),
        )
        self.play(FadeIn(planar),run_time=1)
        self.wait(4.5)

        self.cue(4, "В классической механике скорости складываются как векторы")
        addition = equation(r"\vec v_A=\vec v_{A/B}+\vec v_B",size=41).move_to([0,1.95,0])
        start = np.array([-3.8,-1.4,0.])
        diagram = VGroup(
            velocity_arrow(start,RIGHT*3.6,CYAN),
            velocity_arrow(start+RIGHT*3.6,LEFT*.9,GOLD),
            velocity_arrow(start+DOWN*.85,RIGHT*2.7,LAVENDER),
            equation(r"\vec v_{A/B}",size=25,color=CYAN).move_to(start+RIGHT*1.8+UP*.35),
            equation(r"\vec v_B",size=25,color=GOLD).move_to(start+RIGHT*3.2+UP*.35),
            equation(r"\vec v_A",size=25,color=LAVENDER).move_to(start+RIGHT*1.35+DOWN*1.17),
            label("Инерциальные системы отсчёта",size=23,color=MUTED).move_to([3,-1.8,0]),
        )
        self.play(FadeOut(planar),FadeIn(addition,diagram),run_time=1.2)
        self.wait(5.4)


class WorkedExampleScene(LessonScene):
    chapter_id = 11

    def chapter(self):
        self.cue(0, "Мяч брошен вертикально вверх. Найдём время подъёма и максимальную высоту")
        origin = np.array([-3.6,-2.35,0.])
        scale = .155
        t = ValueTracker(0)
        self.add(t)
        height = lambda: 20*t.get_value()-5*t.get_value()**2
        point_pos = lambda: origin+RIGHT*.9+UP*scale*height()
        vertical = Arrow(origin,origin+UP*4.65,buff=0,color=MUTED,stroke_width=1.8,max_tip_length_to_length_ratio=.035)
        zero = equation("0",size=23,color=MUTED).move_to(origin+LEFT*.3)
        axis_name = equation(r"y,\,\mathrm{m}",size=27,color=MUTED).move_to(origin+UP*4.85)
        ground = Line(origin+LEFT*.7,origin+RIGHT*2.1,color=GRID,stroke_width=2)
        ticks = VGroup(*[VGroup(Line(origin+UP*h*scale+LEFT*.09,origin+UP*h*scale+RIGHT*.09,color=GRID,stroke_width=1),equation(str(h),size=21,color=MUTED).move_to(origin+UP*h*scale+LEFT*.35)) for h in (10,20)])
        ball = Dot(point_pos(),radius=.1,color=GOLD)
        ball.add_updater(lambda m:m.move_to(point_pos()))
        velocity = always_redraw(lambda:velocity_arrow(point_pos(),UP*.038*(20-10*t.get_value()),CYAN).set_opacity(1 if abs(20-10*t.get_value())>.05 else 0))
        acceleration = always_redraw(lambda:velocity_arrow(point_pos()+RIGHT*.65+UP*.4,DOWN*.8,ROSE))
        g_label = equation(r"\vec g",size=28,color=ROSE)
        g_label.add_updater(lambda m:m.move_to(point_pos()+RIGHT*1.03))
        givens = VGroup(equation(r"v_0=20\,\mathrm{m/s}",size=37,color=CYAN),
                        equation(r"g=10\,\mathrm{m/s^2}",size=37,color=ROSE),
                        equation(r"t_{\max}=?\qquad h_{\max}=?",size=35,color=GOLD)).arrange(DOWN,buff=.4).move_to([2.2,1.05,0])
        self.play(Create(vertical),Create(ground),FadeIn(zero,axis_name,ticks,ball,velocity,acceleration,g_label,givens),run_time=1.8)
        self.wait(5.5)

        self.cue(1, "Ось направлена вверх, поэтому проекция ускорения равна минус g")
        law = equation(r"v_y=v_0-gt=20-10t",size=39,color=CYAN).move_to([2.15,1.85,0])
        time_prefix=equation(r"t=",size=31,color=MUTED)
        time_number=DecimalNumber(0,num_decimal_places=1,font_size=32,color=INK)
        time_number.add_updater(lambda m:m.set_value(t.get_value()))
        time_unit=equation(r"\mathrm{s}",size=31,color=MUTED)
        time_display=VGroup(time_prefix,time_number,time_unit).arrange(RIGHT,buff=.12).move_to([1.15,.6,0])
        value_prefix=equation(r"v_y=",size=31,color=CYAN)
        value_number=DecimalNumber(20,num_decimal_places=1,font_size=32,color=CYAN,include_sign=False)
        value_number.add_updater(lambda m:m.set_value(20-10*t.get_value()))
        value_unit=equation(r"\mathrm{m/s}",size=31,color=CYAN)
        velocity_display=VGroup(value_prefix,value_number,value_unit).arrange(RIGHT,buff=.13).move_to([2.25,-.3,0])
        negative_g=equation(r"a_y=-10\,\mathrm{m/s^2}",size=32,color=ROSE).move_to([2.2,-1.3,0])
        self.play(FadeOut(givens),FadeIn(law,time_display,velocity_display,negative_g),run_time=1.2)
        self.wait(5.8)

        self.cue(2, "В вершине скорость равна нулю: уравнение 0 = 20 − 10t даёт две секунды")
        self.play(t.animate.set_value(2),run_time=4.1,rate_func=linear)
        apex_line=DashedLine(origin+UP*20*scale,point_pos(),color=GOLD,stroke_width=1.5,dash_length=.08)
        apex_dot=Circle(radius=.2,color=GOLD,stroke_width=2).move_to(point_pos())
        solve=VGroup(equation(r"0=20-10t",size=41,color=CYAN),
                     equation(r"t_{\max}=\frac{20}{10}=2\,\mathrm{s}",size=41,color=GOLD)).arrange(DOWN,buff=.45).move_to([2.2,.8,0])
        self.play(Create(apex_line),Create(apex_dot),FadeOut(law,time_display,velocity_display),FadeIn(solve),run_time=1.1)
        self.wait(2.1)

        self.cue(3, "Подставляем две секунды в закон координаты и получаем высоту двадцать метров")
        height_solution=VGroup(
            equation(r"h=v_0t-\frac{gt^2}{2}",size=37),
            equation(r"h_{\max}=20\cdot2-\frac{10\cdot2^2}{2}",size=35),
            equation(r"h_{\max}=20\,\mathrm{m}",size=43,color=GOLD),
        ).arrange(DOWN,buff=.32).move_to([2.2,.65,0])
        apex_truth=equation(r"v_y=0,\qquad a_y=-g\ne0",size=33,color=ROSE).move_to([2.2,-1.85,0])
        self.play(FadeOut(solve,negative_g),FadeIn(height_solution,apex_truth),run_time=1.2)
        self.play(Indicate(apex_line,color=GOLD),run_time=1)
        self.wait(5)

        self.cue(4, "Проверка: средняя скорость десять метров в секунду за две секунды даёт двадцать метров")
        average_check=VGroup(
            equation(r"\overline v_y=\frac{v_0+v}{2}=\frac{20+0}{2}",size=36,color=CYAN),
            equation(r"\overline v_y=10\,\mathrm{m/s}",size=36,color=CYAN),
            equation(r"h=\overline v_y t=10\cdot2=20\,\mathrm{m}",size=38,color=GOLD),
        ).arrange(DOWN,buff=.42).move_to([2.2,.65,0])
        self.play(ReplacementTransform(height_solution,average_check),run_time=1.2)
        self.play(Indicate(apex_line,color=GOLD),run_time=1)
        self.wait(5)


class FinaleScene(LessonScene):
    chapter_id = 12

    def chapter(self):
        self.cue(0, "Любое движение начинается с вопроса: как меняется положение тела?")
        straight_line=Line([-5.2,.35,0],[5.2,.35,0],color=GRID,stroke_width=2)
        straight_point=Dot([-4.6,.35,0],radius=.095,color=CYAN)
        straight_arrow=always_redraw(lambda:velocity_arrow(np.array([-4.6,.35,0]),straight_point.get_center()-np.array([-4.6,.35,0]),CYAN,2))
        straight_caption=label("Положение и перемещение",size=26).move_to([0,1.6,0])
        self.play(Create(straight_line),FadeIn(straight_point,straight_caption),run_time=.9)
        self.add(straight_arrow)
        self.play(straight_point.animate.move_to([3.4,.35,0]),run_time=3.3,rate_func=smooth)
        straight_arrow.clear_updaters()
        straight=VGroup(straight_line,straight_point,straight_arrow,straight_caption)

        self.cue(1, "Путь измеряет длину дороги; перемещение соединяет её начало и конец")
        graph_axes=[]
        graphs=VGroup()
        for name,col,y,func in [("x(t)",GOLD,1.52,lambda t:.24*t*t),("v(t)",CYAN,.58,lambda t:.48*t),("a(t)",ROSE,-.36,lambda t:.48)]:
            ax=Axes(x_range=(0,2.5,1),y_range=(0,1.6,.5),x_length=2.4,y_length=.65,
                    axis_config={"stroke_width":1.1,"color":GRID,"include_tip":False},tips=False).move_to([0,y,0])
            curve=ax.plot(func,x_range=[0,2.4],color=col,stroke_width=2.2)
            name_mob=equation(name,size=24,color=col).next_to(ax,LEFT,buff=.14)
            graphs.add(ax,curve,name_mob)
            graph_axes.append(ax)
        graphs.add(label("Графики",size=23).move_to([0,2.27,0]))
        self.play(straight.animate.scale(.38).move_to([-4.4,.7,0]),FadeIn(graphs),run_time=1.3)
        self.wait(3.4)

        self.cue(2, "Скорость описывает изменение положения, ускорение — изменение скорости")
        ax=Axes(x_range=(0,4,1),y_range=(0,2,1),x_length=2.7,y_length=1.8,
                axis_config={"stroke_width":1.2,"color":GRID,"include_tip":False},tips=False).move_to([4.3,.65,0])
        trajectory=ax.plot(lambda x:1.5*x-.375*x*x,x_range=[0,4],color=GOLD,stroke_width=2.1)
        flight=ValueTracker(0)
        flying=Dot(ax.c2p(0,0),radius=.06,color=GOLD)
        flying.add_updater(lambda m:m.move_to(ax.c2p(flight.get_value(),1.5*flight.get_value()-.375*flight.get_value()**2)))
        flight_caption=label("Полёт",size=23).move_to([4.3,2.27,0])
        projectile=VGroup(ax,trajectory,flying,flight_caption)
        self.add(flight)
        self.play(Create(ax),Create(trajectory),FadeIn(flying,flight_caption),run_time=.9)
        self.play(flight.animate.set_value(4),run_time=3.4,rate_func=linear)
        flying.clear_updaters()

        self.cue(3, "Выбирайте оси, следите за знаками и проверяйте условия применения формул")
        circle_center=np.array([0,-1.77,0.])
        circle=Circle(radius=.62,color=GRID,stroke_width=1.7).move_to(circle_center)
        angle=ValueTracker(.45)
        angle.add_updater(lambda m,dt:m.increment_value(1.1*dt))
        circle_pos=lambda:circle_center+.62*np.array([np.cos(angle.get_value()),np.sin(angle.get_value()),0])
        circular_point=Dot(circle_pos(),radius=.06,color=INK)
        circular_point.add_updater(lambda m:m.move_to(circle_pos()))
        cv=always_redraw(lambda:velocity_arrow(circle_pos(),.5*np.array([-np.sin(angle.get_value()),np.cos(angle.get_value()),0]),CYAN,2))
        ca=always_redraw(lambda:velocity_arrow(circle_pos(),.45*np.array([-np.cos(angle.get_value()),-np.sin(angle.get_value()),0]),ROSE,2))
        circular=VGroup(circle,circular_point,cv,ca)
        relations=VGroup(equation(r"\vec v=\frac{d\vec r}{dt}",size=34,color=CYAN).move_to([-3.6,-1.75,0]),
                         equation(r"\vec a=\frac{d\vec v}{dt}",size=34,color=ROSE).move_to([3.6,-1.75,0]))
        links=VGroup(Line([-4.4,-.05,0],[-1,-1.4,0],color=GRID,stroke_width=1),
                     Line([0,-.86,0],[0,-1.03,0],color=GRID,stroke_width=1),
                     Line([4.3,-.4,0],[1,-1.4,0],color=GRID,stroke_width=1))
        self.add(angle)
        self.play(Create(circle),Create(links),FadeIn(circular_point,cv,ca,relations),run_time=.9)
        self.wait(3.9)

        self.cue(4, "Одна система понятий помогает увидеть порядок в самых разных движениях")
        angle.clear_updaters()
        circular_point.clear_updaters()
        cv.clear_updaters()
        ca.clear_updaters()
        final=label("Кинематика — это язык,\nна котором мы описываем движение",size=40,line_spacing=1.25)
        final.move_to([0,.35,0])
        if final.width>12.3:
            final.scale_to_fit_width(12.3)
        underline=Line([-2.3,-.85,0],[2.3,-.85,0],color=CYAN,stroke_width=2)
        self.play(FadeOut(straight,graphs,projectile,circular,links,relations),run_time=.9)
        self.play(FadeIn(final,shift=UP*.1),Create(underline),run_time=1.4)
        self.wait(3.5)
