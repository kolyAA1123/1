"""Constant acceleration, graphs, free fall, and projectile motion."""
from manim import *
import numpy as np

from common import (
    LessonScene, label, equation, axes_2d, velocity_arrow, car,
    INK, MUTED, CYAN, GOLD, ROSE, LAVENDER, GRID,
)


def _stop(*objects):
    for obj in objects:
        obj.clear_updaters(recursive=True)


def _vertical_arrow(origin, value, color, scale=1):
    """Hide the vector at zero rather than drawing a spurious horizontal arrow."""
    length = abs(value * scale)
    vector = np.array([0., np.sign(value or 1) * max(length, .02), 0.])
    return velocity_arrow(origin, vector, color=color).set_opacity(min(1., length / .08))


class ConstantAccelerationScene(LessonScene):
    chapter_id = 5

    def chapter(self):
        self.cue(0, "Постоянное ускорение: за равные интервалы скорость меняется одинаково")
        t = ValueTracker(0)
        start = np.array([-5.95, -1.0, 0.])
        position = lambda: start + RIGHT * (.48 * t.get_value() + .15 * t.get_value() ** 2)
        road = Arrow([-6.2, -1.28, 0], [-.35, -1.28, 0], color=MUTED,
                     stroke_width=1.5, buff=0, max_tip_length_to_length_ratio=.025)
        ox = equation("x", size=25, color=MUTED).next_to(road, RIGHT, buff=.12)
        body = car().scale(.8).move_to(start)
        body.add_updater(lambda m: m.move_to(position()))
        varrow = always_redraw(lambda: velocity_arrow(position()+UP*.42,
                            RIGHT * (.48+.3*t.get_value()) * .75, CYAN))
        aarrow = always_redraw(lambda: velocity_arrow(position()+UP*1.18, RIGHT*.7, ROSE))
        vl = equation("v_x", size=27, color=CYAN).move_to([-5.8, .0, 0])
        al = equation("a_x", size=27, color=ROSE).move_to([-5.8, 1.0, 0])
        vl.add_updater(lambda m: m.next_to(varrow, UP, buff=.08))
        al.add_updater(lambda m: m.next_to(aarrow, UP, buff=.08))
        clock = VGroup(equation("t=", size=29, color=MUTED),
                       DecimalNumber(0, num_decimal_places=1, font_size=29, color=INK),
                       label("с", size=23, color=MUTED)).arrange(RIGHT, buff=.1).move_to([-3.4,-2.15,0])
        clock[1].add_updater(lambda m: m.set_value(t.get_value()))
        right = VGroup(equation("a_x=\\mathrm{const}", size=40, color=ROSE),
                       label("Линейное изменение скорости", size=25)).arrange(DOWN, buff=.5).move_to([3.1, .9, 0])
        self.play(Create(road), FadeIn(ox), FadeIn(body), FadeIn(varrow), FadeIn(aarrow),
                  FadeIn(vl), FadeIn(al), FadeIn(clock), FadeIn(right), run_time=1)
        self.play(t.animate.set_value(4), run_time=6.8, rate_func=linear)

        self.cue(1, "Проекция скорости: начальная скорость плюс ускорение, умноженное на время")
        new = VGroup(equation("v_x=v_{0x}+a_xt", size=39),
                     label("Начальное значение + изменение", size=24, color=MUTED)).arrange(DOWN, buff=.5).move_to([3.1,.9,0])
        new[0].set_color_by_tex("v", CYAN)
        self.play(ReplacementTransform(right, new), t.animate.set_value(0), run_time=.8)
        right = new
        self.play(t.animate.set_value(4), run_time=7.5, rate_func=linear)

        self.cue(2, "Координата содержит линейный и квадратичный по времени вклад")
        new = VGroup(equation("x=x_0+v_{0x}t+\\frac{a_xt^2}{2}", size=35),
                     label("Приращения координаты растут", size=24, color=MUTED)).arrange(DOWN, buff=.5).move_to([3.1,.9,0])
        new[0].set_color(GOLD)
        distance = always_redraw(lambda: Line(start+DOWN*.6, position()+DOWN*.6,
                                               color=GOLD, stroke_width=4))
        dl = equation("x-x_0", size=29, color=GOLD).move_to([-3.4,-1.9,0])
        self.play(ReplacementTransform(right, new), t.animate.set_value(.03),
                  clock.animate.shift(DOWN*.55), FadeIn(distance), FadeIn(dl), run_time=.8)
        right = new
        self.play(t.animate.set_value(4), run_time=7.4, rate_func=linear)

        self.cue(3, "Время можно исключить: скорость связана непосредственно с перемещением")
        new = VGroup(equation("v_x^2-v_{0x}^2=2a_x(x-x_0)", size=32),
                     label("Связь без времени", size=27, color=GOLD)).arrange(DOWN, buff=.6).move_to([3.15,.8,0])
        initial = car(color=MUTED).scale(.8).move_to(start).set_opacity(.4)
        vinit = velocity_arrow(start+UP*.42, RIGHT*.48*.75, color=MUTED)
        initlabel = equation("v_{0x}", size=24, color=MUTED).next_to(vinit, UP, buff=.08)
        _stop(clock)
        self.play(ReplacementTransform(right,new), FadeOut(clock), FadeIn(initial),
                  GrowArrow(vinit), FadeIn(initlabel), run_time=1.1)
        self.play(Indicate(new[0], color=GOLD), Indicate(distance, color=GOLD), run_time=1.8)

        self.cue(4, "Модуль скорости растёт при одинаковых знаках скорости и ускорения")
        _stop(body, varrow, aarrow, vl, al, distance)
        self.clear_stage()
        divider = Line([0,-2.25,0],[0,2.3,0],color=GRID,stroke_width=1)
        titles = VGroup(label("Знаки совпадают", size=28, color=CYAN).move_to([-3.35,2.1,0]),
                        label("Знаки противоположны", size=28, color=ROSE).move_to([3.35,2.1,0]))
        signs = VGroup(equation("v_xa_x>0", size=36, color=CYAN).move_to([-3.35,1.25,0]),
                       equation("v_xa_x<0", size=36, color=ROSE).move_to([3.35,1.25,0]))
        speed = ValueTracker(.8)
        opposite = ValueTracker(1.9)
        vehicles = VGroup(car().move_to([-2.5,-.55,0]),car().move_to([4.4,-.55,0]))
        v1 = always_redraw(lambda: velocity_arrow([-2.5,.15,0], LEFT*speed.get_value(), CYAN))
        v2 = always_redraw(lambda: velocity_arrow([4.4,.15,0], LEFT*opposite.get_value(), CYAN))
        accels = VGroup(velocity_arrow([-2.5,-1.25,0],LEFT*.9,ROSE),
                        velocity_arrow([3.5,-1.25,0],RIGHT*.9,ROSE))
        words = VGroup(equation("|v_x|\\nearrow",size=33,color=CYAN).move_to([-3.35,-2.1,0]),
                       equation("|v_x|\\searrow",size=33,color=ROSE).move_to([3.35,-2.1,0]))
        keys = VGroup(equation("v_x",size=24,color=CYAN).move_to([-5.35,.15,0]),
                      equation("a_x",size=24,color=ROSE).move_to([-5.35,-1.25,0]),
                      equation("v_x",size=24,color=CYAN).move_to([1.3,.15,0]),
                      equation("a_x",size=24,color=ROSE).move_to([1.3,-1.25,0]))
        self.play(FadeIn(divider),FadeIn(titles),FadeIn(signs),FadeIn(vehicles),
                  FadeIn(v1),FadeIn(v2),FadeIn(accels),FadeIn(words),FadeIn(keys),run_time=1)
        condition=equation("a_x=\\mathrm{const}",size=24,color=MUTED).move_to([0,-2.72,0])
        self.play(FadeIn(condition),run_time=.4)
        self.play(speed.animate.set_value(1.9),opposite.animate.set_value(.55),run_time=5.5,rate_func=linear)
        _stop(v1,v2)


class GraphsScene(LessonScene):
    chapter_id = 6

    def chapter(self):
        self.cue(0, "Три графика описывают одно движение с постоянным положительным ускорением")
        t = ValueTracker(0)
        axes, curves, dots, guides = [], [], [], []
        functions = [lambda q:.5*q+.25*q*q,lambda q:.5+.5*q,lambda q:.5]
        specs = [("x(t)",(0,7,1),GOLD),("v_x(t)",(0,3,1),CYAN),("a_x(t)",(0,1, .5),ROSE)]
        headings = VGroup()
        for i,(title,yr,color) in enumerate(specs):
            ax = axes_2d((0,4,1),yr,width=3.6,height=3.3,center=[-4.45+i*4.45,-.05,0])
            axes.append(ax)
            f = functions[i]
            curves.append(ax.plot(f,x_range=[0,4],color=color,stroke_width=3))
            dots.append(always_redraw(lambda ax=ax,f=f,color=color: Dot(ax.c2p(t.get_value(),f(t.get_value())),radius=.065,color=color)))
            guides.append(always_redraw(lambda ax=ax,f=f: DashedLine(ax.c2p(t.get_value(),0),ax.c2p(t.get_value(),f(t.get_value())),color=MUTED,stroke_width=1.2,dash_length=.07)))
            headings.add(equation(title,size=33,color=color).move_to([-4.45+i*4.45,2.25,0]))
            headings.add(equation("t",size=23,color=MUTED).next_to(ax.x_axis,RIGHT,buff=.12))
        time = VGroup(equation("t=",size=28,color=MUTED),DecimalNumber(0,num_decimal_places=1,font_size=28),label("с",size=22,color=MUTED)).arrange(RIGHT,buff=.1).move_to([0,-2.45,0])
        time[1].add_updater(lambda m:m.set_value(t.get_value()))
        self.play(*[Create(ax) for ax in axes],FadeIn(headings),FadeIn(time),run_time=1)
        self.play(*[Create(c) for c in curves],*[FadeIn(d) for d in dots],*[FadeIn(g) for g in guides],run_time=2)

        self.cue(1,"Один и тот же момент времени: парабола координаты, прямая скорости, постоянное ускорение")
        tangents=[]
        for ax,f,slope,color in [(axes[0],functions[0],lambda q:.5+.5*q,GOLD),
                                 (axes[1],functions[1],lambda q:.5,CYAN)]:
            tangents.append(always_redraw(lambda ax=ax,f=f,slope=slope,color=color:
                Line(ax.c2p(t.get_value()-.32,f(t.get_value())-.32*slope(t.get_value())),
                     ax.c2p(t.get_value()+.32,f(t.get_value())+.32*slope(t.get_value())),
                     color=color,stroke_width=2.8)))
        self.play(*[FadeIn(tan) for tan in tangents],run_time=.4)
        self.play(t.animate.set_value(4),run_time=8,rate_func=linear)

        self.cue(2,"Под графиком скорости прямоугольник и треугольник дают перемещение")
        _stop(*dots,*guides,*tangents,time)
        self.clear_stage()
        ax = axes_2d((0,4,1),(-3,3,1),width=6.1,height=3.75,center=[-3.1,-.15,0])
        plot = ax.plot(lambda q:.6+.5*q,x_range=[0,3.4],color=CYAN,stroke_width=3)
        rect = Polygon(ax.c2p(0,0),ax.c2p(3,0),ax.c2p(3,.6),ax.c2p(0,.6),
                       stroke_width=1,stroke_color=GOLD,fill_color=GOLD,fill_opacity=.42)
        tri = Polygon(ax.c2p(0,.6),ax.c2p(3,.6),ax.c2p(3,2.1),
                      stroke_width=1,stroke_color=CYAN,fill_color=CYAN,fill_opacity=.34)
        axislabels = VGroup(equation("v_x",size=27,color=CYAN).next_to(ax.y_axis,UP,buff=.1),
                            equation("t",size=26,color=MUTED).next_to(ax.x_axis,RIGHT,buff=.1),
                            equation("v_{0x}",size=24,color=GOLD).move_to(ax.c2p(0,.6)+LEFT*.5),
                            equation("t",size=24,color=GOLD).move_to(ax.c2p(3,0)+DOWN*.32))
        right = VGroup(label("Знаковая площадь",size=29),equation("\\Delta x=\\int_0^t v_x(\\tau)\\,d\\tau",size=37,color=GOLD),
                       label("Прямоугольник + треугольник",size=23,color=MUTED)).arrange(DOWN,buff=.5).move_to([3.5,.65,0])
        self.play(Create(ax),FadeIn(axislabels),Create(plot),FadeIn(right),run_time=1.5)
        self.play(FadeIn(rect),run_time=1.4)
        self.play(FadeIn(tri),run_time=1.4)
        self.play(Indicate(rect,color=GOLD),Indicate(tri,color=CYAN),run_time=1.5)

        self.cue(3,"Площадь превращается в формулу: начальная скорость на время плюс половина ускорения на квадрат времени")
        formula = MathTex("\\Delta x", "=", "v_{0x}t", "+", "\\frac{a_xt^2}{2}", font_size=39, color=INK).move_to([3.5,.55,0])
        formula[0].set_color(INK)
        formula[2].set_color(GOLD)
        formula[4].set_color(CYAN)
        top = label("Геометрия даёт закон движения",size=25).move_to([3.5,1.8,0])
        caption = VGroup(label("прямоугольник",size=22,color=GOLD),label("треугольник",size=22,color=CYAN)).arrange(RIGHT,buff=.45).move_to([3.5,-.5,0])
        self.play(FadeOut(right),FadeIn(top),FadeIn(formula[:2]),FadeIn(formula[3]),run_time=.7)
        self.play(TransformFromCopy(rect,formula[2]),TransformFromCopy(tri,formula[4]),run_time=2)
        self.play(FadeIn(caption),run_time=.7)
        self.play(Circumscribe(formula,color=GOLD,stroke_width=1.5),run_time=1.6)

        self.cue(4,"Площадь ниже оси времени отрицательна: координата уменьшается")
        negative = ax.plot(lambda q:-.6-.5*q,x_range=[0,3.4],color=ROSE,stroke_width=3)
        area = Polygon(ax.c2p(0,0),ax.c2p(3,0),ax.c2p(3,-2.1),ax.c2p(0,-.6),
                       stroke_width=1,stroke_color=ROSE,fill_color=ROSE,fill_opacity=.38)
        negative_start = equation("v_{0x}<0",size=22,color=ROSE).move_to(ax.c2p(.65,-.6)+DOWN*.4)
        result = VGroup(equation("\\Delta x<0",size=43,color=ROSE),equation("x<x_0",size=31),
                        equation("s=\\int_0^t|v_x(\\tau)|\\,d\\tau",size=32,color=GOLD),
                        label("Для пути складываем модули площадей",size=21,color=MUTED)).arrange(DOWN,buff=.4).move_to([3.5,.4,0])
        self.play(FadeOut(rect),FadeOut(tri),FadeOut(formula),FadeOut(top),FadeOut(caption),FadeOut(axislabels[2]),
                  ReplacementTransform(plot,negative),FadeIn(negative_start),FadeIn(result),run_time=1.5)
        self.play(FadeIn(area),run_time=1.5)
        self.play(Indicate(area,color=ROSE),Indicate(result[0],color=ROSE),run_time=2)


class FreeFallScene(LessonScene):
    chapter_id = 7

    def chapter(self):
        self.cue(0,"Без сопротивления воздуха ускорение постоянно и направлено вниз")
        t = ValueTracker(0)
        mode = {"throw":False}
        height = lambda: (-1.4+3.6*t.get_value()-.9*t.get_value()**2 if mode["throw"] else 2.2-.9*t.get_value()**2)
        speed = lambda: (3.6-1.8*t.get_value() if mode["throw"] else -1.8*t.get_value())
        ball = Dot([-3.4,2.2,0],radius=.13,color=GOLD)
        ball.add_updater(lambda m:m.move_to([-3.4,height(),0]))
        oy = Arrow([-5.65,-2.6,0],[-5.65,2.5,0],buff=0,color=MUTED,stroke_width=1.5,
                   max_tip_length_to_length_ratio=.035)
        yl = equation("y",size=28,color=MUTED).next_to(oy,UP,buff=.1)
        ground = Line([-5.15,-1.6,0],[-.6,-1.6,0],color=GRID,stroke_width=2)
        va = always_redraw(lambda:_vertical_arrow(np.array([-2.8,height(),0]),speed(),CYAN,.36))
        ga = always_redraw(lambda:velocity_arrow([-4.35,height(),0],DOWN*.75,ROSE))
        keys = VGroup(equation("v_y",size=26,color=CYAN).move_to([-1.75,.15,0]),
                      equation("g",size=28,color=ROSE).move_to([-4.75,-.2,0]))
        keys[0].add_updater(lambda m:m.next_to(va,RIGHT,buff=.14).set_opacity(min(1.,abs(speed()*.36)/.08)))
        keys[1].add_updater(lambda m:m.next_to(ga,LEFT,buff=.14))
        right = VGroup(label("Свободное падение",size=29),label("Сопротивления воздуха нет",size=24,color=MUTED),
                       equation("g\\approx9.8\\;\\mathrm{m/s^2}",size=35,color=ROSE),
                       equation("a_y=-g",size=38,color=ROSE)).arrange(DOWN,buff=.35).move_to([3.3,.65,0])
        ghosts = VGroup(*[Dot([-3.4,2.2-.9*q*q,0],radius=.09,color=GOLD).set_opacity(.2)
                         for q in [0,.4,.8,1.2,1.6,2]])
        ghosttext = label("Равные интервалы времени",size=22,color=MUTED).move_to([-3.1,-2.8,0])
        self.play(GrowArrow(oy),FadeIn(yl),Create(ground),FadeIn(ball),FadeIn(va),FadeIn(ga),
                  FadeIn(keys),FadeIn(right),FadeIn(ghosts),FadeIn(ghosttext),run_time=1.1)
        self.play(t.animate.set_value(2),run_time=6.8,rate_func=linear)

        self.cue(1,"При выборе оси вверх проекция ускорения отрицательна")
        formulas = VGroup(label("Ось направлена вверх",size=28),
                          equation("a_y=-g",size=43,color=ROSE),
                          equation("\\Delta v_y=-g\\,\\Delta t",size=37,color=CYAN)).arrange(DOWN,buff=.5).move_to([3.35,.6,0])
        self.play(ReplacementTransform(right,formulas),FadeOut(ghosts),FadeOut(ghosttext),t.animate.set_value(0),run_time=.8)
        right=formulas
        self.play(Indicate(oy,color=GOLD),run_time=1)
        self.play(t.animate.set_value(2),run_time=7.5,rate_func=linear)

        self.cue(2,"Знакомые законы равноускоренного движения: вместо ускорения подставляем минус g")
        formulas = VGroup(equation("v_y=v_{0y}-gt",size=37,color=CYAN),
                          equation("y=y_0+v_{0y}t-\\frac{gt^2}{2}",size=34,color=GOLD),
                          equation("a_y=-g",size=30,color=ROSE)).arrange(DOWN,buff=.5).move_to([3.35,.6,0])
        self.play(ReplacementTransform(right,formulas),t.animate.set_value(0),run_time=.8)
        right=formulas
        self.play(t.animate.set_value(2),run_time=7.5,rate_func=linear)

        self.cue(3,"Бросок вверх: модуль скорости уменьшается и в верхней точке становится нулевым")
        mode["throw"]=True
        t.set_value(0)
        formulas = VGroup(label("Бросок вертикально вверх",size=28),
                          equation("v_y=v_{0y}-gt",size=38,color=CYAN),
                          equation("a_y=-g",size=35,color=ROSE),
                          label("Модуль скорости уменьшается",size=24,color=MUTED)).arrange(DOWN,buff=.4).move_to([3.35,.65,0])
        self.play(ReplacementTransform(right,formulas),run_time=.7)
        right=formulas
        self.play(t.animate.set_value(2),run_time=7,rate_func=linear)
        ring = Circle(radius=.28,color=GOLD,stroke_width=1.5).move_to(ball)
        zero = equation("v_y=0",size=38,color=CYAN).move_to(formulas[1])
        self.play(Create(ring),Transform(formulas[1],zero),run_time=.8)

        self.cue(4,"На спуске скорость и ускорение направлены вниз, модуль скорости снова растёт")
        formulas = VGroup(label("Ускорение не исчезает",size=29),
                          equation("a_y=-g\\ne0",size=40,color=ROSE),equation("v_y<0",size=38,color=CYAN),
                          label("На спуске модуль скорости растёт",size=23,color=MUTED)).arrange(DOWN,buff=.4).move_to([3.35,.65,0])
        self.play(FadeOut(right),FadeIn(formulas),Indicate(ga,color=ROSE),run_time=1)
        self.play(Circumscribe(formulas[1],color=ROSE,stroke_width=1.5),run_time=1.2)
        self.play(FadeOut(ring),run_time=.4)
        self.play(t.animate.set_value(4),run_time=7,rate_func=linear)
        _stop(ball,va,ga,keys)


class ProjectileScene(LessonScene):
    chapter_id = 8

    def chapter(self):
        self.cue(0,"Начальную скорость раскладываем на горизонтальную и вертикальную составляющие")
        ax = axes_2d((0,16,4),(0,9,3),width=6.8,height=3.825,center=[-2.85,-.25,0])
        origin=ax.c2p(0,0)
        speed,g,angle=12.,9.8,PI/4
        flight=2*speed*np.sin(angle)/g
        point=lambda q:ax.c2p(speed*np.cos(angle)*q,speed*np.sin(angle)*q-.5*g*q*q)
        ball=Dot(origin,radius=.11,color=GOLD)
        v=velocity_arrow(origin,1.92*np.array([np.cos(angle),np.sin(angle),0]),GOLD)
        vx=velocity_arrow(origin,RIGHT*1.92*np.cos(angle),CYAN)
        vy=velocity_arrow(origin+RIGHT*1.92*np.cos(angle),UP*1.92*np.sin(angle),ROSE)
        arc=Arc(radius=.54,start_angle=0,angle=angle,arc_center=origin,color=MUTED,stroke_width=1.3)
        anglelabel=equation("\\alpha",size=25,color=MUTED).move_to(origin+np.array([.74,.3,0]))
        axislabels=VGroup(equation("x",size=27,color=MUTED).next_to(ax.x_axis,RIGHT,buff=.1),
                          equation("y",size=27,color=MUTED).next_to(ax.y_axis,UP,buff=.1))
        right=VGroup(label("Начальная скорость",size=29),
                     equation("v_{0x}=v_0\\cos\\alpha",size=35,color=CYAN),
                     equation("v_{0y}=v_0\\sin\\alpha",size=35,color=ROSE)).arrange(DOWN,buff=.55).move_to([3.7,.85,0])
        self.play(Create(ax),FadeIn(axislabels),FadeIn(ball),GrowArrow(v),GrowArrow(vx),GrowArrow(vy),
                  Create(arc),FadeIn(anglelabel),FadeIn(right),run_time=2)
        self.play(Indicate(vx,color=CYAN),Indicate(right[1],color=CYAN),run_time=1.5)
        self.play(Indicate(vy,color=ROSE),Indicate(right[2],color=ROSE),run_time=1.5)

        self.cue(1,"По горизонтали движение равномерное, по вертикали — с ускорением свободного падения")
        t=ValueTracker(0)
        ball.add_updater(lambda m:m.move_to(point(t.get_value())))
        curve=ParametricFunction(point,t_range=[0,flight],color=GOLD,stroke_width=2.5)
        px=always_redraw(lambda:Dot(ax.c2p(speed*np.cos(angle)*t.get_value(),0),radius=.055,color=CYAN))
        py=always_redraw(lambda:Dot(ax.c2p(0,speed*np.sin(angle)*t.get_value()-.5*g*t.get_value()**2),radius=.055,color=ROSE))
        horizontal=always_redraw(lambda:DashedLine(ball.get_center(),py.get_center(),color=ROSE,stroke_width=1.3,dash_length=.09))
        vertical=always_redraw(lambda:DashedLine(ball.get_center(),px.get_center(),color=CYAN,stroke_width=1.3,dash_length=.09))
        formulas=VGroup(label("Два независимых движения",size=26),
                        equation("v_x=v_{0x}=\\mathrm{const}",size=34,color=CYAN),
                        equation("a_y=-g",size=37,color=ROSE)).arrange(DOWN,buff=.55).move_to([3.7,.85,0])
        self.play(FadeOut(v),FadeOut(vx),FadeOut(vy),FadeOut(arc),FadeOut(anglelabel),
                  ReplacementTransform(right,formulas),Create(curve),FadeIn(px),FadeIn(py),FadeIn(horizontal),FadeIn(vertical),run_time=1.5)
        right=formulas
        self.play(t.animate.set_value(flight),run_time=8.5,rate_func=linear)

        self.cue(2,"Два закона координат задают положение тела в каждый момент времени")
        formulas=VGroup(equation("x=v_0\\cos\\alpha\\;t",size=34,color=CYAN),
                        equation("y=v_0\\sin\\alpha\\;t-\\frac{gt^2}{2}",size=32,color=ROSE),
                        equation("x_0=y_0=0",size=27,color=MUTED)).arrange(DOWN,buff=.65).move_to([3.7,.85,0])
        self.play(ReplacementTransform(right,formulas),t.animate.set_value(0),run_time=.8)
        right=formulas
        self.play(t.animate.set_value(flight),run_time=9,rate_func=linear)

        self.cue(3,"При одинаковой высоте старта и финиша дальность максимальна под углом сорок пять градусов")
        _stop(ball,px,py,horizontal,vertical)
        theta=ValueTracker(PI/6)
        def trajectory(phi,color=GOLD,width=2.7):
            end=2*speed*np.sin(phi)/g
            return ParametricFunction(lambda q:ax.c2p(speed*np.cos(phi)*q,speed*np.sin(phi)*q-.5*g*q*q),
                                      t_range=[0,end],color=color,stroke_width=width)
        family=VGroup(trajectory(PI/6,GRID,1.5),trajectory(PI/3,GRID,1.5),trajectory(PI/4,GRID,1.5))
        live=always_redraw(lambda:trajectory(theta.get_value()))
        landing=always_redraw(lambda:Dot(ax.c2p(speed**2*np.sin(2*theta.get_value())/g,0),radius=.075,color=GOLD))
        formulas=VGroup(equation("L=\\frac{v_0^2\\sin2\\alpha}{g}",size=38,color=GOLD),
                        label("Одна начальная скорость",size=24,color=MUTED),
                        equation("\\alpha=45^\\circ\\quad\\Rightarrow\\quad L_{\\max}",size=32,color=GOLD),
                        label("Старт и финиш на одной высоте",size=22,color=MUTED)).arrange(DOWN,buff=.45).move_to([3.7,.65,0])
        self.play(FadeOut(ball),FadeOut(px),FadeOut(py),FadeOut(horizontal),FadeOut(vertical),FadeOut(curve),
                  ReplacementTransform(right,formulas),FadeIn(family),FadeIn(live),FadeIn(landing),run_time=1)
        self.play(theta.animate.set_value(PI/3),run_time=4,rate_func=linear)
        self.play(theta.animate.set_value(PI/4),run_time=3,rate_func=smooth)
        self.play(Indicate(formulas[2],color=GOLD),run_time=1.5)

        self.cue(4,"Дальность определяется углом; горизонтальный бросок — частный случай")
        self.play(Indicate(formulas[0],color=GOLD),run_time=1.2)
        self.wait(3.1)
        _stop(live,landing)
        self.clear_stage()
        ax2=axes_2d((0,16,4),(0,9,3),width=6.8,height=3.825,center=[-2.85,-.25,0])
        h,v0=7.,10.
        end=np.sqrt(2*h/g)
        q=ValueTracker(0)
        horizontal_point=lambda z:ax2.c2p(v0*z,h-.5*g*z*z)
        ball2=Dot(horizontal_point(0),radius=.11,color=GOLD)
        ball2.add_updater(lambda m:m.move_to(horizontal_point(q.get_value())))
        platform=Line(ax2.c2p(0,h)+LEFT*.3,ax2.c2p(0,h)+RIGHT*.6,color=GRID,stroke_width=3)
        path=ParametricFunction(horizontal_point,t_range=[0,end],color=GOLD,stroke_width=2.5)
        hv=always_redraw(lambda:velocity_arrow(ball2.get_center(),RIGHT*v0*.05,CYAN))
        vv=always_redraw(lambda:_vertical_arrow(ball2.get_center(),-g*q.get_value(),ROSE,.05))
        formulas=VGroup(label("Горизонтальный бросок",size=28),equation("v_{0y}=0",size=37,color=ROSE),
                        equation("x=v_0t",size=37,color=CYAN),equation("y=h-\\frac{gt^2}{2}",size=37,color=GOLD)).arrange(DOWN,buff=.4).move_to([3.7,.65,0])
        axislabels2=VGroup(equation("x",size=27,color=MUTED).next_to(ax2.x_axis,RIGHT,buff=.1),
                           equation("y",size=27,color=MUTED).next_to(ax2.y_axis,UP,buff=.1))
        self.play(Create(ax2),FadeIn(axislabels2),Create(platform),FadeIn(ball2),Create(path),FadeIn(hv),FadeIn(vv),FadeIn(formulas),run_time=1.5)
        self.play(q.animate.set_value(end),run_time=5.8,rate_func=linear)
        _stop(ball2,hv,vv)
