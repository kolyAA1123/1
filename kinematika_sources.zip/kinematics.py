"""Manim entry points. Run from this directory after sourcing setup_env.sh."""
from scenes.foundations import OpeningScene, PathDisplacementScene, VelocityScene, AccelerationScene
from scenes.dynamics import ConstantAccelerationScene, GraphsScene, FreeFallScene, ProjectileScene
from scenes.advanced import CircularMotionScene, RelativeMotionScene, WorkedExampleScene, FinaleScene

class Opening(OpeningScene): pass
class PathDisplacement(PathDisplacementScene): pass
class Velocity(VelocityScene): pass
class Acceleration(AccelerationScene): pass
class ConstantAcceleration(ConstantAccelerationScene): pass
class Graphs(GraphsScene): pass
class FreeFall(FreeFallScene): pass
class Projectile(ProjectileScene): pass
class CircularMotion(CircularMotionScene): pass
class RelativeMotion(RelativeMotionScene): pass
class WorkedExample(WorkedExampleScene): pass
class Finale(FinaleScene): pass
