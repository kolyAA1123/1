"""Render black-background Manim chapters and assemble a film without audio."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SCENES = ["Opening", "PathDisplacement", "Velocity", "Acceleration", "ConstantAcceleration", "Graphs", "FreeFall", "Projectile", "CircularMotion", "RelativeMotion", "WorkedExample", "Finale"]
DURATIONS = [45,65,55,55,55,60,60,70,65,45,50,35]

def probe(path):
    return json.loads(subprocess.check_output(["ffprobe","-v","error","-show_streams","-show_format","-of","json",str(path)]))

def run_scene(index, preview=False, force=False):
    name=SCENES[index]
    width,height,fps=(854,480,15) if preview else (1920,1080,60)
    dest=ROOT/"output"/("preview_chapters" if preview else "chapters")
    dest.mkdir(parents=True,exist_ok=True)
    output=dest/f"{index+1:02d}_{name}.mp4"
    chapter_file=["foundations.py","dynamics.py","advanced.py"][index//4]
    code_sources=[ROOT/"common.py",ROOT/"kinematics.py",ROOT/"scenes"/chapter_file]
    fresh=output.exists() and output.stat().st_mtime > max(p.stat().st_mtime for p in code_sources)
    if force or not fresh:
        log=dest/f"{index+1:02d}_{name}.log"
        cmd=[sys.executable,"-m","manim","kinematics.py",name,"-r",f"{width},{height}","--fps",str(fps),"--format","mp4","--output_file",str(output),"--verbosity","WARNING","--progress_bar","none"]
        print(f"Rendering {index+1:02d} {name} ({width}x{height}@{fps})",flush=True)
        with log.open("w") as handle:
            result=subprocess.run(cmd,cwd=ROOT,stdout=handle,stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"{name}: renderer exit {result.returncode}\n{log.read_text()[-6000:]}")
    info=probe(output)
    video=next(s for s in info["streams"] if s["codec_type"]=="video")
    duration=float(info["format"]["duration"])
    if video["width"]!=width or video["height"]!=height or abs(duration-DURATIONS[index])>.15:
        raise RuntimeError(f"Invalid chapter {name}: {video['width']}x{video['height']} duration={duration}")
    a,b=map(int,video["avg_frame_rate"].split("/"))
    if abs(a/b-fps)>.001:
        raise RuntimeError(f"Wrong fps for {name}: {video['avg_frame_rate']}")
    print(f"Verified {index+1:02d} {name}: {duration:.2f}s",flush=True)
    return index,output

def mux(paths,preview=False):
    out=ROOT/"output"
    concat=out/("preview_concat.txt" if preview else "concat.txt")
    concat.write_text("".join("file '"+str(p).replace("'","'\\''")+"'\n" for p in paths))
    silent=out/("preview_silent.mp4" if preview else "silent.mp4")
    subprocess.run(["ffmpeg","-hide_banner","-loglevel","warning","-y","-f","concat","-safe","0","-i",str(concat),"-c","copy",str(silent)],check=True)
    data=json.loads((ROOT/"narration.json").read_text())
    metadata=out/"chapters.ffmeta"
    sections=[";FFMETADATA1","title=Вся кинематика с нуля за 11 минут","artist=Образовательная анимация Manim"]
    start=0
    for ch,duration in zip(data["chapters"],DURATIONS):
        sections.extend(["[CHAPTER]","TIMEBASE=1/1000",f"START={start*1000}",f"END={(start+duration)*1000}","title="+ch["title"]])
        start+=duration
    metadata.write_text("\n".join(sections)+"\n")
    final=out/("kinematika_preview.mp4" if preview else "kinematika_1080p60.mp4")
    cmd=["ffmpeg","-hide_banner","-loglevel","warning","-y","-i",str(silent),"-i",str(metadata),"-map","0:v:0","-map_metadata","1","-map_chapters","1","-c:v","copy","-an","-movflags","+faststart",str(final)]
    subprocess.run(cmd,check=True)
    report=probe(final)
    if any(s["codec_type"]=="audio" for s in report["streams"]):
        raise RuntimeError("The delivered film must contain no audio track")
    (out/"validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(f"Complete: {final} ({final.stat().st_size/1024**2:.1f} MiB)",flush=True)
    return final

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--preview",action="store_true")
    parser.add_argument("--jobs",type=int,default=3)
    parser.add_argument("--force",action="store_true")
    parser.add_argument("--chapters",nargs="*",type=int)
    parser.add_argument("--no-mux",action="store_true")
    args=parser.parse_args()
    selected=[n-1 for n in args.chapters] if args.chapters else list(range(12))
    results={}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures=[pool.submit(run_scene,i,args.preview,args.force) for i in selected]
        for f in as_completed(futures):
            i,path=f.result()
            results[i]=path
    if not args.no_mux and len(results)==12:
        mux([results[i] for i in range(12)],args.preview)
