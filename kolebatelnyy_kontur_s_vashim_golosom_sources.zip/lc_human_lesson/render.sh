#!/usr/bin/env bash
set -euo pipefail
film=$1
output=$2
ffmpeg -nostdin -hide_banner -n -threads 2 -i "$film" -i edit/narration.wav \
  -f ffmetadata -i edit/chapters.ffmeta -map 0:v:0 -map 1:a:0 \
  -map_metadata 2 -map_chapters 2 -filter_threads 1 -filter_script:v edit/video.filter \
  -c:v libx264 -threads:v 2 -preset superfast -crf 20 -g 240 \
  -pix_fmt yuv420p -c:a aac -b:a 112k -metadata:s:a:0 language=rus -movflags +faststart "$output"
