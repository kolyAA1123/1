# Колебательный контур и передача энергии — монтаж с записью 1020.MP3

Исходные анимации и сценарий находятся в репозитории в
`kolebatelnyy_kontur_sources.zip` и `kolebatelnyy_kontur_tekst.txt`.
Для монтажа использован опубликованный фильм `kolebatelnyy_kontur_1080p60.mp4`.
Итоговая версия содержит 9 глав, 58 реплик и 29 завершённых действий при 60 кадрах/с.

`boundaries.json` содержит границы пауз в записи в секундах.
Порядок реплик сверялся с исходным русским сценарием по распознанному тексту.
Короткая пауза на 148,55–148,82 с уточнена по сигналу и распознаванию отрывков
по обе стороны. `retain_before.json` сохраняет тихие начала двух реплик,
найденные дополнительной проверкой сигнала около 889 и 991 секунд.
`edit.json` описывает соответствие кадров, окон анимации и аудиоотсчётов.
`timeline.txt` содержит исходный сценарий с новыми таймкодами реплик.

## Повторная сборка

Распакуйте архив и запустите из каталога `lc_human_lesson`. Нужны Python 3.11+
и FFmpeg с libx264. Для проверок требуется NumPy.

```sh
python build_edit.py /path/to/kolebatelnyy_kontur_1080p60.mp4 /path/to/1020.MP3
bash render.sh /path/to/kolebatelnyy_kontur_1080p60.mp4 kolebatelnyy_kontur_s_vashim_golosom_1080p60.mp4
```

Сжатие H.264 и AAC происходит при выпуске, темп и высота голоса
сохраняются. Для звуковой дорожки практически одинаковые каналы записи
сведены в моно. Меняются только статичные окна фильма и паузы между
репликами. Внутри реплик отсчёты идут непрерывно, без растяжения звука.

Проверки исходных удержаний и монтажной копии можно повторить так.

```sh
ffmpeg -v error -xerror -threads 2 -i /path/to/kolebatelnyy_kontur_1080p60.mp4 \
  -map 0:v:0 -vf scale=160:90,format=gray -filter_threads 1 -f rawvideo source.gray
python check_holds.py source.gray
ffmpeg -v error -xerror -threads 2 -i kolebatelnyy_kontur_s_vashim_golosom_1080p60.mp4 \
  -map 0:v:0 -vf scale=160:90,format=gray -filter_threads 1 -f rawvideo delivered.gray \
  -map 0:a:0 -f s16le audio_decode.s16
python verify_edit.py kolebatelnyy_kontur_s_vashim_golosom_1080p60.mp4
```

Проект использует исходную запись только локально. В архив включены сценарий,
план, монтажные решения и результаты проверок.
