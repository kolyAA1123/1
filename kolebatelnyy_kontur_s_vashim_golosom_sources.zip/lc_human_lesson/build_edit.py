"""Build a frame-accurate edit by replacing the source's frozen narration holds."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
import wave

FPS = 60
SAMPLE_RATE = 48000
SAMPLES_PER_FRAME = SAMPLE_RATE // FPS
SOURCE_SHA256 = "c411d76b5ee84309f9cd025d62e171f3b62a3255e51dc0fddef4c8b7f7bd460d"

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("film", type=Path)
parser.add_argument("recording", type=Path)
parser.add_argument("--plan", type=Path, default=Path("lc_oscillations_lesson/plan.json"))
parser.add_argument("--boundaries", type=Path, default=Path("boundaries.json"))
parser.add_argument("--retain-before", type=Path, default=Path("retain_before.json"))
parser.add_argument("--output", type=Path, default=Path("edit"))
args = parser.parse_args()
out = args.output
out.mkdir(exist_ok=True)
with args.film.open("rb") as original:
    assert hashlib.file_digest(original, "sha256").hexdigest() == SOURCE_SHA256

plan = json.loads(args.plan.read_text())
gaps = json.loads(args.boundaries.read_text())
retain_before = json.loads(args.retain_before.read_text())
assert len(gaps) == 1 + 2 * sum(len(ch["beats"]) for ch in plan["chapters"])
assert all(a <= b and b < c for (a,b), (c,d) in zip(gaps, gaps[1:]))

audio = subprocess.check_output([
    "ffmpeg", "-v", "error", "-i", str(args.recording), "-map", "0:a:0",
    "-ac", "1", "-ar", str(SAMPLE_RATE), "-f", "s16le", "pipe:1",
])
sample_count = len(audio) // 2
wave_out = wave.open(str(out/"narration.wav"), "wb")
wave_out.setparams((1, 2, SAMPLE_RATE, 0, "NONE", "not compressed"))
output_cursor = 0
shift = 0
windows = []
chapters = []
index = 0
timeline = ["КОЛЕБАТЕЛЬНЫЙ КОНТУР И ПЕРЕДАЧА ЭНЕРГИИ", "Сценарий с таймкодами версии с авторской озвучкой"]

def pad(to_sample):
    global output_cursor
    assert to_sample >= output_cursor
    wave_out.writeframesraw(bytes(2 * (to_sample-output_cursor)))
    output_cursor = to_sample

def stamp(seconds):
    total = round(seconds)
    return f"{total//60:02d}:{total%60:02d}"

for chapter in plan["chapters"]:
    chapters.append(dict(title=chapter["title"], begin=chapter["start"]*FPS+shift))
    timeline.extend(["", f"{chapter['id']:02d}. {chapter['title']} · {stamp(chapters[-1]['begin']/FPS)}"])
    for beat in chapter["beats"]:
        for phase,label in (("intro","Теория"),("result","Объяснение результата")):
            # Leave the first/last quarter second of every original reading
            # window in place, in case the renderer rounded a boundary.
            begin = round((chapter["start"]+beat[phase+"_at"])*FPS)+15
            end = begin + beat[phase+"_duration"]*FPS-30
            left, right = gaps[index:index+2]
            left_mid = sum(left)/2
            right_mid = sum(right)/2
            cut_from = max(left_mid, left[1]-.24) if index else 0
            cut_to = min(right_mid, right[0]+.30) if index+2 < len(gaps) else sample_count/SAMPLE_RATE
            clip_start = round(cut_from*SAMPLE_RATE)
            clip_end = min(sample_count, round(cut_to*SAMPLE_RATE))
            assert clip_end > clip_start and cut_to > right[0] and cut_from < left[1]
            audio_frames = math.ceil((clip_end-clip_start)/SAMPLES_PER_FRAME)
            hold_frames = audio_frames + 12
            adjusted = begin+shift
            clip_at = (adjusted+6)*SAMPLES_PER_FRAME
            speech_source_begin = left[1]
            override = retain_before.get(str(index))
            if override:
                earlier = round(override["clip_from"] * SAMPLE_RATE)
                assert round(left[0]*SAMPLE_RATE) < earlier < clip_start
                clip_at -= clip_start-earlier
                clip_start = earlier
                cut_from = override["clip_from"]
                speech_source_begin = override["speech_from"]
            pad(clip_at)
            wave_out.writeframesraw(audio[2*clip_start:2*clip_end])
            output_cursor += clip_end-clip_start
            speech_begin = (clip_at/SAMPLE_RATE) + speech_source_begin-cut_from
            speech_end = (clip_at/SAMPLE_RATE) + right[0]-cut_from
            windows.append(dict(chapter=chapter["id"], beat=beat["index"]+1, phase=phase,
                source_hold=[begin,end], output_hold=[adjusted,adjusted+hold_frames],
                audio_source_samples=[clip_start,clip_end], audio_output_sample=clip_at,
                speech=[round(speech_begin,3),round(speech_end,3)]))
            timeline.extend(["",f"[{stamp(speech_begin)}–{stamp(speech_end)}] {label}",beat[phase]])
            shift += hold_frames-(end-begin)
            index += 1

total = plan["duration"]*FPS+shift
pad(total*SAMPLES_PER_FRAME)
wave_out.close()
chapters.append(dict(begin=total))
(out/"edit.json").write_text(json.dumps(dict(fps=FPS,total_frames=total,windows=windows,chapters=chapters[:-1]),
                                         ensure_ascii=False,indent=2)+"\n")
(out/"timeline.txt").write_text("\n".join(timeline)+"\n",encoding="utf-8-sig")
metadata = [";FFMETADATA1", "title=Колебательный контур и передача энергии"]
for current, following in zip(chapters, chapters[1:]):
    metadata.extend(["", "[CHAPTER]", "TIMEBASE=1/60", f"START={current['begin']}",
                     f"END={following['begin']}", "title="+current["title"]])
(out/"chapters.ffmeta").write_text("\n".join(metadata)+"\n")
# One representative per frozen window. Move following frames by a whole
# number of ticks, then duplicate only the frozen frames to fill PTS gaps.
remove = []
retime = []
for window in windows:
    a,b = window["source_hold"]
    c,d = window["output_hold"]
    remove.append(f"between(n,{a+1},{b-1})")
    retime.append(f"{d-c-b+a}*gte(PTS,{b})")
(out/"video.filter").write_text("select='not("+"+".join(remove)+")',settb=1/60,setpts='PTS+"+
                               "+".join(retime)+"',fps=60\n")
print(out, total, f"{total/FPS:.3f}s")
