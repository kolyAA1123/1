from pathlib import Path
import math
import json

import numpy as np
from manim import Axes, Create, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Многочлены и квадратные уравнения"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



def graph(kind):
    if kind=="parabola":
        axes=Axes(x_range=[-2.25,4.25,1],y_range=[-2.25,5.15,1],x_length=5.25,y_length=3.8,
                  axis_config={"stroke_width":1.7,"color":MUTED,"include_ticks":False}).move_to([-3.67,-.15,0])
        curve=axes.plot(lambda x:(x-1)**2-1, x_range=[-1.36,3.36],color=CYAN,stroke_width=3.2)
        dots=VGroup(*[Dot(axes.c2p(x,y),radius=.068,color=color) for x,y,color in [(0,0,GOLD),(2,0,GOLD),(1,-1,LAVENDER)]])
        return VGroup(axes),VGroup(curve,dots)
    if kind=="signs":
        left=-5.98
        width=.83
        def p(k):
            return np.array([left+width*(k+4),-.22,0])
        axis=Line(p(-4),p(2),color=MUTED,stroke_width=2.0)
        ticks=VGroup(*[equation(str(v),INK,p(v)+[0,-.33,0],.31) for v in (-3,1)])
        marks=VGroup(Line(p(-3),p(2),color=CYAN,stroke_width=5),
                    Dot(p(-3),color=GOLD,radius=.075),Dot(p(1),color=GOLD,radius=.075))
        return VGroup(axis,ticks),marks
    if kind=="horner":
        cells=[-5.75,-4.38,-3.0,-1.62]
        values=(("2","-3","-8","12"),("","4","2","-12"),("2","1","-6","0"))
        base=VGroup(Line([-6.2,-.54,0],[-1.05,-.54,0],color=MUTED,stroke_width=1.7),
                    equation("2",GOLD,[-6.35,-.21,0],.31))
        marks=VGroup()
        for row,tokens in enumerate(values):
            for x,token in zip(cells,tokens):
                if token:
                    marks.add(equation(token,(INK,LAVENDER,CYAN)[row],[x,.5-.74*row,0],.34))
        return base,marks
    return VGroup(),VGroup()


class PolynomialLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind=="signs" else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
