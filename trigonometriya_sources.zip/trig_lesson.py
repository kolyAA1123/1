from pathlib import Path
import math

import numpy as np
from manim import (
    Arc, Arrow, Circle, Create, DashedLine, Dot, FadeIn, FadeOut, Line,
    Scene, VGroup, config, smootherstep,
)

from lesson_data import SECTIONS
from visual_style import (
    BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt,
)

config.background_color = BLACK_BG
config.pixel_width = 1920
config.pixel_height = 1080
config.frame_rate = 60

CENTER = np.array([-3.62, -0.33, 0])
RADIUS = 1.63
TITLE = "Тригонометрия"


def angular_point(angle, center=CENTER, radius=RADIUS):
    return center + radius * np.array([math.cos(angle), math.sin(angle), 0])


def circle_diagram(angles, orientation):
    axes = VGroup(
        Arrow(CENTER + [-2.28, 0, 0], CENTER + [2.29, 0, 0], buff=0, stroke_width=2, color=MUTED),
        Arrow(CENTER + [0, -2.06, 0], CENTER + [0, 2.03, 0], buff=0, stroke_width=2, color=MUTED),
        Circle(radius=RADIUS, color=MUTED, stroke_width=2.2).move_to(CENTER),
        txt("x", 18, MUTED).move_to(CENTER + [2.18, -0.25, 0]),
        txt("y", 18, MUTED).move_to(CENTER + [0.20, 1.95, 0]),
    )
    marks = VGroup()
    for angle, color in zip(angles, (CYAN, GOLD, ROSE, LAVENDER)):
        tip = angular_point(angle)
        marks.add(Line(CENTER, tip, color=color, stroke_width=3), Dot(tip, radius=.067, color=color))
    if len(angles) == 1:
        tip = angular_point(angles[0])
        foot = np.array([tip[0], CENTER[1], 0])
        if np.linalg.norm(tip-foot) > .05:
            marks.add(DashedLine(tip, foot, color=ROSE, stroke_width=2))
        foot = np.array([CENTER[0], tip[1], 0])
        if np.linalg.norm(tip-foot) > .05:
            marks.add(DashedLine(tip, foot, color=CYAN, stroke_width=2))
    if orientation and angles:
        marks.add(Arc(radius=.47, start_angle=min(0, angles[0]), angle=abs(angles[0]),
                      arc_center=CENTER, color=LAVENDER))
    return axes, marks


def interval_diagram():
    left, right, y = -6.3, -.81, -.32
    scale = .42
    def point(unit):
        return np.array([left+.27+unit*scale, y, 0])
    axis = Arrow([left, y, 0], [right, y, 0], buff=0, stroke_width=2.5, color=MUTED)
    segment = Line(point(0), point(6), stroke_width=5, color=LAVENDER)
    labels = VGroup()
    for place, latex in [(0, r"-4\pi"), (6, r"-5\pi/2")]:
        labels.add(equation(latex, INK, point(place)+[0,-.42,0], .29))
    points = VGroup(*[Dot(point(i), radius=.064, color=GOLD) for i in (1,2,6)])
    return VGroup(axis, segment, labels), points


def diagram(spec):
    if spec == "interval":
        return interval_diagram()
    if isinstance(spec, tuple):
        return circle_diagram(spec, len(spec) == 1)
    return VGroup(), VGroup()


def timestamp(seconds):
    point = round(seconds)
    return f"{point // 60:02d}:{point % 60:02d}"


class TrigonometryLesson(Scene):
    def construct(self):
        heading = txt(TITLE, 27).to_corner(np.array([-1,1,0]), buff=.38)
        rule = Line([-6.57, 2.79, 0], [6.57, 2.79, 0], color=GRID, stroke_width=1.3)
        self.play(FadeIn(heading), Create(rule), run_time=1.2, rate_func=smootherstep)
        script = [TITLE, "Сценарий для озвучки"]
        for number, (title, spec, beats) in enumerate(SECTIONS, 1):
            subtitle = txt(title, 25, MUTED).move_to([0,2.37,0])
            count = txt(f"{number:02d} / {len(SECTIONS):02d}", 16, MUTED).move_to([6.06,3.51,0])
            base, marks = diagram(spec)
            before = [subtitle, count]
            if len(base):
                before.append(base)
            self.play(*[FadeIn(mob) for mob in before], run_time=.88, rate_func=smootherstep)
            script.extend(["", title])
            centers = np.linspace(1.2,-1.56,len(beats))
            center_x = 3.28 if spec is not None else 0
            limit = 6.65 if spec is not None else 12.25
            for i, ((formula, text), y) in enumerate(zip(beats, centers)):
                color = (INK, CYAN, GOLD, LAVENDER)[i]
                height = .67 if "\\frac" in formula else .49
                visual = equation(formula, color, [center_x,y,0], height)
                if visual.width > limit:
                    visual.scale_to_fit_width(limit)
                add = [visual]
                if i==0 and len(marks):
                    add.append(marks)
                self.play(*[FadeIn(mob, shift=np.array([0,.04,0])) for mob in add],
                          run_time=.65, rate_func=smootherstep)
                before.extend(add)
                start = timestamp(self.time)
                self.wait(math.ceil(len(text.split())/2.15)+1)
                script.extend([f"[{start}–{timestamp(self.time)}]", text])
            self.play(*[FadeOut(mob) for mob in before], run_time=.70, rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        Path("trigonometry_narration.txt").write_text("\n".join(script)+"\n", encoding="utf-8-sig")
