Установите Python, системные зависимости Manim, шрифт DejaVu Sans и FFmpeg. Из распакованной папки последовательно выполните команды.

python -m pip install manim==0.20.1 matplotlib
python -m manim -qh --fps 60 trig_lesson.py TrigonometryLesson
