"""All five theory pages of the user's capacitor notes; no numerical tasks."""
from electric_style import *


def plates(left=-4.4,right=-1.8,dielectric=True,signs=True):
    """Facing plates. Charges mark plate charge, never cross the dielectric."""
    metal=VGroup(Line([left,-1.25,0],[left,1.25,0],color=ROSE,stroke_width=6),
                 Line([right,-1.25,0],[right,1.25,0],color=CYAN,stroke_width=6))
    medium=Rectangle(width=right-left-.12,height=2.5,stroke_width=0,
                     fill_color=LAVENDER,fill_opacity=.12).move_to([(left+right)/2,0,0])
    markers=VGroup(*[charge(s,[x,y,0],.15) for x,s in [(left,'+'),(right,'−')] for y in [-.85,0,.85]])
    names=VGroup(formula('+q',[left,1.85,0],31,ROSE,width=1.2),
                 formula('-q',[right,1.85,0],31,CYAN,width=1.2))
    body=VGroup(metal)
    if dielectric:body.add(medium)
    if signs:body.add(markers,names)
    return body,metal,medium,markers,names


def symbol(center=(-3.1,0,0),label='C',color=INK,scale=1):
    x,y,_=center;gap=.18*scale;h=.45*scale;length=1.1*scale
    bars=VGroup(Line([x-gap,y-h,0],[x-gap,y+h,0],color=color,stroke_width=3),
                Line([x+gap,y-h,0],[x+gap,y+h,0],color=color,stroke_width=3))
    leads=VGroup(Line([x-length,y,0],[x-gap,y,0],color=MUTED),
                 Line([x+gap,y,0],[x+length,y,0],color=MUTED))
    name=formula(label,[x,y+.8*scale,0],30,color,width=2.1)
    return VGroup(bars,leads,name)


def parallel():
    caps=VGroup(symbol((-3.1,.85,0),'C_1',scale=.7),
                symbol((-3.1,-.85,0),'C_2',scale=.7))
    # All labels are above their branch, not on a lead.
    wires=VGroup(Line([-5.2,.85,0],[-3.87,.85,0],color=MUTED),
                 Line([-2.33,.85,0],[-1,.85,0],color=MUTED),
                 Line([-5.2,-.85,0],[-3.87,-.85,0],color=MUTED),
                 Line([-2.33,-.85,0],[-1,-.85,0],color=MUTED),
                 Line([-5.2,-.85,0],[-5.2,.85,0],color=MUTED),
                 Line([-1,-.85,0],[-1,.85,0],color=MUTED),
                 Line([-5.75,0,0],[-5.2,0,0],color=MUTED),
                 Line([-1,0,0],[-.45,0,0],color=MUTED))
    nodes=VGroup(Dot([-5.2,0,0],radius=.05,color=GOLD),Dot([-1,0,0],radius=.05,color=GOLD))
    return caps,wires,nodes


def series():
    caps=VGroup(symbol((-4.05,0,0),'C_1',scale=.7),symbol((-1.85,0,0),'C_2',scale=.7))
    wires=VGroup(Line([-5.75,0,0],[-4.82,0,0],color=MUTED),
                 Line([-3.28,0,0],[-2.62,0,0],color=MUTED),
                 Line([-1.08,0,0],[-.45,0,0],color=MUTED))
    node=Dot([-2.95,0,0],radius=.05,color=GOLD)
    return caps,wires,node


class CapacitanceGeometry(ElectricScene):
    chapter_id=13
    def chapter(self):
        self.beat(0)
        body,metal,medium,markers,names=plates(signs=False)
        definition=words(['Две проводящие обкладки','Между ними диэлектрик'],(3.1,1.0,0),25)
        self.show(body,definition,run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(FadeIn(markers),FadeIn(names),lag_ratio=.4))
        self.show(symbol((3.1,-.7,0)),words('q — модуль заряда одной обкладки',(3.1,-2.0,0),22,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        body,metal,medium,markers,names=plates(signs=False)
        s=formula('S',(-5.1,.15,0),33,LAVENDER,width=1)
        epsilon=formula(r'\varepsilon',(-3.1,.15,0),38,LAVENDER,width=1)
        gap=DoubleArrow([-4.4,-1.75,0],[-1.8,-1.75,0],buff=0,color=GOLD)
        d=formula('d',(-3.1,-2.1,0),29,GOLD,width=1)
        law=formula(r'C=\frac{\varepsilon\varepsilon_0S}{d}',(3.1,1.25,0),45)
        self.show(body,s,epsilon,gap,d,law,run_time=1.2)
        self.intro(1)
        consequences=words(['S ↑  ⇒  C ↑','ε ↑  ⇒  C ↑','d ↑  ⇒  C ↓'],(3.1,-.2,0),25)
        self.act(1,LaggedStart(*[FadeIn(x) for x in consequences],lag_ratio=.3))
        self.show(words('C — Ф; S — м²; d — м',(3.1,-1.4,0),21,MUTED),
                  formula(r'\varepsilon_0=8.85\cdot10^{-12}\ \mathrm{F/m}',(3.1,-2.1,0),28,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        initial=formula(r'C=\frac{q}{U}',(-3.1,.8,0),49,CYAN)
        condition=words(['Геометрия и диэлектрик','не меняются'],(-3.1,-.8,0),24,MUTED)
        result=formula('q=CU',(3.1,.8,0),49,GOLD)
        self.show(initial,condition,words(['Линейная модель','Постоянная ёмкость'],(3.1,2,0),22),run_time=1.2)
        self.intro(2)
        self.act(2,Write(result))
        self.show(formula(r'1\ \mathrm{F}=1\ \mathrm{C/V}',(3.1,-.8,0),34),
                  words('При увеличении U заряд растёт пропорционально',(0,-2.25,0),23,MUTED,width=11.5),run_time=1.2)
        self.result(2)


class CapacitorModesField(ElectricScene):
    chapter_id=14
    def chapter(self):
        self.beat(0)
        body,metal,medium,markers,names=plates(left=-4.4,right=-2.2,dielectric=False)
        # Moving the complete right group preserves its charge markers and label.
        left=VGroup(metal[0],markers[0],markers[1],markers[2],names[0])
        right=VGroup(metal[1],markers[3],markers[4],markers[5],names[1])
        fixed=formula(r'q=\mathrm{const}',(3.1,1.1,0),43,GOLD)
        self.show(left,right,fixed,words('Обкладки изолированы',(-3.1,-2.0,0),24,MUTED),run_time=1.2)
        self.intro(0)
        self.act(0,right.animate.shift(RIGHT*.65))
        self.show(formula(r'U=\frac qC',(3.1,-.25,0),43),
                  words('d ↑  ⇒  C ↓  ⇒  U ↑',(3.1,-1.6,0),25,CYAN),run_time=1.2)
        self.result(0)

        self.beat(1)
        body,metal,medium,markers,names=plates(dielectric=False)
        wires=VGroup(VMobject(color=MUTED).set_points_as_corners([[-4.4,1.25,0],[-5.3,1.25,0],[-5.3,-1.9,0],[-3.35,-1.9,0]]),
                     VMobject(color=MUTED).set_points_as_corners([[-1.8,1.25,0],[-.9,1.25,0],[-.9,-1.9,0],[-2.85,-1.9,0]]))
        battery=VGroup(Line([-3.35,-2.25,0],[-3.35,-1.55,0],color=ROSE,stroke_width=3),
                       Line([-2.85,-2.08,0],[-2.85,-1.72,0],color=CYAN,stroke_width=3))
        u=words('Источник: U = const',(-3.1,-2.65,0),22,GOLD)
        condition=formula(r'U=\mathrm{const}',(3.1,1.1,0),43,GOLD)
        self.show(body,wires,battery,u,condition,run_time=1.2)
        self.intro(1)
        extra=VGroup(*[charge(s,[x,y,0],.15) for x,s in [(-4.4,'+'),(-1.8,'−')] for y in [-.425,.425]])
        self.act(1,FadeIn(medium),FadeIn(extra))
        self.show(formula('q=CU',(3.1,-.3,0),43),words(['ε ↑  ⇒  C ↑  ⇒  q ↑','Заряд идёт по внешней цепи'],(3.1,-1.65,0),23,CYAN),run_time=1.2)
        self.result(1)

        self.beat(2)
        body,metal,medium,markers,names=plates(dielectric=False)
        field=VGroup(*[arrow([-4.15,y,0],[2.1,0,0],GOLD) for y in [-.75,.75]])
        probe=charge('+',[-4.4,.425,0],.15)
        dline=DoubleArrow([-4.4,-1.75,0],[-1.8,-1.75,0],buff=0,color=MUTED)
        dlabel=formula('d',(-3.1,-2.1,0),27,MUTED,width=1)
        first=formula(r'U=\frac{A}{q_0}',(3.1,1.2,0),43)
        self.show(body,field,probe,dline,dlabel,first,run_time=1.2)
        self.intro(2)
        work=formula(r'A=Fd=Eq_0d',(3.1,-.05,0),35,GOLD)
        self.act(2,probe.animate.move_to([-1.8,.425,0]),Write(work))
        self.show(formula(r'U=Ed\quad\Rightarrow\quad E=\frac Ud',(3.1,-1.35,0),35),
                  formula(r'[E]=\mathrm{V/m}=\mathrm{N/C}',(3.1,-2.4,0),26,MUTED),run_time=1.2)
        self.result(2)


class CapacitorEnergy(ElectricScene):
    chapter_id=15
    def chapter(self):
        self.beat(0)
        body,metal,medium,markers,names=plates()
        field=VGroup(*[arrow([-4.15,y,0],[2.1,0,0],GOLD) for y in [-.65,.65]])
        definition=words(['Энергия электрического поля','Идеальный линейный конденсатор'],(3.1,1.25,0),24)
        energy=formula(r'W_C=\frac{CU^2}{2}',(3.1,-.2,0),49,GOLD)
        self.show(body,field,definition,run_time=1.2)
        self.intro(0)
        self.act(0,Write(energy),medium.animate.set_fill(opacity=.25))
        self.show(words('Энергия измеряется в джоулях',(3.1,-1.9,0),24,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        initial=formula(r'W_C=\frac{CU^2}{2}',(-3.1,1.1,0),45)
        connection=formula(r'q=CU\quad\Rightarrow\quad U=\frac qC',(-3.1,-.3,0),35,CYAN)
        substitution=formula(r'W_C=\frac{C}{2}\left(\frac qC\right)^2',(3.1,1.0,0),40)
        final=formula(r'W_C=\frac{q^2}{2C}',(3.1,-.65,0),47,GOLD)
        self.show(initial,connection,run_time=1.2)
        self.intro(1)
        self.act(1,Succession(Write(substitution),Write(final)))
        self.show(words('Тот же конденсатор, та же энергия',(0,-2.2,0),25,MUTED,width=11.5),run_time=1.2)
        self.result(1)

        self.beat(2)
        title=words('Одна и та же энергия поля',(0,2.05,0),27,width=11.5)
        connection=formula('q=CU',(-3.1,.7,0),45,CYAN)
        old=formula(r'W_C=\frac{CU^2}{2}',(3.1,.7,0),45)
        new=formula(r'W_C=\frac{qU}{2}',(3.1,.7,0),45,GOLD)
        self.show(title,connection,old,run_time=1.2)
        self.intro(2)
        self.act(2,Succession(FadeOut(old),FadeIn(new)))
        self.show(formula(r'W_C=\frac{CU^2}{2}=\frac{q^2}{2C}=\frac{qU}{2}',(0,-1.4,0),42,GOLD,width=11.5),run_time=1.2)
        self.result(2)


class ParallelCapacitors(ElectricScene):
    chapter_id=16
    def chapter(self):
        self.beat(0)
        caps,wires,nodes=parallel()
        description=words(['Параллельное соединение','Два общих узла'],(3.1,1.1,0),26)
        relation=formula(r'U=U_1=U_2',(3.1,-.2,0),41,GOLD)
        self.show(caps,description,run_time=1.2)
        self.intro(0)
        self.act(0,Create(wires),FadeIn(nodes),Write(relation))
        self.show(words('Ёмкости C₁ и C₂ могут различаться',(3.1,-1.65,0),23,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        caps,wires,nodes=parallel()
        labels=VGroup(formula('q_1',(-4.3,1.3,0),27,ROSE,width=1),formula('q_2',(-4.3,-.4,0),27,ROSE,width=1))
        description=words(['Заряды складываются','На соответствующих обкладках'],(3.1,1.0,0),24)
        relation=formula(r'q=q_1+q_2',(3.1,-.3,0),42,ROSE)
        self.show(caps,wires,nodes,description,run_time=1.2)
        self.intro(1)
        self.act(1,FadeIn(labels),Write(relation))
        self.show(formula(r'q_1=C_1U,\qquad q_2=C_2U',(0,-2.2,0),36,CYAN,width=11.5),run_time=1.2)
        self.result(1)

        self.beat(2)
        substitution=formula(r'CU=C_1U+C_2U',(0,1.25,0),47)
        condition=words('Одно и то же напряжение U',(0,0,0),27,MUTED,width=11.5)
        result=formula(r'C=C_1+C_2',(0,-1.2,0),50,GOLD,width=11.5)
        self.show(substitution,condition,run_time=1.2)
        self.intro(2)
        self.act(2,Write(result))
        self.show(words('Эквивалентная ёмкость параллельных ветвей',(0,-2.35,0),24,MUTED,width=11.5),run_time=1.2)
        self.result(2)


class SeriesCapacitors(ElectricScene):
    chapter_id=17
    def chapter(self):
        self.beat(0)
        caps,wires,node=series()
        given=words(['Последовательная цепочка','Исходно конденсаторы','не заряжены'],(3.1,1.2,0),25)
        markers=VGroup(*[formula(s,[x,-.65,0],26,c,width=.8) for x,s,c in
                        [(-4.3,'+q',ROSE),(-3.8,'-q',CYAN),(-2.1,'+q',ROSE),(-1.6,'-q',CYAN)]])
        self.show(caps,wires,node,given,run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(markers),Write(formula(r'q=q_1=q_2',(3.1,-.55,0),43,GOLD)))
        self.show(words('Внутренний узел остаётся нейтральным',(-3.1,-1.75,0),22,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        caps,wires,node=series()
        labels=VGroup(formula('U_1',(-4.05,-.75,0),30,GOLD,width=1),formula('U_2',(-1.85,-.75,0),30,GOLD,width=1))
        total=formula(r'U=U_1+U_2',(3.1,1.4,0),42)
        first=formula(r'U_1=\frac q{C_1}',(3.1,.05,0),39)
        second=formula(r'U_2=\frac q{C_2}',(3.1,-1.3,0),39)
        self.show(caps,wires,node,labels,total,run_time=1.2)
        self.intro(1)
        self.act(1,Succession(Write(first),Write(second)))
        self.show(words('При одном q: меньшая C — большее U',(0,-2.55,0),24,MUTED,width=11.5),run_time=1.2)
        self.result(1)

        self.beat(2)
        initial=formula(r'\frac qC=\frac q{C_1}+\frac q{C_2}',(0,1.25,0),48)
        given=words('Сокращаем общий ненулевой заряд обкладки',(0,-.05,0),25,MUTED,width=11.5)
        final=formula(r'\frac1C=\frac1{C_1}+\frac1{C_2}',(0,-1.3,0),49,GOLD,width=11.5)
        self.show(initial,given,run_time=1.2)
        self.intro(2)
        self.act(2,Write(final))
        self.show(words('Формула описывает и незаряженную цепочку',(0,-2.55,0),24,MUTED,width=11.5),run_time=1.2)
        self.result(2)

        self.beat(3)
        headings=VGroup(words('Параллельно',(-3.1,2.15,0),28,CYAN),words('Последовательно',(3.1,2.15,0),28,GOLD))
        left=VGroup(formula(r'C=C_1+C_2+\cdots+C_n',(-3.1,1.1,0),31,CYAN),
                    formula(r'q=q_1+q_2+\cdots+q_n',(-3.1,-.15,0),31),
                    formula(r'U=U_1=U_2=\cdots=U_n',(-3.1,-1.4,0),31))
        right=VGroup(formula(r'\frac1C=\frac1{C_1}+\frac1{C_2}+\cdots+\frac1{C_n}',(3.1,1.1,0),30,GOLD),
                     formula(r'q=q_1=q_2=\cdots=q_n',(3.1,-.15,0),31),
                     formula(r'U=U_1+U_2+\cdots+U_n',(3.1,-1.4,0),31))
        self.show(headings,run_time=1.2)
        self.intro(3)
        self.act(3,LaggedStart(*[FadeIn(m) for m in [*left,*right]],lag_ratio=.2))
        self.show(words('Выбираем формулу по способу соединения',(0,-2.6,0),24,MUTED,width=11.5),run_time=1.2)
        self.result(3)
