"""Electrostatic work, matter and a conducting sphere (source pp. 8–14)."""
from electric_style import *


def dipole_lines():
    plus=np.array([-1.4,0.]);minus=np.array([1.4,0.]);curves=VGroup();heads=VGroup()
    for angle in [-1.,-.7,-.35,0,.35,.7,1.]:
        p=plus+.3*np.array([np.cos(angle),np.sin(angle)]);points=[p.copy()]
        for _ in range(3000):
            a=p-plus;b=p-minus
            field=a/np.linalg.norm(a)**3-b/np.linalg.norm(b)**3
            p=p+.025*field/np.linalg.norm(field);points.append(p.copy())
            if np.linalg.norm(p-minus)<.3:break
        path=VMobject(color=GOLD,stroke_width=2).set_points_smoothly(
            [[x-3.1,y,0] for x,y in points])
        curves.add(path)
        mid=path.point_from_proportion(.5);later=path.point_from_proportion(.57)
        heads.add(arrow(mid,later-mid,GOLD,2))
    return curves,heads


def plates(center=(-3.1,0,0),width=4.3,height=3.3,with_field=False):
    x,y,_=center;left=x-width/2;right=x+width/2
    metal=VGroup(Line([left,y-height/2,0],[left,y+height/2,0],color=ROSE,stroke_width=3),
                 Line([right,y-height/2,0],[right,y+height/2,0],color=CYAN,stroke_width=3))
    signs=VGroup();field=VGroup()
    for yy in np.linspace(y-1.2,y+1.2,5):
        signs.add(txt('+',22,ROSE).move_to([left-.28,yy,0]),txt('−',22,CYAN).move_to([right+.28,yy,0]))
        field.add(arrow([left+.25,yy,0],[width-.5,0,0],GOLD,2))
    return VGroup(metal,signs),field


def conductor():
    body=RoundedRectangle(width=4.6,height=2.4,corner_radius=.08,color=MUTED).move_to([-3.1,0,0])
    surfaces=VGroup()
    for y in (-.75,0,.75):
        surfaces.add(charge('−',[-5.16,y,0],.16),charge('+',[-1.04,y,0],.16))
    outside=arrow([-5.2,1.78,0],[4.2,0,0],GOLD,3)
    e0=eq(r'\vec E_{\rm ext}',27,GOLD).move_to([-3.1,2.15,0])
    induced=arrow([-1.0,-1.8,0],[-4.2,0,0],LAVENDER,3)
    ei=eq(r'\vec E_{\rm ind}',27,LAVENDER).move_to([-3.1,-2.18,0])
    return body,surfaces,VGroup(outside,e0),VGroup(induced,ei)


def dipole(center,angle=0):
    c=np.array(center,dtype=float)
    group=VGroup(Line(c+LEFT*.14,c+RIGHT*.14,color=MUTED,stroke_width=1.5),
                 Dot(c+LEFT*.25,radius=.1,color=CYAN),Dot(c+RIGHT*.25,radius=.1,color=ROSE))
    return group.rotate(angle,about_point=c)


def polarized_body():
    body=Rectangle(width=4.8,height=2.6,color=MUTED).move_to([-3.1,0,0])
    ds=VGroup(*[dipole([x,y,0]) for y in (-.65,.65) for x in (-4.5,-3.1,-1.7)])
    return body,ds


def sphere(center=(-3.1,0,0),radius=1.05,signs=True):
    c=np.array(center,dtype=float)
    surface=Circle(radius=radius,color=ROSE,stroke_width=2.5,fill_color=ROSE,fill_opacity=.035).move_to(c)
    marks=VGroup()
    if signs:
        for a in np.linspace(0,TAU,8,endpoint=False):
            marks.add(txt('+',18,ROSE).move_to(c+(radius+.17)*np.array([np.cos(a),np.sin(a),0])))
    return VGroup(surface,marks)


class FieldGeometry(ElectricScene):
    chapter_id=7
    def chapter(self):
        self.beat(0)
        q=VGroup(charge('+',[-4.5,0,0]),charge('−',[-1.7,0,0]))
        curves,heads=dipole_lines()
        initial=words(['Два разноимённых заряда','Поле — векторная сумма'],[3.1,1.2,0],25)
        self.show(q,initial,run_time=1.2);self.intro(0)
        self.act(0,Create(curves),FadeIn(heads))
        self.show(words(['Линии: от + к −','Вектор E — по касательной','Линии не пересекаются'],[3.1,-.9,0],24,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        metal,field=plates()
        self.show(metal,words(['Большие параллельные пластины','Центральная область'],[3.1,1.2,0],24),run_time=1.2)
        self.intro(1);self.act(1,LaggedStart(*[Create(a) for a in field],lag_ratio=.2))
        self.show(formula(r'\vec E=\vec E_{+}+\vec E_{-}',[3.1,-.2,0],37,GOLD),
                  words(['Поля между пластинами сонаправлены','Краевыми эффектами пренебрегаем'],[3.1,-1.7,0],21),run_time=1.2)
        self.result(1)

        self.beat(2)
        objects=VGroup();paths=[];markers=[]
        for index,cx in enumerate((-3.2,3.2)):
            a=np.array([cx-1.4,-.65,0]);b=np.array([cx+1.4,-.65,0])
            fields=VGroup(*[arrow([cx-2.25,y,0],[4.5,0,0],GRID,1.3) for y in (-.2,.45,1.1)])
            heading=words('Прямой перенос' if index==0 else 'Вертикальные участки',[cx,2.0,0],24)
            names=VGroup(eq('A',25).move_to(a+DOWN*.43),eq('B',25).move_to(b+DOWN*.43),eq('E',25,GOLD).move_to([cx+2.05,1.5,0]))
            marker=charge('+',a,.17)
            path=Line(a,b,color=LAVENDER,stroke_width=2.5) if index==0 else VMobject(color=LAVENDER,stroke_width=2.5).set_points_as_corners([a,a+UP*1.7,b+UP*1.7,b])
            paths.append(path);markers.append(marker);objects.add(fields,heading,names,marker)
        self.show(objects,run_time=1.2);self.intro(2)
        self.act(2,*[Create(p) for p in paths],*[MoveAlongPath(m,p) for m,p in zip(markers,paths)],rate_func=linear)
        self.show(formula(r'A_1=A_2',[0,-2.25,0],43,GOLD,11.5),run_time=1.2);self.result(2)


class WorkPotential(ElectricScene):
    chapter_id=8
    def chapter(self):
        self.beat(0)
        definition=formula(r'\Delta W_{\rm p}=W_{{\rm p}2}-W_{{\rm p}1}',[-3.1,.9,0],37)
        purpose=words(['Потенциальная энергия','заряда во внешнем поле'],[3.1,.9,0],25)
        work=formula(r'A_{\rm el}=W_{{\rm p}1}-W_{{\rm p}2}',[0,-.55,0],43,GOLD,11.5)
        self.show(definition,purpose,run_time=1.2);self.intro(0)
        self.act(0,Write(work))
        self.show(formula(r'A_{\rm el}=-\Delta W_{\rm p}',[0,-1.95,0],43,LAVENDER,11.5),run_time=1.2);self.result(0)

        self.beat(1)
        headings=VGroup(words('Потенциал в точке',[-3.1,1.9,0],25),words('Напряжение между точками',[3.1,1.9,0],25))
        definitions=VGroup(formula(r'\varphi=\frac{W_{\rm p}}{q}',[-3.1,.65,0],45),formula(r'U_{AB}=\frac{A_{AB}}{q}',[3.1,.65,0],45))
        result=formula(r'U_{AB}=\varphi_A-\varphi_B',[0,-.9,0],44,GOLD,11.5)
        self.show(headings,definitions,run_time=1.2);self.intro(1);self.act(1,Write(result))
        self.show(formula(r'[\varphi]=[U]=\mathrm{J}/\mathrm{C}=\mathrm{V}',[0,-2.15,0],33,MUTED,11.5),run_time=1.2);self.result(1)

        self.beat(2)
        particle=charge('+',[-4.8,0,0],.24)
        force=VGroup(arrow([-4.65,.55,0],[1.0,0,0],LAVENDER),eq('F',27,LAVENDER).move_to([-4.1,.95,0]))
        moving=VGroup(particle,force)
        e=VGroup(arrow([-5.4,1.45,0],[4.6,0,0],GOLD),eq('E',27,GOLD).move_to([-1.05,1.85,0]))
        shift=arrow([-4.8,-.8,0],[3.1,0,0],MUTED)
        self.show(moving,e,formula(r'A_{\rm el}=Fs\cos\alpha',[3.1,1.2,0],39),run_time=1.2)
        self.intro(2);self.act(2,moving.animate.shift(RIGHT*3.1),Create(shift))
        self.show(formula(r'A_{\rm el}>0,\quad U_{AB}>0',[3.1,-.1,0],36,GOLD),
                  formula(r'\varphi_A>\varphi_B',[3.1,-1.4,0],42),run_time=1.2);self.result(2)

        self.beat(3)
        e=arrow([-5.6,.45,0],[5.0,0,0],GOLD)
        marks=VGroup(*[Dot([x,.45,0],radius=.065,color=GOLD) for x in (-5.0,-3.1,-1.2)])
        labels=VGroup(*[eq(rf'\varphi_{i+1}',28).move_to([x,-.3,0]) for i,x in enumerate((-5.0,-3.1,-1.2))])
        self.show(e,marks,eq('E',30,GOLD).move_to([-3.1,1.2,0]),words('По направлению поля',[3.1,1.4,0],26),run_time=1.2)
        self.intro(3)
        self.act(3,LaggedStart(*[FadeIn(m) for m in labels],lag_ratio=.3))
        self.show(formula(r'\varphi_1>\varphi_2>\varphi_3',[3.1,-.05,0],39,GOLD),
                  words(['φ — скалярная величина','E — векторная величина'],[3.1,-1.65,0],24),run_time=1.2);self.result(3)


class ConductorInduction(ElectricScene):
    chapter_id=9
    def chapter(self):
        self.beat(0)
        frames=VGroup(*[RoundedRectangle(width=4.7,height=2.7,corner_radius=.1,color=MUTED).move_to([x,0,0]) for x in (-3.1,3.1)])
        heads=VGroup(words('Свободные носители',[-3.1,1.95,0],25),words('Связанные заряды',[3.1,1.95,0],25))
        electron=charge('−',[-2.65,0,0],.2)
        lattice=VGroup(Dot([-3.8,.65,0],radius=.12,color=MUTED),Dot([-2.4,-.65,0],radius=.12,color=MUTED))
        minus=charge('−',[2.85,0,0],.2);plus=charge('+',[3.35,0,0],.2)
        fields=VGroup(*[arrow([x-1.7,-1.9,0],[3.4,0,0],GOLD,2) for x in (-3.1,3.1)])
        self.show(frames,heads,electron,lattice,minus,plus,fields,run_time=1.2);self.intro(0)
        self.act(0,electron.animate.shift(LEFT*1.6),minus.animate.shift(LEFT*.12),plus.animate.shift(RIGHT*.12))
        self.show(words('Перемещение по веществу',[-3.1,-2.6,0],22,CYAN),words('Малое внутреннее смещение',[3.1,-2.6,0],22,ROSE),run_time=1.2);self.result(0)

        self.beat(1)
        body,surfaces,external,induced=conductor()
        self.show(body,external,words(['Изначально нейтральный проводник','Полный заряд сохраняется'],[3.1,1.1,0],24),run_time=1.2);self.intro(1)
        self.act(1,FadeIn(surfaces),Create(induced))
        self.show(words(['Электроны смещаются влево','Справа — недостаток электронов'],[3.1,-.65,0],24),
                  formula(r'Q_{\rm total}=0',[3.1,-2.0,0],36),run_time=1.2);self.result(1)

        self.beat(2)
        body,surfaces,external,induced=conductor()
        zero=formula(r'\vec E_{\rm res}=0',[-3.1,0,0],37,GOLD)
        balance=formula(r'\vec E_{\rm ext}+\vec E_{\rm ind}=0',[3.1,.1,0],35,GOLD)
        self.show(body,surfaces,external,induced,words('Электростатическое равновесие',[3.1,1.65,0],24),run_time=1.2);self.intro(2)
        self.act(2,FadeIn(zero),Write(balance))
        self.show(words(['Направленное перераспределение','зарядов прекращается'],[3.1,-1.7,0],24),run_time=1.2);self.result(2)


class DielectricPolarization(ElectricScene):
    chapter_id=10
    def chapter(self):
        self.beat(0)
        nucleus=charge('+',[-3.1,0,0],.18)
        cloud=Circle(radius=.72,color=CYAN,stroke_width=2).move_to([-3.1,0,0])
        cloud_name=txt('−',26,CYAN).move_to([-3.1,-.95,0])
        field=VGroup(arrow([-5.3,1.65,0],[4.4,0,0],GOLD),eq('E',28,GOLD).move_to([-1.1,2.08,0]))
        self.show(nucleus,cloud,cloud_name,field,words(['Смещение связанных зарядов','Атом остаётся нейтральным'],[3.1,1.4,0],24),run_time=1.2);self.intro(0)
        self.act(0,nucleus.animate.shift(RIGHT*.18),cloud.animate.shift(LEFT*.18).stretch(1.18,0),cloud_name.animate.shift(LEFT*.18))
        self.show(VGroup(charge('−',[2.1,-.25,0],.24),charge('+',[4.1,-.25,0],.24)),
                  words(['Диполь: равные по модулю','разноимённые заряды'],[3.1,-1.65,0],24),run_time=1.2);self.result(0)

        self.beat(1)
        body=Rectangle(width=4.8,height=2.6,color=MUTED).move_to([-3.1,0,0])
        centers=[[x,y,0] for y in (-.65,.65) for x in (-4.5,-3.1,-1.7)]
        angles=[-.8,.9,2.2,-1.2,2.7,.4]
        ds=VGroup(*[dipole(c,a) for c,a in zip(centers,angles)])
        field=VGroup(arrow([-5.2,-1.8,0],[4.2,0,0],GOLD),eq('E',27,GOLD).move_to([-3.1,-2.23,0]))
        self.show(body,ds,field,words(['Постоянные диполи','Ориентация в поле'],[3.1,1.2,0],26),run_time=1.2);self.intro(1)
        self.act(1,*[Rotate(d,-a,about_point=np.array(c)) for d,a,c in zip(ds,angles,centers)])
        self.show(words(['Поляризация диэлектрика','Тепловое движение сохраняется'],[3.1,-.8,0],24,GOLD),run_time=1.2);self.result(1)

        self.beat(2)
        body,ds=polarized_body()
        ext=VGroup(arrow([-5.2,1.78,0],[4.2,0,0],GOLD),eq(r'E_{\rm ext}',26,GOLD).move_to([-3.1,2.15,0]))
        pol=VGroup(arrow([-1.7,-1.8,0],[-2.8,0,0],LAVENDER),eq(r'E_{\rm pol}',26,LAVENDER).move_to([-3.1,-2.2,0]))
        resultant=VGroup(arrow([-3.8,0,0],[1.4,0,0],GOLD),eq(r'E_{\rm res}',25,GOLD).move_to([-3.1,.3,0]))
        self.show(body,ds,ext,pol,formula(r'E_{\rm res}=E_{\rm ext}-E_{\rm pol}',[3.1,1.35,0],34),
                  words('Заданные свободные источники',[3.1,.35,0],22),run_time=1.2)
        self.intro(2)
        self.act(2,Create(resultant),Write(formula(r'\varepsilon=\frac{E_{\rm ext}}{E_{\rm res}}',[3.1,-.7,0],40)))
        self.show(words(['Однородная среда','ε ≥ 1, безразмерная величина'],[3.1,-1.95,0],23),run_time=1.2);self.result(2)

        self.beat(3)
        nucleus=charge('+',[-3.7,0,0],.24)
        cloud=Circle(radius=.8,color=GRID).move_to([-3.7,0,0])
        electron=charge('−',[-2.9,0,0],.17)
        path=Line([-2.9,0,0],[-1.05,1.3,0])
        self.show(nucleus,cloud,electron,words(['Температура или излучение','Может возникнуть ионизация'],[3.1,1.25,0],24),run_time=1.2);self.intro(3)
        self.act(3,MoveAlongPath(electron,path),FadeOut(cloud))
        self.show(words('Положительный ион',[-3.7,-.85,0],21,ROSE),eq('e^{-}',27,CYAN).move_to([-1.05,1.8,0]),
                  words(['Атом → ион + электрон','Появляются свободные носители','Проводимость может возрасти'],[3.1,-.7,0],24),run_time=1.2);self.result(3)


class SphereField(ElectricScene):
    chapter_id=11
    def chapter(self):
        self.beat(0)
        body=sphere()
        arrows=VGroup(*[arrow(np.array([-3.1,0,0])+1.47*np.array([np.cos(a),np.sin(a),0]),
                              .65*np.array([np.cos(a),np.sin(a),0]),GOLD,2)
                         for a in np.linspace(0,TAU,8,endpoint=False)])
        self.show(body,words(['Проводящая сфера','Электростатическое равновесие'],[3.1,1.35,0],24),run_time=1.2);self.intro(0)
        self.act(0,Create(arrows),FadeIn(formula('E=0',[-3.1,0,0],37,GOLD)))
        self.show(words(['Снаружи — радиальное поле','При Q > 0 направлено наружу'],[3.1,-.25,0],24),
                  words(['Изолированная сфера в вакууме','Нет внешних источников'],[3.1,-1.85,0],22,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        body=sphere(center=(-4.4,0,0),radius=.7,signs=False)
        points=VGroup(Dot([-2.9,0,0],radius=.06,color=INK),Dot([-1.25,0,0],radius=.06,color=INK))
        fields=VGroup(arrow([-2.9,.45,0],[.9,0,0],GOLD),arrow([-1.25,.45,0],[.9*(1.5/3.15)**2,0,0],GOLD))
        labels=VGroup(eq('E_1',26,GOLD).move_to([-2.45,.95,0]),eq('E_2',26,GOLD).move_to([-1.08,.95,0]),
                      eq('r_1',25).move_to([-2.9,-.5,0]),eq('r_2',25).move_to([-1.25,-.5,0]))
        self.show(body,points,formula(r'E=\frac{k|Q|}{r^2}',[3.1,1.2,0],44),formula('r>R',[3.1,.15,0],34,MUTED),run_time=1.2);self.intro(1)
        self.act(1,Create(fields),FadeIn(labels))
        self.show(words(['r отсчитывают от центра','Модуль поля убывает как 1/r²','Знак Q задаёт направление'],[3.1,-1.5,0],24,GOLD),run_time=1.2);self.result(1)

        self.beat(2)
        ax,frame=chart(center=(-3.1,0,0),width=4.8,height=3.5,x_range=(0,4.5,1),y_range=(0,3.5,1),x_label='r',y_label='E')
        radius=1.5;peak=2.7
        inside=Line(ax.c2p(0,0),ax.c2p(radius,0),color=CYAN,stroke_width=4)
        outside=ax.plot(lambda r:peak*(radius/r)**2,x_range=[radius,4.4],color=GOLD)
        jump=DashedLine(ax.c2p(radius,0),ax.c2p(radius,peak),color=MUTED,stroke_width=1.3)
        boundary=eq('R',26).next_to(ax.c2p(radius,0),DOWN,buff=.2)
        limits=VGroup(*[Circle(radius=.055,color=INK,stroke_width=1.5,fill_color=BLACK_BG,fill_opacity=1).move_to(ax.c2p(radius,v)) for v in (0,peak)])
        given=formula(r'E(r)=\begin{cases}0,&r<R,\\k|Q|/r^2,&r>R.\end{cases}',[3.1,1.15,0],34)
        self.show(frame,boundary,given,run_time=1.2);self.intro(2)
        self.act(2,Succession(Create(inside),Create(outside)))
        self.show(jump,limits,words(['У поверхности — скачок','Показаны предельные значения','Далеко от сферы E → 0'],[3.1,-1.25,0],24),run_time=1.2);self.result(2)


class SpherePotential(ElectricScene):
    chapter_id=12
    def chapter(self):
        self.beat(0)
        body=sphere(center=(-4.5,0,0),radius=.68,signs=False)
        point=Dot([-3.35,0,0],radius=.075,color=LAVENDER)
        indicator=Rectangle(width=.72,height=1.1,color=GOLD,fill_color=GOLD,fill_opacity=.3).move_to([2.35,-.85,0])
        final_height=1.1*1.15/3.1
        lower=Rectangle(width=.72,height=final_height,color=GOLD,fill_color=GOLD,fill_opacity=.3).move_to([2.35,-1.4+final_height/2,0])
        guide=Line([-3.8,0,0],[-1.4,0,0],color=GRID)
        self.show(body,guide,point,formula(r'\varphi=\frac{kQ}{r}',[3.1,1.5,0],45),
                  formula(r'\varphi(\infty)=0',[3.1,.45,0],31,MUTED),indicator,
                  eq(r'\varphi',30,GOLD).move_to([3.3,-.85,0]),run_time=1.2);self.intro(0)
        self.act(0,point.animate.move_to([-1.4,0,0]),Transform(indicator,lower))
        self.show(words(['При Q > 0: r растёт → φ уменьшается'],[0,-2.3,0],25,GOLD,width=11.8),run_time=1.2);self.result(0)

        self.beat(1)
        body=sphere(radius=1.35,signs=False)
        a=np.array([-3.65,-.25,0]);b=np.array([-2.55,.25,0])
        marker=Dot(a,radius=.075,color=LAVENDER)
        route=Line(a,b,color=LAVENDER,stroke_width=2)
        names=VGroup(eq('A',26).move_to(a+DOWN*.4),eq('B',26).move_to(b+UP*.4))
        self.show(body,marker,names,formula('E=0',[3.1,1.5,0],42,GOLD),run_time=1.2);self.intro(1)
        self.act(1,MoveAlongPath(marker,route),Create(route),Write(formula(r'A_{AB}=0',[3.1,.25,0],42)))
        self.show(formula(r'\varphi_A=\varphi_B=\frac{kQ}{R}',[3.1,-1.0,0],38,GOLD),
                  words('Постоянен внутри и на поверхности',[3.1,-2.15,0],22),run_time=1.2);self.result(1)

        self.beat(2)
        ax,frame=chart(center=(-3.1,0,0),width=4.8,height=3.5,x_range=(0,4.5,1),y_range=(0,3.5,1),x_label='r',y_label=r'\varphi')
        radius=1.5;value=2.2
        inside=Line(ax.c2p(0,value),ax.c2p(radius,value),color=CYAN,stroke_width=3)
        outside=ax.plot(lambda r:value*radius/r,x_range=[radius,4.4],color=GOLD)
        guide=DashedLine(ax.c2p(radius,0),ax.c2p(radius,value),color=MUTED,stroke_width=1.3)
        marker=eq('R',26).next_to(ax.c2p(radius,0),DOWN,buff=.2)
        given=formula(r'\varphi(r)=\begin{cases}kQ/R,&r\leq R,\\kQ/r,&r>R.\end{cases}',[3.1,1.25,0],33)
        self.show(frame,marker,given,run_time=1.2);self.intro(2)
        self.act(2,Succession(Create(inside),Create(outside)))
        self.show(guide,words(['Потенциал непрерывен у R','При r → ∞ стремится к нулю'],[3.1,-.75,0],24),
                  formula(r'E=0\ \not\Rightarrow\ \varphi=0',[3.1,-2.0,0],34,GOLD),run_time=1.2);self.result(2)
