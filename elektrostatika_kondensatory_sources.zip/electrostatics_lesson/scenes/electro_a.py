"""Source-based electrostatics, PDF pages 1–7.

Unnumbered coordinates are diagram geometry, not added numerical problems.
All signed charge symbols remain distinct from force and field labels.
"""
from electric_style import *


def meter(center=(-3.1,-.1,0),angle=0):
    x,y,_=center; pivot=np.array([x,y-.25,0])
    head=Circle(radius=.28,color=INK,stroke_width=2).move_to([x,y+1.25,0])
    body=Circle(radius=.75,color=MUTED,stroke_width=2).move_to(pivot)
    stem=Line([x,y+.97,0],pivot,color=MUTED,stroke_width=2)
    base=Line([x-.55,y-1.25,0],[x+.55,y-1.25,0],color=MUTED,stroke_width=3)
    leg=Line([x,y-1,0],[x,y-1.25,0],color=MUTED,stroke_width=2)
    pointer=Line(pivot,pivot+DOWN*.58,color=GOLD,stroke_width=3).rotate(angle,about_point=pivot)
    return VGroup(head,body,stem,base,leg,pointer),pointer,pivot,head


def particle_model():
    box=RoundedRectangle(width=5.1,height=3.25,corner_radius=.12,color=GRID).move_to([-3.1,.2,0])
    positives=VGroup(*[charge('+',[x,.85,0],.22) for x in [-4.45,-3.1,-1.75]])
    negatives=VGroup(*[charge('−',[x,-.45,0],.22) for x in [-4.75,-3.65,-2.55,-1.45]])
    return box,VGroup(positives,negatives)


class ChargeInteraction(ElectricScene):
    chapter_id=1

    def pair(self,i,s1,s2,attract,headline):
        self.beat(i)
        left=charge(s1,[-4.6,0,0]);right=charge(s2,[-1.6,0,0])
        given=words(['Электрический заряд','Положительный и отрицательный'],[3.1,1.0,0],25)
        names=VGroup(formula('q_1',[-4.6,-.7,0],28),formula('q_2',[-1.6,-.7,0],28))
        self.show(left,right,names,given,run_time=1.2)
        self.intro(i)
        if attract:
            forces=VGroup(arrow([-4.27,0,0],[1.05,0,0],LAVENDER),arrow([-1.93,0,0],[-1.05,0,0],LAVENDER))
        else:
            forces=VGroup(arrow([-4.93,0,0],[-1.05,0,0],LAVENDER),arrow([-1.27,0,0],[1.05,0,0],LAVENDER))
        self.act(i,Create(forces))
        self.show(words([headline],[3.1,-.45,0],29,LAVENDER),
                  words(['Направление задаётся','знаками обоих зарядов'],[3.1,-1.7,0],23,MUTED),run_time=1.2)
        self.result(i)

    def chapter(self):
        self.pair(0,'+','+',False,'Одноимённые: отталкивание')
        self.pair(1,'−','−',False,'Одноимённые: отталкивание')
        self.pair(2,'+','−',True,'Разноимённые: притяжение')


class ElementaryCharge(ElectricScene):
    chapter_id=2
    def chapter(self):
        self.beat(0)
        electron=charge('−',[-4.4,.8,0],.32);proton=charge('+',[-1.8,.8,0],.32)
        names=VGroup(words('Электрон',[-4.4,.0,0],23,CYAN),words('Протон',[-1.8,.0,0],23,ROSE))
        value=formula(r'e\approx1.6\cdot10^{-19}\,\mathrm{C}',[3.1,1,0],37,GOLD)
        signed=VGroup(formula(r'q_e=-e',[-4.4,-1.0,0],32,CYAN),formula(r'q_p=+e',[-1.8,-1.0,0],32,ROSE))
        law=formula(r'q=ne,\quad n\in\mathbb{Z}',[3.1,-.4,0],39)
        self.show(electron,proton,names,value,run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(signed),Write(law))
        self.show(words(['Дискретность заряда','Модуль e положителен'],[3.1,-1.8,0],23,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        proposed=formula(r'q=2\cdot10^{-19}\,\mathrm{C}',[-3.1,1,0],38)
        unit=formula(r'e\approx1.6\cdot10^{-19}\,\mathrm{C}',[3.1,1,0],38,GOLD)
        test=words('Проверяем кратность элементарному заряду',[0,-.1,0],25,width=11.7)
        result=formula(r'\frac{q}{e}=1.25\notin\mathbb{Z}',[0,-1.15,0],43,CYAN,width=11)
        self.show(proposed,unit,test,run_time=1.2)
        self.intro(1)
        self.act(1,Write(result))
        self.show(words('Не соответствует целому числу элементарных зарядов',[0,-2.35,0],23,MUTED,width=11.7),run_time=1.2)
        self.result(1)

        self.beat(2)
        box,particles=particle_model()
        title=words(['Условная модель конспекта','3 протона и 4 электрона'],[3.1,1.2,0],27)
        summation=formula(r'q=(3-4)e=-e',[3.1,-.15,0],41,CYAN)
        self.show(box,particles,title,run_time=1.2)
        self.intro(2)
        self.act(2,Write(summation))
        self.show(words(['Один лишний электрон','Нейтральность: сумма зарядов равна нулю'],[3.1,-1.7,0],22,MUTED),run_time=1.2)
        self.result(2)


class Electrization(ElectricScene):
    chapter_id=3

    def transfer(self,i,left_name,right_name):
        self.beat(i)
        left=RoundedRectangle(width=1.85,height=1.25,corner_radius=.1,color=MUTED).move_to([-4.7,.1,0])
        right=RoundedRectangle(width=1.85,height=1.25,corner_radius=.1,color=MUTED).move_to([-1.5,.1,0])
        names=VGroup(words(left_name,[-4.7,1.2,0],24),words(right_name,[-1.5,1.2,0],24))
        electron=Dot([-4.7,.1,0],radius=.095,color=CYAN)
        initial=words(['До взаимодействия','Оба тела нейтральны'],[3.1,1.15,0],26)
        note=words('Показан перенос одного из электронов',[-3.1,-1.8,0],21,MUTED)
        self.show(left,right,names,electron,initial,note,run_time=1.2)
        self.intro(i)
        self.act(i,electron.animate.move_to([-1.5,.1,0]),left.animate.set_color(ROSE),right.animate.set_color(CYAN))
        net=VGroup(formula('+',[-4.7,-.95,0],35,ROSE),formula('-',[-1.5,-.95,0],35,CYAN))
        final=words(['После взаимодействия','Недостаток / избыток электронов'],[3.1,-.6,0],24)
        self.show(net,final,run_time=1.2)
        self.result(i)

    def chapter(self):
        self.beat(0)
        rod=RoundedRectangle(width=3.5,height=.55,corner_radius=.08,color=CYAN).move_to([-3.1,.8,0])
        rod_signs=VGroup(*[txt('−',22,CYAN).move_to([x,.8,0]) for x in [-4.25,-3.1,-1.95]])
        initial=words(['Диэлектрик','Малая проводимость в обычных условиях'],[3.1,1,0],24)
        toy,_,_,_=meter([-3.1,-1.0,0])
        toy.scale(.55).move_to([-3.1,-.9,0])
        self.show(rod,rod_signs,initial,run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(toy))
        self.show(words(['Электроскоп обнаруживает заряд','Отклонение не определяет знак'],[3.1,-.75,0],24,GOLD),run_time=1.2)
        self.result(0)

        self.transfer(1,'Шерсть','Эбонит')
        self.transfer(2,'Стекло','Шёлк')

        self.beat(3)
        toy,pointer,pivot,head=meter([-3.6,-.1,0])
        rod=VGroup(Rectangle(width=1.6,height=.25,color=CYAN),
                   VGroup(*[txt('−',19,CYAN).move_to([x,0,0]) for x in [-.5,0,.5]])).move_to([-1.55,1.15,0])
        head_charge=txt('−',23,CYAN).move_to(head.get_center())
        given=words(['Касание металлической головки','Изначально нейтральный прибор'],[3.1,1.1,0],25)
        self.show(toy,rod,given,run_time=1.2)
        self.intro(3)
        self.act(3,Succession(rod.animate.shift(LEFT*.97),AnimationGroup(FadeIn(head_charge),Rotate(pointer,.55,about_point=pivot))))
        self.show(words(['Одноимённые части отталкиваются','Стрелка отклонилась'],[3.1,-.5,0],24,GOLD),
                  words('Знак нельзя узнать только по отклонению',[3.1,-1.9,0],21,MUTED),run_time=1.2)
        self.result(3)


class ConservationAndCoulomb(ElectricScene):
    chapter_id=4
    def chapter(self):
        self.beat(0)
        left,p1,o1,h1=meter([-4.65,-.1,0],.45)
        right,p2,o2,h2=meter([-1.55,-.1,0],.45)
        signs=VGroup(txt('+',23,ROSE).move_to(h1),txt('−',23,CYAN).move_to(h2))
        wire=Line(h1.get_right(),h2.get_left(),color=MUTED,stroke_width=3)
        path=Line(h2.get_left(),h1.get_right())
        electron=Dot(path.get_start(),radius=.07,color=CYAN)
        initial=formula(r'q_1+q_2=0',[3.1,1.05,0],39)
        self.show(left,right,signs,initial,run_time=1.2)
        self.intro(0)
        self.act(0,Succession(AnimationGroup(Create(wire),FadeIn(electron)),
                    AnimationGroup(MoveAlongPath(electron,path),Rotate(p1,-.45,about_point=o1),Rotate(p2,-.45,about_point=o2),FadeOut(signs)),FadeOut(electron)))
        self.show(formula(r"q_1'=q_2'=0",[3.1,-.2,0],39),run_time=1.2)
        self.result(0)

        self.beat(1)
        before=formula(r'q_1+q_2',[-3.1,.5,0],45)
        after=formula(r"q_1'+q_2'",[3.1,.5,0],45)
        headings=VGroup(words('До взаимодействия',[-3.1,1.65,0],26),words('После взаимодействия',[3.1,1.65,0],26))
        equal=formula(r"q_1+q_2=q_1'+q_2'",[0,-.85,0],43,GOLD,width=11.7)
        self.show(before,after,headings,run_time=1.2)
        self.intro(1)
        self.act(1,Write(equal))
        self.show(formula(r'\sum_iq_i=\sum_iq_i^{\prime}',[0,-2.05,0],36,CYAN,width=11.7),run_time=1.2)
        self.result(1)

        self.beat(2)
        bodies=VGroup(Circle(radius=.38,color=ROSE).move_to([-4.7,.2,0]),Circle(radius=.38,color=CYAN).move_to([-1.5,.2,0]))
        names=VGroup(formula('q_1',[-4.7,1,0],30),formula('q_2',[-1.5,1,0],30))
        distance=DoubleArrow([-4.7,-.7,0],[-1.5,-.7,0],buff=0,color=MUTED)
        r=eq('r',28,MUTED).move_to([-3.1,-1.15,0])
        condition=formula(r'a\ll r',[3.1,1,0],45,GOLD)
        self.show(bodies,names,distance,r,condition,run_time=1.2)
        self.intro(2)
        dots=VGroup(*[Circle(radius=.065,color=obj.get_color(),fill_opacity=1).move_to(obj) for obj in bodies])
        self.act(2,Transform(bodies,dots))
        self.show(words(['a — размер тела','r — расстояние между точками','Точечный заряд — приближение'],[3.1,-.6,0],25),run_time=1.2)
        self.result(2)

        self.beat(3)
        left=charge('+',[-4.7,.25,0]);right=charge('−',[-1.5,.25,0])
        names=VGroup(formula('q_1',[-4.7,1.05,0],30),formula('q_2',[-1.5,1.05,0],30))
        distance=DoubleArrow([-4.7,-.6,0],[-1.5,-.6,0],buff=0,color=MUTED)
        initial=words(['Неподвижные точечные заряды','Вакуум'],[3.1,1.35,0],25)
        law=formula(r'F=k\frac{|q_1q_2|}{r^2}',[3.1,-.05,0],43,LAVENDER)
        self.show(left,right,names,distance,eq('r',28).move_to([-3.1,-1.05,0]),initial,run_time=1.2)
        self.intro(3)
        self.act(3,Write(law))
        self.show(formula(r'k\approx9\cdot10^9\,\frac{\mathrm{N}\,\mathrm{m}^2}{\mathrm{C}^2}',[0,-2.0,0],33,GOLD,width=11.5),run_time=1.2)
        self.result(3)


class CoulombVectors(ElectricScene):
    chapter_id=5
    def chapter(self):
        self.beat(0)
        pair=VGroup(charge('−',[-4.6,0,0]),charge('+',[-1.6,0,0]))
        names=VGroup(formula('q_1',[-4.6,-.7,0],29),formula('q_2',[-1.6,-.7,0],29))
        forces=VGroup(arrow([-4.27,0,0],[1.05,0,0],LAVENDER),arrow([-1.93,0,0],[-1.05,0,0],LAVENDER))
        labels=VGroup(formula(r'\vec F_{21}',[-3.9,.65,0],29,LAVENDER),formula(r'\vec F_{12}',[-2.3,.65,0],29,LAVENDER))
        law=formula(r'\vec F_{12}=-\vec F_{21}',[3.1,.8,0],39)
        self.show(pair,names,words('Разноимённые заряды',[3.1,1.85,0],25),run_time=1.2)
        self.intro(0)
        self.act(0,Create(forces),FadeIn(labels),Write(law))
        self.show(words(['Силы приложены к разным телам','Модули равны'],[3.1,-.8,0],24,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        left=charge('+',[-4.8,.2,0]);right=charge('+',[-2.8,.2,0])
        force=arrow([-2.47,.2,0],[1.1,0,0],LAVENDER)
        span=DoubleArrow([-4.8,-.65,0],[-2.8,-.65,0],buff=0,color=MUTED)
        small=formula('r_1',[-3.8,-1.15,0],28)
        initial=formula(r'F\propto\frac1{r^2}',[3.1,1,0],43)
        self.show(left,right,force,span,small,initial,run_time=1.2)
        self.intro(1)
        bigger=DoubleArrow([-4.8,-.65,0],[-1.2,-.65,0],buff=0,color=MUTED)
        newforce=arrow([-.87,.2,0],[.34,0,0],LAVENDER)
        large=formula('r_2',[-3,-1.15,0],28)
        self.act(1,right.animate.move_to([-1.2,.2,0]),Transform(force,newforce),Transform(span,bigger),Succession(FadeOut(small),FadeIn(large)))
        self.show(formula(r'r_2>r_1\quad\Rightarrow\quad F_2<F_1',[3.1,-.4,0],36,LAVENDER),words('Заряды остаются прежними',[3.1,-1.7,0],24,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        origin=np.array([-4.5,-1.05,0]);a=np.array([2.2,0,0]);b=np.array([0,1.85,0])
        dot=Dot(origin,radius=.065,color=INK)
        f1=arrow(origin,a,LAVENDER);f2=arrow(origin,b,LAVENDER)
        copy=f2.copy()
        labels=VGroup(formula(r'\vec F_1',origin+a*.5+DOWN*.45,30,LAVENDER),formula(r'\vec F_2',origin+b*.5+LEFT*.5,30,LAVENDER))
        self.show(dot,f1,f2,labels,words('Силы на одном выбранном теле',[3.1,1.55,0],25),run_time=1.2)
        self.intro(2)
        resultant=arrow(origin,a+b,GOLD,4)
        self.act(2,copy.animate.shift(a),Create(resultant))
        self.show(formula(r'\vec F=\vec F_1+\vec F_2+\cdots+\vec F_n',[3.1,-.05,0],36,GOLD),
                  formula(r'\vec F',origin+a+b+UP*.4,32,GOLD),words('Складываем векторы, учитывая направления',[3.1,-1.5,0],22,MUTED),run_time=1.2)
        self.result(2)


class FieldStrength(ElectricScene):
    chapter_id=6
    def chapter(self):
        self.beat(0)
        source=charge('+',[-4.8,0,0],.32)
        qname=formula('Q',[-4.8,.8,0],31,ROSE)
        point=Dot([-1.65,0,0],radius=.055,color=INK)
        aname=formula('A',[-1.65,-.8,0],29)
        test=VGroup(charge('+',[-1.65,0,0],.23),formula('q_0',[-1.65,.9,0],28,ROSE))
        force=arrow([-1.34,.2,0],[1.0,0,0],LAVENDER)
        fname=formula(r'\vec F',[-.8,.65,0],29,LAVENDER)
        self.show(source,qname,point,aname,words(['Электрическое поле','действует на заряды'],[3.1,1.1,0],27),run_time=1.2)
        self.intro(0)
        self.act(0,Succession(AnimationGroup(FadeOut(point),FadeIn(test)),AnimationGroup(Create(force),FadeIn(fname))))
        self.show(formula(r'\vec E=\frac{\vec F}{q_0}',[3.1,-.2,0],45,GOLD),formula(r'[E]=\mathrm{N}/\mathrm{C}',[3.1,-1.8,0],32),run_time=1.2)
        self.result(0)

        self.beat(1)
        ratio=formula(r'E=\frac F{q_0}',[-3.1,1,0],43)
        coulomb=formula(r'F=k\frac{|Q|q_0}{r^2}',[-3.1,-.55,0],39,LAVENDER)
        middle=formula(r'E=k\frac{|Q|q_0}{r^2q_0}',[3.1,1,0],38)
        final=formula(r'E=k\frac{|Q|}{r^2}',[3.1,-.65,0],43,GOLD)
        self.show(ratio,coulomb,run_time=1.2)
        self.intro(1)
        self.act(1,Succession(Write(middle),Write(final)))
        self.show(words('Точечный источник в вакууме; пробный q₀ > 0',[0,-2.25,0],23,MUTED,width=11.5),run_time=1.2)
        self.result(1)

        self.beat(2)
        positive=charge('+',[-3.1,-.4,0]);negative=charge('−',[-3.1,-.4,0])
        field=arrow([-4.35,.85,0],[2.5,0,0],GOLD)
        elabel=formula(r'\vec E',[-3.1,1.4,0],33,GOLD)
        fpos=VGroup(arrow([-2.77,-.4,0],[1.4,0,0],LAVENDER),formula(r'\vec F',[-2.05,-1.0,0],30,LAVENDER))
        fneg=VGroup(arrow([-3.43,-.4,0],[-1.4,0,0],LAVENDER),formula(r'\vec F',[-4.15,-1.0,0],30,LAVENDER))
        given=formula(r'\vec F=q_0\vec E',[3.1,1.15,0],43)
        first=words('q₀ > 0: сила по полю',[3.1,-.2,0],26)
        after=words('q₀ < 0: сила против поля',[3.1,-.2,0],26)
        self.show(positive,field,elabel,fpos,given,first,run_time=1.2)
        self.intro(2)
        self.act(2,Succession(AnimationGroup(FadeOut(positive),FadeOut(fpos),FadeOut(first)),AnimationGroup(FadeIn(negative),FadeIn(fneg),FadeIn(after))))
        self.show(words('Поле не меняется при замене пробного заряда',[3.1,-1.75,0],22,MUTED),run_time=1.2)
        self.result(2)

        self.beat(3)
        origin=np.array([-4.5,-1.0,0]);v1=np.array([2.1,0,0]);v2=np.array([0,1.8,0])
        one=arrow(origin,v1,GOLD);two=arrow(origin,v2,GOLD)
        labels=VGroup(formula(r'\vec E_1',origin+v1*.5+DOWN*.45,30,GOLD),formula(r'\vec E_2',origin+v2*.5+LEFT*.5,30,GOLD))
        initial=words('Напряжённости в одной точке',[3.1,1.85,0],25)
        self.show(Dot(origin,radius=.065,color=INK),one,two,labels,initial,run_time=1.2)
        self.intro(3)
        moved=two.copy();resultant=arrow(origin,v1+v2,GOLD,4)
        self.act(3,moved.animate.shift(v1),Create(resultant))
        self.show(formula(r'\vec E=\vec E_1+\vec E_2+\cdots+\vec E_n',[3.1,.55,0],35,GOLD),
                  words(['Касательная к линии — по E','Линии выходят из + и входят в −'],[3.1,-1.15,0],23),run_time=1.2)
        self.result(3)
