"""Publish only the checked film, reading copies and reproducible source."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent
PREFIX='elektrostatika_kondensatory'

def package():
    quality=json.loads((ROOT/'output/quality_validation.json').read_text())
    movie=ROOT/'output'/f'{PREFIX}_1080p60.mp4'
    assert hashlib.file_digest(movie.open('rb'),'sha256').hexdigest()==quality['sha256']
    assert quality['full_decode_passed'] and movie.stat().st_size<100*1024**2
    targets=[(movie,REPO/movie.name),(ROOT/'tekst_ozvuchki.txt',REPO/f'{PREFIX}_tekst.txt'),(ROOT/f'{PREFIX}_tekst.docx',REPO/f'{PREFIX}_tekst.docx')]
    for source,target in targets:shutil.copyfile(source,target)
    files=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or '_draft' in p.stem:continue
        rel=p.relative_to(ROOT)
        if any(x in rel.parts for x in ('output','__pycache__','.git','media')):continue
        if p.suffix.lower() not in {'.py','.json','.md','.txt','.cfg'}:continue
        files.append(p)
    files.extend(REPO/name for name in ('setup_env.sh','install.sh','requirements.lock','AGENTS.md'))
    files.extend(sorted((ROOT/'output/layout_checks').glob('*.json')))
    files.extend(sorted((ROOT/'output/sync_checks').rglob('*.json')))
    files.append(ROOT/'output/quality_validation.json')
    archive=REPO/f'{PREFIX}_sources.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:z.write(p,p.relative_to(REPO))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert not any(n.endswith(('.pdf','.png','.jpg','.mp4','.wav','.mp3')) for n in z.namelist())
    print(f'Packaged {len(files)} source/check files, MP4, TXT, DOCX.')
if __name__=='__main__':package()
