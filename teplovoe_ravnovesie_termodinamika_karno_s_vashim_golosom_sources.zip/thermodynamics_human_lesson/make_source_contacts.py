"""Read-only HD review captures for all thermal theory/action/result states."""
from pathlib import Path
import hashlib,json,subprocess
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'thermodynamics_lesson'
FPS=60

def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def capture(clip,frame,destination):
    seek=max(0,frame//FPS-1);first=frame-seek*FPS
    subprocess.run(['ffmpeg','-v','error','-y','-threads','1','-ss',str(seek),'-i',str(clip),
                    '-vf',f'trim=start_frame={first}:end_frame={first+1}',
                    '-frames:v','1','-threads','1','-q:v','2',str(destination)],check=True)

def main():
    plan=json.loads((SOURCE/'plan.json').read_text())
    out=ROOT/'output/source_contacts';out.mkdir(parents=True,exist_ok=True)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
    manifest=[];source_hashes=[]
    for ch in plan['chapters']:
        clip=SOURCE/'output/chapters'/f"{ch['id']:02d}_{ch['class']}.mp4"
        before=digest(clip)
        sheet=Image.new('RGB',(1536,len(ch['beats'])*312),'#151515');draw=ImageDraw.Draw(sheet)
        for row,beat in enumerate(ch['beats']):
            for col,phase in enumerate(('intro','action','result')):
                if phase=='action':time=beat['action_at']+beat['action_seconds']/2
                else:time=beat[phase+'_at']+beat[phase+'_duration']/2
                frame=round(time*FPS);key=f"{ch['id']:02d}_{row+1:02d}_{phase}"
                path=out/(key+'_full.jpg');capture(clip,frame,path)
                im=Image.open(path);im.thumbnail((512,288));sheet.paste(im,(col*512,row*312))
                draw.text((col*512+8,row*312+290),f'{key} / source {frame/FPS:.3f}s',font=font,fill='white')
                manifest.append({'key':key,'chapter':ch['id'],'beat':row+1,'phase':phase,
                                 'source_frame':frame,'source_time':frame/FPS,
                                 'source_clip':str(clip),'file':path.name})
        sheet.save(out/f"sheet_{ch['id']:02d}.jpg",quality=95)
        assert before==digest(clip)
        source_hashes.append({'chapter':ch['id'],'sha256':before})
        print(f"Captured {ch['id']:02d}: {len(ch['beats'])*3} HD states",flush=True)
    (out/'manifest.json').write_text(json.dumps({'fps':FPS,'states':manifest,
        'source_hashes':source_hashes,'source_clips_unchanged':True},ensure_ascii=False,indent=2)+'\n')
    print(f'COMPLETE {len(manifest)} states',flush=True)

if __name__=='__main__':main()
