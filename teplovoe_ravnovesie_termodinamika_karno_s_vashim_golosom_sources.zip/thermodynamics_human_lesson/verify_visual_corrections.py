"""Verify an isolated thermal label-position correction against immutable originals."""
from pathlib import Path
import difflib, hashlib, json
from audit_source_timeline import mp4_frames, probe

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'thermodynamics_lesson'
NEW=ROOT/'visual_source'
CORRECTED=[7]

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())
def partials(ch,root):
    p=root/f"output/render_cache/final/{ch['id']:02d}/videos/{ch['module'][:-3]}/1080p60/partial_movie_files/{ch['class']}/partial_movie_file_list.txt"
    paths=[Path(s[6:-1].removeprefix('file:')) for s in p.read_text().splitlines() if s.startswith("file '")]
    return [mp4_frames(p) for p in paths]

def main():
    before=read(ROOT/'output/visual_source_before.json');plan=read(OLD/'plan.json')
    originals=[]
    for item in before['original_chapters']:
        p=OLD/'output/chapters'/item['name'];actual=sha(p)
        assert actual==item['sha256'],p
        originals.append({'id':int(item['name'][:2]),'name':item['name'],
            'before_sha256':item['sha256'],'after_sha256':actual,'unchanged':True})
    for item in before['original_files']:
        assert sha(OLD/item['relative'])==item['sha256'],item['relative']
        if item['relative']!='scenes/thermodynamics.py':
            assert sha(NEW/item['relative'])==item['sha256'],item['relative']
    original_reports=[]
    for item in before['original_reports']:
        actual=sha(OLD/item['relative'])
        assert actual==item['sha256'],item['relative']
        original_reports.append({'relative':item['relative'],'before_sha256':item['sha256'],
                                 'after_sha256':actual,'unchanged':True})
    old=(OLD/'scenes/thermodynamics.py').read_text()
    old_label="eq(r'F_{\\rm fr}',27,LAVENDER).move_to([-4.3,.9,0])"
    new_label="eq(r'F_{\\rm fr}',27,LAVENDER).move_to([-4.3,1.3,0])"
    assert old.count(old_label)==1
    expected=old.replace(old_label,new_label)
    current=(NEW/'scenes/thermodynamics.py').read_text()
    assert current==expected,'Unexpected visual source edit'
    diff=list(difflib.unified_diff(old.splitlines(),current.splitlines(),
              fromfile='original/scenes/thermodynamics.py',tofile='visual_source/scenes/thermodynamics.py',n=2))
    corrections=[]
    for ch in plan['chapters']:
        name=f"{ch['id']:02d}_{ch['class']}.mp4";p=NEW/'output/chapters'/name
        if ch['id'] not in CORRECTED:
            assert p.is_symlink() and p.resolve()==OLD/'output/chapters'/name
            continue
        assert p.is_file() and not p.is_symlink(),p
        old_partials=partials(ch,OLD);new_partials=partials(ch,NEW)
        assert old_partials==new_partials,(ch['id'],old_partials,new_partials)
        v=probe(p);oldclip=OLD/'output/chapters'/name
        assert (int(v['width']),int(v['height']),v['r_frame_rate'])==(1920,1080,'60/1')
        fullframes=mp4_frames(p);oldfullframes=mp4_frames(oldclip)
        assert int(v['nb_frames'])==fullframes==oldfullframes==ch['duration']*60
        old_tail=oldfullframes-sum(old_partials);new_tail=fullframes-sum(new_partials)
        assert old_tail==new_tail==1,'Expected documented one-frame faded-tail clone'
        corrections.append({'id':ch['id'],'class':ch['class'],
            'original_sha256':sha(oldclip),'new_sha256':sha(p),
            'source_frames':fullframes,'same_frame_count':True,
            'partial_frame_counts_unchanged':True,'partial_frame_counts':new_partials,
            'original_tail_padding_frames':old_tail,'new_tail_padding_frames':new_tail,
            'source_tail_padding_frames':new_tail,'event_timing_unchanged':True,
            'label_changes':'F_fr moved vertically from y=0.9 to y=1.3, clear of the cylinder wall at y=1.0; no geometry or timing changes.'})
    result={'new_source_root':str(NEW),'original_sources_unchanged':True,
            'original_source_files_checked':len(before['original_files']),
            'original_reports_unchanged':True,'original_reports_checked':len(original_reports),
            'original_reports_before_after':original_reports,
            'original_chapters_before_after':originals,'all14_original_chapters_unchanged':True,
            'only_label_positions_changed':True,'source_diff':diff,
            'corrected_chapter_ids':CORRECTED,'chapters':corrections,
            'tail_padding_note':'render_thermal.py pads the fully faded source tail by one cloned frame; exact per-play and Wait frame counts remain unchanged.'}
    (ROOT/'visual_corrections.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('Verified one isolated label correction; 14 original clips, 22 source files, and 28 reports unchanged.',flush=True)

if __name__=='__main__':main()
