"""Measure 104 recorded phases; replace only their exact static reading waits.

Prepared conditions precede intro speech. Every original action, reveal, guard,
and fade remains in order at60fps; result speech follows its completed action.
No speech synthesis, word replacement, speed change or pitch change is used.
"""
from pathlib import Path
import hashlib,json,math,wave
import numpy as np

ROOT=Path(__file__).resolve().parent
FPS=60;RATE=48000

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def dump(p,data):Path(p).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def loadwav(p,rate):
    with wave.open(str(p)) as w:
        assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,rate)
        return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy()
def savewav(p,a):
    p.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(p),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE);w.writeframes(a.tobytes())
def stamp(t):
    ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
    return f'{h:02d}:{m:02d}:{s:02d}.{ms:03d}'
def mapped_frame(point,replacements):
    delta=0
    for r in replacements:
        a,b=r['old_start_frame'],r['old_end_frame']
        if point>=b:delta+=r['new_frame_count']-(b-a)
        elif a<point<b:raise ValueError(f'Phase marker lies inside a replaced reading wait: {point}')
    return point+delta

def main():
    original=read(ROOT.parent/'thermodynamics_lesson/plan.json')
    source=read(ROOT/'source_windows.json')
    cuts=read(ROOT/'cuts.json')['cues']
    cutmap={c['key']:c for c in cuts}
    expected=[f"{ch['id']:02d}_{i+1:02d}_{phase}"
              for ch in original['chapters'] for i,b in enumerate(ch['beats'])
              for phase in ('intro','result')]
    assert len(cutmap)==len(cuts)==len(expected)==104 and set(cutmap)==set(expected)
    assert len(source['chapters'])==len(original['chapters'])==14
    audio=loadwav(ROOT/'materials/recording_processed.wav',RATE)
    guide=loadwav(ROOT/'materials/recording_16k.wav',16000)
    parts={};edits=[]
    for key in expected:
        c=cutmap[key];s,e=c['source_start'],c['source_end']
        a=audio[round(s*RATE):round(e*RATE)]
        g=guide[round(s*16000):round(e*16000)]
        hop=160;n=len(g)//hop
        energy=np.sqrt((g[:n*hop].astype(float).reshape(n,hop)**2).mean(axis=1))
        active=np.flatnonzero(energy>32768*10**(-45/20))
        assert len(active),key
        left=max(0,round((active[0]*.01-.18)*RATE))
        right=min(len(a),round(((active[-1]+1)*.01+.25)*RATE))
        pcm=a[left:right].copy();ramp=min(240,len(pcm)//2)
        pcm[:ramp]=(pcm[:ramp]*np.linspace(0,1,ramp)).astype('<i2')
        pcm[-ramp:]=(pcm[-ramp:]*np.linspace(1,0,ramp)).astype('<i2')
        p=ROOT/'output/audio/parts'/f'{key}.wav';savewav(p,pcm);parts[key]=pcm
        edits.append({'key':key,'source_start':s,'source_end':e,
                      'retained_source_start':s+left/RATE,'retained_source_end':s+right/RATE,
                      'samples':len(pcm),'sha256':digest(p),
                      'edit':'Quiet edges only,180/250ms handles,5msfade; no speed or pitch change.'})
    plan={'title':'Тепловое равновесие, термодинамика и цикл Карно — с вашим голосом',
          'fps':FPS,'duration':0,'audio':True,'voice':{'type':'provided_recording',
              'synthetic_speech_used':False,'sample_rate':RATE,
              'processing':'Mono48k;65Hz highpass;loudness normalization;quiet-edge handles;natural pace/pitch'},
          'chapters':[]}
    narrative={'title':plan['title'],'chapters':[]};mapping={'fps':FPS,'chapters':[]}
    text=[plan['title'].upper(),'Сценарий с фактическими временами записанных реплик.',
          'Это подготовленный текст, а не дословная расшифровка. Переформулировки рассказчика сохранены в аудио.',
          'Таймкоды и названия фаз произносить не нужно.','']
    offset=0;master=[]
    for old,src in zip(original['chapters'],source['chapters']):
        assert old['id']==src['id']
        windows=src['windows'];want=[f"{old['id']:02d}_{i+1:02d}_{phase}"
                                  for i,b in enumerate(old['beats']) for phase in ('intro','result')]
        assert [w['key'] for w in windows]==want
        replacements=[];delta=0;cues=[]
        for w in windows:
            key=w['key'];phase=w['phase'];beat=int(w['beat']);pcm=parts[key]
            a,b=int(w['old_start_frame']),int(w['old_end_frame'])
            length=math.ceil(len(pcm)/RATE*FPS-1e-9)
            assert 0<=a<b<=src['source_frames']
            at=(a+delta)/FPS
            replacements.append({'old_start_frame':a,'old_end_frame':b,
                'new_frame_count':length,'new_start_frame':a+delta,'label':key})
            speech=len(pcm)/RATE
            cues.append({'key':key,'chapter':old['id'],'beat':beat,'phase':phase,'part':phase,
                'at':at,'global_at':offset+at,'speech_duration':speech,'global_until':offset+at+speech,
                'speech_source_start_frame':a,'file':f'output/audio/parts/{key}.wav',
                'text':old['beats'][beat-1][phase],
                'caption':old['beats'][beat-1]['caption']})
            delta+=length-(b-a)
        raw=src['source_frames']+delta;pad=(-raw)%FPS
        if pad:
            a=src['source_frames']-1
            replacements.append({'old_start_frame':a,'old_end_frame':a+1,
                'new_frame_count':pad+1,'new_start_frame':a+delta,'label':'tail_padding'})
        frames=raw+pad;duration=frames//FPS
        ch={k:old[k] for k in ('id','class','title','source','short','pages','module')}
        ch.update(start=offset,duration=duration,cues=cues,beats=[],actions=[])
        for action in src['actions']:
            a,b=action['old_start_frame'],action['old_end_frame']
            na,nb=mapped_frame(a,replacements),mapped_frame(b,replacements)
            assert nb-na==b-a
            ch['actions'].append({**action,'new_start_frame':na,'new_end_frame':nb})
        for i,beat in enumerate(old['beats'],1):
            cs=[c for c in cues if c['beat']==i];act=ch['actions'][i-1]
            ch['beats'].append({'index':i-1,'caption':beat['caption'],
                'intro':cs[0]['text'],'result':cs[1]['text'],
                'intro_at':cs[0]['at'],'intro_duration':cs[0]['speech_duration'],
                'action_at':act['new_start_frame']/FPS,'action_seconds':(act['new_end_frame']-act['new_start_frame'])/FPS,
                'result_at':cs[1]['at'],'result_duration':cs[1]['speech_duration']})
        track=np.zeros(duration*RATE,dtype='<i2');cursor=0
        for cue in cues:
            at=round(cue['at']*RATE);pcm=parts[cue['key']]
            assert cursor<=at and at+len(pcm)<=len(track)
            track[at:at+len(pcm)]=pcm;cursor=at+len(pcm)
        savewav(ROOT/'output/audio/chapters'/f"{old['id']:02d}.wav",track);master.append(track)
        plan['chapters'].append(ch);narrative['chapters'].append(ch)
        mapping['chapters'].append({'id':old['id'],'class':old['class'],
            'expected_frames':frames,'replacements':replacements})
        text.extend([f"{old['id']:02d}. {old['title']} — {stamp(offset)}",''])
        for cue in cues:
            label='Условия и теория' if cue['phase']=='intro' else 'Объяснение результата'
            text.extend([f"[{stamp(cue['global_at'])}–{stamp(cue['global_until'])}] {label}: {cue['text']}",''])
        offset+=duration
    plan['duration']=offset;narrative['total_duration']=offset
    dump(ROOT/'plan.json',plan);dump(ROOT/'narration.json',narrative);dump(ROOT/'frame_map.json',mapping)
    dump(ROOT/'output/edit_decisions.json',edits)
    savewav(ROOT/'output/audio/narration.wav',np.concatenate(master))
    (ROOT/'tekst_ozvuchki.txt').write_text('\n'.join(text).rstrip()+'\n',encoding='utf-8-sig')
    print(f'Prepared104readingparts;52actionsunchanged;{offset//60}:{offset%60:02d};{offset*FPS}frames',flush=True)

if __name__=='__main__':main()
