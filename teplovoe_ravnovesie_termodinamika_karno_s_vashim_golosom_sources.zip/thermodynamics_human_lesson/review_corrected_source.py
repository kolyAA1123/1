"""Capture exact-frame source proof for the isolated chapter7 label correction."""
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
from make_source_contacts import capture,digest
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/corrected_source_contacts'
OUT.mkdir(parents=True,exist_ok=True)
ch=next(x for x in json.loads((ROOT/'source_windows.json').read_text())['chapters'] if x['id']==7)
clip=ROOT/'visual_source/output/chapters/07_PistonWork.mp4'
before=digest(clip);samples=[]
for beat in range(1,4):
    windows={w['phase']:w for w in ch['windows'] if w['beat']==beat}
    action=next(x for x in ch['actions'] if x['beat']==beat)
    for phase in ('intro','action_start','action_mid','action_end','result'):
        if phase in windows:
            w=windows[phase];frame=(w['old_start_frame']+w['old_end_frame'])//2
        elif phase=='action_start':frame=action['old_start_frame']+1
        elif phase=='action_mid':frame=(action['old_start_frame']+action['old_end_frame'])//2
        else:frame=action['old_end_frame']-1
        key=f'07_{beat:02d}_{phase}';path=OUT/(key+'_full.jpg')
        capture(clip,frame,path)
        samples.append({'key':key,'beat':beat,'phase':phase,'source_frame':frame,'source_time':frame/60,'file':path.name})
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
sheet=Image.new('RGB',(1920,3*240),'#151515');draw=ImageDraw.Draw(sheet)
for i,row in enumerate(samples):
    im=Image.open(OUT/row['file']);im.thumbnail((384,216));x=(i%5)*384;y=(i//5)*240
    sheet.paste(im,(x,y));draw.text((x+4,y+219),f"{row['key']} / f{row['source_frame']}",font=font,fill='white')
sheet.save(OUT/'sheet_07.jpg',quality=96)
assert before==digest(clip)
(OUT/'manifest.json').write_text(json.dumps({'scope':'Source-only chapter7 correction review; exact source frames before audio retiming.','fps':60,'source_clip':str(clip),'source_sha256':before,'source_unchanged_during_capture':True,'states':samples},ensure_ascii=False,indent=2)+'\n')
print(f'Captured {len(samples)} exact-frame corrected chapter7 proof states')
