"""Collect strict source-hold checks without accepting unreviewed exceptions."""
from pathlib import Path
import json
import numpy as np
from PIL import Image,ImageDraw
import verify_delivery as v

def main():
    out=v.ROOT/'output/static_diagnostics';out.mkdir(exist_ok=True)
    cache_path=v.ROOT/'output/source_static_validation.json'
    cache=v.read(cache_path) if cache_path.exists() else {'schema':1,'checks':{}};failures=[]
    for ch in v.read(v.ROOT/'source_windows.json')['chapters']:
        p=Path(ch['source']);sha=v.digest(p)
        for window in ch['windows']:
            a,b=window['old_start_frame'],window['old_end_frame']
            label=window['key'];key=f'{sha}:{a}:{b}'
            if key in cache['checks']:continue
            frames=v.interval_frames(p,a,b)
            diff=np.abs(frames.astype(np.int16)-frames[len(frames)//2].astype(np.int16))
            means=diff.mean(axis=(1,2,3));maximum=int(diff.max());mean=float(means.max())
            check={'label':label,'start_frame':a,'end_frame':b,'decoded_frames':len(frames),
                   'max_frame_mean_abs_rgb_difference':round(mean,6),'max_channel_difference':maximum,
                   'accepted_limits':{'mean_limit':.15,'channel_limit':8}}
            if mean<.15 and maximum<=8:
                cache['checks'][key]=check
                cache_path.write_text(json.dumps(cache,ensure_ascii=False,indent=2)+'\n')
                print('PASS',label,round(mean,6),maximum,flush=True);continue
            k=int(means.argmax());sheet=Image.new('RGB',(960,572),'#111111');draw=ImageDraw.Draw(sheet)
            for i,(name,image) in enumerate([('first',frames[0]),('reference',frames[len(frames)//2]),('last',frames[-1]),('difference20x',(diff[k]*20).clip(0,255).astype(np.uint8))]):
                img=Image.fromarray(image).resize((480,270));x=(i%2)*480;y=(i//2)*286
                sheet.paste(img,(x,y));draw.text((x+5,y+272),name,fill='white')
            sheet.save(out/f'{label}_sheet.jpg',quality=95)
            item={**check,'source_sha256':sha,'frozen_wait':window['frozen_wait'],
                  'observed_mean_exact':mean,'sheet':f'{label}_sheet.jpg'}
            failures.append(item);print('REVIEW',label,round(mean,6),maximum,flush=True)
    (out/'pending_exceptions.json').write_text(json.dumps({'failures':failures},ensure_ascii=False,indent=2)+'\n')
    print('Pendingvisualreview',len(failures),flush=True)

if __name__=='__main__':main()
