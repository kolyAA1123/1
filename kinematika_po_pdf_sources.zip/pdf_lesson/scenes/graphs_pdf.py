"""Five graph chapters, checked against all eight pages of the supplied PDF.

All internal numeric coordinates are schematic drawing coordinates. Only the
speeds 1 and 0.5 m/s and the 5--10 s example are labelled with source numbers.
"""
from pdf_style import *


def _labels(a, vertical, xmax, ymax):
    return VGroup(
        eq('t', 27, MUTED).move_to(a.c2p(xmax, 0) + RIGHT*.20 + DOWN*.15),
        eq(vertical, 29, MUTED).move_to(a.c2p(0, ymax) + LEFT*.22 + UP*.18),
    )


def _fit_formula(tex, position, size=36, color=INK, width=5.5):
    obj=eq(tex,size,color).move_to(position)
    if obj.width>width:obj.scale_to_fit_width(width)
    return obj


def _triangle(a, t0, t1, y0, y1, vertical='\\Delta x', color=GOLD):
    p=a.c2p(t0,y0);q=a.c2p(t1,y0);r=a.c2p(t1,y1)
    legs=VGroup(DashedLine(p,q,color=color,dash_length=.11),
                DashedLine(q,r,color=color,dash_length=.11))
    h=eq(r'\Delta t',25,color).move_to((p+q)/2+DOWN*.29)
    v=eq(vertical,25,color).move_to((q+r)/2+RIGHT*.40)
    return legs,VGroup(h,v)


class UniformGraphs(ChapterScene):
    chapter_id=6

    def chapter(self):
        self.beat(0,'Равномерное движение: проекция скорости постоянна.')
        a=axes((0,5,1),(-2,2,1),width=6.0,height=3.5,center=LEFT*2.8+DOWN*.15)
        self.show(a,_labels(a,'v_x',5,2),create=True,run_time=1.5)
        positive=a.plot(lambda t:1.15,x_range=[0,4.7],color=CYAN)
        self.show(positive,create=True,run_time=1.5)
        self.show(_fit_formula('v_x>0',[3.3,1.35,0],color=CYAN),
                  _fit_formula(r'\vec v=\mathrm{const}',[3.3,.45,0]))
        self.wait(1.5)

        self.beat(1,'Отрицательная проекция означает движение против оси OX.')
        negative=a.plot(lambda t:-1.15,x_range=[0,4.7],color=ROSE)
        self.show(negative,create=True,run_time=1.5)
        self.show(_fit_formula('v_x<0',[3.3,-.5,0],color=ROSE),
                  txt('Знак задаёт направление',22,MUTED).move_to([3.2,-1.4,0]))
        self.wait(2)

        self.beat(2,'При постоянной скорости координата линейно зависит от времени.')
        self.clear_stage()
        a=axes((0,4.5,1),(0,6,1),width=6,height=3.8,center=LEFT*2.8+DOWN*.2)
        self.show(a,_labels(a,'x',4.5,6),create=True,run_time=1.5)
        origin=a.c2p(0,1)
        d1=Dot(origin,radius=.065,color=CYAN)
        d3=Dot(origin,radius=.052,color=GOLD)
        self.show(d1,d3,eq('x_0',25,MUTED).move_to(origin+LEFT*.36))
        self.show(_fit_formula('x=x_0+v_xt',[3.3,1.25,0]),
                  txt('Общая начальная точка',22,MUTED).move_to([3.2,.35,0]))

        self.beat(3,'В файле: первая скорость 1 м/с, третья — 0,5 м/с.')
        g1=a.plot(lambda t:1+t,x_range=[0,4],color=CYAN)
        g3=a.plot(lambda t:1+.5*t,x_range=[0,4],color=GOLD)
        speedlabels=VGroup(txt('v₁ = 1 м/с',28,CYAN),txt('v₃ = 0,5 м/с',28,GOLD)).arrange(DOWN,buff=.45).move_to([3.2,-.9,0])
        self.show(speedlabels)
        self.show(g1,g3,create=True,run_time=1.5)
        self.play(MoveAlongPath(d1,g1),MoveAlongPath(d3,g3),run_time=3.5,rate_func=linear)
        self.wait(1.2)

        self.beat(4,'За одно время большее изменение координаты — у более быстрого тела.')
        guide=DashedLine(a.c2p(4,0),a.c2p(4,5),color=MUTED,dash_length=.11)
        ends=VGroup(eq('x_1',24,CYAN).move_to(a.c2p(4,5)+RIGHT*.27),
                    eq('x_3',24,GOLD).move_to(a.c2p(4,3)+RIGHT*.27))
        self.show(guide,create=True,run_time=1.5)
        self.show(ends,_fit_formula('v_1>v_3',[3.3,-2.1,0],color=CYAN))
        self.wait(2)


class GraphSlopes(ChapterScene):
    chapter_id=7

    def slope_diagram(self):
        a=axes((0,4,1),(0,5,1),width=6,height=3.7,center=LEFT*2.8+DOWN*.2)
        g=a.plot(lambda t:1+.8*t,x_range=[0,3.7],color=CYAN)
        self.show(a,_labels(a,'x',4,5),create=True,run_time=1.5)
        self.show(g,create=True,run_time=1.5)
        legs,labs=_triangle(a,0,3,1,3.4)
        self.show(legs,create=True,run_time=1.2)
        self.show(labs)
        return a

    def chapter(self):
        self.beat(0,'Дельта обозначает изменение величины между двумя моментами.')
        self.slope_diagram()
        self.show(_fit_formula(r'v_x=\frac{\Delta x}{\Delta t}',[3.3,.8,0]),
                  txt('Наклон задаёт скорость',22,MUTED).move_to([3.2,-.3,0]))

        self.beat(1,'Первые 5 с — покой. Движение от 5 до 10 с занимает 5 с.')
        self.clear_stage()
        timeline=Line([-5.5,1.25,0],[5.5,1.25,0],color=MUTED)
        ticks=VGroup(*[Line([x,1.1,0],[x,1.4,0],color=MUTED) for x in [-5.5,0,5.5]])
        times=VGroup(*[txt(label,24).move_to([x,1.75,0]) for x,label in [(-5.5,'0 с'),(0,'5 с'),(5.5,'10 с')]])
        road=Line([-5.5,-.95,0],[5.5,-.95,0],color=GRID)
        self.show(timeline,ticks,road,create=True,run_time=1.2)
        self.show(times)
        vehicle=car().move_to([-4.8,-.65,0])
        pointer=Dot([-5.5,1.25,0],color=GOLD,radius=.075)
        self.show(vehicle,pointer,run_time=.6)
        self.play(pointer.animate.move_to([0,1.25,0]),run_time=1.3,rate_func=linear)
        self.wait(.3)
        self.play(pointer.animate.move_to([5.5,1.25,0]),vehicle.animate.move_to([4.7,-.65,0]),run_time=2.1,rate_func=linear)
        self.wait(.4)
        result=VGroup(eq(r'\Delta t=10-5=5',35,GOLD),txt('с',27,GOLD)).arrange(RIGHT,buff=.15).move_to([0,-2.0,0])
        self.show(result,run_time=.8)

        self.beat(2,'При отрицательной скорости координата уменьшается и может пройти через ноль.')
        self.clear_stage()
        a=axes((0,5,1),(-2.5,3.5,1),width=6,height=3.7,center=LEFT*2.8+DOWN*.15)
        g=a.plot(lambda t:2.5-.9*t,x_range=[0,5],color=ROSE)
        d=Dot(a.c2p(0,2.5),color=ROSE,radius=.065)
        self.show(a,_labels(a,'x',5,3.5),create=True,run_time=1.5)
        self.show(g,create=True,run_time=1.5)
        self.show(d,eq('x_0',24,MUTED).move_to(a.c2p(0,2.5)+LEFT*.33))
        self.show(_fit_formula('v_x<0',[3.3,1.05,0],color=ROSE),
                  _fit_formula('x=x_0+v_xt',[3.3,.1,0]))
        self.play(MoveAlongPath(d,g),run_time=2.5,rate_func=linear)
        self.wait(.6)

        self.beat(3,'Перемещение отсчитывается от начальной координаты: Sₓ = x − x₀.')
        self.clear_stage()
        a=axes((0,4,1),(0,4,1),width=6,height=3.7,center=LEFT*2.8+DOWN*.15)
        g=a.plot(lambda t:.8*t,x_range=[0,3.8],color=CYAN)
        d=Dot(a.c2p(0,0),color=CYAN,radius=.065)
        self.show(a,_labels(a,'S_x',4,4),create=True,run_time=1.5)
        self.show(g,create=True,run_time=1.5)
        self.show(d)
        self.show(_fit_formula('S_x=x-x_0',[3.3,1.25,0]),
                  _fit_formula('S_x=v_xt',[3.3,.2,0]),
                  _fit_formula('S_x(0)=0',[3.3,-.85,0],color=GOLD))
        self.play(MoveAlongPath(d,g),run_time=2.4,rate_func=linear)

        self.beat(4,'Сравнивая наклоны, учитываем масштаб и единицы обеих осей.')
        self.clear_stage()
        self.slope_diagram()
        self.show(_fit_formula(r'v_x=\frac{\Delta x}{\Delta t}',[3.3,.9,0]),
                  VGroup(txt('Отношение приращений',23),txt('с учётом масштаба осей',21,MUTED)).arrange(DOWN,buff=.25).move_to([3.2,-.5,0]))


class AccelerationGraphs(ChapterScene):
    chapter_id=8

    def car_motion(self,braking):
        road=Line([-5.8,-1.45,0],[5.8,-1.45,0],color=GRID)
        xaxis=arrow([-5.8,-2.15,0],[11.6,0,0],MUTED)
        self.show(road,xaxis,create=True,run_time=1.1)
        self.show(eq('x',25,MUTED).move_to([5.95,-2.15,0]))
        s=ValueTracker(0)
        self.add(s)
        def position():
            p=s.get_value()
            return np.array([-4.6+8.6*((2*p-p*p) if braking else (.25*p+.75*p*p)),-1.15,0])
        vehicle=car().move_to(position())
        vehicle.add_updater(lambda m:m.move_to(position()))
        def vl():return (2.2*(1-s.get_value())) if braking else (.3+1.8*s.get_value())
        vel=always_redraw(lambda:arrow(position()+UP*.72,[vl(),0,0],CYAN))
        acc=always_redraw(lambda:arrow(position()+UP*1.37,[-1.3 if braking else 1.3,0,0],ROSE))
        self.show(vehicle,vel,acc,run_time=.9)
        labels=VGroup(eq('v_x',25,CYAN).move_to([-5.5,-.43,0]),eq('a_x',25,ROSE).move_to([-5.5,.22,0]))
        self.show(labels,run_time=.6)
        signs=VGroup(eq('v_x>0',33,CYAN),eq('a_x<0' if braking else 'a_x>0',33,ROSE)).arrange(RIGHT,buff=1.0).move_to([0,1.75,0])
        self.show(signs)
        self.play(s.animate.set_value(1),run_time=3.6,rate_func=linear)
        freeze(vehicle,vel,acc)
        if braking:
            self.play(Transform(signs[0],eq('v_x=0',33,CYAN).move_to(signs[0])),run_time=.6)
            end=eq('v_x=0',30,CYAN).move_to([3.7,-.35,0])
            self.show(end,run_time=.6)
        self.wait(.6)

    def chapter(self):
        self.beat(0,'Торможение при движении вдоль +OX: скорость положительна, ускорение отрицательно.')
        self.car_motion(True)

        self.beat(1,'При разгоне вдоль +OX скорость и ускорение сонаправлены.')
        self.clear_stage()
        self.car_motion(False)

        self.beat(2,'У равноускоренного движения проекция ускорения постоянна.')
        self.clear_stage()
        a=axes((0,5,1),(0,3,1),width=6,height=3.7,center=LEFT*2.8+DOWN*.15)
        g=a.plot(lambda t:1.4,x_range=[0,4.7],color=ROSE)
        self.show(a,_labels(a,'a_x',5,3),create=True,run_time=1.5)
        self.show(g,create=True,run_time=1.5)
        self.show(_fit_formula(r'a_x=\mathrm{const}',[3.3,1.0,0],color=ROSE),
                  _fit_formula(r'a_x=\frac{\Delta v_x}{\Delta t}',[3.3,-.1,0]))

        self.beat(3,'Скорость меняется линейно: vₓ = v₀ₓ + aₓt.')
        self.clear_stage()
        a=axes((0,5,1),(0,4.5,1),width=6,height=3.7,center=LEFT*2.8+DOWN*.15)
        g=a.plot(lambda t:1+.6*t,x_range=[0,4.7],color=CYAN)
        d=Dot(a.c2p(0,1),color=CYAN,radius=.065)
        self.show(a,_labels(a,'v_x',5,4.5),create=True,run_time=1.5)
        self.show(g,create=True,run_time=1.5)
        self.show(d,eq('v_{0x}',24,MUTED).move_to(a.c2p(0,1)+LEFT*.38))
        self.show(_fit_formula('v_x=v_{0x}+a_xt',[3.3,1.2,0]))
        self.play(MoveAlongPath(d,g),run_time=3.2,rate_func=linear)
        self.wait(.8)

        self.beat(4,'Наклон vₓ(t) задаёт ускорение через Δvₓ / Δt с учётом масштаба.')
        legs,labs=_triangle(a,0,4,1,3.4,vertical=r'\Delta v_x')
        self.show(legs,create=True,run_time=1.5)
        self.show(labs,_fit_formula(r'a_x=\frac{\Delta v_x}{\Delta t}',[3.3,-.05,0],color=ROSE))
        caveat=VGroup(txt('Масштаб осей учитывается',21,MUTED),txt('в отношении приращений',21,MUTED)).arrange(DOWN,buff=.25).move_to([3.2,-1.5,0])
        self.show(caveat)
        self.wait(2)


class AreaParabolas(ChapterScene):
    chapter_id=9

    def signed_area(self,negative=False):
        sign=-1 if negative else 1
        a=axes((0,5,1),(-4,1,1) if negative else (0,4,1),width=6,height=3.7,center=LEFT*2.8+DOWN*.15)
        f=lambda t:sign*(1+.5*t)
        g=a.plot(f,x_range=[0,4],color=ROSE if negative else CYAN)
        self.show(a,_labels(a,'v_x',5,1 if negative else 4),create=True,run_time=1.5)
        self.show(g,create=True,run_time=1.5)
        tau=ValueTracker(0);self.add(tau)
        color=ROSE if negative else CYAN
        def area_shape():
            t=max(tau.get_value(),.0001)
            return Polygon(a.c2p(0,0),a.c2p(0,f(0)),a.c2p(t,f(t)),a.c2p(t,0),
                           stroke_width=0,fill_color=color,fill_opacity=.24)
        area=always_redraw(area_shape)
        edge=always_redraw(lambda:DashedLine(a.c2p(tau.get_value(),0),a.c2p(tau.get_value(),f(tau.get_value())),color=GOLD,dash_length=.10))
        marker=always_redraw(lambda:Dot(a.c2p(tau.get_value(),f(tau.get_value())),color=color,radius=.06))
        self.show(area,edge,marker,run_time=.8)
        self.play(tau.animate.set_value(4),run_time=3.2,rate_func=linear)
        freeze(area,edge,marker)
        self.show(_fit_formula('S_x<0' if negative else 'S_x>0',[3.3,1.1,0],color=color),
                  VGroup(txt('Проекция перемещения',22),txt('знаковая площадь',22,MUTED)).arrange(DOWN,buff=.3).move_to([3.2,-.15,0]),
                  eq('t_0',25,GOLD).move_to(a.c2p(4,0)+DOWN*.3))
        self.wait(.5)

    def parabola(self,upwards):
        a=axes((0,4.3,1),(0,4,1) if upwards else (-1.2,4,1),width=6,height=3.7,center=LEFT*2.8+DOWN*.15)
        f=(lambda t:.55*(t-1.8)**2+.6) if upwards else (lambda t:3.2-.5*(t-1.2)**2)
        g=a.plot(f,x_range=[0,4],color=CYAN if upwards else ROSE)
        self.show(a,_labels(a,'x',4.3,4),create=True,run_time=1.5)
        self.show(g,create=True,run_time=1.5)
        tau=ValueTracker(0);self.add(tau)
        d=always_redraw(lambda:Dot(a.c2p(tau.get_value(),f(tau.get_value())),color=GOLD,radius=.07))
        self.show(d,run_time=.6)
        self.show(_fit_formula('a_x>0' if upwards else 'a_x<0',[3.3,1.1,0],color=CYAN if upwards else ROSE),
                  txt('Ветви вверх' if upwards else 'Ветви вниз',27).move_to([3.2,.15,0]))
        self.play(tau.animate.set_value(4),run_time=3.4,rate_func=linear)
        freeze(d)
        self.wait(.8)

    def chapter(self):
        self.beat(0,'Положительная площадь под vₓ(t) даёт положительное перемещение.')
        self.signed_area(False)

        self.beat(1,'Ниже оси времени вклад в проекцию перемещения отрицателен.')
        self.clear_stage()
        self.signed_area(True)

        self.beat(2,'При постоянном ускорении координата зависит от времени квадратично.')
        self.clear_stage()
        formula=eq('x=x_0+v_{0x}t+\\frac{a_xt^2}{2}',49).move_to([0,.5,0])
        self.show(txt('Закон координаты',30).move_to([0,1.9,0]))
        self.show(formula,run_time=1.5)
        underline=Line(formula.get_right()+LEFT*2.15+DOWN*.55,formula.get_right()+DOWN*.55,color=GOLD,stroke_width=3)
        self.show(underline,create=True,run_time=1.2)
        self.show(txt('Квадратичная зависимость от времени',28,GOLD).move_to([0,-1.25,0]))
        self.wait(1.5)

        self.beat(3,'При aₓ > 0 ветви направлены вверх: кривая проходит через минимум.')
        self.clear_stage()
        self.parabola(True)

        self.beat(4,'При aₓ < 0 ветви направлены вниз: кривая проходит через максимум.')
        self.clear_stage()
        self.parabola(False)


class TangentsAverage(ChapterScene):
    chapter_id=10

    def chapter(self):
        self.beat(0,'Мгновенную скорость определяют по касательной к графику координаты.')
        a=axes((0,5.2,1),(0,4,1),width=7,height=3.6,center=LEFT*2.45+DOWN*.25)
        f=lambda t:1.8+.65*np.sin(2.5*t+.2)+.1*t
        df=lambda t:1.625*np.cos(2.5*t+.2)+.1
        g=a.plot(f,x_range=[0,5],color=CYAN)
        self.show(a,_labels(a,'x',5.2,4),create=True,run_time=1.5)
        self.show(g,create=True,run_time=1.5)
        def tangent(t,color):
            p=a.c2p(t,f(t));slope=df(t)
            line=Line(a.c2p(t-.38,f(t)-slope*.38),a.c2p(t+.58,f(t)+slope*.58),color=color,stroke_width=2.6)
            return line,Dot(p,color=color,radius=.067)
        line1,d1=tangent(.15,GOLD)
        self.show(line1,create=True,run_time=1.5)
        self.show(d1,eq('1',25,GOLD).move_to(a.c2p(.15,f(.15))+UP*.32))
        explanation=VGroup(txt('Наклон касательной',23),txt('мгновенная скорость',21,MUTED)).arrange(DOWN,buff=.3).move_to([3.8,.7,0])
        self.show(explanation,txt('Общий график x(t)',23,MUTED).move_to([-2.5,2.15,0]))

        self.beat(1,'Возрастание — vₓ > 0, минимум — vₓ = 0, убывание — vₓ < 0.')
        min_t=(2*PI-np.arccos(-.1/1.625)-.2)/2.5
        line2,d2=tangent(min_t,LAVENDER)
        line3,d3=tangent(3.5,ROSE)
        self.play(FadeOut(explanation),run_time=.8)
        self.show(line2,line3,create=True,run_time=1.5)
        self.show(d2,d3,eq('2',25,LAVENDER).move_to(a.c2p(min_t,f(min_t))+DOWN*.35),
                  eq('3',25,ROSE).move_to(a.c2p(3.5,f(3.5))+UP*.36))
        signs=VGroup(eq('1:\ v_x>0',31,GOLD),eq('2:\ v_x=0',31,LAVENDER),eq('3:\ v_x<0',31,ROSE)).arrange(DOWN,buff=.5).move_to([3.8,.25,0])
        self.show(signs)
        self.wait(2)

        self.beat(2,'Три участка пути проходят последовательно со скоростями v₁, v₂ и v₃.')
        self.clear_stage()
        points=[np.array([x,-.35,0]) for x in [-5.55,-1.85,1.85,5.55]]
        segments=VGroup(*[Line(points[i],points[i+1],color=GRID,stroke_width=3) for i in range(3)])
        knots=VGroup(*[Dot(p,radius=.045,color=MUTED) for p in points])
        slabels=VGroup(*[eq(f'S_{i+1}',29,[CYAN,GOLD,ROSE][i]).move_to((points[i]+points[i+1])/2+DOWN*.5) for i in range(3)])
        speeds=VGroup(*[VGroup(arrow((points[i]+points[i+1])/2+UP*.8+LEFT*.5,[1,0,0],[CYAN,GOLD,ROSE][i]),eq(f'v_{i+1}',26,[CYAN,GOLD,ROSE][i]).move_to((points[i]+points[i+1])/2+UP*1.22)) for i in range(3)])
        self.show(segments,create=True,run_time=1.5)
        self.show(knots,slabels,speeds)
        moving=Dot(points[0],color=INK,radius=.08)
        self.show(moving,run_time=.5)
        for i,duration in enumerate([1.4,1.8,1.6]):
            color=[CYAN,GOLD,ROSE][i]
            trace=Line(points[i],points[i+1],color=color,stroke_width=3.5)
            self.play(Create(trace),moving.animate.move_to(points[i+1]),run_time=duration,rate_func=linear)
            self.show(eq(f't_{i+1}',27,color).move_to((points[i]+points[i+1])/2+DOWN*1.25),run_time=.4)
        self.wait(.8)

        self.beat(3,'Средняя путевая скорость — весь пройденный путь, делённый на всё время.')
        numerator=txt('весь путь',28)
        denominator=txt('всё время',28)
        bar=Line(LEFT*1.35,RIGHT*1.35,color=INK,stroke_width=1.7)
        fraction=VGroup(numerator,bar,denominator).arrange(DOWN,buff=.14)
        wordformula=VGroup(eq(r'v_{\mathrm{cp}}=',36),fraction).arrange(RIGHT,buff=.22).move_to([0,1.8,0])
        self.show(wordformula,run_time=1.2)
        self.wait(2)

        self.beat(4,'В числителе складываем три пути, в знаменателе — три времени.')
        final=eq(r'v_{\mathrm{cp}}=\frac{S_1+S_2+S_3}{t_1+t_2+t_3}',43).move_to([0,1.8,0])
        self.play(FadeOut(wordformula),FadeIn(final),run_time=1.2)
        self.play(*[Indicate(slabels[i],color=[CYAN,GOLD,ROSE][i],scale_factor=1.1) for i in range(3)],run_time=1.6)
        self.wait(2)
