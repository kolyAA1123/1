"""Chapters 11–15. Every physical traversal and construction finishes."""
from pdf_style import *


def polar(center, radius, theta):
    return np.asarray(center) + radius*np.array([np.cos(theta), np.sin(theta), 0.])


def orbit(center, radius, phase, color=CYAN):
    """A dot and a radius controlled by an explicit angle tracker."""
    dot=always_redraw(lambda: Dot(polar(center,radius,phase.get_value()),radius=.085,color=color))
    ray=always_redraw(lambda: Line(center,polar(center,radius,phase.get_value()),color=color,stroke_width=2))
    return dot,ray


class RelativeClosing(ChapterScene):
    chapter_id=11
    def chapter(self):
        self.beat(0,"Навстречу друг другу: скорости складываются")
        road=Line([-5,.35,0],[5,.35,0],color=GRID,stroke_width=2)
        left=Dot([-4,.35,0],radius=.12,color=CYAN)
        right=Dot([4,.35,0],radius=.12,color=GOLD)
        vl=always_redraw(lambda: arrow(left.get_center(),RIGHT*1.2,CYAN))
        vr=always_redraw(lambda: arrow(right.get_center(),LEFT*1.2,GOLD))
        labels=VGroup(eq('v_1',29,CYAN).move_to([-3.45,.9,0]),eq('v_2',29,GOLD).move_to([3.45,.9,0]))
        form=eq(r'v_{\mathrm{сближ}}=v_1+v_2',42).move_to([0,-1.35,0])
        self.show(road,create=True,run_time=.7)
        self.show(left,right,vl,vr,labels,run_time=1)
        self.show(form,run_time=.9)
        self.beat(1,"Движение заканчивается встречей, расстояние становится нулевым")
        self.play(left.animate.move_to([0,.35,0]),right.animate.move_to([0,.35,0]),run_time=5.8,rate_func=linear)
        freeze(vl,vr)
        self.play(FadeOut(vl),FadeOut(vr),FadeOut(labels),run_time=.7)
        meeting=txt('Встреча',28).move_to([0,1.1,0])
        self.show(meeting,run_time=.8)
        self.beat(2,"Одна сторона: более быстрое тело находится сзади")
        self.clear_stage(run_time=.9)
        lanes=VGroup(Line([-5,.9,0],[5,.9,0],color=GRID),Line([-5,-.15,0],[5,-.15,0],color=GRID))
        rear=car(GOLD).move_to([-4,-.15,0]);front=car(CYAN).move_to([-.8,.9,0])
        ar=always_redraw(lambda: arrow(rear.get_center()+UP*.05,RIGHT*1.4,GOLD))
        af=always_redraw(lambda: arrow(front.get_center()+UP*.05,RIGHT*.76,CYAN))
        f2=eq(r'v_2>v_1',36).move_to([0,2,0])
        l2=eq('v_2',28,GOLD).move_to([-3.3,-.7,0]);l1=eq('v_1',28,CYAN).move_to([-.3,1.5,0])
        self.show(lanes,create=True,run_time=.8)
        self.show(rear,front,ar,af,l1,l2,f2,run_time=1)
        self.beat(3,"Догоняющее тело сокращает расстояние со скоростью v₂ − v₁")
        diff=eq(r'v_{\mathrm{сближ}}=v_2-v_1',42).move_to([0,-1.65,0])
        self.show(diff,run_time=.9)
        self.play(rear.animate.move_to([3,-.15,0]),front.animate.move_to([3,.9,0]),run_time=6,rate_func=linear)
        freeze(ar,af)
        self.play(FadeOut(ar),FadeOut(af),FadeOut(l1),FadeOut(l2),run_time=.6)
        finish=DashedLine([3,-.55,0],[3,1.35,0],color=INK)
        self.show(finish,create=True,run_time=.65)
        self.beat(4,"Оба процесса завершены: встреча и догоняние")
        self.clear_stage(run_time=.9)
        summaries=VGroup(
            txt('Навстречу',27,CYAN).move_to([-3,1.5,0]),
            eq(r'v_{\mathrm{сближ}}=v_1+v_2',39).move_to([1.5,1.5,0]),
            txt('Быстрое тело сзади',26,GOLD).move_to([-3,-.1,0]),
            eq(r'v_{\mathrm{сближ}}=v_2-v_1',39).move_to([1.5,-.1,0]),
            eq(r'v_2>v_1',29,MUTED).move_to([1.5,-.9,0]))
        self.show(summaries,run_time=1.2)


class TurnPeriod(ChapterScene):
    chapter_id=12
    def chapter(self):
        c=np.array([-3.,-.1,0]);r=1.65;a=PI/3
        self.beat(0,"Поворот задаёт угол между двумя радиусами")
        circle=Circle(r,color=CYAN,stroke_width=2).move_to(c)
        origin=Dot(c,radius=.045,color=INK)
        ra=Line(c,polar(c,r,a),color=CYAN);rb=Line(c,polar(c,r,0),color=GOLD)
        angle=Arc(radius=.48,start_angle=0,angle=a,color=GOLD).shift(c)
        arc=Arc(radius=r,start_angle=0,angle=a,color=GOLD,stroke_width=5).shift(c)
        labels=VGroup(txt('O',22).move_to(c+LEFT*.25+DOWN*.2),txt('A',24).move_to(polar(c,r+.25,a)),
            txt('B',24).move_to(polar(c,r+.25,0)),eq('R',27).move_to(c+RIGHT*.9+DOWN*.25),
            eq(r'\Delta\varphi',29,GOLD).move_to(c+RIGHT*.78+UP*.3),eq('S',26,GOLD).move_to(polar(c,r+.26,a/2)))
        self.show(circle,create=True,run_time=1.3)
        self.show(origin,ra,rb,create=True,run_time=.8)
        self.show(arc,angle,create=True,run_time=.9)
        self.show(labels,run_time=.8)
        self.beat(1,"Угловая скорость — угол поворота за промежуток времени")
        omega=eq(r'\omega=\frac{\Delta\varphi}{\Delta t}',47).move_to([2.7,.8,0])
        units=eq(r'[\omega]=\mathrm{рад/с}',32,MUTED).move_to([2.7,-.45,0])
        self.show(omega,run_time=1.1);self.show(units,run_time=.8)
        self.beat(2,"Полный оборот заканчивается в начальной точке")
        self.play(FadeOut(ra),FadeOut(rb),FadeOut(arc),FadeOut(angle),FadeOut(labels),run_time=.8)
        phase=ValueTracker(a);dot,ray=orbit(c,r,phase)
        self.show(dot,ray,run_time=.8)
        full=eq(r'360^\circ=2\pi\ \mathrm{рад}',35,GOLD).move_to([2.7,-1.65,0])
        self.show(full,run_time=.8)
        self.play(phase.animate.set_value(a-TAU),run_time=6,rate_func=linear)
        self.beat(3,"Период T — время одного полного оборота")
        self.clear_stage(run_time=.9)
        phase=ValueTracker(PI/2);dot,ray=orbit(c,r,phase)
        circle=Circle(r,color=CYAN,stroke_width=2).move_to(c)
        period=VGroup(txt('Один оборот',29).move_to([2.6,1.4,0]),eq('T',46,GOLD).move_to([2.6,.55,0]),
            eq(r'\omega=\frac{2\pi}{T}',43).move_to([2.6,-.65,0]))
        self.show(circle,create=True,run_time=.8);self.show(dot,ray,period,run_time=1)
        self.play(phase.animate.set_value(PI/2-TAU),run_time=5,rate_func=linear)
        self.beat(4,"Частота показывает число полных оборотов за секунду")
        frequency=eq(r'\nu=\frac{1}{T}',42,CYAN).move_to([2.6,-1.9,0])
        unit=txt('ν — частота, Гц',23,MUTED).move_to([-3,-2.35,0])
        self.show(frequency,unit,run_time=1)


class LinearRotation(ChapterScene):
    chapter_id=13
    def chapter(self):
        self.beat(0,"Из файла: 10 оборотов за 13,2 секунды")
        facts=VGroup(eq('N=10',43,GOLD),eq(r't=13{,}2\ \mathrm{с}',43,CYAN)).arrange(DOWN,buff=.65).move_to([-3,.6,0])
        c=np.array([2.8,.25,0]);r=1.4;turns=ValueTracker(0)
        phase=ValueTracker(PI/2)
        circle=Circle(r,color=CYAN,stroke_width=2).move_to(c)
        dot=always_redraw(lambda: Dot(polar(c,r,PI/2-TAU*turns.get_value()),radius=.08,color=GOLD))
        ray=always_redraw(lambda: Line(c,polar(c,r,PI/2-TAU*turns.get_value()),color=GOLD,stroke_width=2))
        counter=always_redraw(lambda: VGroup(txt('Оборотов:',24,MUTED),Integer(min(10,int(turns.get_value()+1e-5)),font_size=31,color=GOLD)).arrange(RIGHT,buff=.2).move_to([2.8,-1.7,0]))
        self.show(facts,circle,run_time=1);self.show(dot,ray,counter,run_time=.8)
        self.play(turns.animate.set_value(10),run_time=7,rate_func=linear)
        self.beat(1,"Разделим время на число оборотов и число оборотов на время")
        self.clear_stage(run_time=.9)
        result=VGroup(eq(r'T=\frac{t}{N}=\frac{13{,}2}{10}=1{,}32\ \mathrm{с}',43,GOLD),
            eq(r'\nu=\frac{N}{t}=\frac{10}{13{,}2}\approx0{,}76\ \mathrm{Гц}',43,CYAN)).arrange(DOWN,buff=.9).move_to([0,.2,0])
        self.show(result[0],run_time=1.2);self.show(result[1],run_time=1.2)
        self.beat(2,"Одна частота соответствует угловой скорости 2πν")
        self.clear_stage(run_time=.9)
        conversion=VGroup(eq(r'\omega=\frac{2\pi}{T}',43),eq(r'\nu=\frac{1}{T}',43),eq(r'\omega=2\pi\nu',52,GOLD)).arrange(DOWN,buff=.55).move_to([0,.15,0])
        for formula in conversion:self.show(formula,run_time=.9)
        self.beat(3,"За один оборот точка проходит путь 2πR за время T")
        self.clear_stage(run_time=.9)
        c=np.array([-3.,-.05,0]);r=1.65;phase=ValueTracker(PI/2)
        circle=Circle(r,color=CYAN,stroke_width=2).move_to(c);dot,ray=orbit(c,r,phase)
        length=eq(r'l_{\mathrm{окр}}=2\pi R',39,GOLD).move_to([2.5,1.1,0])
        speed=eq(r'v=\frac{l_{\mathrm{окр}}}{T}=\frac{2\pi R}{T}',43).move_to([2.5,-.4,0])
        self.show(circle,create=True,run_time=1.2);self.show(dot,ray,length,speed,run_time=1)
        self.play(phase.animate.set_value(PI/2-TAU),run_time=5.5,rate_func=linear)
        self.beat(4,"Скорость направлена по касательной и равна ωR")
        tangent=always_redraw(lambda: arrow(polar(c,r,phase.get_value()),
            np.array([np.sin(phase.get_value()),-np.cos(phase.get_value()),0.])*1.15,CYAN))
        self.show(tangent,run_time=.9)
        final=eq(r'v=\omega R',46,GOLD).move_to([2.5,-1.7,0])
        self.show(final,run_time=.9)
        self.play(phase.animate.set_value(PI/2-2*TAU),run_time=6,rate_func=linear)


class CircularAcceleration(ChapterScene):
    chapter_id=14
    def chapter(self):
        c=np.array([-3.,-.1,0]);r=1.65;phase=ValueTracker(PI/2)
        self.beat(0,"При постоянном модуле скорости её направление меняется")
        circle=Circle(r,color=CYAN,stroke_width=2).move_to(c)
        dot=always_redraw(lambda: Dot(polar(c,r,phase.get_value()),radius=.085,color=INK))
        velocity=always_redraw(lambda: arrow(polar(c,r,phase.get_value()),np.array([np.sin(phase.get_value()),-np.cos(phase.get_value()),0.])*1.1,CYAN))
        normal=always_redraw(lambda: arrow(polar(c,r,phase.get_value()),(c-polar(c,r,phase.get_value()))*.65,GOLD))
        info=VGroup(eq(r'v=\mathrm{const}',36,CYAN),eq(r'\vec v\perp\vec a_{\mathrm{ц}}',38,GOLD),txt('К центру окружности',25,MUTED)).arrange(DOWN,buff=.55).move_to([2.6,.35,0])
        self.show(circle,create=True,run_time=1);self.show(dot,velocity,normal,info,run_time=1)
        self.play(phase.animate.set_value(PI/2-TAU),run_time=5.7,rate_func=linear)
        self.beat(1,"Касательное ускорение меняет модуль скорости; здесь он растёт")
        self.clear_stage(run_time=.9)
        circle=Circle(r,color=CYAN,stroke_width=2).move_to(c);p=c+UP*r
        dot=Dot(p,radius=.085,color=INK)
        va=arrow(p,RIGHT*1.45,CYAN,width=4);at=arrow(p,RIGHT*2.15,GOLD,width=2)
        lv=eq(r'\vec v',30,CYAN).move_to(p+RIGHT*.7+UP*.37)
        lat=eq(r'\vec a_\tau',30,GOLD).move_to(p+RIGHT*1.9+DOWN*.38)
        text=VGroup(txt('Скорость растёт',29),eq(r'\vec a_\tau\parallel\vec v',39,GOLD),txt('Направление — по касательной',22,MUTED)).arrange(DOWN,buff=.6).move_to([2.7,.3,0])
        self.show(circle,create=True,run_time=.9);self.show(dot,at,va,lv,lat,text,run_time=1.1)
        self.beat(2,"Полное ускорение — полностью построенная векторная сумма")
        self.clear_stage(run_time=.9)
        circle=Circle(r,color=CYAN,stroke_width=2).move_to(c);p=c+UP*r
        dot=Dot(p,radius=.08,color=INK);at=arrow(p,RIGHT*1.5,CYAN);ac=arrow(p,DOWN*1.2,GOLD)
        dashed=VGroup(DashedLine(p+RIGHT*1.5,p+RIGHT*1.5+DOWN*1.2,color=MUTED),DashedLine(p+DOWN*1.2,p+RIGHT*1.5+DOWN*1.2,color=MUTED))
        total=arrow(p,RIGHT*1.5+DOWN*1.2,ROSE,width=4)
        labs=VGroup(eq(r'\vec a_\tau',27,CYAN).move_to(p+RIGHT*.75+UP*.35),eq(r'\vec a_{\mathrm{ц}}',27,GOLD).move_to(p+LEFT*.48+DOWN*.6),eq(r'\vec a',28,ROSE).move_to(p+RIGHT*.9+DOWN*.9))
        form=eq(r'\vec a=\vec a_\tau+\vec a_{\mathrm{ц}}',38).move_to([2.6,1.35,0])
        self.show(circle,create=True,run_time=.8);self.show(dot,at,ac,run_time=.9)
        self.show(dashed,create=True,run_time=1.1);self.show(total,create=True,run_time=1)
        self.show(labs,form,run_time=.9)
        self.beat(3,"Перпендикулярные составляющие связаны теоремой Пифагора")
        perp=eq(r'\vec a_\tau\perp\vec a_{\mathrm{ц}}',34,MUTED).move_to([2.6,.1,0])
        magnitude=eq(r'a^2=a_\tau^2+a_{\mathrm{ц}}^2',41).move_to([2.6,-.95,0])
        self.show(perp,run_time=.9);self.show(magnitude,run_time=1.1)
        self.beat(4,"Центростремительное ускорение выражается через скорость и радиус")
        centripetal=eq(r'a_{\mathrm{ц}}=\frac{v^2}{R}=\omega^2R',40,GOLD).move_to([2.6,-2.1,0])
        self.show(centripetal,run_time=1.1)


def wheel(center,radius,phase,color=CYAN,teeth=0):
    if teeth:
        points=[polar(ORIGIN,radius+(.055 if i%2==0 else -.055),TAU*i/(teeth*2)) for i in range(teeth*2)]
        ring=Polygon(*points,color=color,stroke_width=2)
    else:ring=Circle(radius,color=color,stroke_width=2)
    base=VGroup(ring,Line(ORIGIN,RIGHT*radius*.9,color=color,stroke_width=2),Dot(ORIGIN,radius=.045,color=INK))
    return always_redraw(lambda: base.copy().rotate(phase.get_value()).move_to(center))


class RotationTransmission(ChapterScene):
    chapter_id=15
    def chapter(self):
        self.beat(0,"Цепь без проскальзывания: скорости ободов одинаковы")
        c1=np.array([-3.9,0,0]);c2=np.array([-.65,0,0]);r1=1.2;r2=.6
        turn=ValueTracker(0);ph1=ValueTracker(0);ph2=ValueTracker(0)
        w1=wheel(c1,r1,ph1,CYAN);w2=wheel(c2,r2,ph2,GOLD)
        q=(r1-r2)/np.linalg.norm(c2-c1);n=np.array([q,np.sqrt(1-q*q),0])
        chain=VGroup(Line(c1+r1*n,c2+r2*n,color=INK,stroke_width=3),Line(c1+r1*n*np.array([1,-1,1]),c2+r2*n*np.array([1,-1,1]),color=INK,stroke_width=3))
        form=eq(r'|\vec v_1|=|\vec v_2|=v',39).move_to([3,1,0])
        note=txt('Центры неподвижны',23,MUTED).move_to([3,-.1,0])
        sense=txt('Одно направление вращения',22,MUTED).move_to([1.6,-1.9,0])
        self.show(w1,w2,run_time=1);self.show(chain,create=True,run_time=1)
        self.show(form,note,sense,run_time=1)
        self.play(ph1.animate.set_value(-TAU),ph2.animate.set_value(-2*TAU),run_time=8,rate_func=linear)
        self.beat(1,"Один диск: за одинаковое время точки поворачиваются на один угол")
        self.clear_stage(run_time=.9)
        c=np.array([-3.,0,0]);r=1.7;phase=ValueTracker(0);ra=1.35;rb=.75;aa=-PI/4;ab=3*PI/4
        disk=Circle(r,color=CYAN,stroke_width=2).move_to(c)
        da=always_redraw(lambda: Dot(polar(c,ra,aa+phase.get_value()),radius=.08,color=GOLD))
        db=always_redraw(lambda: Dot(polar(c,rb,ab+phase.get_value()),radius=.08,color=LAVENDER))
        rays=always_redraw(lambda: VGroup(Line(c,polar(c,ra,aa+phase.get_value()),color=GOLD,stroke_width=2),Line(c,polar(c,rb,ab+phase.get_value()),color=LAVENDER,stroke_width=2)))
        labs=always_redraw(lambda: VGroup(txt('A',23,GOLD).move_to(polar(c,ra+.25,aa+phase.get_value())),txt('B',23,LAVENDER).move_to(polar(c,rb+.26,ab+phase.get_value()))))
        omega=eq(r'\omega_A=\omega_B=\omega',41).move_to([2.7,1.3,0])
        self.show(disk,create=True,run_time=.9);self.show(da,db,rays,labs,omega,run_time=1)
        self.play(phase.animate.set_value(TAU),run_time=6.5,rate_func=linear)
        self.beat(2,"На одном диске линейная скорость пропорциональна расстоянию до центра")
        ratio=eq(r'\frac{v_A}{v_B}=\frac{\omega R_A}{\omega R_B}=\frac{R_A}{R_B}',41,GOLD).move_to([2.7,-.05,0])
        tangent=lambda rad,ang,col: always_redraw(lambda: arrow(polar(c,rad,ang+phase.get_value()),rad*.6*np.array([-np.sin(ang+phase.get_value()),np.cos(ang+phase.get_value()),0]),col))
        va=tangent(ra,aa,GOLD);vb=tangent(rb,ab,LAVENDER)
        self.show(ratio,va,vb,run_time=1.1)
        self.play(phase.animate.set_value(2*TAU),run_time=6.5,rate_func=linear)
        self.beat(3,"При общей угловой скорости центростремительное ускорение также пропорционально R")
        aratio=eq(r'\frac{a_{\mathrm{ц}A}}{a_{\mathrm{ц}B}}=\frac{\omega^2R_A}{\omega^2R_B}=\frac{R_A}{R_B}',38,LAVENDER).move_to([2.7,-1.6,0])
        normal=lambda rad,ang,col: always_redraw(lambda: arrow(polar(c,rad,ang+phase.get_value()),(c-polar(c,rad,ang+phase.get_value()))*.6,col,width=2))
        na=normal(ra,aa,GOLD);nb=normal(rb,ab,LAVENDER)
        self.show(aratio,na,nb,run_time=1.1)
        self.play(phase.animate.set_value(3*TAU),run_time=6.5,rate_func=linear)
        self.beat(4,"Шестерни: скорости в зацеплении равны, направления вращения противоположны")
        self.clear_stage(run_time=.9)
        ca=np.array([-3.65,0,0]);cb=np.array([-1.4,0,0]);pa=ValueTracker(0);pb=ValueTracker(0)
        ga=wheel(ca,.9,pa,CYAN,12);gb=wheel(cb,1.35,pb,GOLD,18)
        equals=eq(r'|\vec v_1|=|\vec v_2|=v',39).move_to([3,1.05,0])
        same=txt('Скорость в точке контакта',23,MUTED).move_to([2.7,-.2,0])
        contact=arrow(ca+RIGHT*.9,UP*1.05,ROSE)
        labels=VGroup(txt('Против часовой',20,CYAN).move_to([-3.7,-1.7,0]),txt('По часовой',20,GOLD).move_to([-1.2,-2.05,0]))
        self.show(ga,gb,run_time=1.1);self.show(equals,same,labels,contact,run_time=1)
        self.play(pa.animate.set_value(3*TAU),pb.animate.set_value(-2*TAU),run_time=9.8,rate_func=linear)
