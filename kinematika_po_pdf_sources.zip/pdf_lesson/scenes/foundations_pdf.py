"""Source-faithful first five chapters from КИНЕМАТИКА.pdf, pp. 1–11."""
from pdf_style import *


def named_axis(a):
    return VGroup(eq('x',25,MUTED).next_to(a.x_axis.get_end(),RIGHT,buff=.08),
                  eq('y',25,MUTED).next_to(a.y_axis.get_end(),UP,buff=.08))


def dashed(p,q,color=MUTED):
    return DashedLine(p,q,color=color,stroke_width=1.3,dash_length=.08)


def row_formula(*strings,size=31,color=INK):
    return VGroup(*[eq(s,size,color) for s in strings]).arrange(DOWN,buff=.5)


class ModelsFrames(ChapterScene):
    chapter_id=1
    def chapter(self):
        self.beat(0,'Кинематика описывает движение, не рассматривая вызывающие его силы')
        root=txt('Механика',35).move_to([0,1.95,0])
        self.show(root)
        labels=VGroup(*[txt(s,29,c).move_to([x,.4,0]) for s,x,c in
            [('Кинематика',-4.2,CYAN),('Динамика',0,GOLD),('Статика',4.2,LAVENDER)]])
        edges=VGroup(*[arrow([0,1.4,0],[x,-.6,0],GRID,1.7) for x in [-4.2,0,4.2]])
        self.show(edges,create=True,run_time=1.4);self.show(labels)
        desc=VGroup(txt('Описание движения',21,CYAN).move_to([-4.2,-.45,0]),
                    txt('Причины движения',21,GOLD).move_to([0,-.45,0]),
                    txt('Условия равновесия',21,LAVENDER).move_to([4.2,-.45,0]))
        self.show(desc)
        self.show(txt('Механическое движение — изменение положения тел с течением времени',23).move_to([0,-1.75,0]))

        self.beat(1,'Модель сохраняет существенные свойства тела для данной задачи')
        self.clear_stage(run_time=.8)
        self.show(txt('Физическая модель — упрощённое описание тела или процесса',25).move_to([0,2.15,0]))
        self.show(txt('Материальная точка',27,CYAN).move_to([-3.4,1.25,0]),
                  txt('Абсолютно твёрдое тело',27,GOLD).move_to([3.1,1.25,0]))
        ball=Circle(radius=.65,color=CYAN,stroke_width=2).move_to([-3.4,-.05,0])
        shape=Rectangle(width=2.3,height=1.05,color=GOLD,stroke_width=2).move_to([2.7,-.1,0])
        pa=shape.get_left()+RIGHT*.25;pb=shape.get_right()+LEFT*.25
        rigidity=VGroup(shape,Dot(pa,radius=.055,color=INK),Dot(pb,radius=.055,color=INK),Line(pa,pb,color=INK,stroke_width=1.4))
        self.show(ball,rigidity,create=True)
        self.play(Transform(ball,Dot(ball.get_center(),radius=.065,color=CYAN)),rigidity.animate.shift(RIGHT*.65+DOWN*.35),run_time=2)
        self.show(txt('Размерами можно пренебречь',21,CYAN).move_to([-3.4,-1.55,0]),
                  txt('Расстояния между точками постоянны',21,GOLD).move_to([3.0,-1.75,0]))

        self.beat(2,'При поступательном движении любой отрезок тела остаётся параллельным себе')
        self.clear_stage(run_time=.8)
        self.show(txt('Поступательное движение',31,CYAN).move_to([0,2.05,0]))
        initial=np.array([-3.3,-.5,0]);target=np.array([2.7,.5,0])
        rect=Rectangle(width=1.65,height=1.25,color=CYAN,stroke_width=2).move_to(initial)
        seg=Line(initial+[-.6,-.25,0],initial+[.5,.3,0],color=GOLD,stroke_width=3)
        body=VGroup(rect,seg,Dot(seg.get_start(),radius=.055),Dot(seg.get_end(),radius=.055))
        ghost=body.copy().set_stroke(opacity=.25).set_fill(opacity=.25)
        self.show(ghost,body,run_time=.8)
        path=Line(initial,target,color=GRID,stroke_width=1.2)
        self.show(path,create=True,run_time=.7)
        self.play(body.animate.shift(target-initial),run_time=3.5,rate_func=smooth)
        connectors=VGroup(dashed(ghost[1].get_start(),body[1].get_start()),dashed(ghost[1].get_end(),body[1].get_end()))
        self.show(connectors,create=True)
        self.show(txt('Направление отрезка не изменилось',25,GOLD).move_to([0,-2.15,0]))

        self.beat(3,'Кабины колеса движутся по окружности и сохраняют вертикальную ориентацию')
        self.clear_stage(run_time=.8)
        center=np.array([-3.1,-.05,0]);radius=1.7
        rim=Circle(radius=radius,color=CYAN,stroke_width=2).move_to(center)
        spokes=VGroup(*[Line(center,center+radius*np.array([np.cos(t),np.sin(t),0]),color=GRID,stroke_width=1.4) for t in np.linspace(0,TAU,8,endpoint=False)])
        phi=ValueTracker(0);self.add(phi)
        cabins=VGroup()
        for theta in np.linspace(0,TAU,8,endpoint=False):
            cab=RoundedRectangle(width=.3,height=.42,corner_radius=.035,color=GOLD,stroke_width=1.8,fill_color=BLACK,fill_opacity=1)
            def update_cabin(m,theta=theta):
                m.move_to(center+radius*np.array([np.cos(theta+phi.get_value()),np.sin(theta+phi.get_value()),0])+DOWN*.2)
            cab.add_updater(update_cabin);cab.update(0);cabins.add(cab)
        self.show(rim,spokes,cabins,run_time=1.2)
        words=VGroup(txt('Траектория — окружность',25).move_to([2.9,.85,0]),
                     txt('Кабины не поворачиваются',24,GOLD).move_to([2.9,.05,0]),
                     txt('Движение поступательное',24,CYAN).move_to([2.9,-.75,0]))
        self.show(words,run_time=.7)
        self.play(Rotate(spokes,angle=TAU,about_point=center),phi.animate.set_value(TAU),run_time=5.3,rate_func=linear)
        freeze(cabins,spokes)

        self.beat(4,'Система отсчёта: тело отсчёта, координаты и прибор для измерения времени')
        self.clear_stage(run_time=.8)
        headers=VGroup(*[txt(s,24,c).move_to([x,1.9,0]) for s,x,c in
            [('Тело отсчёта',-4.4,CYAN),('Координаты',0,GOLD),('Часы',4.3,LAVENDER)]])
        self.show(headers)
        post=VGroup(Rectangle(width=.7,height=1.7,color=CYAN,stroke_width=2).move_to([-4.4,-.1,0]),Line([-5.6,-.95,0],[-3.2,-.95,0],color=MUTED))
        a=axes((-1,2,1),(-1,2,1),3.1,2.7,ORIGIN+DOWN*.1)
        clock=Circle(radius=.95,color=LAVENDER,stroke_width=2).move_to([4.3,-.05,0])
        marks=VGroup(*[Line(clock.get_center()+.82*np.array([np.cos(t),np.sin(t),0]),clock.get_center()+.9*np.array([np.cos(t),np.sin(t),0]),color=MUTED,stroke_width=1.2) for t in np.linspace(0,TAU,12,endpoint=False)])
        hand=Line(clock.get_center(),clock.get_center()+UP*.72,color=LAVENDER,stroke_width=2.7)
        self.show(post,a,named_axis(a),clock,marks,hand,run_time=1.2)
        self.show(Dot(a.c2p(.9,1),radius=.07,color=GOLD),run_time=.6)
        self.play(Rotate(hand,angle=-TAU,about_point=clock.get_center()),run_time=3.8,rate_func=linear)
        self.show(txt('Описываем положение тела и момент времени',25).move_to([0,-2.2,0]))


class PathUniform(ChapterScene):
    chapter_id=2
    def chapter(self):
        self.beat(0,'Тело проходит всю траекторию от А до Б; перемещение соединяет её концы')
        p=np.array([-5.3,1.2,0]);q=np.array([-.9,-1.4,0])
        curve=VMobject().set_points_smoothly([p,[-2,1.3,0],[-2.6,-.1,0],[-4,-1.4,0],q])
        dot=Dot(p,radius=.075,color=CYAN)
        labels=VGroup(txt('А',25).next_to(p,UP),txt('Б',25).next_to(q,RIGHT))
        self.show(labels,dot,run_time=.9)
        trace=TracedPath(dot.get_center,stroke_color=CYAN,stroke_width=2.4);self.add(trace)
        self.play(MoveAlongPath(dot,curve),run_time=4.7,rate_func=linear);freeze(trace)
        self.show(arrow(p,q-p,GOLD,2.6),create=True,run_time=1.2)
        self.show(eq(r'\vec S',35,GOLD).move_to([-2.5,.3,0]))
        definitions=VGroup(txt('Траектория — линия движения',24,CYAN),txt('Путь — длина траектории',24),txt('Перемещение — вектор АБ',24,GOLD)).arrange(DOWN,buff=.7).move_to([3.15,.25,0])
        if definitions.width>6:definitions.scale_to_fit_width(6)
        self.show(definitions)

        self.beat(1,'После полного возвращения в начальную точку перемещение равно нулю')
        self.clear_stage(run_time=.8)
        center=np.array([-3,-.1,0]);loop=Circle(radius=1.65).move_to(center).rotate(PI/3,about_point=center)
        point=Dot(loop.point_from_proportion(0),radius=.075,color=CYAN)
        self.show(point,txt('А = Б',25).next_to(point,UP),run_time=.8)
        trace=TracedPath(point.get_center,stroke_color=CYAN,stroke_width=2.6);self.add(trace)
        self.play(MoveAlongPath(point,loop),run_time=4.5,rate_func=linear);freeze(trace)
        results=row_formula(r'\vec S=0',r'L>0',r'L\geq|\vec S|',size=40).move_to([3,.15,0])
        self.show(results)
        self.show(txt('Путь не меньше модуля перемещения',23).move_to([0,-2.45,0]))

        self.beat(2,'На прямой проекция перемещения равна разности конечной и начальной координат')
        self.clear_stage(run_time=.8)
        line=arrow([-5.6,-.1,0],[11.1,0,0],MUTED,1.6)
        x0=np.array([-4.5,-.1,0]);x=np.array([3.7,-.1,0]);point=Dot(x0,radius=.075,color=CYAN)
        self.show(line,eq('x',27,MUTED).move_to([5.8,-.15,0]),point,
                  eq('x_0',30).move_to(x0+DOWN*.5),eq('x',30).move_to(x+DOWN*.5))
        self.play(point.animate.move_to(x),run_time=3.2,rate_func=linear)
        self.show(arrow(x0+UP*.55,x-x0,GOLD,2.5),create=True,run_time=1.1)
        self.show(eq('S_x=x-x_0',44,GOLD).move_to([0,1.6,0]))
        ticks=VGroup(*[Line([z,-.25,0],[z,.05,0],color=CYAN,stroke_width=2) for z in np.linspace(-4.5,3.7,5)])
        self.show(ticks,create=True,run_time=.8)
        self.show(txt('Равным промежуткам времени — равные перемещения',24,CYAN).move_to([0,-1.75,0]))

        self.beat(3,'При постоянной скорости перемещение пропорционально времени')
        self.clear_stage(run_time=.8)
        road=arrow([-5.6,-.35,0],[5.4,0,0],MUTED,1.6)
        vehicle=car().move_to([-5.15,.1,0])
        steps=VGroup(*[Dot([z,-.35,0],radius=.035,color=CYAN) for z in np.linspace(-5.15,-.8,5)])
        self.show(road,steps,vehicle,run_time=1)
        formula=row_formula(r'v_x=\mathrm{const}',r'S_x=v_xt',r'x=x_0+v_xt',size=39).move_to([3.1,.2,0])
        self.show(formula)
        self.play(vehicle.animate.shift(RIGHT*4.35),run_time=4.5,rate_func=linear)
        self.show(txt('Равномерное прямолинейное движение',24,CYAN).move_to([0,-2.15,0]))

        self.beat(4,'Алгебраическая площадь под графиком скорости равна проекции перемещения')
        self.clear_stage(run_time=.8)
        left=axes((0,4,1),(-2,2,1),4.8,2.8,LEFT*3.3+UP*.1)
        right=axes((0,4,1),(-2,2,1),4.8,2.8,RIGHT*3.3+UP*.1)
        self.show(left,right,run_time=1)
        graph_labels=VGroup(eq('v_x',25).next_to(left.y_axis.get_end(),UP,buff=.08),eq('t',25).next_to(left.x_axis.get_end(),RIGHT,buff=.08),eq('v_x',25).next_to(right.y_axis.get_end(),UP,buff=.08),eq('t',25).next_to(right.x_axis.get_end(),RIGHT,buff=.08))
        self.show(graph_labels,run_time=.6)
        positive=Line(left.c2p(0,1.35),left.c2p(3.3,1.35),color=CYAN,stroke_width=2.8)
        negative=Line(right.c2p(0,-1.35),right.c2p(3.3,-1.35),color=ROSE,stroke_width=2.8)
        self.show(positive,negative,create=True,run_time=1.5)
        area1=Polygon(left.c2p(0,0),left.c2p(3.3,0),left.c2p(3.3,1.35),left.c2p(0,1.35),stroke_width=0,fill_color=CYAN,fill_opacity=.22)
        area2=Polygon(right.c2p(0,0),right.c2p(3.3,0),right.c2p(3.3,-1.35),right.c2p(0,-1.35),stroke_width=0,fill_color=ROSE,fill_opacity=.22)
        self.show(area1,area2,run_time=1.2)
        self.show(eq(r'S_{1x}=v_{1x}t_1>0',33,CYAN).move_to([-3.3,-2.1,0]),eq(r'S_{2x}=-|v_{2x}|t_2<0',33,ROSE).move_to([3.3,-2.1,0]))


class AcceleratedLaws(ChapterScene):
    chapter_id=3
    def speed_plot(self):
        a=axes((0,4,1),(0,4,1),5.2,3.2,LEFT*3.1+DOWN*.15)
        g=Line(a.c2p(0,1),a.c2p(3.6,3.35),color=CYAN,stroke_width=2.6)
        lab=VGroup(eq('v_x',26).next_to(a.y_axis.get_end(),UP,buff=.08),eq('t',26).next_to(a.x_axis.get_end(),RIGHT,buff=.08),eq('v_{0x}',25).next_to(a.c2p(0,1),LEFT,buff=.12),eq('v_x',25).next_to(a.c2p(3.6,3.35),UP,buff=.1),eq('t',25).next_to(a.c2p(3.6,0),DOWN,buff=.15))
        return a,g,lab
    def chapter(self):
        self.beat(0,'При постоянном ускорении за равные промежутки времени скорость меняется одинаково')
        a,g,lab=self.speed_plot();self.show(a,lab,run_time=1)
        definition=eq(r'a_x=\frac{v_x-v_{0x}}{t}',38,GOLD).move_to([3,.8,0])
        self.show(definition)
        self.show(g,create=True,run_time=2.5)
        self.show(eq(r'v_x=v_{0x}+a_xt',39,CYAN).move_to([3,-.55,0]),eq(r'a_x=\mathrm{const}',30).move_to([3,-1.75,0]))

        self.beat(1,'Под линейным графиком скорости получается трапеция')
        self.clear_stage(run_time=.8)
        a,g,lab=self.speed_plot();self.show(a,lab,g,run_time=1)
        region=Polygon(a.c2p(0,0),a.c2p(3.6,0),a.c2p(3.6,3.35),a.c2p(0,1),stroke_width=0,fill_color=CYAN,fill_opacity=.22)
        self.show(region,run_time=1.2)
        trap=Polygon([1.5,.9,0],[4.8,.9,0],[4.1,2.05,0],[2.25,2.05,0],color=GOLD,stroke_width=2)
        tlab=VGroup(eq('a',25,GOLD).move_to([3.2,2.3,0]),eq('b',25,GOLD).move_to([3.2,.6,0]),eq('h',25,GOLD).move_to([2.5,1.45,0]))
        self.show(trap,tlab,create=True,run_time=1)
        self.show(eq(r'S=\frac{a+b}{2}h',34).move_to([3.15,-.1,0]))
        self.show(eq(r'S_x=\frac{v_{0x}+v_x}{2}\,t',37,CYAN).move_to([3.1,-1.55,0]))

        self.beat(2,'Подставляем закон скорости и доводим преобразование до формулы перемещения')
        self.clear_stage(run_time=.8)
        law=eq(r'v_x=v_{0x}+a_xt',36,GOLD).move_to([0,1.8,0])
        formula=eq(r'S_x=\frac{v_{0x}+v_x}{2}\,t',44,CYAN).move_to([0,.35,0])
        self.show(law,formula)
        next_formula=eq(r'S_x=\frac{v_{0x}+v_{0x}+a_xt}{2}\,t',44,CYAN).move_to(formula)
        self.play(Transform(formula,next_formula),run_time=1.3)
        self.wait(.7)
        self.play(Transform(formula,eq(r'S_x=\frac{2v_{0x}t+a_xt^2}{2}',44,CYAN).move_to(formula)),run_time=1.3)
        self.wait(.7)
        self.play(Transform(formula,eq(r'S_x=v_{0x}t+\frac{a_xt^2}{2}',46,CYAN).move_to(formula)),run_time=1.3)
        self.show(txt('Начальное движение  +  изменение из-за ускорения',25).move_to([0,-1.65,0]))

        self.beat(3,'Связываем перемещение с координатами и получаем закон координаты')
        self.clear_stage(run_time=.8)
        axis=arrow([-5.7,.7,0],[5.1,0,0],MUTED,1.7)
        p=np.array([-5,.7,0]);q=np.array([-1.3,.7,0])
        self.show(axis,Dot(p,radius=.06,color=CYAN),Dot(q,radius=.06,color=CYAN),eq('x_0',28).move_to(p+DOWN*.45),eq('x',28).move_to(q+DOWN*.45))
        self.show(arrow(p+UP*.5,q-p,GOLD,2.5),create=True,run_time=1.2)
        self.show(eq(r'S_x=x-x_0',39,GOLD).move_to([3.1,.9,0]))
        formula=eq(r'x-x_0=v_{0x}t+\frac{a_xt^2}{2}',40).move_to([0,-.8,0])
        self.show(formula)
        self.play(Transform(formula,eq(r'x=x_0+v_{0x}t+\frac{a_xt^2}{2}',44,CYAN).move_to(formula)),run_time=1.4)

        self.beat(4,'Исключаем время; при делении на ускорение требуется aₓ ≠ 0')
        self.clear_stage(run_time=.8)
        known=row_formula(r'v_x=v_{0x}+a_xt',r't=\frac{v_x-v_{0x}}{a_x}',size=35).move_to([-3.3,.65,0])
        self.show(known)
        expression=eq(r'S_x=\frac{v_{0x}+v_x}{2}\,\frac{v_x-v_{0x}}{a_x}',33,CYAN).move_to([3,.6,0])
        if expression.width>6.05:expression.scale_to_fit_width(6.05)
        self.show(expression)
        self.wait(.7)
        self.play(Transform(expression,eq(r'S_x=\frac{v_x^2-v_{0x}^2}{2a_x}',43,CYAN).move_to([3,.6,0])),run_time=1.7)
        self.show(eq(r'a_x\ne0',32,GOLD).move_to([-3.3,-1.3,0]),eq(r'v_x^2-v_{0x}^2=2a_xS_x',39).move_to([2,-1.55,0]))


class VectorProjections(ChapterScene):
    chapter_id=4
    def chapter(self):
        self.beat(0,'Вектор задаётся модулем и направлением; скалярные проекции имеют знак')
        a=axes((-1,4,1),(-1,4,1),4.8,3.7,LEFT*3.25+DOWN*.1)
        p=a.c2p(.4,.5);q=a.c2p(3.2,2.8)
        vec=arrow(p,q-p,CYAN,2.7)
        projx=arrow(a.c2p(.4,0),a.c2p(3.2,0)-a.c2p(.4,0),GOLD,2.5)
        projy=arrow(a.c2p(0,.5),a.c2p(0,2.8)-a.c2p(0,.5),LAVENDER,2.5)
        perps=VGroup(dashed(p,a.c2p(.4,0)),dashed(q,a.c2p(3.2,0)),dashed(p,a.c2p(0,.5)),dashed(q,a.c2p(0,2.8)))
        self.show(a,named_axis(a));self.show(vec,create=True,run_time=1.7)
        self.show(perps,create=True,run_time=1.4);self.show(projx,projy,create=True)
        self.show(eq(r'\vec a',30,CYAN).move_to((p+q)/2+UP*.25),eq('a_x',28,GOLD).next_to(projx,DOWN),eq('a_y',28,LAVENDER).next_to(projy,LEFT))
        meaning=VGroup(txt('Модуль и направление',25,CYAN),txt('Проекция — число со знаком',23),eq('a_x>0,\quad a_y>0',37)).arrange(DOWN,buff=.65).move_to([3.15,.15,0])
        self.show(meaning)

        self.beat(1,'Модуль находим по проекциям; перпендикулярная проекция равна нулю')
        self.clear_stage(run_time=.8)
        self.show(txt('Плоскость',26,CYAN).move_to([-3.4,2.3,0]),txt('Пространство',26,LAVENDER).move_to([3.25,2.3,0]))
        p=np.array([-5, .7,0]);u=np.array([2.9,0,0]);v=np.array([0,1.25,0])
        tri=VGroup(Line(p,p+u,color=GOLD,stroke_width=2),Line(p+u,p+u+v,color=LAVENDER,stroke_width=2),arrow(p,u+v,CYAN,2.5))
        self.show(tri,create=True)
        o=np.array([2.9,.75,0]);vx=np.array([-1.05,-.6,0]);vy=np.array([1.8,0,0]);vz=np.array([0,1.2,0])
        spatial=VGroup(arrow(o,vx,MUTED,1.6),arrow(o,vy,MUTED,1.6),arrow(o,vz,MUTED,1.6),arrow(o,vx+vy+vz,LAVENDER,2.7),dashed(o+vx,o+vx+vy),dashed(o+vx+vy,o+vx+vy+vz),eq('x',23).move_to(o+vx+DOWN*.18),eq('y',23).move_to(o+vy+RIGHT*.18),eq('z',23).move_to(o+vz+UP*.18))
        self.show(spatial,create=True,run_time=1.3)
        self.show(eq(r'|\vec a|=\sqrt{a_x^2+a_y^2}',35,CYAN).move_to([-3.4,-.35,0]),eq(r'|\vec a|=\sqrt{a_x^2+a_y^2+a_z^2}',33,LAVENDER).move_to([3.1,-.35,0]))
        horizontal=arrow([-4.9,-1.55,0],[2.1,0,0],GOLD,2.7)
        vertical=arrow([3.2,-2.05,0],[0,.9,0],LAVENDER,2.7)
        self.show(horizontal,vertical,create=True)
        self.show(eq('a_x=a,\quad a_y=0',30,GOLD).move_to([-3.4,-2.35,0]),eq('b_x=0,\quad b_y=b',30,LAVENDER).move_to([3.4,-2.5,0]))

        self.beat(2,'В прямоугольном треугольнике роли катетов зависят от выбранного угла')
        self.clear_stage(run_time=.8)
        p=np.array([-5.3,-1.6,0]);r=np.array([-2.9,-1.6,0]);q=np.array([-2.9,1.75,0])
        triangle=Polygon(p,r,q,color=CYAN,stroke_width=2)
        labs=VGroup(eq('a',31,GOLD).move_to([-2.6,.05,0]),eq('b',31,GOLD).move_to([-4.1,-1.95,0]),eq('c',31,CYAN).move_to([-4.55,.15,0]),eq(r'\alpha',28,GOLD).move_to([-4.63,-1.32,0]),eq(r'\beta',28,LAVENDER).move_to([-3.12,1.12,0]))
        square=Square(side_length=.18,color=MUTED,stroke_width=1.4).move_to(r+[-.09,.09,0])
        self.show(triangle,labs,square,create=True,run_time=1.6)
        atab=row_formula(r'\sin\alpha=\frac ac',r'\cos\alpha=\frac bc',r'\tan\alpha=\frac ab',r'\cot\alpha=\frac ba',size=30,color=GOLD).arrange(DOWN,buff=.34).move_to([.7,.3,0])
        btab=row_formula(r'\sin\beta=\frac bc',r'\cos\beta=\frac ac',r'\tan\beta=\frac ba',r'\cot\beta=\frac ab',size=30,color=LAVENDER).arrange(DOWN,buff=.34).move_to([4,.3,0])
        self.show(atab,run_time=1.3);self.show(btab,run_time=1.3)
        self.show(eq(r'\sin^2\alpha+\cos^2\alpha=1',35).move_to([2.4,-2.15,0]))

        self.beat(3,'Для угла от положительного направления OX: косинус даёт x, синус — y')
        self.clear_stage(run_time=.8)
        a=axes((0,4,1),(0,3,1),4.8,3.6,LEFT*3.2+DOWN*.1);o=a.c2p(0,0);p=a.c2p(3.4,2.3)
        vec=arrow(o,p-o,CYAN,2.8);px=arrow(o,a.c2p(3.4,0)-o,GOLD,2.5);py=arrow(o,a.c2p(0,2.3)-o,LAVENDER,2.5)
        angle=np.arctan2((p-o)[1],(p-o)[0]);arc=Arc(radius=.58,start_angle=0,angle=angle,color=GOLD,stroke_width=2).shift(o)
        self.show(a,named_axis(a));self.show(vec,create=True,run_time=1.3)
        self.show(dashed(p,a.c2p(3.4,0)),dashed(p,a.c2p(0,2.3)),px,py,arc,create=True,run_time=1.5)
        self.show(eq(r'\alpha',29,GOLD).move_to(o+[.85,.2,0]))
        formulas=row_formula(r'\cos\alpha=\frac{a_x}{|\vec a|}',r'a_x=|\vec a|\cos\alpha',r'a_y=|\vec a|\sin\alpha',size=36).move_to([3.1,.25,0])
        formulas[1].set_color(GOLD);formulas[2].set_color(LAVENDER)
        self.show(formulas,run_time=1.4)

        self.beat(4,'Во второй четверти x-проекция отрицательна; γ отсчитываем от отрицательной полуоси OX')
        self.clear_stage(run_time=.8)
        a=axes((-3,2,1),(-1,3.5,1),4.8,4.32,LEFT*3.2+DOWN*.05);o=a.c2p(0,0);p=a.c2p(-2.15,2.75)
        vec=arrow(o,p-o,CYAN,2.8);cx=arrow(o,a.c2p(-2.15,0)-o,ROSE,2.6);cy=arrow(o,a.c2p(0,2.75)-o,LAVENDER,2.6)
        theta=np.arctan2((p-o)[1],(p-o)[0]);arc=Arc(radius=.55,start_angle=theta,angle=PI-theta,color=GOLD,stroke_width=2).shift(o)
        self.show(a,named_axis(a));self.show(vec,create=True,run_time=1.4)
        self.show(cx,cy,dashed(p,a.c2p(-2.15,0)),dashed(p,a.c2p(0,2.75)),arc,create=True,run_time=1.4)
        self.show(eq(r'\gamma',29,GOLD).move_to(o+[-.78,.35,0]),eq(r'\vec c',30,CYAN).move_to((o+p)/2+LEFT*.3))
        f=row_formula(r'c_x=-|\vec c|\cos\gamma',r'c_y=|\vec c|\sin\gamma',r'c_x<0,\quad c_y>0',size=36).move_to([3.1,.25,0]);f[0].set_color(ROSE);f[1].set_color(LAVENDER)
        self.show(f)


class VectorOperations(ChapterScene):
    chapter_id=5
    def chapter(self):
        self.beat(0,'Правило треугольника: совмещаем конец первого вектора с началом второго')
        o=np.array([-5,-1.5,0]);av=np.array([2.5,2.25,0]);bv=np.array([2.1,0,0])
        aa=arrow(o,av,CYAN,2.8);bstart=o+DOWN*.65;bb=arrow(bstart,bv,GOLD,2.8)
        al=eq(r'\vec a',30,CYAN).move_to(o+av*.5+LEFT*.3);bl=eq(r'\vec b',30,GOLD).move_to(bstart+bv*.5+DOWN*.32)
        bg=VGroup(bb,bl)
        self.show(aa,al,bg,create=True,run_time=1.4)
        self.play(bg.animate.shift(o+av-bstart),run_time=2.3,rate_func=smooth)
        self.show(arrow(o,av+bv,LAVENDER,3),create=True,run_time=1.6)
        self.show(eq(r'\vec a+\vec b',37,LAVENDER).move_to([3.5,.7,0]),txt('От начала первого',23).move_to([3.5,-.2,0]),txt('до конца второго',23).move_to([3.5,-.75,0]))

        self.beat(1,'Правило параллелограмма: сумма — диагональ из общего начала')
        self.clear_stage(run_time=.8)
        o=np.array([-5,-1.5,0]);av=np.array([2,2.25,0]);bv=np.array([2.6,0,0])
        aa=arrow(o,av,CYAN,2.8);bb=arrow(o,bv,GOLD,2.8)
        self.show(aa,bb,create=True,run_time=1.3)
        self.show(eq(r'\vec a',29,CYAN).move_to(o+av*.5+LEFT*.3),eq(r'\vec b',29,GOLD).move_to(o+bv*.5+DOWN*.35))
        sides=VGroup(dashed(o+av,o+av+bv,GOLD),dashed(o+bv,o+av+bv,CYAN))
        self.show(sides,create=True,run_time=1.5)
        self.show(arrow(o,av+bv,LAVENDER,3),create=True,run_time=1.5)
        self.show(eq(r'\vec a+\vec b',39,LAVENDER).move_to([3.5,.8,0]),txt('Стороны параллельны',23).move_to([3.5,-.2,0]),txt('исходным векторам',23).move_to([3.5,-.75,0]))

        self.beat(2,'Оба геометрических построения дают один и тот же вектор суммы')
        self.clear_stage(run_time=.8)
        self.show(txt('Треугольник',27,CYAN).move_to([-3.4,2.05,0]),txt('Параллелограмм',27,GOLD).move_to([3.2,2.05,0]))
        av=np.array([1.6,2.1,0]);bv=np.array([2,0,0]);l=np.array([-5.4,-1.5,0]);r=np.array([1.1,-1.5,0])
        originals=VGroup(arrow(l,av,CYAN,2.5),arrow(l+av,bv,GOLD,2.5),arrow(r,av,CYAN,2.5),arrow(r,bv,GOLD,2.5))
        self.show(originals,create=True,run_time=1.8)
        self.show(dashed(r+av,r+av+bv,GOLD),dashed(r+bv,r+av+bv,CYAN),create=True,run_time=1.2)
        self.show(arrow(l,av+bv,LAVENDER,3),arrow(r,av+bv,LAVENDER,3),create=True,run_time=1.6)
        self.show(eq(r'\vec a+\vec b',39,LAVENDER).move_to([0,-2.35,0]))

        self.beat(3,'Противоположный вектор имеет тот же модуль и обратное направление')
        self.clear_stage(run_time=.8)
        b=arrow([-4.9,.4,0],[3.15,0,0],GOLD,3);label=eq(r'\vec b',37,GOLD).move_to([-3.3,1.25,0])
        self.show(b,label,create=True,run_time=1)
        original_b=b.copy().set_opacity(.25)
        self.show(original_b,run_time=.6)
        self.play(Rotate(b,angle=PI,about_point=b.get_center()),Transform(label,eq(r'-\vec b',37,GOLD).move_to(label)),run_time=2.5,rate_func=smooth)
        self.show(eq(r'|-\vec b|=|\vec b|',39).move_to([3,.8,0]),txt('Модуль сохраняется',25).move_to([3,-.2,0]),txt('Направление меняется',25,GOLD).move_to([3,-.9,0]))
        self.show(eq(r'\vec a-\vec b=\vec a+(-\vec b)',39,LAVENDER).move_to([0,-2.15,0]))

        self.beat(4,'Вычитание заканчиваем построением суммы первого вектора и противоположного второму')
        self.clear_stage(run_time=.8)
        o=np.array([-4.9,-1.55,0]);av=np.array([3.4,2.6,0]);neg=np.array([-1.55,0,0])
        aa=arrow(o,av,CYAN,2.8);al=eq(r'\vec a',31,CYAN).move_to(o+av*.5+RIGHT*.25)
        initial=np.array([-.8,-2.1,0]);bb=arrow(initial,neg,GOLD,2.8);bl=eq(r'-\vec b',31,GOLD).move_to(initial+neg*.5+DOWN*.33);bg=VGroup(bb,bl)
        self.show(aa,al,bg,create=True,run_time=1.2)
        self.play(bg.animate.shift(o+av-initial),run_time=2.1,rate_func=smooth)
        result=arrow(o,av+neg,LAVENDER,3)
        self.show(result,create=True,run_time=1.5)
        self.show(eq(r'\vec a-\vec b',40,LAVENDER).move_to([3.2,.6,0]),eq(r'=\vec a+(-\vec b)',35).move_to([3.2,-.35,0]))
