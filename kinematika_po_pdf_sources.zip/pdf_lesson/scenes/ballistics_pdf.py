"""Five silent ballistics chapters, read directly from pages 1–11 of the PDF."""
from pdf_style import *


def formulas(*lines, x=3.05, y=.15, size=34, color=INK, gap=.4, width=6.05):
    group=VGroup(*[eq(line,size,color) for line in lines]).arrange(DOWN,buff=gap,aligned_edge=LEFT)
    if group.width>width:group.scale_to_fit_width(width)
    return group.move_to([x,y,0])


def labels(*lines, x=2.7, y=.3, size=24, gap=.38, width=6.0):
    group=VGroup(*[txt(line,size) for line in lines]).arrange(DOWN,buff=gap,aligned_edge=LEFT)
    if group.width>width:group.scale_to_fit_width(width)
    return group.move_to([x,y,0])


def vertical_frame(up=True):
    ground_y=-2.1
    top_y=1.85
    axis_x=-5.25
    body_x=-3.55
    ground=Line([-5.75,ground_y,0],[-1.4,ground_y,0],color=MUTED,stroke_width=2)
    if up:
        shaft=arrow([axis_x,ground_y,0],[0,4.6,0],MUTED,1.7)
        zero=eq('0',24,MUTED).move_to([axis_x-.25,ground_y-.18,0])
        ylabel=eq('y',28,MUTED).move_to([axis_x-.23,2.43,0])
    else:
        shaft=arrow([axis_x,top_y,0],[0,-4.35,0],MUTED,1.7)
        zero=eq('0',24,MUTED).move_to([axis_x-.25,top_y+.08,0])
        ylabel=eq('y',28,MUTED).move_to([axis_x-.27,-2.52,0])
    return VGroup(ground,shaft,zero,ylabel),np.array([body_x,ground_y,0.]),np.array([body_x,top_y,0.])


def flight_frame():
    origin=np.array([-5.85,-2.08,0.])
    frame=VGroup(
        arrow(origin,[5.25,0,0],MUTED,1.6),
        arrow(origin,[0,4.48,0],MUTED,1.6),
        eq('0',25,MUTED).move_to(origin+[-.24,-.21,0]),
        eq('x',27,MUTED).move_to(origin+[5.35,-.17,0]),
        eq('y',27,MUTED).move_to(origin+[-.2,4.53,0]))
    return frame,origin


def height_marker(bottom,top,x,color=GOLD):
    d=DoubleArrow([x,bottom[1],0],[x,top[1],0],buff=0,color=color,
        stroke_width=2,tip_length=.1)
    return VGroup(d,eq('h',28,color).move_to([x+.25,(bottom[1]+top[1])/2,0]))


class GravityModel(ChapterScene):
    chapter_id=16

    def chapter(self):
        self.beat(0,'Свободное падение: сопротивлением воздуха пренебрегаем')
        frame,bottom,top=vertical_frame()
        ball=Dot([-3.55,.65,0],radius=.14,color=CYAN)
        gravity=VGroup(arrow([-2.65,1.15,0],[0,-1.5,0],GOLD),eq(r'\vec g',31,GOLD).move_to([-2.2,.45,0]))
        definition=labels('Движение в поле','силы тяжести','Другие воздействия','пренебрежимо малы',size=25)
        self.show(frame,create=True,run_time=1.5)
        self.show(ball,definition,run_time=1.2)
        self.show(gravity,create=True,run_time=1.5)

        self.beat(1,'В конспекте для расчётов принято g = 10 м/с²')
        self.clear_stage()
        gtitle=txt('Ускорение свободного падения',29).move_to([0,1.75,0])
        gval=formulas(r'g=9{,}80665\;\text{м/с}^{2}',r'g_{\text{ЕГЭ}}=10\;\text{м/с}^{2}',x=0,y=.15,size=43,gap=.7,width=11)
        down=VGroup(arrow([-4.5,1,0],[0,-2.6,0],GOLD),eq(r'\vec g',37,GOLD).move_to([-3.8,-.3,0]))
        gval.shift(RIGHT*.8)
        self.show(gtitle,run_time=1)
        self.show(down,create=True,run_time=1.5)
        self.show(gval,run_time=1.3)

        self.beat(2,'Начинаем с общих законов равноускоренного движения')
        self.clear_stage()
        title=txt('Координата и проекция скорости',28).move_to([0,1.9,0])
        laws=formulas(r'y=y_0+v_{0y}t+\frac{a_y t^2}{2}',r'v_y=v_{0y}+a_y t',x=0,y=.3,size=43,gap=.7,width=11.5)
        self.show(title,run_time=1)
        for law in laws:self.show(law,run_time=1.3)

        self.beat(3,'Ось направлена вверх, поэтому проекция ускорения отрицательна')
        self.clear_stage()
        frame,bottom,top=vertical_frame()
        gv=VGroup(arrow([-3.5,1.35,0],[0,-1.5,0],GOLD),eq(r'\vec g',33,GOLD).move_to([-2.95,.65,0]))
        sign=eq(r'a_y=-g',40,GOLD).move_to([2.8,1.7,0])
        laws=formulas(r'y=y_0+v_{0y}t-\frac{gt^2}{2}',r'v_y=v_{0y}-gt',x=2.9,y=-.25,size=36,gap=.6)
        self.show(frame,create=True,run_time=1.5)
        self.show(gv,create=True,run_time=1.2)
        self.show(sign,laws,run_time=1.4)

        self.beat(4,'Для каждой задачи сначала выбираем ось и начальные условия')
        self.clear_stage()
        steps=VGroup(*[txt(line,27,color) for line,color in [
            ('1. Выбрать начало и направление оси',CYAN),
            ('2. Записать начальные координаты',INK),
            ('3. Найти проекции начальной скорости',INK),
            ('4. Подставить проекцию ускорения',GOLD)]]).arrange(DOWN,buff=.55,aligned_edge=LEFT).move_to([0,.25,0])
        for item in steps:self.show(item,run_time=.9)


class VerticalThrow(ChapterScene):
    chapter_id=17

    def chapter(self):
        self.beat(0,'Тело брошено от земли вертикально вверх')
        frame,A,B=vertical_frame()
        marks=VGroup(eq('A',27,CYAN).move_to(A+[.35,.03,0]),eq('B',27,CYAN).move_to(B+[.35,.07,0]))
        path=DashedLine(A,B,color=GRID,dash_length=.1)
        self.show(frame,path,create=True,run_time=1.5)
        self.show(marks,run_time=.8)
        p=ValueTracker(0)
        def pos():
            s=p.get_value();return A+(B-A)*(2*s-s*s)
        ball=always_redraw(lambda:Dot(pos(),radius=.14,color=CYAN))
        velocity=always_redraw(lambda:arrow(pos(),UP*(1.35*(1-p.get_value())),CYAN))
        gv=VGroup(arrow([-2,1,0],[0,-1.3,0],GOLD),eq(r'\vec g',29,GOLD).move_to([-1.6,.3,0]))
        initial=formulas(r'y_0=0,\quad v_{0y}=v_0',r'a_y=-g',x=2.7,y=.45,size=34)
        self.show(ball,run_time=.8)
        self.show(velocity,gv,create=True,run_time=1.2)
        self.show(initial,run_time=1.2)
        fixed=VGroup(frame,path,marks,gv)

        self.beat(1,'Подъём полностью заканчивается в точке B: vᵧ = 0')
        self.play(FadeOut(initial),run_time=.8)
        laws=formulas(r'y=v_0t-\frac{gt^2}{2}',r'v_y=v_0-gt',x=2.8,y=.55,size=37,gap=.55)
        self.show(laws,run_time=1.1)
        self.play(p.animate.set_value(1),run_time=7,rate_func=linear)
        freeze(ball,velocity)
        self.show(eq(r'v_y(B)=0',32,CYAN).move_to([2.8,-1.4,0]),run_time=.9)

        self.beat(2,'Время подъёма получаем из условия нулевой скорости в вершине')
        self.clear_stage(keep=(fixed,ball,velocity))
        time_laws=formulas(r'0=v_0-gt_B',r'gt_B=v_0',r't_B=\frac{v_0}{g}',x=2.8,y=.2,size=40,gap=.6)
        for line in time_laws:self.show(line,run_time=1.1)

        self.beat(3,'Подставляем найденное время в уравнение координаты')
        self.clear_stage(keep=(fixed,ball,velocity))
        hm=height_marker(A,B,-2.55)
        height_laws=formulas(r'h=v_0t_B-\frac{gt_B^2}{2}',r'h=\frac{v_0^2}{g}-\frac{v_0^2}{2g}',r'h=\frac{v_0^2}{2g}',x=2.7,y=.15,size=37,gap=.48)
        self.show(hm,create=True,run_time=1.3)
        for line in height_laws:self.show(line,run_time=1.15)

        self.beat(4,'Подъём завершён: время и максимальная высота найдены')
        self.clear_stage(keep=(fixed,ball,velocity,hm))
        result=formulas(r't_B=\frac{v_0}{g}',r'h=\frac{v_0^2}{2g}',r'v_y(B)=0',x=2.8,y=.15,size=42,gap=.55)
        self.show(result,run_time=1.4)
        done=txt('Конечная точка подъёма — B',23,CYAN).move_to([2.65,-2.2,0])
        self.show(done,run_time=1)


class FallingAxes(ChapterScene):
    chapter_id=18

    def chapter(self):
        self.beat(0,'Отпускаем тело с высоты h без начальной скорости')
        frame,D,C=vertical_frame()
        marks=VGroup(eq('C',27,CYAN).move_to(C+[.35,.06,0]),eq('D',27,CYAN).move_to(D+[.35,.1,0]))
        hm=height_marker(D,C,-2.45)
        gv=VGroup(arrow([-1.7,.85,0],[0,-1.2,0],GOLD),eq(r'\vec g',28,GOLD).move_to([-1.3,.25,0]))
        p=ValueTracker(0)
        def pos():return C+(D-C)*p.get_value()**2
        ball=always_redraw(lambda:Dot(pos(),radius=.14,color=CYAN))
        vel=always_redraw(lambda:arrow(pos(),DOWN*.5*p.get_value(),CYAN))
        self.show(frame,hm,create=True,run_time=1.5)
        self.show(marks,ball,run_time=1)
        self.show(gv,vel,create=True,run_time=1.2)
        initial=formulas(r'y_0=h,\quad v_{0y}=0',r'a_y=-g,\quad y_D=0',x=2.75,y=.45,size=34)
        self.show(initial,run_time=1.2)
        fixed=VGroup(frame,marks,hm,gv)

        self.beat(1,'Падение заканчивается на земле: координата точки D равна нулю')
        self.play(FadeOut(initial),run_time=.8)
        law=formulas(r'y=h-\frac{gt^2}{2}',r'0=h-\frac{gt_D^2}{2}',r't_D=\sqrt{\frac{2h}{g}}',x=2.9,y=.25,size=36,gap=.45)
        self.show(law[0],run_time=1)
        self.play(p.animate.set_value(1),run_time=6,rate_func=linear)
        freeze(ball,vel)
        for line in law[1:]:self.show(line,run_time=1)

        self.beat(2,'При оси вверх проекция скорости отрицательна, модуль положителен')
        self.clear_stage(keep=(fixed,ball,vel))
        speeds=formulas(r'v_y=-gt',r'v_{yD}=-g\sqrt{\frac{2h}{g}}=-\sqrt{2gh}',r'v_D=|v_{yD}|=\sqrt{2gh}',x=2.8,y=.25,size=35,gap=.58)
        for line in speeds:self.show(line,run_time=1.2)

        self.beat(3,'Повторяем то же падение с осью, направленной вниз')
        self.clear_stage(run_time=1)
        frame2,D2,C2=vertical_frame(up=False)
        marks2=VGroup(eq('C',27,CYAN).move_to(C2+[.35,.06,0]),eq('D',27,CYAN).move_to(D2+[.35,.1,0]))
        hm2=height_marker(D2,C2,-2.45)
        q=ValueTracker(0)
        def pos2():return C2+(D2-C2)*q.get_value()**2
        ball2=always_redraw(lambda:Dot(pos2(),radius=.14,color=CYAN))
        vel2=always_redraw(lambda:arrow(pos2(),DOWN*.5*q.get_value(),CYAN))
        down_laws=formulas(r'y_0=0,\quad a_y=g',r'y=\frac{gt^2}{2},\quad v_y=gt',r'y_D=h',x=2.8,y=.4,size=35,gap=.55)
        self.show(frame2,hm2,create=True,run_time=1.5)
        self.show(marks2,ball2,down_laws,run_time=1)
        self.show(vel2,create=True,run_time=.8)
        self.play(q.animate.set_value(1),run_time=6,rate_func=linear)
        freeze(ball2,vel2)
        fixed2=VGroup(frame2,marks2,hm2)

        self.beat(4,'Знак проекции зависит от оси; время и модуль скорости совпадают')
        self.clear_stage(keep=(fixed2,ball2,vel2))
        final=formulas(r't_D=\sqrt{\frac{2h}{g}}',r'|v_{yD}|=v_D=\sqrt{2gh}',r'\uparrow Oy:\ v_{yD}<0',r'\downarrow Oy:\ v_{yD}>0',x=2.85,y=.15,size=34,gap=.35)
        for line in final:self.show(line,run_time=1)


class HorizontalThrow(ChapterScene):
    chapter_id=19

    def chapter(self):
        self.beat(0,'Начальная скорость горизонтальна, вертикальная составляющая равна нулю')
        frame,O=flight_frame()
        A=O+UP*3.55
        B=O+RIGHT*4.7
        hm=height_marker(O,A,-5.25)
        marks=VGroup(eq('B',27,CYAN).move_to(B+[.2,.17,0]))
        p=ValueTracker(0)
        def point(s):return A+RIGHT*4.7*s+DOWN*3.55*s*s
        def pos():return point(p.get_value())
        ball=always_redraw(lambda:Dot(pos(),radius=.13,color=CYAN))
        vel=always_redraw(lambda:arrow(pos(),[.3995,-.6035*p.get_value(),0],CYAN))
        gv=VGroup(arrow([-1,1.75,0],[0,-1.25,0],GOLD),eq(r'\vec g',27,GOLD).move_to([-.58,1.15,0]))
        self.show(frame,hm,create=True,run_time=1.5)
        self.show(ball,marks,run_time=1)
        self.show(vel,gv,create=True,run_time=1.3)
        initial=formulas(r'x_0=0,\ y_0=h',r'v_{0x}=v_0,\ v_{0y}=0',r'a_x=0,\ a_y=-g',x=2.8,y=.55,size=32,gap=.45)
        self.show(initial,run_time=1.3)
        fixed=VGroup(frame,hm,marks,gv)

        self.beat(1,'Горизонтальное и вертикальное движения вместе дают полный полёт до B')
        self.play(FadeOut(initial),run_time=.8)
        laws=formulas(r'x=v_0t,\qquad v_x=v_0',r'y=h-\frac{gt^2}{2}',r'v_y=-gt',x=2.85,y=.45,size=33,gap=.5)
        self.show(laws,run_time=1.1)
        trace=VMobject(color=CYAN,stroke_width=2.7)
        trace.add_updater(lambda m:m.set_points_as_corners([point(s) for s in np.linspace(0,max(p.get_value(),1e-6),100)]))
        self.add(trace)
        self.play(p.animate.set_value(1),run_time=8,rate_func=linear)
        freeze(ball,vel,trace)
        landed=eq(r'y_B=0',31,CYAN).move_to([2.8,-1.6,0])
        self.show(landed,run_time=.9)

        self.beat(2,'Из вертикального движения находим время, затем горизонтальную дальность')
        self.clear_stage(keep=(fixed,ball,vel,trace))
        trange=formulas(r'0=h-\frac{gt_B^2}{2}',r't_B=\sqrt{\frac{2h}{g}}',r'l=v_0t_B=v_0\sqrt{\frac{2h}{g}}',x=2.85,y=.4,size=36,gap=.55)
        for line in trange:self.show(line,run_time=1.2)
        measure=VGroup(DoubleArrow(O+DOWN*.38,B+DOWN*.38,buff=0,color=GOLD,stroke_width=2,tip_length=.09),eq('l',27,GOLD).move_to((O+B)/2+DOWN*.66))
        self.show(measure,create=True,run_time=1.4)

        self.beat(3,'Перед ударом складываем две перпендикулярные составляющие скорости')
        self.clear_stage(run_time=1)
        P=np.array([-5.1,1.25,0.]);Q=P+RIGHT*3.1;R=Q+DOWN*2.7
        vx=arrow(P,Q-P,CYAN)
        vy=arrow(Q,R-Q,GOLD)
        resultant=arrow(P,R-P,LAVENDER)
        triangle=VGroup(vx,vy,resultant)
        vlabels=VGroup(eq(r'v_{Bx}=v_0',29,CYAN).move_to((P+Q)/2+UP*.38),eq(r'|v_{By}|',28,GOLD).move_to((Q+R)/2+RIGHT*.55),eq(r'v_B',29,LAVENDER).move_to((P+R)/2+[-.35,-.15,0]))
        self.show(vx,create=True,run_time=1.4)
        self.show(vy,create=True,run_time=1.4)
        self.show(resultant,create=True,run_time=1.4)
        self.show(vlabels,run_time=1)
        vcalc=formulas(r'v_{By}=-gt_B=-\sqrt{2gh}',r'v_B^2=v_0^2+v_{By}^2',r'v_B=\sqrt{v_0^2+2gh}',x=3.0,y=.35,size=34,gap=.6)
        for line in vcalc:self.show(line,run_time=1.2)

        self.beat(4,'Угол падения получаем из отношения модулей катетов')
        self.clear_stage(keep=(triangle,vlabels))
        angle=-np.arctan(2.7/3.1)
        arc=Arc(radius=.65,start_angle=angle,angle=-angle,arc_center=P,color=ROSE,stroke_width=2)
        alpha=eq(r'\alpha',31,ROSE).move_to(P+[.9,-.35,0])
        self.show(arc,create=True,run_time=1.5)
        self.show(alpha,run_time=.9)
        acalc=formulas(r'\tan\alpha=\frac{|v_{By}|}{v_{Bx}}=\frac{\sqrt{2gh}}{v_0}',r'\alpha=\arctan\!\left(\frac{\sqrt{2gh}}{v_0}\right)',x=3.0,y=.8,size=32,gap=.6)
        for line in acalc:self.show(line,run_time=1.4)
        results=formulas(r't_B=\sqrt{2h/g},\quad l=v_0t_B',r'v_B=\sqrt{v_0^2+2gh}',x=2.9,y=-1.7,size=28,gap=.3)
        self.show(results,run_time=1.1)


class AngledThrow(ChapterScene):
    chapter_id=20

    def chapter(self):
        self.beat(0,'Разлагаем начальную скорость на горизонтальную и вертикальную проекции')
        frame,O=flight_frame()
        theta=.77
        v=np.array([.752,2.176,0.])
        V=O+v;X=O+RIGHT*v[0]
        v0=arrow(O,v,CYAN)
        vx=arrow(O,X-O,LAVENDER)
        vy=arrow(X,V-X,GOLD)
        arc=Arc(radius=.58,start_angle=0,angle=np.arctan2(v[1],v[0]),arc_center=O,color=ROSE,stroke_width=2)
        alpha=eq(r'\alpha',28,ROSE).move_to(O+[.85,.34,0])
        component_labels=VGroup(eq(r'v_0',28,CYAN).move_to(V+[-.23,.25,0]),eq(r'v_{0x}',25,LAVENDER).move_to(O+[v[0]/2,-.34,0]),eq(r'v_{0y}',25,GOLD).move_to(X+[.43,.9,0]))
        components=VGroup(v0,vx,vy,arc,alpha,component_labels)
        self.show(frame,create=True,run_time=1.5)
        self.show(v0,create=True,run_time=1.3)
        self.show(vx,vy,create=True,run_time=1.5)
        self.show(arc,create=True,run_time=1.2)
        self.show(alpha,component_labels,run_time=1)
        comp_eq=formulas(r'v_{0x}=v_0\cos\alpha',r'v_{0y}=v_0\sin\alpha',r'a_x=0,\qquad a_y=-g',x=2.8,y=.6,size=36,gap=.6)
        self.show(comp_eq,run_time=1.3)

        self.beat(1,'В вершине обнуляется только vᵧ; полёт заканчивается на исходном уровне')
        self.clear_stage(keep=(frame,))
        B=O+np.array([2.35,3.4,0.]);C=O+RIGHT*4.7
        marks=VGroup(eq('B',27,CYAN).move_to(B+[0,.3,0]),eq('C',27,CYAN).move_to(C+[.2,.15,0]))
        p=ValueTracker(0)
        def point(s):return O+np.array([4.7*s,13.6*s*(1-s),0.])
        def pos():return point(p.get_value())
        ball=always_redraw(lambda:Dot(pos(),radius=.13,color=CYAN))
        vel=always_redraw(lambda:arrow(pos(),[.235,.68*(1-2*p.get_value()),0],CYAN))
        self.show(marks,ball,run_time=.8)
        self.show(vel,create=True,run_time=.8)
        laws=formulas(r'x=v_0\cos\alpha\cdot t',r'v_x=v_0\cos\alpha',r'y=v_0\sin\alpha\cdot t-\frac{gt^2}{2}',r'v_y=v_0\sin\alpha-gt',x=2.85,y=.35,size=30,gap=.4)
        self.show(laws,run_time=1.2)
        trace=VMobject(color=CYAN,stroke_width=2.7)
        trace.add_updater(lambda m:m.set_points_as_corners([point(s) for s in np.linspace(0,max(p.get_value(),1e-6),140)]))
        self.add(trace)
        self.play(p.animate.set_value(.5),run_time=4.1,rate_func=linear)
        apex=eq(r'v_y(B)=0,\quad v_x\ne0',28,GOLD).move_to([2.9,-2.25,0])
        self.show(apex,run_time=.8)
        self.wait(1.2)
        self.play(p.animate.set_value(1),run_time=4.1,rate_func=linear)
        freeze(ball,vel,trace)
        fixed=VGroup(frame,marks,trace)

        self.beat(2,'Время достижения вершины подставляем в формулу максимальной высоты')
        self.clear_stage(keep=(fixed,ball,vel))
        hm=height_marker(O,B,-2.95)
        hcalc=formulas(r'0=v_0\sin\alpha-gt_B',r't_B=\frac{v_0\sin\alpha}{g}',r'h=v_0\sin\alpha\cdot t_B-\frac{gt_B^2}{2}',r'h=\frac{v_0^2\sin^2\alpha}{2g}',x=2.85,y=.25,size=32,gap=.48)
        self.show(hm,create=True,run_time=1.5)
        for line in hcalc:self.show(line,run_time=1.15)

        self.beat(3,'Берём ненулевой корень: возвращение на землю происходит после броска')
        self.clear_stage(keep=(fixed,ball,vel,hm))
        tcalc=formulas(r'0=v_0\sin\alpha\cdot t_C-\frac{gt_C^2}{2}',r't_C\!\left(v_0\sin\alpha-\frac{gt_C}{2}\right)=0',r't_C=0\quad\text{--- бросок}',r't_C=\frac{2v_0\sin\alpha}{g}=2t_B',x=2.9,y=.35,size=31,gap=.42)
        for line in tcalc:self.show(line,run_time=1.15)
        same=txt('Старт и приземление на одном уровне',21,GOLD).move_to([2.85,-2.25,0])
        if same.width>6.1:same.scale_to_fit_width(6.1)
        self.show(same,run_time=1)

        self.beat(4,'Подставляем время полёта и используем формулу синуса двойного угла')
        self.clear_stage(keep=(fixed,ball,vel,hm))
        range_calc=formulas(r'l=v_0\cos\alpha\cdot t_C',r'l=\frac{v_0^2\,2\sin\alpha\cos\alpha}{g}',r'2\sin\alpha\cos\alpha=\sin 2\alpha',r'l=\frac{v_0^2\sin 2\alpha}{g}',x=2.95,y=.35,size=33,gap=.45)
        for line in range_calc:self.show(line,run_time=1.3)
        lm=VGroup(DoubleArrow(O+DOWN*.38,C+DOWN*.38,buff=0,color=GOLD,stroke_width=2,tip_length=.1),eq('l',28,GOLD).move_to((O+C)/2+DOWN*.68))
        self.show(lm,create=True,run_time=1.5)
        end=txt('Полёт завершён в точке C',22,CYAN).move_to([2.85,-2.3,0])
        self.show(end,run_time=1)
