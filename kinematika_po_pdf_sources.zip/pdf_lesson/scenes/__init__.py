"""Scenes based on the user's four PDF sources."""
