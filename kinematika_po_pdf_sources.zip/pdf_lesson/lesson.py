"""All source-based scenes; see plan.json for page references."""
from scenes.foundations_pdf import ModelsFrames as _ModelsFrames
from scenes.foundations_pdf import PathUniform as _PathUniform
from scenes.foundations_pdf import AcceleratedLaws as _AcceleratedLaws
from scenes.foundations_pdf import VectorProjections as _VectorProjections
from scenes.foundations_pdf import VectorOperations as _VectorOperations
from scenes.graphs_pdf import UniformGraphs as _UniformGraphs
from scenes.graphs_pdf import GraphSlopes as _GraphSlopes
from scenes.graphs_pdf import AccelerationGraphs as _AccelerationGraphs
from scenes.graphs_pdf import AreaParabolas as _AreaParabolas
from scenes.graphs_pdf import TangentsAverage as _TangentsAverage
from scenes.rotation_pdf import RelativeClosing as _RelativeClosing
from scenes.rotation_pdf import TurnPeriod as _TurnPeriod
from scenes.rotation_pdf import LinearRotation as _LinearRotation
from scenes.rotation_pdf import CircularAcceleration as _CircularAcceleration
from scenes.rotation_pdf import RotationTransmission as _RotationTransmission
from scenes.ballistics_pdf import GravityModel as _GravityModel
from scenes.ballistics_pdf import VerticalThrow as _VerticalThrow
from scenes.ballistics_pdf import FallingAxes as _FallingAxes
from scenes.ballistics_pdf import HorizontalThrow as _HorizontalThrow
from scenes.ballistics_pdf import AngledThrow as _AngledThrow

class ModelsFrames(_ModelsFrames): pass
class PathUniform(_PathUniform): pass
class AcceleratedLaws(_AcceleratedLaws): pass
class VectorProjections(_VectorProjections): pass
class VectorOperations(_VectorOperations): pass
class UniformGraphs(_UniformGraphs): pass
class GraphSlopes(_GraphSlopes): pass
class AccelerationGraphs(_AccelerationGraphs): pass
class AreaParabolas(_AreaParabolas): pass
class TangentsAverage(_TangentsAverage): pass
class RelativeClosing(_RelativeClosing): pass
class TurnPeriod(_TurnPeriod): pass
class LinearRotation(_LinearRotation): pass
class CircularAcceleration(_CircularAcceleration): pass
class RotationTransmission(_RotationTransmission): pass
class GravityModel(_GravityModel): pass
class VerticalThrow(_VerticalThrow): pass
class FallingAxes(_FallingAxes): pass
class HorizontalThrow(_HorizontalThrow): pass
class AngledThrow(_AngledThrow): pass
