from math import cos, sin, pi, sqrt

import numpy as np
from manim import Circle, Dot, Line, VGroup

from visual_style import CYAN, GOLD, INK, LAVENDER, MUTED, ROSE, txt


def regular(angles, radius=1.0, center=(0,0)):
    return [np.array(center)+radius*np.array((cos(a),sin(a))) for a in angles]


def foot(p,a,b):
    d=b-a
    return a+d*np.dot(p-a,d)/np.dot(d,d)


def line_cross(a,b,c,d):
    m=np.column_stack((b-a,c-d))
    return a+np.linalg.solve(m,c-a)[0]*(b-a)


def circumcenter(a,b,c):
    return np.linalg.solve(2*np.stack((b-a,c-a)),(b@b-a@a,c@c-a@a))


class Diagram:
    def __init__(self, points):
        self.points = {name:np.array(value,dtype=float) for name,value in points.items()}
        self.edges = []
        self.circles = []
        self.labels = set()
        self.deferred = set()

    def lines(self, pairs, color=MUTED, later=False):
        names=pairs.split()
        for a,b in zip(names[::2],names[1::2],strict=True):
            self.edges.append((a,b,color,later))
        return self

    def rim(self, center, radius, color=MUTED, later=False):
        self.circles.append((np.array(center),radius,color,later))
        return self

    def mark(self, primary, extra=""):
        self.labels.update(primary.split())
        self.deferred.update(extra.split())
        return self

    def mobjects(self):
        if not self.points:
            return VGroup(),VGroup()
        positions = list(self.points.values())
        for c,r,_,_ in self.circles:
            positions.extend([c-r,c+r])
        low = np.min(positions,axis=0)
        high = np.max(positions,axis=0)
        scale = min(4.65/max(.05,high[0]-low[0]),3.43/max(.05,high[1]-low[1]))
        mid = (low+high)/2
        def p(x):
            x=(x-mid)*scale
            return np.array([x[0]-3.69,x[1]-.10,0])
        stages=(VGroup(),VGroup())
        for a,b,color,extra in self.edges:
            if np.linalg.norm(self.points[a]-self.points[b])>.005:
                stages[extra].add(Line(p(self.points[a]),p(self.points[b]),color=color,stroke_width=3.0))
        for center,r,color,extra in self.circles:
            stages[extra].add(Circle(radius=r*scale,color=color,stroke_width=2.2).move_to(p(center)))
        for name in sorted(self.labels | self.deferred):
            position=p(self.points[name])
            vector=position-p(mid)
            if name in {"O","H","I","G","E","K","P","M","N"} and np.linalg.norm(vector)<.42:
                vector=np.array([.0,.5,0])
            shift=.19*(vector/max(.01,np.linalg.norm(vector)))
            target=stages[name in self.deferred]
            target.add(Dot(position,radius=.043,color=INK),
                       txt(name,19,INK).move_to(position+shift))
        return stages


def triangle(index):
    side_a=np.array([-2.0,-1.0])
    side_b=np.array([.17,1.76])
    side_c=np.array([1.83,-1.0])
    if index in (12,92):
        side_b=np.array([0.,2.0])
        side_c=np.array([2.0,-1.0])
        if index==92:
            side_b=np.array([0.,-1+2*sqrt(3)])
    if index in range(13,18):
        side_b=np.array([-2.,1.3])
        side_c=np.array([1.98,-1.])
    a,b,c=side_a,side_b,side_c
    if index in (14,15,16,17):
        a,b,c=b,c,a
    if index==5:
        a,b,c=a,c,b
    d,e,f=foot(a,b,c),foot(b,c,a),foot(c,a,b)
    t=np.array([np.linalg.norm(b-c),np.linalg.norm(a-c),np.linalg.norm(a-b)])
    o=circumcenter(a,b,c)
    h=a+b+c-2*o
    g=(a+b+c)/3
    i=(a*t[0]+b*t[1]+c*t[2])/sum(t)
    ma,mb,mc=(b+c)/2,(a+c)/2,(a+b)/2
    obj=Diagram({"A":a,"B":b,"C":c})
    obj.lines("A B B C C A",CYAN).mark("A B C")
    if index==5:
        obj.points.update({"U":c+[-2.3,0],"V":c+[2.3,0]})
        obj.lines("U V",GOLD,True)
    elif index in (12,15,16,17,36,67,68,69,70,75,93):
        if index==12:
            obj.points["M"]=mb
            obj.lines("B M",GOLD,True).mark("", "M")
        elif index in (15,16):
            obj.points.update({"H":f,"M":mc,"T": (t[0]*a+t[1]*b)/(t[0]+t[1])})
            obj.lines("C H",GOLD,True).mark("","H")
            if index==16:
                obj.lines("C M",LAVENDER,True).mark("","M")
        elif index==17:
            obj.points["I"]=i
            obj.rim(i,np.linalg.norm(i-foot(i,a,b)),GOLD,True).mark("","I")
        else:
            obj.points.update({"D":d,"E":e,"F":f,"H":h})
            obj.lines("A D B E C F",GOLD,True).mark("","D E F H")
            if index==68:
                obj.lines("D E E F F D",ROSE,True)
            if index==67:
                obj.rim((a+h)/2,np.linalg.norm(a-h)/2,LAVENDER,True)
    elif index in (10,14,33,76):
        obj.points["O"]=o
        obj.rim(o,np.linalg.norm(a-o),LAVENDER,True).lines("O A O C",GOLD,True).mark("","O")
    elif index in (34,37,39,40,41,42,80):
        ray="B D A I C I" if index in (39,40) else "A D B I C I"
        end=line_cross(b,i,a,c) if index in (39,40) else line_cross(a,i,b,c)
        obj.points.update({"I":i,"D":end})
        obj.rim(i,np.linalg.norm(i-foot(i,a,b)),LAVENDER,True).lines(ray,GOLD,True).mark("","I D")
    elif index in (25,35,38,43,86):
        obj.points.update({"D":ma,"E":mb,"F":mc,"G":g})
        if index==43:
            obj.lines("D E E F F D",GOLD,True).mark("","D E F")
        else:
            obj.lines("A D B E C F",GOLD,True).mark("","D E F G")
    return obj


def trapezoid(index):
    a,b,c,d=np.array([[-2.15,-1.],[-.9,1.],[.9,1.],[2.15,-1.]])
    obj=Diagram({"A":a,"B":b,"C":c,"D":d}).lines("A B B C C D D A",CYAN).mark("A B C D")
    if index in (47,48,49,51):
        e=line_cross(a,c,b,d)
        obj.points.update({"E":e,"M":(a+d)/2,"N":(b+c)/2})
        obj.lines("A C B D",LAVENDER,True).mark("", "E")
        if index in (48,51):
            obj.lines("M N",GOLD,True).mark("","M N")
    if index==50:
        a,d=a*.96,d*.96
        a[0],d[0]=-2.,2.
        b[0],c[0]=-.5,.5
        a[1],d[1]=-1.,-1.
        b[1],c[1]=1.,1.
        obj.points.update({"A":a,"B":b,"C":c,"D":d,"O":np.array([0.,0.])})
        obj.rim((0.,0.),1.,GOLD,True).mark("","O")
    if index in (44,54,94):
        p=(a+b)/2
        q=(c+d)/2
        obj.points.update({"M":p,"N":q,"K":(a+c)/2,"L":(b+d)/2})
        obj.lines("M N",GOLD,True).mark("", "M N")
        if index in (44,94):
            obj.lines("A C B D",LAVENDER,True).mark("", "K L")
    if index==95:
        o=circumcenter(a,b,c)
        obj.points["O"]=o
        obj.rim(o,np.linalg.norm(a-o),GOLD,True).mark("","O")
    return obj


def cyclic(index):
    points=regular([.98*pi,.14*pi,1.3*pi,1.78*pi],1.61)
    a,b,c,d=points
    obj=Diagram(dict(zip("ABCD",points))|{"O":(0.,0.)}).rim((0.,0.),1.61,LAVENDER)
    if index==60:
        obj.lines("A C C B O A O B",CYAN,False).mark("A B C O")
    elif index==61:
        tangent=np.array([-a[1],a[0]])/np.linalg.norm(a)
        obj.points.update({"M":a+.95*tangent,"P":a-.95*tangent})
        obj.lines("A C C B A B O A",CYAN).lines("M P",GOLD,True).mark("A B C O")
    elif index==63:
        aa=np.array([-1.61,0.])
        bb=np.array([1.61,0.])
        obj.points.update({"A":aa,"B":bb,"C":np.array([0.,1.61]),"P":np.array([.55,2.25])})
        obj.lines("A B A C C B",CYAN).lines("A P P B",GOLD,True).mark("A B C","P")
    elif index==64:
        obj.points.update(dict(zip("ABCD",regular([2.55,.59,3.76,5.67],1.61))))
        obj.points["T"]=np.array([0.,1.61])
        obj.points["N"]=np.array([0.,-1.61])
        obj.lines("A B C D",CYAN).lines("T N",GOLD,True).mark("A B C D","O")
    elif index==78:
        a,b,c,d=regular([3*pi/2-.95, pi/2+.42, 3*pi/2+.95, 3*pi/2],1.61)
        obj.points.update(dict(zip("ABCD",(a,b,c,d))))
        obj.lines("A B B C C D D A",CYAN).lines("B D",GOLD,True).mark("A B C D")
    elif index==85:
        a,b,c,d=np.array([[1.7,0],[0,1.36],[-1.2,0],[0,-1.5]])
        o=circumcenter(a,b,c)
        obj=Diagram(dict(zip("ABCD",(a,b,c,d)))|{"O":o,"E":(0,0),"M":(a+b)/2})
        return obj.rim(o,np.linalg.norm(a-o),LAVENDER).lines("A B B C C D D A",CYAN).lines("A C B D E M",GOLD,True).mark("A B C D","E M O")
    else:
        a,b,c,d=regular([2.65,1.25,.15,4.37],1.61)
        obj.points.update({"A":a,"B":b,"C":c,"D":d,"E":line_cross(a,c,b,d)})
        obj.lines("A B B C C D D A",CYAN).lines("A C B D",GOLD,True).mark("A B C D","E")
    return obj


def quadrilateral(index):
    if index in (83,88,96):
        a=np.array([0.,0.])
        b=np.array([1.,0.])
        c=np.array([1.,1.])
        d=np.array([0.,1.])
    elif index==58:
        a,b,c,d=np.array([[-.15,-1.24],[-1.43,0.],[-.15,1.24],[1.88,0.]])
    else:
        a,b,c,d=np.array([[-1.9,-.96],[-.99,1.13],[2.15,1.13],[1.24,-.96]])
    if index in (45,46,84):
        c=c+[-.46,.2]
    obj=Diagram({"A":a,"B":b,"C":c,"D":d}).lines("A B B C C D D A",CYAN).mark("A B C D")
    if index in (45,46,55,56,58,84):
        ab,bc,cd,da=(a+b)/2,(b+c)/2,(c+d)/2,(d+a)/2
        obj.points.update({"M":ab,"N":bc,"P":cd,"Q":da})
        obj.lines("A C B D",LAVENDER,True)
        if index in (45,46):
            obj.lines("M N N P P Q Q M",GOLD,True).mark("","M N P Q")
    if index in (83,88):
        m,n=np.array([1.,1/3]),np.array([.5,1.])
        if index==83:
            n=np.array([2/3,1.])
        obj.points.update({"M":m,"N":n})
        obj.mark("","M N").lines("A N",GOLD,True)
        if index==83:
            obj.lines("D M",GOLD,True)
        else:
            obj.lines("A M M N B D",GOLD,True)
            obj.rim((m+n)/2,np.linalg.norm(m-n)/2,LAVENDER,True)
    return obj


def example():
    a,b,c,o=np.array([[-3.,0.],[0.,4.],[3.,0.],[0.,3.]])
    h=foot(c,a,b)
    m=(a+c)/2
    return (Diagram({"A":a,"B":b,"C":c,"O":o,"H":h,"M":m})
        .lines("A B B C C A",CYAN)
        .lines("C H B M A O",GOLD,True)
        .rim(o,3/5,ROSE,True)
        .mark("A B C","H O M"))


def other(index):
    if index in (1,2,3):
        if index==1:
            slope=np.arctan2(1.7,1.2)/2
            u,v=regular([slope+pi/2,slope],1.48)
            obj=Diagram({"A":(-2.,0),"B":(2.,0),"O":(0,0),"C":(1.2,1.7),"D":(-1.2,-1.7),
                         "U":u,"V":v})
            return obj.lines("A B C D",CYAN).lines("O U O V",GOLD,True).mark("O")
        obj=Diagram({"A":(-2,-.92),"B":(2,-.92),"C":(-2,.92),"D":(2,.92),
                     "P":(-.8,-.92),"Q":(.48,.92),"X":(-1.07,0.)})
        obj.lines("A B C D P Q",CYAN)
        if index==3:
            l1=obj.points["P"]
            l2=obj.points["Q"]
            toward=(l2-l1)/np.linalg.norm(l2-l1)
            v1=toward+[-1,0]
            v2=-toward+[-1,0]
            obj.points["X"]=line_cross(l1,l1+v1,l2,l2+v2)
            obj.lines("P X Q X",GOLD,True)
        return obj
    if index in (4,97):
        a,b,c,d,e,f=regular([pi,2*pi/3,pi/3,0,-pi/3,-2*pi/3],1.65)
        obj=Diagram(dict(zip("ABCDEF",[a,b,c,d,e,f]))|{"O":(0.,0.)})
        obj.lines("A B B C C D D E E F F A",CYAN).mark("A B C D E F")
        return obj.lines("A C A D A E" if index==4 else "O A O B O C O D O E O F",GOLD,True)
    if index==28:
        obj=Diagram({"O":(-2,0),"A":(-.5,-.5),"B":(-.5,.65),"A'":(1.2,-1.06),"B'":(1.2,1.38)})
        return obj.lines("O A' O B'",CYAN).lines("A B A' B'",GOLD,True).mark("O A B A' B'")
    if index in (31,32):
        a,b,c=np.array([[-1.7,-1.1],[.43,1.3],[1.55,-1.1]])
        d=a+.42*(b-a)
        if index==31:
            e=b+.68*(c-b)
            f=line_cross(d,e,c,a)
            marks="D E F"
        else:
            p=.43*a+.33*b+.24*c
            e=line_cross(a,p,b,c)
            f=line_cross(b,p,c,a)
            marks="D E F"
            d=line_cross(c,p,a,b)
        obj=Diagram(dict(zip("ABCDEF",(a,b,c,d,e,f)))).lines("A B B C C A",CYAN).mark("A B C",marks)
        if index==31:
            obj.lines("C F",MUTED,True).lines("D F",GOLD,True)
        else:
            obj.points["T"]=p
            obj.lines("A E B F C D",GOLD,True).mark("","T")
        return obj
    if index in (71,72,73,81):
        if index==71:
            return (Diagram({"O₁":(-.7,0),"O₂":(.8,0),"A":(.05,.95),"B":(.05,-.95)})
              .rim((-.7,0),1.21,CYAN).rim((.8,0),1.21,LAVENDER)
              .lines("O₁ O₂ A B",GOLD,True).mark("O₁ O₂","A B"))
        if index in (72,73):
            a,b=np.array([-.94,0.]),np.array([.94,0.])
            r,s=1.17,.71
            un=np.array([(r-s)/(b[0]-a[0]),sqrt(1-((r-s)/(b[0]-a[0]))**2)])
            k=np.array([a[0]+r,0.])
            tb=a+r*un
            tc=b+s*un
            p=line_cross(tb,tc,k,k+[0,1])
            obj=Diagram({"O₁":a,"O₂":b,"K":k,"A":tb,"B":tc,"P":p})
            return obj.rim(a,r,CYAN).rim(b,s,LAVENDER).lines("A B P K",GOLD,True).mark("O₁ O₂","A B P K")
        b,a,c,d=regular([pi/2,3.82,5.60,3*pi/2],1.55)
        m=np.array([0.,a[1]])
        if abs(a[1]-c[1])>.05:
            c=np.array([-a[0],a[1]])
        r=(b[1]-m[1])/2
        return (Diagram({"A":a,"B":b,"C":c,"D":d,"M":m}).rim((0,0),1.55,CYAN)
                .rim((b+m)/2,r,LAVENDER).lines("A C B D",GOLD,True).mark("A B C","M D"))
    if index in (89,90,91):
        a,b,c,p=regular([2.55,.97,5.52,3.81],1.64)
        o=np.zeros(2)
        h=a+b+c
        obj=Diagram({"A":a,"B":b,"C":c,"O":o}).rim(o,1.64,LAVENDER).lines("A B B C C A",CYAN).mark("A B C")
        if index==90:
            x,y,z=foot(p,b,c),foot(p,c,a),foot(p,a,b)
            obj.points.update({"P":p,"X":x,"Y":y,"Z":z})
            obj.lines("P X P Y P Z",ROSE,True).lines("X Y Y Z",GOLD,True).mark("","P X Y Z")
        if index==91:
            lab={"D":foot(a,b,c),"E":foot(b,c,a),"F":foot(c,a,b),"M":(a+b)/2}
            obj.points.update(lab|{"H":h,"G":h/3,"K":h/2})
            obj.lines("A D B E C F O H",ROSE,True).rim(h/2,1.64/2,GOLD,True).mark("", "O H G K M")
        if index==89:
            i=(a*np.linalg.norm(b-c)+b*np.linalg.norm(c-a)+c*np.linalg.norm(a-b))/sum(
                [np.linalg.norm(b-c),np.linalg.norm(c-a),np.linalg.norm(a-b)])
            obj.points["I"]=i
            obj.rim(i,np.linalg.norm(i-foot(i,a,c)),GOLD,True).lines("O I B I",ROSE,True).mark("","I O")
        return obj
    return Diagram({})


def make_diagram(index):
    if index==99:
        obj=example()
    elif index in {5,6,8,9,10,11,12,13,14,15,16,17,20,21,23,25,30,33,34,35,36,37,38,39,40,41,42,43,67,68,69,70,75,76,80,86,92,93}:
        obj=triangle(index)
    elif index in {19,44,47,48,49,50,51,52,53,54,94,95}:
        obj=trapezoid(index)
    elif index in {60,61,62,63,64,65,66,78,85,87}:
        obj=cyclic(index)
    elif index in {18,24,26,27,45,46,55,56,57,58,59,83,84,88,96}:
        obj=quadrilateral(index)
    else:
        obj=other(index)
    return obj.mobjects()
