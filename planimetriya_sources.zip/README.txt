Установите Python, системные зависимости Manim, шрифт DejaVu Sans и FFmpeg. Из распакованной папки последовательно выполните команды.

python -m pip install manim==0.20.1 matplotlib
PLANIMETRY_RANGE=1-99 python -m manim --disable_caching --media_dir media/01_99 -o part.mp4 planimetry_lesson.py PlanimetryLesson
python assemble.py 1-99
