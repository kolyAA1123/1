from pathlib import Path
import json
import math
import os
from textwrap import wrap

import numpy as np
from manim import Create, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from diagrams import make_diagram
from fast_video import enable
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, MUTED, txt

ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/"planimetry_data.json").read_text())
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=3000
enable()


def fit(mob, width, height=None):
    if mob.width>width:
        mob.scale_to_fit_width(width)
    if height is not None and mob.height>height:
        mob.scale_to_fit_height(height)
    return mob


def proof_card(text, has_diagram):
    x=3.25 if has_diagram else 0
    width=6.34 if has_diagram else 10.9
    cut=45 if has_diagram else 77
    lines=wrap(text,width=cut,break_on_hyphens=False,break_long_words=False)
    color=GOLD if text.startswith(("Пример","Например")) else INK
    proof=txt("\n".join(lines),29 if has_diagram else 33,color,line_spacing=1.15)
    fit(proof,width,4.15)
    return proof.move_to([x,-.22,0])


class PlanimetryLesson(Scene):
    def construct(self):
        selected=os.environ.get("PLANIMETRY_RANGE")
        if selected:
            first,last=map(int,selected.split("-"))
        else:
            first,last=1,len(DATA)
        entries=[]
        holds={}

        def hold(seconds):
            self.wait(1/60)
            clip=self.renderer.num_plays-1
            holds[clip]=round(seconds*60)
            return clip
        if first == 1:
            title = txt("Планиметрия", 52, INK)
            sub = txt("Теория, доказательства и задачи", 28, MUTED).next_to(title, [0,-1,0], buff=.35)
            self.play(FadeIn(title),FadeIn(sub),run_time=.80,rate_func=smootherstep)
            hold(2.5)
            self.play(FadeOut(title),FadeOut(sub),run_time=.65,rate_func=smootherstep)
        for index,section in enumerate(DATA[first-1:last],first):
            group=txt(section["group"],25,CYAN).move_to([-6.56,3.48,0],aligned_edge=np.array([-1,0,0]))
            number=txt("Планиметрия",17,MUTED).move_to([6.51,3.48,0],aligned_edge=np.array([1,0,0]))
            rule=Line([-6.55,2.93,0],[6.55,2.93,0],color=GRID,stroke_width=1.35)
            heading=fit(txt(section["heading"],29),12.8).move_to([0,2.43,0])
            base,marks=make_diagram(index)
            active=[group,number,rule,heading]
            animation=[FadeIn(m) for m in active]
            if len(base):
                animation.append(Create(base))
                active.append(base)
            self.play(*animation,run_time=.56, rate_func=smootherstep)
            entries.append(dict(heading=section["heading"],group=section["group"],points=[]))
            previous=None
            for beat_index,beat in enumerate(section["beats"]):
                proof=proof_card(beat,bool(len(base)))
                showing=[FadeIn(proof,shift=np.array([0,.06,0]))]
                if previous is not None:
                    showing.append(FadeOut(previous,shift=np.array([0,-.05,0])))
                if beat_index==min(1,len(section["beats"])-1) and len(marks):
                    showing.append(Create(marks))
                    active.append(marks)
                self.play(*showing,run_time=.48,rate_func=smootherstep)
                clip=hold(max(4,math.ceil(len(beat.split())/2.26)+1))
                entries[-1]["points"].append(dict(clip=clip,text=beat))
                previous=proof
            self.play(*[FadeOut(m) for m in active+[previous]],run_time=.52, rate_func=smootherstep)
        if last==len(DATA):
            ending=txt("Планиметрия",38,INK)
            self.play(FadeIn(ending),run_time=.72,rate_func=smootherstep)
            hold(1.25)
            self.play(FadeOut(ending),run_time=.65,rate_func=smootherstep)
        record=dict(holds=holds,data=entries,clips=self.renderer.num_plays)
        Path(f"timing_{first:02d}_{last:02d}.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
