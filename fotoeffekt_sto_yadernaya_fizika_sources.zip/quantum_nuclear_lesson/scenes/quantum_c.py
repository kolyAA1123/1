"""Two inertial frames, rest energy and historical atom models: second PDF pp1–7."""
from quantum_style import *
from quantum_math import light_clock


def qc_arrow(start, end, color=CYAN, width=2.5):
    return Arrow(np.array(start, float), np.array(end, float), buff=0,
                 color=color, stroke_width=width, tip_length=.12,
                 max_tip_length_to_length_ratio=.16)


def qc_car(center=(-4.6, -.1, 0)):
    body=RoundedRectangle(width=2.5,height=1.2,corner_radius=.16,
                          color=LAVENDER,fill_color=LAVENDER,fill_opacity=.07)
    body.move_to(center)
    wheels=VGroup(*[Circle(radius=.2,color=MUTED,stroke_width=1.5)
                     .move_to(np.asarray(center)+[x,-.8,0]) for x in (-.75,.75)])
    source=Dot(np.asarray(center)+[-.5,.1,0],radius=.05,color=GOLD)
    return VGroup(body,wheels,source)


def qc_clock_ship(floor):
    p=np.asarray(floor,float)
    box=RoundedRectangle(width=2.5,height=1.2,corner_radius=.09,
                         color=LAVENDER,stroke_width=1.8,
                         fill_color=LAVENDER,fill_opacity=.035).move_to(p+[.65,.6,0])
    emitter=Dot(p,radius=.045,color=MUTED)
    receiver=Line(p+[-.15,1.2,0],p+[.15,1.2,0],color=GOLD,stroke_width=4)
    return VGroup(box,emitter,receiver)


def qc_small_charge(center, color=CYAN):
    return VGroup(Circle(radius=.085,color=color,stroke_width=1.2,
                         fill_color=color,fill_opacity=.2).move_to(center),
                  Line(np.asarray(center)+LEFT*.045,np.asarray(center)+RIGHT*.045,
                       color=color,stroke_width=1.3))


class RelativityPostulates(QuantumScene):
    chapter_id=9

    def chapter(self):
        self.beat(0)
        train=qc_car()
        source=np.array([-5.1,0,0.]);arrival=np.array([-.8,0,0.])
        detector=VGroup(Line([-.75,-.5,0],[-.75,.5,0],color=INK,stroke_width=3),
                        words('Приёмник',[-1.05,.9,0],20,MUTED,width=1.5))
        rail=Line([-5.95,-1.1,0],[-.65,-1.1,0],color=GRID,stroke_width=1.6)
        velocity=qc_arrow([-5.5,-1.75,0],[-3.9,-1.75,0],LAVENDER)
        pulse=Dot(source,radius=.07,color=GOLD)
        trail=Line(source,arrival,color=GOLD,stroke_width=2)
        self.show(train,rail,detector,velocity,pulse,
                  formula('v',[-4.7,-2.15,0],29,LAVENDER,width=.5),
                  words('Внешняя инерциальная система',[-3.2,2.15,0],22,MUTED),
                  words(['Поезд движется равномерно','Свет направлен вперёд'],[3.1,1.35,0],26),
                  formula(r'0<v<c',[3.1,-.05,0],36),run_time=1.2)
        self.intro(0)
        # Both displacements share the same external animation time:
        # train_speed / light_speed = 1.25/4.3 < 1, never c+v.
        self.act(0,train.animate.shift(RIGHT*1.25),
                 MoveAlongPath(pulse,Line(source,arrival)),Create(trail),rate_func=linear)
        self.show(words(['Во внешней системе скорость света — c',
                         'Скорости по правилу c + v не складываются'],[3.1,-1.65,0],24,GOLD),
                  formula('c',[-2.9,1.05,0],30,GOLD,width=.5),run_time=1.2)
        self.result(0)

        self.beat(1)
        frames=VGroup()
        for name,y in [('S',.9),("S'",-1.1)]:
            frames.add(RoundedRectangle(width=4.8,height=1.05,corner_radius=.12,
                                        color=LAVENDER,stroke_width=1.8).move_to([-3.2,y,0]),
                       formula(name,[-5.15,y,0],34,LAVENDER,width=.7),
                       words('Инерциальная система',[-2.9,y,0],23,INK,width=3.7))
        self.show(frames,words('Относительное движение равномерно',[-3.2,-2.3,0],22,MUTED),
                  words('Два постулата СТО',[3.1,2.05,0],28),run_time=1.2)
        self.intro(1)
        first=words(['Законы природы имеют одинаковый вид',
                     'во всех инерциальных системах'],[3.1,.85,0],24,CYAN)
        second=words(['Скорость света в вакууме одинакова',
                      'во всех инерциальных системах'],[3.1,-.65,0],24,GOLD)
        self.act(1,Succession(FadeIn(first),FadeIn(second)))
        self.show(words('Абсолютно неподвижная система не выделяется',[3.1,-2.2,0],22,MUTED),run_time=1.2)
        self.result(1)


class LightClockDilation(QuantumScene):
    chapter_id=10

    def chapter(self):
        self.beat(0)
        geometry=light_clock(.6,height=1.2,c=1.)
        upper=np.array([-5.25,.55,0.]);lower=np.array([-5.25,-1.6,0.])
        fixed=qc_clock_ship(upper);moving=qc_clock_ship(lower)
        upper_end=upper+UP*geometry['vertical']
        lower_end=lower+[geometry['horizontal'],geometry['vertical'],0]
        upper_path=Line(upper,upper_end);lower_path=Line(lower,lower_end)
        upper_pulse=Dot(upper,radius=.055,color=GOLD)
        lower_pulse=Dot(lower,radius=.055,color=CYAN)
        upper_trace=Line(upper,upper_end,color=GOLD,stroke_width=2.6)
        lower_trace=Line(lower,lower_end,color=CYAN,stroke_width=2.6)
        self.show(fixed,moving,upper_pulse,lower_pulse,
                  words('Система корабля',[-3.5,2.25,0],23,GOLD),
                  words('Внешняя система',[-3.5,-.05,0],23,CYAN),
                  words(['Одно испускание и один приём','Свет проходит от пола к потолку'],[3.1,1.6,0],25),
                  words(['Вакуум; одинаковая высота','Скорость света в обеих системах — c'],[3.1,.05,0],23,MUTED),run_time=1.2)
        self.intro(0)
        # One common distance/time scale: c=1.2/4=1.5/5, v=.9/5=.6c.
        # The upper pulse finishes at t1; the lab pulse reaches the moving
        # receiver at t2. Neither is removed before completing its route.
        upper_action=Succession(AnimationGroup(
            MoveAlongPath(upper_pulse,upper_path,rate_func=linear,run_time=4),
            Create(upper_trace,rate_func=linear,run_time=4),lag_ratio=0,run_time=4),
            Wait(run_time=1))
        self.act(0,upper_action,
                 MoveAlongPath(lower_pulse,lower_path,rate_func=linear),
                 Create(lower_trace,rate_func=linear),
                 moving.animate.shift(RIGHT*geometry['horizontal']),rate_func=linear)
        self.show(formula('t_1',[-2.0,1.1,0],29,GOLD,width=.6),
                  formula('t_2',[-1.65,-1.,0],29,CYAN,width=.6),
                  formula(r't_2>t_1',[3.1,-1.65,0],41,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        geometry=light_clock(.6,height=2.5,c=1.)
        start=np.array([-5.4,-1.5,0.]);corner=start+UP*geometry['vertical']
        end=corner+RIGHT*geometry['horizontal']
        vertical=Line(start,corner,color=GOLD,stroke_width=2.7)
        horizontal=Line(corner,end,color=LAVENDER,stroke_width=2.7)
        diagonal=Line(start,end,color=CYAN,stroke_width=2.7)
        right_angle=VGroup(Line(corner+DOWN*.16,corner+[.16,-.16,0],color=MUTED,stroke_width=1.5),
                           Line(corner+[.16,-.16,0],corner+RIGHT*.16,color=MUTED,stroke_width=1.5))
        self.show(vertical,Dot(start,radius=.045,color=INK),Dot(corner,radius=.045,color=INK),
                  formula('ct_1',[-6.03,-.25,0],31,GOLD,width=.76),
                  words(['Высота: c t₁','Смещение корабля: v t₂'],[3.1,1.45,0],26),
                  words('Диагональ — путь света во внешней системе',[3.1,.15,0],23,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,Create(horizontal),Create(diagonal),FadeIn(right_angle),
                 FadeIn(formula('vt_2',[(corner[0]+end[0])/2,1.45,0],30,LAVENDER,width=1.)),
                 FadeIn(formula('ct_2',[(start[0]+end[0])/2+.5,-.65,0],31,CYAN,width=1.)))
        self.show(formula(r'(ct_2)^2=(ct_1)^2+(vt_2)^2',[3.1,-1.05,0],34),
                  formula(r'c^2t_2^2=c^2t_1^2+v^2t_2^2',[3.1,-2.25,0],33,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        self.show(formula(r'c^2t_2^2=c^2t_1^2+v^2t_2^2',[0,1.75,0],43,width=11.8),
                  words('Сравниваем интервалы в двух выбранных системах',[0,2.4,0],22,MUTED,width=12),run_time=1.2)
        self.intro(2)
        factor=formula(r't_2^2(c^2-v^2)=c^2t_1^2',[0,.4,0],43,width=11.8)
        final=formula(r't_2=\frac{t_1}{\sqrt{1-v^2/c^2}}',[0,-1.15,0],45,GOLD,width=11.8)
        self.act(2,Succession(Write(factor),Write(final)))
        self.show(formula(r'0\leq v<c,\qquad t_2\geq t_1,\qquad v=0:\ t_2=t_1',
                          [0,-2.65,0],31,MUTED,width=12),run_time=1.2)
        self.result(2)


class RestEnergyAndPhotons(QuantumScene):
    chapter_id=11

    def chapter(self):
        self.beat(0)
        body=Circle(radius=.85,color=LAVENDER,stroke_width=2.2,
                    fill_color=LAVENDER,fill_opacity=.08).move_to([-3.2,.5,0])
        self.show(body,formula('m',[-3.2,.5,0],47,LAVENDER,width=1),
                  words('Тело покоится в выбранной системе',[-3.2,1.95,0],23,MUTED),
                  words(['Даже покоящееся тело обладает энергией','m — масса тела'],[3.1,1.4,0],25),
                  words('c — скорость света в вакууме',[3.1,-.1,0],24,MUTED),run_time=1.2)
        self.intro(0)
        self.act(0,Write(formula(r'E_0=mc^2',[3.1,-1.45,0],49,GOLD)))
        self.show(words(['Энергия покоя','Индекс 0 относится к состоянию покоя'],[-3.2,-1.65,0],24,INK),run_time=1.2)
        self.result(0)

        self.beat(1)
        origin=np.array([-3.3,0,0.]);left=origin+LEFT*2.2;right=origin+RIGHT*2.2
        pion=VGroup(Circle(radius=.35,color=LAVENDER,stroke_width=2,
                          fill_color=LAVENDER,fill_opacity=.1).move_to(origin),
                    formula(r'\pi^0',origin,32,LAVENDER,width=.55))
        photon_l=Dot(origin,radius=.07,color=CYAN);photon_r=Dot(origin,radius=.07,color=ROSE)
        left_path=Line(origin,left);right_path=Line(origin,right)
        left_arrow=qc_arrow(origin,left,CYAN);right_arrow=qc_arrow(origin,right,ROSE)
        self.show(pion,words('Исправление конспекта: фотоны γ, а не мюоны',[0,2.3,0],23,MUTED,width=12),
                  words('Нейтральный π-мезон первоначально покоится',[3.1,1.35,0],24),
                  formula(r'E_{\gamma}=pc',[3.1,.15,0],39,GOLD),run_time=1.2)
        self.intro(1)
        self.act(1,Succession(
            AnimationGroup(FadeOut(pion),FadeIn(photon_l),FadeIn(photon_r),lag_ratio=0,run_time=.5),
            AnimationGroup(MoveAlongPath(photon_l,left_path,rate_func=linear),
                           MoveAlongPath(photon_r,right_path,rate_func=linear),
                           Create(left_arrow,rate_func=linear),Create(right_arrow,rate_func=linear),
                           lag_ratio=0,run_time=4.5)),rate_func=linear)
        self.show(formula(r'\vec p_1',[-4.4,.5,0],30,CYAN,width=.7),
                  formula(r'\vec p_2',[-2.2,.5,0],30,ROSE,width=.7),
                  formula(r'\gamma',left+DOWN*.5,26,CYAN,width=.5),
                  formula(r'\gamma',right+DOWN*.5,26,ROSE,width=.5),
                  words('Равные энергии двух фотонов',[-3.3,-1.4,0],24,GOLD),
                  formula(r'mc^2=2pc',[3.1,-1.1,0],42,GOLD),
                  formula(r'\vec p_1+\vec p_2=0',[3.1,-2.3,0],33),run_time=1.2)
        self.result(1)


class AtomicModels(QuantumScene):
    chapter_id=12

    def chapter(self):
        self.beat(0)
        dalton=Circle(radius=.76,color=MUTED,stroke_width=2,
                      fill_color=MUTED,fill_opacity=.16).move_to([-4.75,-.15,0])
        thomson=Circle(radius=.76,color=LAVENDER,stroke_width=2,
                       fill_color=LAVENDER,fill_opacity=.15).move_to([-1.85,-.15,0])
        electrons=VGroup(*[qc_small_charge(np.array([-1.85,-.15,0])+radius*np.array([np.cos(angle),np.sin(angle),0]))
                           for angle,radius in zip(np.linspace(0,TAU,7)[:-1],[.48]*6)])
        self.show(dalton,thomson,formula('+',[-1.85,-.15,0],39,ROSE,width=.5),
                  words('Дальтон',[-4.75,1.9,0],26,MUTED,width=2.2),
                  words('Томсон',[-1.85,1.9,0],26,LAVENDER,width=2.2),
                  words('1808',[-4.75,1.2,0],21,MUTED,width=1),
                  words('1904',[-1.85,1.2,0],21,MUTED,width=1),
                  words(['В модели Томсона положительный заряд','распределён по объёму'],[3.1,1.4,0],25),
                  words('Электроны находятся внутри этого объёма',[3.1,-.05,0],24,MUTED),run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(*[FadeIn(e) for e in electrons],lag_ratio=.17))
        self.show(formula(r'q_{+}+q_{-}=0',[3.1,-1.6,0],41,GOLD),
                  words('Исторические модели строения атома',[-3.3,-1.9,0],23,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        center=np.array([-3.3,0,0.]);radius=1.9
        screen=Arc(radius=radius,start_angle=PI+.12,angle=TAU-.24,
                   color=MUTED,stroke_width=2.2).shift(center)
        foil=Line(center+DOWN*1.4,center+UP*1.4,color=GOLD,stroke_width=4)
        source=Rectangle(width=.5,height=.65,color=LAVENDER,stroke_width=1.8,
                         fill_color=LAVENDER,fill_opacity=.12).move_to([-5.75,0,0])
        straight=Line([-5.5,0,0],center+RIGHT*radius,color=CYAN,stroke_width=3)
        end_down=center+radius*np.array([np.cos(-.45),np.sin(-.45),0])
        down=VMobject(color=GOLD,stroke_width=1.9).set_points_smoothly([
            [-5.5,-.12,0],[-4.5,-.12,0],[-3.65,-.15,0],[-2.9,-.32,0],end_down])
        end_back=center+radius*np.array([np.cos(2.48),np.sin(2.48),0])
        back=VMobject(color=ROSE,stroke_width=1.9).set_points_smoothly([
            [-5.5,.12,0],[-4.6,.12,0],[-3.85,.18,0],[-3.5,.4,0],[-3.65,.73,0],[-4.2,1.04,0],end_back])
        self.show(screen,foil,source,
                  formula(r'\alpha',[-5.75,.7,0],28,LAVENDER,width=.6),
                  words('Золотая фольга',[-3.3,2.25,0],22,GOLD,width=3.7),
                  words('Экран с сернистым цинком',[-3.3,-2.35,0],21,MUTED,width=5.4),
                  words(['Опыт рассеяния Резерфорда','Схема возможных направлений'],[3.1,1.6,0],25),
                  words('Положительные α отклоняются полем ядра',[3.1,.1,0],23,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,Create(straight),Create(down),Create(back),rate_func=linear)
        self.show(Dot(center+RIGHT*radius,radius=.055,color=CYAN),
                  Dot(end_down,radius=.055,color=GOLD),Dot(end_back,radius=.055,color=ROSE),
                  words(['Большинство частиц идёт почти прямо','Редкие сближения дают большие углы'],[3.1,-1.05,0],23,GOLD),
                  words('Вывод: малое положительное ядро',[3.1,-2.3,0],24,INK),run_time=1.2)
        self.result(1)

        self.beat(2)
        classical_center=np.array([-3.2,.2,0.]);bohr_center=np.array([3.2,.2,0.])
        nucleus_l=Dot(classical_center,radius=.12,color=ROSE)
        nucleus_r=Dot(bohr_center,radius=.12,color=ROSE)
        orbit_l=Circle(radius=1.,color=GRID,stroke_width=1.5).move_to(classical_center)
        bohr_orbits=VGroup(*[Circle(radius=r,color=LAVENDER,stroke_width=1.6).move_to(bohr_center)
                            for r in (.62,1.05)])
        electron_l=Dot(classical_center+RIGHT,radius=.055,color=CYAN)
        electron_r=Dot(bohr_center+RIGHT*1.05,radius=.055,color=CYAN)
        spiral=VMobject(color=GOLD,stroke_width=2).set_points_smoothly([
            classical_center+(1-.825*a)*np.array([np.cos(TAU*a),np.sin(TAU*a),0])
            for a in np.linspace(0,1,150)])
        self.show(nucleus_l,nucleus_r,orbit_l,bohr_orbits,electron_l,electron_r,
                  words('Классическая модель',[-3.2,2.15,0],25),
                  words('Модель Бора',[3.2,2.15,0],25,LAVENDER),
                  words('Классическое предсказание сближения',[-3.2,-1.35,0],23,MUTED),
                  words('Стационарное состояние',[3.2,-1.35,0],23,LAVENDER),run_time=1.2)
        self.intro(2)
        self.act(2,MoveAlongPath(electron_l,spiral),Create(spiral),
                 MoveAlongPath(electron_r,Circle(radius=1.05).move_to(bohr_center)),rate_func=linear)
        self.show(words(['Классический вывод: неустойчивость','Это не аннигиляция электрона'],[-3.2,-2.05,0],21,GOLD),
                  words(['На стационарной орбите нет излучения','Переходы: излучение или поглощение'],[3.2,-2.05,0],21,INK),
                  words('Нуклонная модель ядра: протоны и нейтроны',[0,-2.85,0],21,MUTED,width=12),run_time=1.2)
        self.result(2)
