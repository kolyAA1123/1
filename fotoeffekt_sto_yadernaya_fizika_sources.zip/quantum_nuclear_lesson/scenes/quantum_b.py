"""External photoeffect, apparatus, photocurrent and energy balance: PDF pp8–13."""
from quantum_style import *


def qb_ray(start, end, color=GOLD, width=2.2):
    return Arrow(np.array(start, float), np.array(end, float), buff=0,
                 color=color, stroke_width=width, tip_length=.12,
                 max_tip_length_to_length_ratio=.16)


def qb_meter(letter, center):
    return VGroup(Circle(radius=.29, color=MUTED, stroke_width=1.5).move_to(center),
                  formula(letter, center, 26, INK, width=.43))


def qb_photoelement(polarity=1):
    """Fixed K/A and instrument topology; polarity never swaps electrode names."""
    k, a = -4.85, -1.65
    yl, yb, yv = .35, -2.05, -1.25
    left, right = -5.65, -.85
    electrodes=VGroup(Line([k,-.35,0],[k,1.08,0],color=CYAN,stroke_width=3),
                      Line([a,-.35,0],[a,1.08,0],color=INK,stroke_width=3))
    names=VGroup(words('Фотокатод',[-5.1,1.7,0],20,CYAN,width=1.8),
                 words('Анод',[-1.65,1.7,0],20,INK,width=1.2))
    wire=VGroup(Line([k,yl,0],[left,yl,0],color=MUTED,stroke_width=1.5),
                Line([left,yl,0],[left,yb,0],color=MUTED,stroke_width=1.5),
                Line([a,yl,0],[right,yl,0],color=MUTED,stroke_width=1.5),
                Line([right,yl,0],[right,yb,0],color=MUTED,stroke_width=1.5),
                Line([left,yv,0],[-4.49,yv,0],color=MUTED,stroke_width=1.5),
                Line([-3.91,yv,0],[right,yv,0],color=MUTED,stroke_width=1.5),
                Line([left,yb,0],[-4.45,yb,0],color=MUTED,stroke_width=1.5),
                Line([-4.2,yb,0],[-2.44,yb,0],color=MUTED,stroke_width=1.5),
                Line([-1.86,yb,0],[right,yb,0],color=MUTED,stroke_width=1.5))
    # Positive anode: the battery's longer positive plate is on the right.
    first,second=(.18,.34) if polarity>0 else (.34,.18)
    battery=VGroup(Line([-4.45,yb-first,0],[-4.45,yb+first,0],color=INK,stroke_width=2),
                   Line([-4.2,yb-second,0],[-4.2,yb+second,0],color=INK,stroke_width=2))
    signs=VGroup(formula('-' if polarity>0 else '+',[k-.3,.87,0],25,ROSE,width=.35),
                 formula('+' if polarity>0 else '-',[a+.29,.87,0],25,ROSE,width=.35),
                 formula('-' if polarity>0 else '+',[-4.62,-2.62,0],23,MUTED,width=.3),
                 formula('+' if polarity>0 else '-',[-4.02,-2.62,0],23,MUTED,width=.3))
    meters=VGroup(qb_meter('V',[-4.2,yv,0]),qb_meter('A',[-2.15,yb,0]))
    lights=VGroup(*[qb_ray([-3.55+.13*j,2.12,0],[k,.94-.24*j,0]) for j in range(3)])
    return dict(base=VGroup(electrodes,names,wire,battery,signs,meters),
                lights=lights,k=k,a=a)


def qb_flights(k, a, acceleration=.7):
    """Three full flights with different initial speeds in one uniform field.

    Coordinates/time are hidden schematic units. A common acceleration and
    the actual quadratic x(t) determine each arrival time and animation.
    """
    start,end=k+.055,a-.055;distance=end-start
    dots=VGroup();trails=VGroup();motions=[]
    for y,v0,vy in zip((-.14,.35,.82),(.7,1.,1.35),(.12,0.,-.12)):
        t=(-v0+np.sqrt(v0*v0+2*acceleration*distance))/acceleration
        dot=Dot([start,y,0],radius=.055,color=CYAN);dots.add(dot)
        def position(alpha, speed=v0, duration=t, yy=y, vertical_speed=vy):
            time=alpha*duration
            return np.array([start+speed*time+.5*acceleration*time*time,yy+vertical_speed*time,0])
        trail=VMobject(color=CYAN,stroke_width=1.3,stroke_opacity=.45)
        trail.set_points_as_corners([position(alpha) for alpha in np.linspace(0,1,80)])
        trails.add(trail)
        motions.append(Succession(UpdateFromAlphaFunc(dot,lambda m,alpha,f=position:m.move_to(f(alpha)),
                                                       run_time=float(t),rate_func=linear),
                                   FadeOut(dot,run_time=.16)))
    return dots,trails,AnimationGroup(*motions,lag_ratio=0)


def qb_returns(k):
    """An opposing force turns every shown electron before A and returns it to K."""
    start=k+.055;deceleration=3.
    dots=VGroup();trails=VGroup();motions=[]
    for y,v0 in zip((-.14,.35,.82),(1.6,2.2,2.7)):
        t=2*v0/deceleration;turn=v0*v0/(2*deceleration)
        dot=Dot([start,y,0],radius=.055,color=CYAN);dots.add(dot)
        trails.add(Line([start,y,0],[start+turn,y,0],color=CYAN,stroke_width=1.3,stroke_opacity=.5))
        def position(alpha, speed=v0, duration=t, yy=y):
            time=alpha*duration
            return np.array([start+speed*time-.5*deceleration*time*time,yy,0])
        motions.append(Succession(UpdateFromAlphaFunc(dot,lambda m,alpha,f=position:m.move_to(f(alpha)),
                                                       run_time=float(t),rate_func=linear),
                                   FadeOut(dot,run_time=.16)))
    return dots,trails,AnimationGroup(*motions,lag_ratio=0)


def qb_current(u, saturation=1.):
    """Qualitative C1 I(U): zero through stopping boundary; finite flat plateau."""
    x=np.clip((u+1.)/3.,0.,1.)
    return saturation*x*x*(3.-2.*x)


def qb_iu_axes(signed=False, maximum=1.4):
    start=-1.45 if signed else 0
    ax=axes((start,4.,1.),(0,maximum,.5),4.55,3.0,np.array([-3.35,-.05,0]))
    ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
    origin=ax.c2p(0,0)
    labels=VGroup(formula('I',ax.y_axis.get_end()+UP*.23,26,MUTED,width=.4),
                  formula('U',ax.x_axis.get_end()+RIGHT*.23,26,MUTED,width=.4),
                  formula('0',origin+[-.16,-.3,0],22,MUTED,width=.35),
                  words('Качественная характеристика',[-3.35,2.16,0],22,MUTED,width=5.5))
    return ax,VGroup(ax,labels)


def qb_plateau(ax, level, name, color):
    return VGroup(DashedLine(ax.c2p(0,level),ax.c2p(3.6,level),color=color,
                             dash_length=.1,stroke_width=1.2),
                  formula(name,ax.c2p(0,level)+LEFT*.46,27,color,width=.85))


def qb_energy_bar(width=4.6, center=(-3.3,1.,0), color=GOLD):
    return Rectangle(width=width,height=.36,color=color,stroke_width=1.8,
                     fill_color=color,fill_opacity=.16).move_to(center)


class PhotoelectricApparatus(QuantumScene):
    chapter_id=5

    def chapter(self):
        self.beat(0)
        f=qb_photoelement(1)
        self.show(f['base'],words(['Внешний фотоэффект','Электроны покидают вещество'],[3.1,1.5,0],26),
                  words(['Вольтметр — параллельно','Амперметр — последовательно'],[3.1,-.15,0],24,MUTED),run_time=1.2)
        self.intro(0)
        dots,trails,motion=qb_flights(f['k'],f['a'])
        self.act(0,Succession(Create(f['lights']),FadeIn(dots),AnimationGroup(Create(trails),motion)),rate_func=linear)
        self.show(words(['Свет вызывает эмиссию','Собранные электроны дают фототок'],[3.1,-1.95,0],24,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        f=qb_photoelement(1);dots,trails,motion=qb_flights(f['k'],f['a'])
        field=VGroup(qb_ray([-1.95,1.12,0],[-4.42,1.12,0],ROSE),
                     formula(r'\vec E',[-3.15,1.42,0],25,ROSE,width=.7))
        force=VGroup(qb_ray([-4.45,-.55,0],[-2.15,-.55,0],GOLD),
                     formula(r'\vec F_e',[-3.3,-.84,0],25,GOLD,width=.9))
        self.show(f['base'],f['lights'],dots,
                  formula(r'U=V_{\mathrm{ан}}-V_{\mathrm{кат}}>0',[3.1,1.55,0],32),
                  words(['Анод положителен','Начальные скорости различны'],[3.1,.05,0],25,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,FadeIn(field),FadeIn(force),Create(trails),motion,rate_func=linear)
        self.show(words(['Сила на электрон направлена к аноду','Поле увеличивает скорость при движении'],[3.1,-1.85,0],23,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        f=qb_photoelement(-1);dots,trails,motion=qb_returns(f['k'])
        field=VGroup(qb_ray([-4.42,1.12,0],[-1.95,1.12,0],ROSE),
                     formula(r'\vec E',[-3.15,1.42,0],25,ROSE,width=.7))
        force=VGroup(qb_ray([-2.15,-.55,0],[-4.45,-.55,0],GOLD),
                     formula(r'\vec F_e',[-3.3,-.84,0],25,GOLD,width=.9))
        self.show(f['base'],f['lights'],dots,
                  formula(r'U=V_{\mathrm{ан}}-V_{\mathrm{кат}}<0',[3.1,1.55,0],32),
                  words(['Анод отрицателен','Поле препятствует сбору электронов'],[3.1,.05,0],25,MUTED),run_time=1.2)
        self.intro(2)
        self.act(2,FadeIn(field),FadeIn(force),Create(trails),motion,rate_func=linear)
        self.show(words(['Достаточное торможение','Показанные электроны вернулись к катоду'],[3.1,-1.85,0],23,GOLD),run_time=1.2)
        self.result(2)


class PhotocurrentAndLaws(QuantumScene):
    chapter_id=6

    def chapter(self):
        self.beat(0)
        ax,base=qb_iu_axes();curve=ax.plot(qb_current,x_range=[0,4,.025],color=CYAN,stroke_width=3)
        self.show(base,words(['Увеличиваем ускоряющее напряжение','Собирается всё больше электронов'],[3.1,1.45,0],25),run_time=1.2)
        self.intro(0)
        self.act(0,Create(curve),rate_func=linear)
        self.show(qb_plateau(ax,1.,r'I_{\mathrm{н}}',GOLD),
                  words(['Ток насыщения','Все испущенные электроны собраны'],[3.1,-.35,0],25,GOLD),
                  words('В этой схеме 0 < I(0) < Iн',[3.1,-2.1,0],24,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        surface=Rectangle(width=2.2,height=1.7,color=LAVENDER,stroke_width=2,
                          fill_color=LAVENDER,fill_opacity=.05).move_to([-3.4,.45,0])
        packets=VGroup(*[Dot([x,y,0],radius=.055,color=GOLD)
                         for x in (-4.1,-3.4,-2.7) for y in (-.05,.45,.95)])
        self.show(surface,formula('S',[-3.4,-.8,0],32,LAVENDER,width=.6),
                  words('Энергия за время t',[-3.4,1.95,0],23,MUTED),
                  formula(r'J=\frac{W}{St}',[3.1,1.3,0],44),
                  words('Интенсивность: Вт/м²',[3.1,.05,0],25,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,LaggedStart(*[FadeIn(dot) for dot in packets],lag_ratio=.12),
                 Write(formula(r'W=NE_{\mathrm{ф}}=Nh\nu',[3.1,-1.3,0],37,GOLD)))
        self.show(words(['Одна частота — одна энергия фотона','N — число фотонов за выбранное время'],[-3.4,-2.,0],22,MUTED,width=5.3),run_time=1.2)
        self.result(1)

        self.beat(2)
        ax,base=qb_iu_axes(maximum=1.8)
        low=ax.plot(lambda u:qb_current(u,1.),x_range=[0,4,.025],color=CYAN,stroke_width=2.8)
        high=ax.plot(lambda u:qb_current(u,1.45),x_range=[0,4,.025],color=ROSE,stroke_width=2.8)
        self.show(base,low,words(['Частота и поверхность постоянны','Меняется только интенсивность'],[3.1,1.55,0],24),
                  formula(r'J_2>J_1',[3.1,.15,0],37,ROSE),run_time=1.2)
        self.intro(2)
        self.act(2,Create(high),rate_func=linear)
        self.show(qb_plateau(ax,1.,r'I_{\mathrm{н}1}',CYAN),
                  qb_plateau(ax,1.45,r'I_{\mathrm{н}2}',ROSE),
                  formula(r'I_{\mathrm{н}}\propto J',[3.1,-1.15,0],40,GOLD),
                  words('Первый закон Столетова',[3.1,-2.3,0],24,MUTED),run_time=1.2)
        self.result(2)

        self.beat(3)
        self.show(words('Второй закон',[-3.1,2.05,0],27,CYAN),
                  formula(r'\nu=\mathrm{const}',[-3.1,1.0,0],37),
                  words('Третий закон',[3.1,2.05,0],27,ROSE),
                  words('Для данного вещества и состояния поверхности',[0,-2.65,0],23,MUTED,width=12),run_time=1.2)
        self.intro(3)
        self.act(3,Write(formula(r'K_{\max}=\mathrm{const}',[-3.1,-.15,0],37,CYAN)),
                 Write(formula(r'\nu\geq\nu_{\min}',[3.1,.8,0],39,ROSE)),
                 Write(formula(r'\lambda\leq\lambda_{\max}',[3.1,-.55,0],39,ROSE)))
        self.show(words(['Интенсивность меняет число электронов','Максимальная начальная энергия прежняя'],[-3.1,-1.6,0],22,MUTED),
                  words('Красная граница фотоэффекта',[3.1,-1.8,0],24,GOLD),run_time=1.2)
        self.result(3)


class EinsteinPhotoelectricBalance(QuantumScene):
    chapter_id=7

    def chapter(self):
        self.beat(0)
        metal=Rectangle(width=2.7,height=2.5,color=LAVENDER,stroke_width=1.5,
                        fill_color=LAVENDER,fill_opacity=.08).move_to([-4.35,0,0])
        surface=Line([-3.,-1.25,0],[-3.,1.25,0],color=INK,stroke_width=2.5)
        electron=Dot([-3.3,.25,0],radius=.065,color=CYAN)
        path=Line([-3.3,.25,0],[-1.25,.25,0],color=CYAN,stroke_width=1.5)
        self.show(metal,surface,electron,words('Вещество',[-4.35,1.8,0],24,LAVENDER),
                  words('Вакуум',[-1.75,1.8,0],24,MUTED),
                  words(['Электронная эмиссия','Выход электрона из вещества'],[3.1,1.45,0],25),
                  words('Свет или нагрев передают энергию',[3.1,-.1,0],24,MUTED),run_time=1.2)
        self.intro(0)
        self.act(0,Create(path),electron.animate.move_to([-1.25,.25,0]),
                 Write(formula(r'A_{\mathrm{вых}}>0',[3.1,-1.45,0],40,GOLD)))
        self.show(words('Работа выхода — минимальная энергия перехода в вакуум',[0,-2.45,0],24,MUTED,width=12),run_time=1.2)
        self.result(0)

        self.beat(1)
        photon=qb_energy_bar()
        cost=qb_energy_bar(2.6,[-4.3,-.45,0],LAVENDER)
        excess=qb_energy_bar(2.,[-2.,-.45,0],CYAN)
        self.show(photon,formula(r'E_{\mathrm{ф}}=h\nu',[-3.3,1.75,0],33,GOLD),
                  words('Энергия одного фотона',[3.1,2.15,0],25,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,FadeIn(cost),FadeIn(excess),
                 Write(formula(r'h\nu=A_{\mathrm{вых}}+K_{\max}',[3.1,1.05,0],37,GOLD)))
        self.show(formula(r'A_{\mathrm{вых}}',[-4.3,-1.12,0],31,LAVENDER,width=2),
                  formula(r'K_{\max}',[-2.,-1.12,0],31,CYAN,width=1.5),
                  formula(r'K_{\max}=\frac{m_e v_{\max}^{2}}{2}',[3.1,-.3,0],36),
                  formula(r'm_e\approx9{,}1\cdot10^{-31}\ \mathrm{кг}',[3.1,-1.6,0],29,MUTED),
                  words('Нерелятивистские фотоэлектроны',[0,-2.55,0],24,MUTED,width=12),run_time=1.2)
        self.result(1)

        self.beat(2)
        ax,base=qb_iu_axes(signed=True)
        curve=ax.plot(qb_current,x_range=[-1.45,4,.025],color=CYAN,stroke_width=2.8)
        self.show(base,formula(r'U=V_{\mathrm{ан}}-V_{\mathrm{кат}}',[3.1,1.7,0],34),
                  words('Запирающее напряжение — положительный модуль',[3.1,.45,0],23,MUTED),run_time=1.2)
        self.intro(2)
        zero=Dot(ax.c2p(-1.,0),radius=.055,color=GOLD)
        self.act(2,Create(curve),FadeIn(zero),
                 Write(formula(r'eU_{\mathrm{зап}}=K_{\max}',[3.1,-.85,0],39,GOLD)),rate_func=linear)
        self.show(formula(r'-U_{\mathrm{зап}}',ax.c2p(-1,0)+DOWN*.82,26,GOLD,width=1.4),
                  formula(r'U=-U_{\mathrm{зап}},\qquad e>0',[3.1,-2.15,0],32),run_time=1.2)
        self.result(2)


class PhotoelectricThreshold(QuantumScene):
    chapter_id=8

    def chapter(self):
        self.beat(0)
        self.show(words('На красной границе',[-3.1,1.9,0],27,GOLD),
                  formula(r'K_{\max}=0',[-3.1,.65,0],42,CYAN),
                  formula(r'h\nu=A_{\mathrm{вых}}+K_{\max}',[3.1,1.7,0],36),
                  words('Поверхность и вещество заданы',[3.1,.4,0],24,MUTED),run_time=1.2)
        self.intro(0)
        self.act(0,Write(formula(r'A_{\mathrm{вых}}=h\nu_{\min}',[3.1,-.85,0],40,GOLD)))
        self.show(formula(r'\nu_{\min}=\frac{A_{\mathrm{вых}}}{h}',[-3.1,-1.1,0],43),
                  words('Пороговая частота определяется работой выхода',[0,-2.55,0],24,MUTED,width=12),run_time=1.2)
        self.result(0)

        self.beat(1)
        self.show(formula(r'\nu=\frac{c}{\lambda}',[-3.1,1.4,0],44),
                  words('c — скорость света в вакууме',[-3.1,-.1,0],24,MUTED),
                  formula(r'A_{\mathrm{вых}}=h\nu_{\min}',[3.1,1.4,0],39),run_time=1.2)
        self.intro(1)
        self.act(1,Write(formula(r'A_{\mathrm{вых}}=\frac{hc}{\lambda_{\max}}',[3.1,-.2,0],41,GOLD)))
        self.show(formula(r'\lambda_{\max}=\frac{hc}{A_{\mathrm{вых}}}',[-3.1,-1.65,0],42),
                  words('Наибольшая длина волны, допускающая однофотонную эмиссию',[0,-2.65,0],23,MUTED,width=12),run_time=1.2)
        self.result(1)

        self.beat(2)
        titles=VGroup(words('Ниже порога',[-4.4,2.05,0],23,MUTED,width=3.2),
                      words('На пороге',[0,2.05,0],23,GOLD,width=3.2),
                      words('Выше порога',[4.4,2.05,0],23,CYAN,width=3.2))
        conditions=VGroup(formula(r'h\nu<A_{\mathrm{вых}}',[-4.4,1.2,0],30,MUTED,width=3.8),
                          formula(r'h\nu=A_{\mathrm{вых}}',[0,1.2,0],30,GOLD,width=3.8),
                          formula(r'h\nu>A_{\mathrm{вых}}',[4.4,1.2,0],30,CYAN,width=3.8))
        surfaces=VGroup(*[Line([x,-.15,0],[x,.65,0],color=LAVENDER,stroke_width=2) for x in (-4.4,0,3.65)])
        bound=Dot([-4.5,.25,0],radius=.065,color=MUTED)
        threshold=Dot([.02,.25,0],radius=.065,color=GOLD)
        free=Dot([3.7,.25,0],radius=.065,color=CYAN)
        self.show(titles,conditions,surfaces,bound,threshold,free,run_time=1.2)
        self.intro(2)
        path=Line([3.7,.25,0],[5.3,.25,0],color=CYAN,stroke_width=1.8)
        self.act(2,Create(path),free.animate.move_to([5.3,.25,0]),
                 FadeIn(words('Эмиссии нет',[-4.4,-.7,0],22,MUTED,width=3.4)),
                 FadeIn(formula(r'K_{\max}=0',[0,-.7,0],30,GOLD,width=3.4)),
                 FadeIn(formula(r'K_{\max}>0',[4.4,-.7,0],30,CYAN,width=3.4)))
        self.show(formula(r'E_{\mathrm{ф}}=h\nu=\frac{hc}{\lambda}',[-4.4,-1.9,0],28,GOLD,width=4.),
                  formula(r'A_{\mathrm{вых}}=h\nu_{\min}=\frac{hc}{\lambda_{\max}}',[0,-1.9,0],28,LAVENDER,width=4.),
                  formula(r'K_{\max}=eU_{\mathrm{зап}}=\frac{m_e v_{\max}^{2}}{2}',[4.4,-1.9,0],28,CYAN,width=4.),
                  words('Один фотон; данная поверхность; нерелятивистские фотоэлектроны',[0,-2.75,0],22,MUTED,width=12),run_time=1.2)
        self.result(2)
