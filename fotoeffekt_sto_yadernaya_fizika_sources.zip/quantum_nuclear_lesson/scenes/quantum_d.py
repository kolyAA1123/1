"""Nucleons, radiation, binding, decay and reactions: source PDF pp7–14."""
from quantum_style import *
from quantum_math import nuclide, decay_fraction, reaction_balance


def qd_dot(point, proton=True, radius=.17):
    return Circle(radius=radius, color=ROSE if proton else CYAN,
                  fill_color=ROSE if proton else CYAN, fill_opacity=.75,
                  stroke_width=1.4).move_to(point)


def qd_cluster(A, Z, center=(-3.2, 0, 0), spacing=.38, radius=.17):
    """Counted nucleons, never a literal geometric nuclear-scale model."""
    data=nuclide(A,Z);center=np.array(center,float)
    offsets=[(0,0),(-1,0),(1,0),(-.5,.87),(.5,.87),(-.5,-.87),(.5,-.87)]
    assert A<=len(offsets)
    return VGroup(*[qd_dot(center+spacing*np.array([*offsets[j],0]),j<Z,radius)
                    for j in range(data['A'])])


def qd_species(A,Z,symbol,center,radius=.5,color=GOLD):
    ring=Circle(radius=radius,color=color,fill_color=color,fill_opacity=.09,stroke_width=2).move_to(center)
    name=formula(rf'^{{{A}}}_{{{Z}}}\mathrm{{{symbol}}}',center,29,color,width=radius*1.7)
    return VGroup(ring,name)


def qd_ray(p,q,color=GOLD,width=2.3):
    return Arrow(p,q,buff=0,color=color,stroke_width=width,tip_length=.12,
                 max_tip_length_to_length_ratio=.12)


def qd_decay_plot(center,decayed=False):
    ax=axes((0,4.25,1),(0,1.12,.25),4.65,2.75,np.array(center,float))
    ax.x_axis.ticks.set_opacity(0);ax.y_axis.ticks.set_opacity(0)
    labels=VGroup()
    labels.add(formula('t',ax.x_axis.get_end()+RIGHT*.22,23,MUTED,width=.35))
    for x,tex in ((0,'0'),(1,'T'),(2,'2T'),(4,'4T')):
        labels.add(formula(tex,ax.c2p(x,0)+DOWN*.32,20,MUTED,width=.55))
    y_values=((1,'N_0'),(.75,r'3N_0/4'),(.5,r'N_0/2')) if decayed else ((1,'N_0'),(.5,r'N_0/2'),(.25,r'N_0/4'))
    for y,tex in y_values:
        labels.add(formula(tex,ax.c2p(0,y)+LEFT*.48,20,MUTED,width=.9))
    function=(lambda t:1-decay_fraction(t,1)) if decayed else (lambda t:decay_fraction(t,1))
    curve=ax.plot(function,x_range=[0,4,.025],color=GOLD if decayed else CYAN,stroke_width=2.8)
    guides=VGroup()
    for t in (1,2):
        point=ax.c2p(t,function(t))
        guides.add(DashedLine(ax.c2p(t,0),point,color=GRID,dash_length=.07,stroke_width=1.3),
                   DashedLine(ax.c2p(0,function(t)),point,color=GRID,dash_length=.07,stroke_width=1.3),
                   Dot(point,radius=.045,color=GOLD if decayed else CYAN))
    return VGroup(ax,labels),curve,guides


class NucleonsAndIsotopes(QuantumScene):
    chapter_id=13

    def chapter(self):
        self.beat(0)
        headings=VGroup(words('Частица',[-4.65,2.0,0],25,MUTED,width=2.6),
                        words('Масса, кг',[-.6,2.0,0],25,MUTED,width=4.6),
                        words('Заряд',[4.4,2.0,0],25,MUTED,width=3.1))
        rows=VGroup()
        entries=[('Протон',r'm_p\approx1{,}673\cdot10^{-27}',r'+e',ROSE),
                 ('Нейтрон',r'm_n\approx1{,}675\cdot10^{-27}','0',CYAN),
                 ('Электрон',r'm_e\approx9{,}1\cdot10^{-31}',r'-e',LAVENDER)]
        for y,(name,mass,q,color) in zip((1.,-.25,-1.5),entries):
            rows.add(VGroup(words(name,[-4.65,y,0],27,color,width=2.7),
                            formula(mass,[-.6,y,0],30,width=5),
                            formula(q,[4.4,y,0],32,color,width=1)))
        self.show(headings,run_time=1.2);self.intro(0)
        self.act(0,LaggedStart(*[FadeIn(row) for row in rows],lag_ratio=.25))
        self.show(formula(r'e\approx1{,}6\cdot10^{-19}\ \mathrm{Кл}',[0,-2.55,0],29,GOLD,width=11.8),run_time=1.2)
        self.result(0)

        self.beat(1)
        centers=[np.array([x,.8,0]) for x in (-4.8,-2.7,-.6)]
        protons=VGroup(*[qd_dot(p,True) for p in centers])
        additions=VGroup(qd_dot(centers[1]+RIGHT*.39,False),
                          qd_dot(centers[2]+RIGHT*.39,False),qd_dot(centers[2]+DOWN*.36,False))
        names=VGroup(*[words(name,[p[0],1.8,0],23,INK,width=1.8)
                        for p,name in zip(centers,('Протий','Дейтерий','Тритий'))])
        counts=VGroup(*[formula(tex,[p[0],-.1,0],25,GOLD,width=1.8)
                         for p,tex in zip(centers,(r'1p,\ 0n',r'1p,\ 1n',r'1p,\ 2n'))])
        li6=qd_cluster(6,3,[3.1,1.1,0]);li7=qd_cluster(7,3,[3.1,-1.0,0])
        self.show(protons,names,words('Один элемент: одинаковое число протонов',[-2.7,-1.65,0],23,MUTED,width=6),
                  words('Литий',[3.1,2.15,0],26,ROSE),run_time=1.2)
        self.intro(1)
        self.act(1,FadeIn(additions),FadeIn(counts),FadeIn(li6),FadeIn(li7))
        self.show(formula(r'3p,\ 3n',[4.65,1.1,0],25,GOLD,width=2),
                  formula(r'3p,\ 4n',[4.65,-1.0,0],25,GOLD,width=2),
                  words('Изотопы различаются числом нейтронов',[0,-2.65,0],25,GOLD,width=12),run_time=1.2)
        self.result(1)

        self.beat(2)
        data=nuclide(7,3);assert (data['protons'],data['neutrons'],data['electrons_neutral'])==(3,4,3)
        nucleus=qd_cluster(7,3,[-3.4,.1,0],.46,.2)
        electron_points=[[-5.1,1.45,0],[-1.7,1.45,0],[-3.4,-1.85,0]]
        electrons=VGroup(*[Dot(p,radius=.075,color=LAVENDER) for p in electron_points])
        labels=VGroup(formula(r'{}^7_3\mathrm{Li}',[-3.4,2.0,0],40,GOLD,width=3),
                      words('Нейтральный атом: 3 электрона',[-3.4,-2.55,0],22,LAVENDER,width=5.8))
        self.show(nucleus,labels,formula(r'Z=N_p=3',[3.1,1.65,0],34,ROSE),
                  formula(r'A=N_p+N_n=7',[3.1,.45,0],34),run_time=1.2)
        self.intro(2)
        self.act(2,FadeIn(electrons),Write(formula(r'N_n=A-Z=4',[3.1,-.75,0],34,CYAN)))
        self.show(formula(r'q_{\mathrm{ядра}}=Ze',[3.1,-2.0,0],33,GOLD),run_time=1.2)
        self.result(2)


class NuclearRadiations(QuantumScene):
    chapter_id=14

    def chapter(self):
        self.beat(0)
        names=VGroup(words('Три рассматриваемых вида ядерного излучения',[0,2.2,0],25,MUTED,width=12))
        rows=VGroup()
        specs=[(1.15,r'\alpha={}^4_2\mathrm{He}','Ядро гелия; заряд +2e',ROSE),
               (0,r'\beta^-:e^-\quad\beta^+:e^+','Электрон и позитрон; заряды −e и +e',CYAN),
               (-1.25,r'\gamma','Электромагнитное излучение; заряд 0',GOLD)]
        for y,tex,label,color in specs:
            rows.add(VGroup(formula(tex,[-3.55,y,0],34,color,width=5.2),
                            words(label,[3.0,y,0],25,width=6)))
        self.show(names,run_time=1.2);self.intro(0)
        self.act(0,LaggedStart(*[FadeIn(row) for row in rows],lag_ratio=.2))
        self.show(words('Позитрон имеет массу электрона и противоположный заряд',[0,-2.65,0],23,MUTED,width=12),run_time=1.2)
        self.result(0)

        self.beat(1)
        layers=VGroup(Rectangle(width=.13,height=3.5,color=MUTED,fill_color=MUTED,fill_opacity=.2).move_to([-4.15,0,0]),
                      Rectangle(width=.44,height=3.5,color=MUTED,fill_color=MUTED,fill_opacity=.2).move_to([-2.65,0,0]),
                      Rectangle(width=.8,height=3.5,color=MUTED,fill_color=MUTED,fill_opacity=.25).move_to([-1.1,0,0]))
        labels=VGroup(*[formula(tex,[-5.85,y,0],30,c,width=.7)
                        for tex,y,c in [(r'\alpha',1.1,ROSE),(r'\beta',0,CYAN),(r'\gamma',-1.1,GOLD)]])
        rays=VGroup(qd_ray([-5.4,1.1,0],[-4.23,1.1,0],ROSE),
                    qd_ray([-5.4,0,0],[-2.89,0,0],CYAN),
                    qd_ray([-5.4,-1.1,0],[-1.51,-1.1,0],GOLD),
                    qd_ray([-1.49,-1.1,0],[-.5,-1.1,0],GOLD).set_opacity(.38))
        self.show(layers,labels,words('Качественное сравнение',[3.1,1.8,0],27),
                  words(['Ослабление зависит от энергии,','материала и толщины экрана'],[3.1,.55,0],24,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,Create(rays))
        self.show(words(['α — обычно наименее проникающее','β — промежуточное','γ — ослабляется более протяжённым экраном'],[3.1,-1.5,0],22),
                  words('Схема не задаёт универсальную толщину защиты',[0,-2.65,0],23,GOLD,width=12),run_time=1.2)
        self.result(1)

        self.beat(2)
        field=VGroup()
        for x in (-4.7,-3.5,-2.3,-1.1):
            for y in (-.7,.7):
                field.add(VGroup(Line([x-.085,y-.085,0],[x+.085,y+.085,0],color=GRID,stroke_width=1.5),
                                 Line([x-.085,y+.085,0],[x+.085,y-.085,0],color=GRID,stroke_width=1.5)))
        alpha=Arc(radius=4.2,start_angle=-PI/2,angle=.9,color=ROSE,stroke_width=2.8).shift([-5.5,4.55,0]).add_tip(tip_length=.12)
        beta=Arc(radius=4.2,start_angle=PI/2,angle=-.9,color=CYAN,stroke_width=2.8).shift([-5.5,-4.55,0]).add_tip(tip_length=.12)
        gamma=Line([-5.5,0,0],[-.9,0,0],color=GOLD,stroke_width=2.8)
        labels=VGroup(formula(r'\alpha',[-1.55,1.75,0],28,ROSE,width=.5),
                      formula(r'\beta^-',[-1.55,-2.0,0],28,CYAN,width=.65),
                      formula(r'\gamma',[-.5,.25,0],28,GOLD,width=.5))
        self.show(field,words('v направлена вправо; B — в экран',[-3.2,2.35,0],22,MUTED,width=5.8),
                  words(['Положительная α отклоняется вверх','Отрицательная β⁻ — вниз'],[3.1,1.3,0],25),
                  words('Гамма не имеет заряда',[3.1,-.35,0],25,GOLD),run_time=1.2)
        self.intro(2)
        self.act(2,Create(alpha),Create(beta),Create(gamma),rate_func=linear)
        self.show(labels,words('Позитрон β⁺ отклонялся бы в сторону α',[3.1,-1.85,0],23,MUTED),run_time=1.2)
        self.result(2)


class MassDefectBinding(QuantumScene):
    chapter_id=15

    def chapter(self):
        self.beat(0)
        cluster=qd_cluster(7,3,[-3.35,-.35,0],.68,.27)
        repulsion=VGroup(qd_ray([-4.05,-.35,0],[-5.35,-.35,0],ROSE),
                         qd_ray([-2.65,-.35,0],[-1.35,-.35,0],ROSE))
        links=VGroup()
        for i,j in ((0,3),(0,4),(0,5),(0,6),(1,3),(1,5),(2,4),(2,6)):
            links.add(Line(cluster[i].get_center(),cluster[j].get_center(),color=GOLD,stroke_width=2).set_z_index(-1))
        self.show(cluster,words('Протоны электрически отталкиваются',[3.1,1.6,0],25,ROSE),
                  words('Схематическое ядро лития',[-3.35,-1.85,0],23,MUTED,width=5.6),run_time=1.2)
        self.intro(0)
        self.act(0,Create(repulsion),Create(links))
        self.show(words(['На малых ядерных расстояниях','сильное взаимодействие связывает нуклоны'],[3.1,-.45,0],24,GOLD),
                  words('Связанная система имеет меньшую полную энергию',[0,-2.7,0],24,MUTED,width=12),run_time=1.2)
        self.result(0)

        self.beat(1)
        center=np.array([-3.4,0.,0.]);angles=np.linspace(0,TAU,7,endpoint=False)
        free=VGroup(*[qd_dot(center+1.6*np.array([np.cos(a),np.sin(a),0]),j<3,.2) for j,a in enumerate(angles)])
        bound=qd_cluster(7,3,center,.45,.2)
        moves=[free[j].animate.move_to(bound[j].get_center()) for j in range(7)]
        self.show(free,words('3 свободных протона и 4 нейтрона',[-3.4,2.2,0],22,MUTED,width=5.8),
                  formula(r'm_{\mathrm{своб}}=3m_p+4m_n',[3.1,1.55,0],33),run_time=1.2)
        self.intro(1)
        self.act(1,*moves,Write(formula(r'm_{\mathrm{ядра}}<3m_p+4m_n',[3.1,.15,0],32,GOLD)))
        self.show(formula(r'\Delta m=3m_p+4m_n-m_{\mathrm{ядра}}',[3.1,-1.35,0],31,CYAN),
                  words('Сравниваются массы всей системы, а не изменения отдельных p и n',[0,-2.65,0],22,MUTED,width=12),run_time=1.2)
        self.result(1)

        self.beat(2)
        lower=Line([-5.6,-.65,0],[-1.35,-.65,0],color=CYAN,stroke_width=2.5)
        upper=Line([-5.6,1.1,0],[-1.35,1.1,0],color=MUTED,stroke_width=2.5)
        gap=DoubleArrow([-1.6,-.65,0],[-1.6,1.1,0],buff=0,color=GOLD,stroke_width=2,max_tip_length_to_length_ratio=.12)
        names=VGroup(words('Свободные нуклоны',[-3.5,1.65,0],24,MUTED,width=5),
                     words('Связанное ядро',[-3.5,-1.2,0],24,CYAN,width=5),
                     formula(r'E_{\mathrm{св}}',[-.8,.2,0],28,GOLD,width=.8))
        self.show(lower,upper,names,words('Энергия для разделения ядра',[3.1,1.75,0],25),run_time=1.2)
        self.intro(2)
        self.act(2,Create(gap),Write(formula(r'E_{\mathrm{св}}=\Delta m c^2',[3.1,.55,0],39,GOLD)))
        self.show(formula(r'E_{\mathrm{уд}}=\frac{E_{\mathrm{св}}}{A}',[3.1,-1.05,0],39,CYAN),
                  words('Удельная энергия связи — на один нуклон',[0,-2.6,0],25,MUTED,width=12),run_time=1.2)
        self.result(2)


class DecayHalfLifeGraphs(QuantumScene):
    chapter_id=16

    def chapter(self):
        self.beat(0)
        panels=VGroup();changes=[];labels=VGroup()
        for j,x in enumerate((-5.,-2.5,0.,2.5,5.)):
            dots=VGroup(*[Dot([x+(k%4-1.5)*.28,.3+(k//4-1.5)*.28,0],radius=.07,color=CYAN if j==0 else GRID) for k in range(16)])
            panels.add(dots)
            labels.add(formula('0' if j==0 else ('T' if j==1 else f'{j}T'),[x,1.5,0],27,MUTED,width=1.8))
            if j:
                changes.append(AnimationGroup(*[dots[k].animate.set_color(CYAN if k<16//2**j else MUTED) for k in range(16)]))
        amounts=VGroup(*[formula(tex,[x,-.85,0],29,GOLD,width=1.8) for x,tex in zip((-5.,-2.5,0.,2.5,5.),('N_0',r'N_0/2',r'N_0/4',r'N_0/8',r'N_0/16'))])
        self.show(panels,labels,words('Равные промежутки T — период полураспада',[0,2.35,0],25,width=12),run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(*changes,lag_ratio=.2),FadeIn(amounts))
        self.show(words(['Цветные точки — оставшиеся исходные ядра','Серые — продукты превращения; вещество не исчезает'],[0,-2.15,0],24,MUTED,width=12),run_time=1.2)
        self.result(0)

        self.beat(1)
        self.show(formula(r'k=\frac{t}{T}',[-3.1,1.45,0],44),
                  formula(r'N=\frac{N_0}{2^k}',[3.1,1.45,0],44),
                  words('Число оставшихся исходных ядер',[0,.2,0],25,MUTED,width=12),run_time=1.2)
        self.intro(1)
        self.act(1,Write(formula(r'N=N_0\,2^{-t/T}',[0,-1.0,0],48,GOLD,width=11.8)))
        self.show(words('Статистический закон для большого ансамбля',[0,-2.45,0],25,MUTED,width=12),run_time=1.2)
        self.result(1)

        self.beat(2)
        self.show(words('Масса исходного радионуклида',[-3.1,1.95,0],25,width=5.8),
                  words('Активность выбранного нуклида',[3.1,1.95,0],25,width=5.8),
                  formula(r'm=N m_A',[-3.1,.8,0],36),
                  words('Число распадов за единицу времени',[3.1,.8,0],24,MUTED),run_time=1.2)
        self.intro(2)
        self.act(2,Write(formula(r'm=m_0\,2^{-t/T}',[-3.1,-.4,0],38,CYAN)),
                 Write(formula(r'a=a_0\,2^{-t/T}',[3.1,-.4,0],38,GOLD)))
        self.show(words(['m — не масса всей пробы','с дочерними продуктами'],[-3.1,-1.8,0],23,MUTED),
                  formula(r'1\ \mathrm{Бк}=1\ \mathrm{распад/с}',[3.1,-1.8,0],28,MUTED),run_time=1.2)
        self.result(2)

        self.beat(3)
        left,remaining,lguide=qd_decay_plot([-3.25,-.15,0],False)
        right,decayed,rguide=qd_decay_plot([3.55,-.15,0],True)
        self.show(left,right,words('Осталось исходных ядер',[-3.1,2.1,0],25,CYAN,width=5.6),
                  words('Распалось исходных ядер',[3.55,2.1,0],25,GOLD,width=5.6),run_time=1.2)
        self.intro(3)
        self.act(3,Create(remaining),Create(decayed),rate_func=linear)
        self.show(lguide,rguide,formula(r'N_{\mathrm{расп}}=N_0-N',[0,-2.65,0],33,width=12),run_time=1.2)
        self.result(3)


class NuclearReactionsFission(QuantumScene):
    chapter_id=17

    def chapter(self):
        self.beat(0)
        balance=reaction_balance([(14,7),(4,2)],[(17,8),(1,1)])
        assert balance['conserved']
        reaction=formula(r'{}^{14}_{7}\mathrm N+{}^{4}_{2}\mathrm{He}\ \longrightarrow\ {}^{17}_{8}\mathrm O+{}^{1}_{1}\mathrm H',[0,1.4,0],40,width=12)
        self.show(reaction,words('Взаимодействие ядра с ядром или частицей',[0,2.35,0],23,MUTED,width=12),run_time=1.2)
        self.intro(0)
        self.act(0,Write(formula(r'A:\ 14+4=17+1=18',[-3.15,-.15,0],32,CYAN)),
                 Write(formula(r'Z:\ 7+2=8+1=9',[3.15,-.15,0],32,ROSE)))
        self.show(words(['Сохраняются электрический заряд, энергия и импульс','В данном примере сохраняется также число нуклонов'],[0,-1.9,0],25,GOLD,width=12),run_time=1.2)
        self.result(0)

        self.beat(1)
        left=RoundedRectangle(width=2.1,height=1.0,corner_radius=.12,color=CYAN).move_to([-3.3,.65,0])
        right=RoundedRectangle(width=2.1,height=1.0,corner_radius=.12,color=ROSE).move_to([3.1,.65,0])
        names=VGroup(words('Реакция',[-3.3,.65,0],24),words('Реакция',[3.1,.65,0],24),
                     words('Экзотермическая',[-3.3,1.8,0],25,CYAN),words('Эндотермическая',[3.1,1.8,0],25,ROSE))
        out=qd_ray([-2.2,.65,0],[-.8,.65,0],GOLD)
        inward=qd_ray([5.6,.65,0],[4.2,.65,0],GOLD)
        self.show(left,right,names,run_time=1.2);self.intro(1)
        self.act(1,Create(out),Create(inward),FadeIn(words('Энергия выделяется',[-3.3,-.4,0],24,GOLD)),
                 FadeIn(words('Энергия поглощается',[3.1,-.4,0],24,GOLD)))
        self.show(words(['Синтез — объединение лёгких ядер в более тяжёлые','На Солнце в цепочке превращений водород образует гелий'],[0,-1.95,0],24,MUTED,width=12),run_time=1.2)
        self.result(1)

        self.beat(2)
        assert reaction_balance([(235,92),(1,0)],[(92,36),(141,56),(1,0),(1,0),(1,0)])['conserved']
        origin=np.array([-.8,0.,0.]);ratio=92/141
        u=qd_species(235,92,'U',origin,.57)
        compound=qd_species(236,92,'U',origin,.6,LAVENDER)
        excited=formula('*',origin+[.63,.45,0],27,LAVENDER,width=.4)
        compound.add(excited)
        neutron=Dot([-5.9,0,0],radius=.08,color=CYAN)
        kr=qd_species(92,36,'Kr',origin+[-.65,.4,0],.48,ROSE)
        ba=qd_species(141,56,'Ba',origin+[.65*ratio,-.4*ratio,0],.48,GOLD)
        ns=VGroup(*[Dot(origin,radius=.07,color=CYAN) for _ in range(3)])
        kr_displacement=np.array([-2.5,1.25,0.]);ba_displacement=-ratio*kr_displacement
        n_displacements=[np.array([2.7,1.55,0]),np.array([2.7,-1.55,0]),np.array([-5.4,0.,0])]
        assert np.allclose(92*kr_displacement+141*ba_displacement,0)
        assert np.allclose(sum(n_displacements),0)
        self.show(u,neutron,words('Захват нейтрона → возбуждение → деление',[0,2.3,0],25,width=12),
                  words('Схема разлёта, не масштаб скоростей',[0,-2.05,0],22,MUTED,width=12),run_time=1.2)
        self.intro(2)
        capture=MoveAlongPath(neutron,Line([-5.9,0,0],origin))
        excited_step=AnimationGroup(FadeOut(neutron),FadeOut(u),FadeIn(compound))
        split=AnimationGroup(FadeOut(compound),FadeIn(kr),FadeIn(ba),FadeIn(ns))
        flight=AnimationGroup(kr.animate.move_to(origin+kr_displacement),ba.animate.move_to(origin+ba_displacement),
                              *[ns[j].animate.move_to(origin+n_displacements[j]) for j in range(3)])
        self.act(2,Succession(capture,excited_step,split,flight),rate_func=linear)
        self.show(formula(r'{}^{235}_{92}\mathrm U+{}^1_0n\to{}^{236}_{92}\mathrm U^*\to{}^{92}_{36}\mathrm{Kr}+{}^{141}_{56}\mathrm{Ba}+3{}^1_0n',[0,-2.6,0],29,width=12),
                  words(['A: 236 = 92 + 141 + 3','Z: 92 = 36 + 56'],[3.7,.3,0],22,MUTED,width=4.6),run_time=1.2)
        self.result(2)

        self.beat(3)
        boundary=DashedVMobject(Rectangle(width=6.8,height=3.6,stroke_width=1.3,color=GRID).move_to([-2.7,0,0]),num_dashes=48)
        first=Dot([-5.1,0,0],radius=.16,color=GOLD)
        target=qd_species(235,92,'U',[-2.1,.9,0],.4,LAVENDER)
        next_event=Dot([-2.1,.9,0],radius=.16,color=GOLD)
        rod=Rectangle(width=.18,height=3.15,color=ROSE,fill_color=ROSE,fill_opacity=.35).move_to([.3,0,0])
        primary=VGroup(*[Dot([-5.1,0,0],radius=.065,color=CYAN) for _ in range(3)])
        secondary=VGroup(*[Dot([-2.1,.9,0],radius=.065,color=CYAN) for _ in range(3)])
        pends=[[-2.1,.9,0],[.2,-.5,0],[-2.9,-1.8,0]]
        sends=[[.2,1.25,0],[-1.0,1.8,0],[-4.2,1.8,0]]
        paths=VGroup(*[qd_ray([-5.1,0,0],p,CYAN,1.6) for p in pends],
                     *[qd_ray([-2.1,.9,0],p,CYAN,1.6) for p in sends])
        self.show(boundary,first,target,rod,words('Конечный фрагмент цепи',[-2.9,2.2,0],24,MUTED,width=6.1),
                  words('Вторичные нейтроны могут вызвать новое деление',[3.65,1.4,0],24,width=4.9),
                  words('Стержень поглощает нейтроны',[3.65,-.05,0],24,ROSE,width=4.9),run_time=1.2)
        self.intro(3)
        born=FadeIn(primary)
        primary_flight=AnimationGroup(*[primary[i].animate.move_to(pends[i]) for i in range(3)],Create(VGroup(*paths[:3])))
        next_birth=AnimationGroup(FadeOut(primary),FadeOut(target),FadeIn(next_event),FadeIn(secondary))
        secondary_flight=AnimationGroup(*[secondary[i].animate.move_to(sends[i]) for i in range(3)],Create(VGroup(*paths[3:])))
        completed=FadeOut(secondary)
        self.act(3,Succession(born,primary_flight,next_birth,secondary_flight,completed),rate_func=linear)
        self.show(words('Часть нейтронов поглощается или выходит из области',[3.65,-1.45,0],23,GOLD,width=4.9),
                  words('Графит замедляет; регулирующий поглотитель уменьшает продолжение цепи',[0,-2.65,0],22,MUTED,width=12),run_time=1.2)
        self.result(3)
