"""Source-based duality, photons, Bohr states and spectra: photo PDF pp1–7."""
from quantum_style import *
from quantum_math import hydrogen_energy_ev


def qa_ray(start, end, color=CYAN, width=2.2):
    return Arrow(start, end, buff=0, color=color, stroke_width=width,
                 tip_length=.12, max_tip_length_to_length_ratio=.18)


def qa_aperture(y, half_width, spread=False):
    wall_x, screen_x = -4.4, -1.05
    wall = VGroup(Line([wall_x, y-.72, 0], [wall_x, y-half_width, 0], color=INK, stroke_width=3),
                  Line([wall_x, y+half_width, 0], [wall_x, y+.72, 0], color=INK, stroke_width=3))
    screen = Line([screen_x, y-.8, 0], [screen_x, y+.8, 0], color=MUTED, stroke_width=2)
    incoming = VGroup(*[qa_ray([-5.95, y+a, 0], [wall_x, y+a, 0])
                        for a in (-.55, 0, .55)])
    if spread:
        outgoing = VGroup(*[Arc(radius=r, start_angle=-.22, angle=.44,
                                color=GOLD, stroke_width=1.8).shift([wall_x, y, 0])
                           for r in (.55, 1.25, 1.95, 2.65, 3.35)])
    else:
        outgoing = VGroup(*[qa_ray([wall_x, y+a, 0], [screen_x, y+a, 0], GOLD)
                           for a in (-.24, 0, .24)])
    return VGroup(wall, screen), VGroup(incoming, outgoing)


def qa_slits():
    wall_x, screen_x, gap = -3.9, -1.05, .65
    wall = VGroup(Line([wall_x, -1.65, 0], [wall_x, -gap-.12, 0], color=INK, stroke_width=3),
                  Line([wall_x, -gap+.12, 0], [wall_x, gap-.12, 0], color=INK, stroke_width=3),
                  Line([wall_x, gap+.12, 0], [wall_x, 1.65, 0], color=INK, stroke_width=3))
    source = VGroup(Dot([-5.65, 0, 0], radius=.075, color=CYAN),
                    words('Электроны', [-5.35, -1.9, 0], 21, CYAN, width=2.2))
    screen = Line([screen_x, -1.65, 0], [screen_x, 1.65, 0], color=MUTED, stroke_width=2)
    names = VGroup(words('Две щели', [-3.9, 2.05, 0], 22, MUTED, width=2),
                   words('Экран', [-1.05, 2.05, 0], 22, MUTED, width=1.3))
    return VGroup(wall, source, screen, names)


def qa_two_slit_fronts():
    fronts = VGroup()
    for cy, color in ((.65, CYAN), (-.65, ROSE)):
        for radius in (.45, 1.25, 2.05, 2.85):
            angles = np.linspace(-1.15, 1.15, 121)
            points = []
            for theta in angles:
                point = np.array([-3.9+radius*np.cos(theta), cy+radius*np.sin(theta), 0])
                if -1.65 <= point[1] <= 1.65 and point[0] <= -1.05:
                    points.append(point)
                elif points:
                    if len(points)>1:
                        fronts.add(VMobject(color=color, stroke_width=1.3).set_points_as_corners(points))
                    points=[]
            if len(points)>1:
                fronts.add(VMobject(color=color, stroke_width=1.3).set_points_as_corners(points))
    return fronts


def qa_screen_distribution(coherent=True):
    """Qualitative probability profile; hidden common geometry, no numerical task."""
    strips = VGroup()
    for y in np.linspace(-1.55, 1.55, 53):
        l1 = np.hypot(2.85, y-.65)
        l2 = np.hypot(2.85, y+.65)
        envelope = 1/(1+(y/2.4)**2)
        intensity = envelope*(np.cos(PI*(l2-l1)/.8)**2 if coherent else .5)
        strips.add(Line([-.95, y, 0], [-.7, y, 0], color=GOLD,
                        stroke_width=3, stroke_opacity=.04+.94*float(intensity)))
    return strips


def qa_levels_ground():
    zero_y = 2.
    scale = 4.4/13.6
    ys = {n: zero_y+scale*hydrogen_energy_ev(n) for n in range(1, 5)}
    zero = Line([-3.8, zero_y, 0], [-.65, zero_y, 0], color=MUTED, stroke_width=1.3)
    ground = Line([-3.8, ys[1], 0], [-.65, ys[1], 0], color=ROSE, stroke_width=2)
    axis = qa_ray([-3.98, -2.65, 0], [-3.98, 2.25, 0], MUTED, 1.3)
    labels = VGroup(formula(r'E,\ \mathrm{эВ}', [-2.3, 2.36, 0], 23, MUTED, width=1.8),
                    formula('0', [-.8, 2.22, 0], 22, MUTED, width=.3),
                    formula('n=1', [-5.95, ys[1], 0], 22, ROSE, width=.9),
                    formula(r'-13{,}6', [-4.9, ys[1], 0], 22, ROSE, width=.9),
                    Line([-4.35, ys[1], 0], [-4.12, ys[1], 0], color=ROSE, stroke_width=1))
    return VGroup(axis, zero, ground, labels), ys


def qa_levels_excited(ys):
    drawings = VGroup()
    for n, label_y, energy in ((2, .62, r'-3{,}4'),
                               (3, 1.22, r'-1{,}51'),
                               (4, 2.13, r'-0{,}85')):
        drawings.add(Line([-3.8, ys[n], 0], [-.65, ys[n], 0], color=CYAN, stroke_width=2),
                     formula(f'n={n}', [-5.95, label_y, 0], 22, CYAN, width=.9),
                     formula(energy, [-4.95, label_y, 0], 22, CYAN, width=.95),
                     Line([-4.35, label_y, 0], [-4.12, ys[n], 0], color=CYAN, stroke_width=1))
    return drawings


def qa_spectrum_frame(y):
    return Rectangle(width=5.1, height=.6, color=GRID, stroke_width=1.2,
                     fill_color=INK, fill_opacity=.025).move_to([-3.25, y, 0])


def qa_spectrum_lines(y, bands=False):
    palette = ['#8A4FFF', '#496BFF', '#58DCE6', '#F17C55']
    centers = (-5.55, -4.75, -3.15, -.95)
    if bands:
        return VGroup(*[Rectangle(width=w, height=.52, color=c, stroke_width=0,
                                  fill_color=c, fill_opacity=.9).move_to([x, y, 0])
                         for x,w,c in zip(centers,(.42,.62,.48,.52),palette)])
    return VGroup(*[Line([x, y-.26, 0], [x, y+.26, 0], color=c, stroke_width=4)
                     for x,c in zip(centers,palette)])


class WaveParticleDuality(QuantumScene):
    chapter_id = 1

    def chapter(self):
        self.beat(0)
        big, ray = qa_aperture(1., .4)
        small, wave = qa_aperture(-1.15, .1, True)
        self.show(big, small,
                  words('Большая апертура', [-3.25, 2.1, 0], 23, CYAN),
                  words('Малая апертура', [-3.25, -.08, 0], 23, GOLD),
                  words(['Корпускулярно-волновой дуализм',
                         'Разные проявления одного объекта'], [3.1, 1.2, 0], 25),
                  words('Размер отверстия сравнивают с длиной волны', [3.1, -.4, 0], 23, MUTED), run_time=1.2)
        self.intro(0)
        self.act(0, Create(ray), Create(wave))
        self.show(words(['Широкая апертура: удобно лучевое приближение',
                         'Узкая апертура: заметнее дифракция'], [3.1, -1.9, 0], 23, GOLD), run_time=1.2)
        self.result(0)

        self.beat(1)
        self.show(qa_slits(),
                  words(['Волновые свойства электронов',
                         'Гипотеза де Бройля'], [3.1, 1.35, 0], 26),
                  words(['Путь через щели не регистрируется',
                         'Амплитуды двух путей складываются'], [3.1, -.1, 0], 23, MUTED), run_time=1.2)
        self.intro(1)
        self.act(1, Create(qa_two_slit_fronts()), FadeIn(qa_screen_distribution(True)))
        self.show(words(['Схема вероятностей попадания',
                         'Интерференционные полосы'], [3.1, -1.8, 0], 25, GOLD), run_time=1.2)
        self.result(1)

        self.beat(2)
        profile = qa_screen_distribution(True)
        detectors = VGroup(*[RoundedRectangle(width=.42, height=.42, corner_radius=.06,
                              color=LAVENDER, stroke_width=2,
                              fill_color=LAVENDER, fill_opacity=.16).move_to([-3.42, y, 0])
                             for y in (-.65,.65)])
        self.show(qa_slits(), profile,
                  words(['Регистрируем, через какую щель прошёл электрон',
                         'Измерительный прибор взаимодействует с системой'], [3.1, 1.2, 0], 24), run_time=1.2)
        self.intro(2)
        self.act(2, FadeIn(detectors),
                 Succession(FadeOut(profile), FadeIn(qa_screen_distribution(False))))
        self.show(words(['Интерференционный контраст исчезает',
                         'Схема суммы двух вкладов'], [3.1, -1.6, 0], 24, GOLD), run_time=1.2)
        self.result(2)


class PhotonEnergyMomentumPressure(QuantumScene):
    chapter_id = 2

    def chapter(self):
        self.beat(0)
        portions = VGroup(*[VGroup(Circle(radius=.27,color=CYAN,stroke_width=2).move_to([x,.6,0]),
                                    formula('E', [x,.6,0], 24, CYAN, width=.4))
                            for x in (-5.1,-3.3,-1.5)])
        self.show(words(['Кванты одной частоты', 'Условная схема порций энергии'], [-3.3, 1.9, 0], 24),
                  formula(r'E=h\nu', [3.1, 1.6, 0], 43),
                  formula(r'\nu=\frac{c}{\lambda}', [3.1, .25, 0], 39),
                  words('λ и c относятся к вакууму', [3.1, -1.05, 0], 23, MUTED), run_time=1.2)
        self.intro(0)
        self.act(0, LaggedStart(*[FadeIn(q) for q in portions],lag_ratio=.2),
                 Write(formula(r'E=\frac{hc}{\lambda}', [3.1, -2.15, 0], 43, GOLD)))
        self.show(formula(r'h\approx6{,}6\cdot10^{-34}\ \mathrm{Дж}\cdot\mathrm{с}', [-3.3, -1.4, 0], 30, MUTED, width=5.4), run_time=1.2)
        self.result(0)

        self.beat(1)
        photon = Dot([-4.5,.25,0],radius=.12,color=GOLD)
        momentum = qa_ray([-4.5,.25,0],[-2.1,.25,0],GOLD,3)
        self.show(photon,
                  words('Фотон переносит энергию и импульс', [-3.25,1.8,0], 24, width=5.6),
                  formula('E=pc', [3.1, 1.5, 0], 44),
                  formula(r'E=h\nu', [3.1,.2,0], 41), run_time=1.2)
        self.intro(1)
        self.act(1, Create(momentum),
                 Write(formula(r'p=\frac{h\nu}{c}=\frac{h}{\lambda}', [3.1,-1.5,0], 41, GOLD)))
        self.show(formula(r'\vec p',[-3.3,.85,0],30,GOLD,width=.6),
                  words('Импульс направлен по распространению света',[-3.3,-1.3,0],23,MUTED), run_time=1.2)
        self.result(1)

        self.beat(2)
        plate=Rectangle(width=.18,height=2.6,color=INK,stroke_width=2,
                        fill_color=INK,fill_opacity=.06).move_to([-2.2,0,0])
        packet=Dot([-5.65,0,0],radius=.085,color=GOLD)
        force=qa_ray([-2.05,-.7,0],[-1.4,-.7,0],ROSE,3)
        self.show(plate,packet,qa_ray([-5.65,.9,0],[-3.6,.9,0],GOLD),
                  formula(r'\vec p',[-4.65,1.3,0],28,GOLD,width=.6),
                  words('Поглотитель',[-2.2,1.85,0],23,MUTED,width=2.5),
                  words(['Нормальное падение', '+x вдоль падающего света'],[3.1,1.5,0],25),
                  formula(r'p_{\mathrm{перед}}=p',[3.1,.1,0],38), run_time=1.2)
        self.intro(2)
        self.act(2, Succession(MoveAlongPath(packet,Line([-5.65,0,0],[-2.2,0,0]),
                                             run_time=3.,rate_func=linear),
                                FadeOut(packet,run_time=.4),Create(force,run_time=1.6),
                                rate_func=linear),rate_func=linear)
        self.show(formula(r'F_{\mathrm{погл}}=\frac{pN}{\Delta t}',[3.1,-1.5,0],39,ROSE),
                  formula('F',[-1.7,-1.2,0],26,ROSE,width=.5),
                  words('N фотонов за время Δt',[-3.5,-2.1,0],23,MUTED), run_time=1.2)
        self.result(2)

        self.beat(3)
        plate=Rectangle(width=.18,height=2.6,color=INK,stroke_width=2,
                        fill_color=MUTED,fill_opacity=.5).move_to([-2.2,0,0])
        packet=Dot([-5.65,0,0],radius=.085,color=GOLD)
        force=qa_ray([-2.05,-.7,0],[-.75,-.7,0],ROSE,3)
        self.show(plate,packet,
                  qa_ray([-5.65,.95,0],[-3.6,.95,0],GOLD),
                  formula(r'p_{\mathrm{до}}=+p',[-4.65,1.4,0],27,GOLD,width=2.8),
                  words('Идеальный отражатель',[-2.2,1.95,0],22,MUTED,width=3.3),
                  words(['Тот же поток фотонов', 'Нормальное обратное отражение'],[3.1,1.5,0],25),
                  formula(r'p_{\mathrm{перед}}=2p',[3.1,.1,0],38), run_time=1.2)
        self.intro(3)
        self.act(3, Succession(MoveAlongPath(packet,Line([-5.65,0,0],[-2.2,0,0]),
                                             run_time=2.,rate_func=linear),
                                AnimationGroup(MoveAlongPath(packet,Line([-2.2,0,0],[-5.65,0,0]),
                                                               run_time=2.,rate_func=linear),
                                               Create(force,run_time=2.),rate_func=linear),
                                FadeOut(packet,run_time=1.),rate_func=linear),rate_func=linear)
        self.show(qa_ray([-3.6,-.7,0],[-5.65,-.7,0],CYAN),
                  formula(r'p_{\mathrm{после}}=-p',[-4.65,-1.3,0],26,CYAN,width=2.9),
                  formula(r'F_{\mathrm{отр}}=\frac{2pN}{\Delta t}=2F_{\mathrm{погл}}',[3.1,-1.6,0],34,ROSE),
                  words('Опыт Лебедева: свет оказывает давление',[0,-2.6,0],23,MUTED,width=12), run_time=1.2)
        self.result(3)


class BohrStatesHydrogen(QuantumScene):
    chapter_id = 3

    def chapter(self):
        self.beat(0)
        center=np.array([-3.25,0,0])
        classical=VGroup(Circle(radius=1.2,color=MUTED,stroke_width=1.6).move_to(center),
                         Dot(center,radius=.095,color=ROSE),Dot(center+RIGHT*1.2,radius=.065,color=CYAN),
                         words('Планетарная модель',[-3.25,1.95,0],24,MUTED))
        levels=VGroup(*[Line([-4.7,y,0],[-1.8,y,0],color=CYAN,stroke_width=2) for y in (.8,0,-.8)],
                      Dot([-3.25,-.8,0],radius=.065,color=GOLD),
                      words('Стационарные состояния',[-3.25,1.95,0],24,CYAN),
                      words('Схема состояний, не в масштабе',[-3.25,-2.05,0],22,MUTED))
        self.show(classical,
                  words(['Классически ускоренный заряд излучает',
                         'Модель не объясняет устойчивость атома'],[3.1,1.25,0],24),run_time=1.2)
        self.intro(0)
        self.act(0,Succession(FadeOut(classical),FadeIn(levels)))
        self.show(words(['Постулат Бора', 'В стационарном состоянии атом не излучает'],[3.1,-1.1,0],25,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        ground,ys=qa_levels_ground()
        self.show(ground,
                  formula(r'E_n=-\frac{13{,}6}{n^2}\ \mathrm{эВ}',[3.1,1.45,0],39),
                  formula(r'n=1,2,3,\ldots',[3.1,.2,0],30,MUTED),run_time=1.2)
        self.intro(1)
        self.act(1,Write(formula(r'1\ \mathrm{эВ}\approx1{,}6\cdot10^{-19}\ \mathrm{Дж}',[3.1,-1.,0],33,GOLD)))
        self.show(words(['Основное состояние: n = 1',
                         'Связанные уровни приближаются к нулю снизу'],[3.1,-2.25,0],22,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        bars=VGroup(Line([-5.3,1.15,0],[-.9,1.15,0],color=CYAN,stroke_width=2),
                    Line([-5.3,-1.2,0],[-.9,-1.2,0],color=CYAN,stroke_width=2),
                    formula('E_n',[-5.95,1.15,0],27,CYAN,width=.8),
                    formula('E_m',[-5.95,-1.2,0],27,CYAN,width=.8))
        down=qa_ray([-4.25,1.15,0],[-4.25,-1.2,0],ROSE)
        up=qa_ray([-1.85,-1.2,0],[-1.85,1.15,0],GOLD)
        self.show(bars,words('Схема двух переходов',[-3.2,2.1,0],24,MUTED),
                  formula(r'h\nu=|E_n-E_m|',[3.1,1.15,0],41),
                  words('Разность энергий положительна для фотона',[3.1,-.25,0],23,MUTED),run_time=1.2)
        self.intro(2)
        self.act(2,Create(down),Create(up))
        self.show(words('Излучение',[-4.25,-2.1,0],23,ROSE,width=2.3),
                  words('Поглощение',[-1.85,-2.1,0],23,GOLD,width=2.5),
                  words(['Переход вниз — отдача энергии',
                         'Переход вверх — получение энергии'],[3.1,-1.65,0],24),run_time=1.2)
        self.result(2)


class TransitionsAndSpectra(QuantumScene):
    chapter_id = 4

    def chapter(self):
        self.beat(0)
        ground,ys=qa_levels_ground()
        self.show(ground,formula(r'E_n=-\frac{13{,}6}{n^2}\ \mathrm{эВ}',[3.1,1.5,0],38),
                  words(['Первые четыре уровня водорода',
                         'Одна линейная энергетическая шкала'],[3.1,.0,0],25),run_time=1.2)
        self.intro(0)
        self.act(0,FadeIn(qa_levels_excited(ys)))
        self.show(words(['При росте n уровни сближаются',
                         'Числа на схеме округлены'],[3.1,-1.8,0],24,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        scale=4.4/13.6;ys={n:2.+scale*hydrogen_energy_ev(n) for n in range(1,5)}
        base=VGroup(Line([-4.7,2,0],[5.65,2,0],color=MUTED,stroke_width=1.2),
                    formula('0',[-4.7,2.3,0],23,MUTED,width=.3))
        for n,label_y in ((1,ys[1]),(2,.62),(3,1.22),(4,2.13)):
            base.add(Line([-4.7,ys[n],0],[5.65,ys[n],0],color=CYAN,stroke_width=1.5),
                     formula(f'n={n}',[-5.9,label_y,0],23,CYAN,width=1),
                     Line([-5.2,label_y,0],[-4.9,ys[n],0],color=CYAN,stroke_width=1))
        transitions=((2,1),(3,1),(4,1),(3,2),(4,2),(4,3))
        arrows=VGroup();names=VGroup()
        for j,((start,end),x) in enumerate(zip(transitions,(-3.55,-1.95,-.35,1.25,2.85,4.45)),1):
            color=ROSE if end==1 else GOLD
            arrows.add(Arrow([x,ys[start],0],[x,ys[end],0],buff=0,color=color,
                             stroke_width=2,tip_length=.11,
                             max_tip_length_to_length_ratio=.28))
            names.add(formula(rf'\nu_{j}',[x,2.36,0],26,color,width=.6))
        self.show(base,names,run_time=1.2)
        self.intro(1)
        self.act(1,LaggedStart(*[Create(a) for a in arrows],lag_ratio=.12))
        self.show(formula(r'h\nu=E_{\mathrm{нач}}-E_{\mathrm{кон}}>0',[0,-2.9,0],27,GOLD,width=11.8),run_time=1.2)
        self.result(1)

        self.beat(2)
        self.show(qa_spectrum_frame(.75),qa_spectrum_frame(-1.25),
                  words('Линейчатый спектр',[-3.25,1.5,0],23,CYAN),
                  words('Полосатый спектр',[-3.25,-.5,0],23,GOLD),
                  words(['Возбуждённый разреженный атомный газ',
                         'H, He, Ne, Ar, Xe, Kr'],[3.1,1.4,0],24),
                  words('Молекулярный газ, например H₂',[3.1,-.1,0],24,MUTED),run_time=1.2)
        self.intro(2)
        self.act(2,Create(qa_spectrum_lines(.75)),FadeIn(qa_spectrum_lines(-1.25,True)))
        self.show(words('Качественные схемы спектров',[-3.25,-2.35,0],22,MUTED),
                  words(['Характерные частоты связаны',
                         'с энергетическими переходами'],[3.1,-1.8,0],25,GOLD),run_time=1.2)
        self.result(2)

        self.beat(3)
        gradient=VGroup(*[Rectangle(width=5.1/100+.005,height=.6,stroke_width=0,
                                     fill_color=color,fill_opacity=1).move_to([-5.8+(i+.5)*5.1/100,.8,0])
                           for i,color in enumerate(color_gradient(['#8A4FFF','#496BFF','#58DCE6','#64D86B','#FFD071','#F17C55'],100))])
        frames=VGroup(qa_spectrum_frame(.8),
                      Rectangle(width=3.6,height=.38,color=GRID,stroke_width=1).move_to([-2.55,-.85,0]),
                      Rectangle(width=3.6,height=.38,color=GRID,stroke_width=1).move_to([-2.55,-1.75,0]))
        lines=VGroup(*[Line([x,y-.14,0],[x,y+.14,0],color=c,stroke_width=3)
                       for y in (-.85,-1.75) for x,c in ((-3.7,CYAN),(-2.55,GOLD),(-1.3,ROSE))])
        self.show(frames,words('Сплошной спектр: схема диапазона',[-3.25,1.7,0],22,MUTED),
                  words('Образец',[-5.2,-.85,0],21,MUTED,width=1.1),
                  words('Эталон',[-5.2,-1.75,0],21,MUTED,width=1.1),
                  words(['Нагретое плотное вещество',
                         'Интенсивность меняется по спектру'],[3.1,1.3,0],25),run_time=1.2)
        self.intro(3)
        self.act(3,FadeIn(gradient),LaggedStart(*[Create(l) for l in lines],lag_ratio=.15))
        self.show(words(['Спектральный анализ',
                         'Сравниваем характерные линии и полосы'],[3.1,-1.1,0],25,GOLD),
                  words('Сопоставляются положения линий, а не общая яркость',[0,-2.75,0],23,MUTED,width=12),run_time=1.2)
        self.result(3)
