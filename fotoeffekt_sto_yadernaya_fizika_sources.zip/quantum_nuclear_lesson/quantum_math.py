"""Scalar physics for the two supplied quantum/relativity/nuclear notes."""
import math


def _positive(*values):
    if not all(math.isfinite(x) and x > 0 for x in values):
        raise ValueError('Positive finite values required')


def photon_quantities(wavelength_m, h=6.6e-34, c=3e8):
    """Vacuum wavelength, one photon's energy and momentum magnitude in SI."""
    _positive(wavelength_m, h, c)
    frequency = c / wavelength_m
    return dict(frequency=frequency, energy=h*frequency, momentum=h/wavelength_m)


def hydrogen_energy_ev(n):
    """Bound hydrogen levels in the source's Bohr model; zero at ionization."""
    if not isinstance(n, int) or isinstance(n, bool) or n < 1:
        raise ValueError('Positive integer principal quantum number required')
    return -13.6 / n**2


def photoelectric(photon_energy, work_function, e=1.6e-19):
    """One-photon ideal threshold; Kmax is INITIAL and Ustop a positive magnitude.

    At threshold Kmax=0 does not assert a nonzero collected current. Below
    threshold no emitted electron's kinetic energy or stopping voltage exists.
    """
    _positive(work_function, e)
    if not math.isfinite(photon_energy) or photon_energy < 0:
        raise ValueError('Nonnegative finite photon energy required')
    allowed = photon_energy >= work_function
    kinetic = photon_energy-work_function if allowed else None
    return dict(allowed=allowed, kinetic_max=kinetic,
                stopping_voltage=kinetic/e if allowed else None,
                threshold=photon_energy == work_function)


def light_clock(beta, height=1., c=1.):
    """One-way transverse light flight in rest/lab frames; same height.

    c=1 is allowed for internal schematic coordinates. t1 is the flight
    interval in the apparatus frame, not proper time between the distinct
    emission/reflection positions. A full round trip doubles both intervals.
    """
    _positive(height, c)
    if not math.isfinite(beta) or abs(beta) >= 1:
        raise ValueError('Subluminal finite beta required')
    gamma = 1 / math.sqrt((1-beta)*(1+beta))
    t1 = height/c
    t2 = gamma*t1
    return dict(gamma=gamma, t1=t1, t2=t2, horizontal=beta*c*t2,
                path=c*t2, vertical=height, speed=c, v=beta*c)


def nuclide(A, Z, e=1.6e-19):
    """Composition of a nucleus; neutral-atom electron count is separately named."""
    if not all(isinstance(x, int) and not isinstance(x, bool) for x in (A, Z)):
        raise ValueError('Integer A and Z required')
    if A < 1 or not 0 <= Z <= A:
        raise ValueError('A>=1 and 0<=Z<=A required')
    _positive(e)
    return dict(A=A, Z=Z, protons=Z, neutrons=A-Z,
                electrons_neutral=Z, charge=Z*e)


def decay_fraction(t, half_life):
    """Expected surviving fraction of the ORIGINAL radionuclide."""
    _positive(half_life)
    if not math.isfinite(t) or t < 0:
        raise ValueError('Nonnegative finite elapsed time required')
    return 2**(-t/half_life)


def reaction_balance(reactants, products):
    """Check source reaction A/Z sums; pairs are (mass number, charge number)."""
    a_left = sum(x[0] for x in reactants)
    z_left = sum(x[1] for x in reactants)
    a_right = sum(x[0] for x in products)
    z_right = sum(x[1] for x in products)
    return dict(A_left=a_left, Z_left=z_left, A_right=a_right, Z_right=z_right,
                conserved=a_left == a_right and z_left == z_right)


def mass_defect(A, Z, nucleus_mass, mp=1.673e-27, mn=1.675e-27):
    """Free-nucleon sum MINUS the mass of the complete bound nucleus.

    Do not substitute a neutral atomic mass without accounting for electrons.
    No individual nucleon's invariant mass is changed by this bookkeeping.
    """
    composition = nuclide(A, Z)
    _positive(nucleus_mass, mp, mn)
    return composition['protons']*mp + composition['neutrons']*mn - nucleus_mass


def binding_energy(defect, c=3e8):
    """Energy needed to separate a bound nucleus into free resting nucleons."""
    _positive(c)
    if not math.isfinite(defect) or defect < 0:
        raise ValueError('Nonnegative finite bound-state mass defect required')
    return defect*c**2
