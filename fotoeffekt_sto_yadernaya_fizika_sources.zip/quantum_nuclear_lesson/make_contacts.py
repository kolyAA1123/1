"""Sample every theoretical state and the middle of every completed action."""
from pathlib import Path
import argparse,json,subprocess
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent

def contacts(preview=True,chapter_ids=None):
    plan=json.loads((ROOT/'plan.json').read_text())
    dest=ROOT/'output'/('contacts' if preview else 'contacts_final');dest.mkdir(parents=True,exist_ok=True)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
    for ch in plan['chapters']:
        if chapter_ids and ch['id'] not in chapter_ids:continue
        clip=ROOT/'output'/('preview_chapters' if preview else 'chapters')/f"{ch['id']:02d}_{ch['class']}.mp4"
        sheet=Image.new('RGB',(1200,len(ch['beats'])*250),(22,26,33));draw=ImageDraw.Draw(sheet)
        for i,b in enumerate(ch['beats']):
            stamps=[b['intro_at']+.5,b['action_at']+b['action_seconds']/2,b['result_at']+.5]
            for col,t in enumerate(stamps):
                data=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(clip),'-frames:v','1','-vf','scale=400:225','-f','image2pipe','-vcodec','mjpeg','pipe:1'])
                import io
                frame=Image.open(io.BytesIO(data)).convert('RGB');sheet.paste(frame,(col*400,i*250))
                draw.text((col*400+5,i*250+227),f"{ch['id']:02d}.{i+1} {['theory','action','result'][col]} @ {t:.1f}s",font=font,fill='white')
        path=dest/f"{ch['id']:02d}.jpg";sheet.save(path,quality=92)
        print(path,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');p.add_argument('--chapters',nargs='*',type=int);a=p.parse_args();contacts(not a.final,a.chapters)
