"""Conditional exact H264 black padding; original packets are preserved.

Only the two measured Manim/toolchain encodings are accepted. An unknown
AVC extradata hash raises ValueError so callers can keep full re-encoding.
"""
from pathlib import Path
import json, subprocess, tempfile


def _json(args):
    return json.loads(subprocess.check_output(args))


def _probe(path):
    return _json(['ffprobe','-v','error','-show_streams','-show_format',
                  '-show_data_hash','sha256','-of','json',str(path)])


def _packets(path):
    return _json(['ffprobe','-v','error','-show_packets','-select_streams','v',
                  '-show_data_hash','sha256','-show_entries',
                  'packet=pts,dts,duration,data_hash','-of','json',str(path)])['packets']


def _run(args):
    result = subprocess.run(args, check=True, capture_output=True, text=True)
    if result.stderr.strip():
        raise ValueError(result.stderr)


def pad_black_copy(source, destination, missing_frames):
    """Append1–5black frames, preserving every original packet and timestamp."""
    source=Path(source).resolve();destination=Path(destination).resolve()
    assert source!=destination and 1<=missing_frames<=5
    report=_probe(source)
    if len(report['streams'])!=1:raise ValueError('Expected exactly one silent video stream')
    stream=report['streams'][0]
    if (stream['codec_name'],stream['width'],stream['height'],stream['pix_fmt'],
        stream['avg_frame_rate'],stream['time_base'],stream['profile'],stream['level'])!=('h264',1920,1080,'yuv420p','60/1','1/15360','High',42):
        raise ValueError('Unsupported stream parameters; keep proven full re-encoding')
    # Requirement is that only already-black holding frames are extended.
    pixels=subprocess.check_output(['ffmpeg','-v','error','-sseof','-0.05','-i',str(source),
        '-frames:v','1','-vf','scale=160:90,format=rgb24','-f','rawvideo','pipe:1'])
    if not pixels or max(pixels)!=0:raise ValueError('Source ending must already be pure black')
    original=_packets(source)
    with tempfile.TemporaryDirectory(prefix='black-copy-',dir=destination.parent) as temp:
        temp=Path(temp);raw=temp/'black.mp4';tail=temp/'black-delay.mp4'
        for preset,crf in [('medium',23),('veryfast',18)]:
            _run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=black:s=1920x1080:r=60',
                  '-vf','setsar=0','-frames:v',str(missing_frames),'-an','-c:v','libx264',
                  '-preset',preset,'-crf',str(crf),'-threads','2','-pix_fmt','yuv420p',
                  '-profile:v','high','-level:v','4.2','-video_track_timescale','15360',str(raw)])
            if _probe(raw)['streams'][0]['extradata_hash']==stream['extradata_hash']:break
        else:raise ValueError('No identical SPS/PPS profile; keep full re-encoding')
        first,tail_first=original[0],_packets(raw)[0]
        correction=(first['pts']-first['dts'])-(tail_first['pts']-tail_first['dts'])
        if correction<0:raise ValueError('Unexpected DTS delay')
        if correction:
            _run(['ffmpeg','-v','error','-y','-i',str(raw),'-c','copy',
                  '-bsf:v',f'setts=dts=DTS-{correction}',str(tail)])
        else:tail=raw
        listing=temp/'concat.txt'
        # Paths are local generated names; concat escaping also covers apostrophes.
        quote=lambda p:str(p).replace("'", "'\\''")
        listing.write_text(f"file '{quote(source)}'\nfile '{quote(tail)}'\n")
        output=temp/'padded.mp4'
        _run(['ffmpeg','-v','warning','-y','-f','concat','-safe','0','-auto_convert','0',
              '-i',str(listing),'-map','0:v:0','-c','copy','-an','-movflags','+faststart',str(output)])
        padded=_packets(output);new=_probe(output)['streams'][0]
        if padded[:len(original)]!=original:raise ValueError('An original packet or timestamp changed')
        if len(padded)!=len(original)+missing_frames:raise ValueError('Frame count mismatch')
        if new['avg_frame_rate']!='60/1':raise ValueError('Frame rate mismatch')
        if int(new['duration_ts'])!=int(stream['duration_ts'])+missing_frames*256:raise ValueError('Duration mismatch')
        if any(b['dts']-a['dts']!=256 for a,b in zip(padded,padded[1:])):raise ValueError('DTS discontinuity')
        if sorted(p['pts'] for p in padded)!=list(range(0,len(padded)*256,256)):raise ValueError('PTS discontinuity')
        output.replace(destination)
    return {'frames_added':missing_frames,'dts_correction_ticks':correction,
            'original_packets_sha256_and_timestamps_preserved':True,'fps':'60/1'}
