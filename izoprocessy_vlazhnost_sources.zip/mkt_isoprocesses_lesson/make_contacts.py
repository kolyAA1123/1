"""Extract the completed state of each beat for visual label review."""
from pathlib import Path
from PIL import Image, ImageDraw
import argparse
import io
import json
import subprocess

ROOT = Path(__file__).resolve().parent


def make_contact(chapter, final=False):
    directory = 'chapters' if final else 'preview_chapters'
    clip = ROOT / 'output' / directory / f"{chapter['id']:02d}_{chapter['class']}.mp4"
    output = ROOT / 'output' / f"contact_{chapter['id']:02d}{'_final' if final else ''}.png"
    if output.exists() and output.stat().st_mtime > clip.stat().st_mtime:
        return output
    canvas = Image.new('RGB', (1440, 584), '#141414')
    draw = ImageDraw.Draw(canvas)
    times = [t - .6 for t in chapter['beats'][1:]] + [chapter['duration'] - 1.5]
    for index, stamp in enumerate(times):
        raw = subprocess.check_output([
            'ffmpeg', '-v', 'error', '-ss', str(stamp), '-i', str(clip),
            '-frames:v', '1', '-vf', 'scale=480:270',
            '-f', 'image2pipe', '-vcodec', 'png', 'pipe:1',
        ])
        x, y = (index % 3) * 480, (index // 3) * 292
        canvas.paste(Image.open(io.BytesIO(raw)), (x, y))
        draw.text((x + 6, y + 273), f"{chapter['id']}.{index+1} @ {stamp:.2f}s", fill='white')
    canvas.save(output)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('chapters', nargs='*', type=int)
    parser.add_argument('--final', action='store_true')
    args = parser.parse_args()
    plan = json.loads((ROOT / 'plan.json').read_text())
    for chapter in plan['chapters']:
        if not args.chapters or chapter['id'] in args.chapters:
            print(make_contact(chapter, args.final), flush=True)
