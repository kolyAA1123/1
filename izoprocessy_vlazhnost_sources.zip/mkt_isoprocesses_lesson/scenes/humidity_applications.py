"""Humidity applications from supplied PDF, pp. 5–8.

Coordinates and particle counts are qualitative drawing choices, not additional
numerical examples. Heat-flow arrows show the sign of exchange with skin;
their lengths are not a quantitative calorimetric balance.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gas_style import *


def words(lines, center, size=24, color=INK, width=5.35):
    result = VGroup(*[txt(line, size, color) for line in lines]).arrange(DOWN, buff=.18)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result.move_to(center)


def formula(tex, center, size=34, color=INK, width=5.35):
    result = eq(tex, size, color)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result.move_to(center)


def person(center, scale=1.0):
    """A schematic silhouette; arrows are kept away from its head."""
    head = Circle(radius=.23, color=GOLD, stroke_width=2).move_to([0, .8, 0])
    torso = Line([0, .49, 0], [0, -.5, 0], color=INK, stroke_width=11)
    arms = VGroup(*[
        Line([0, .32, 0], [sign*.57, -.23, 0], color=INK, stroke_width=8)
        for sign in (-1, 1)
    ])
    legs = VGroup(*[
        Line([0, -.46, 0], [sign*.35, -1.2, 0], color=INK, stroke_width=9)
        for sign in (-1, 1)
    ])
    return VGroup(head, torso, arms, legs).scale(scale).move_to(center)


def particle_paths(scene, routes, run_time=5.0):
    """Complete every route before dissolving its tracer at the endpoint."""
    particles, paths = [], []
    for start, control, end, color in routes:
        paths.append(CubicBezier(np.array(start), np.array(control),
                                 np.array(control), np.array(end)))
        particles.append(Dot(start, radius=.065, color=color))
    scene.show(*particles, run_time=.35)
    scene.play(*[MoveAlongPath(p, path) for p, path in zip(particles, paths)],
               run_time=run_time, rate_func=smooth)
    scene.play(*[FadeOut(p) for p in particles], run_time=.45)


def heat_pair(center_x, center_y=-.35, scale=1.0, condensation=True):
    """Separated arrows and text: outgoing −Q left, incoming +Q right."""
    c = np.array([center_x, center_y, 0.0])
    outgoing = arrow(c+[-.55*scale, -.38*scale, 0],
                     [-1.18*scale, .68*scale, 0], CYAN)
    out_name = formula('-Q', c+[-1.65*scale, .68*scale, 0],
                       31*scale, CYAN, 1.1)
    group = VGroup(outgoing, out_name)
    if condensation:
        incoming = arrow(c+[1.75*scale, .88*scale, 0],
                         [-1.15*scale, -.76*scale, 0], ROSE)
        in_name = formula('+Q', c+[1.72*scale, 1.25*scale, 0],
                          31*scale, ROSE, 1.1)
        group.add(incoming, in_name)
    return group


def bath_panel(x, wet=True):
    frame = RoundedRectangle(width=5.35, height=4.65, corner_radius=.12,
                             stroke_width=1.6, color=GRID).move_to([x, -.1, 0])
    heading = words(['Русская баня' if wet else 'Сухая сауна'],
                    [x, 1.98, 0], 25, GOLD, 4.8)
    state = words(['Высокая влажность' if wet else 'Низкая влажность'],
                  [x, 1.35, 0], 22, ROSE if wet else CYAN, 4.8)
    human = person([x, -.35, 0], .78)
    heat = heat_pair(x, -.35, .88, condensation=wet)
    # Particles stay in a band above the silhouette and below the state label.
    vapor = VGroup(*[Dot([x+dx, .95, 0], radius=.055, color=LAVENDER)
                     for dx in ((-2.15, -1.1, -.45, .45, .9, 2.25)
                                if wet else (-1.75, 1.75))])
    result = words(['Испарение затруднено' if wet else 'Испарение пота облегчено'],
                   [x, -2.03, 0], 22, INK, 4.85)
    return VGroup(frame, heading, state, human, heat, vapor, result)


class EvaporationCooling(ChapterScene):
    chapter_id = 10

    def chapter(self):
        self.beat(0, 'Испарение отводит тепло от кожи, конденсация возвращает тепло')
        left, right, top, bottom = -5.8, -1.0, 2.08, -2.16
        walls = VGroup(
            Line([left, top, 0], [right, top, 0], color=GRID),
            Line([right, top, 0], [right, bottom, 0], color=GRID),
            Line([right, bottom, 0], [left, bottom, 0], color=GRID),
            Line([left, top, 0], [left, -.1, 0], color=GRID),
            Line([left, -1.9, 0], [left, bottom, 0], color=GRID),
        )
        door = Line([left, -1.9, 0], [left, -.1, 0], color=MUTED, stroke_width=3)
        human = person([-3.4, -.4, 0], .9)
        room_name = words(['Закрытая влажная комната'], [-3.4, 2.45, 0], 22, GOLD, 5.2)
        vapor = VGroup(*[Dot([x, y, 0], radius=.055, color=LAVENDER)
                         for x, y in [(-5.25, 1.65), (-4.55, 1.3), (-3.7, 1.7),
                                      (-2.9, 1.55), (-1.6, 1.7), (-1.55, -.85),
                                      (-2.1, -1.72), (-4.7, -1.7), (-5.2, -.85)]])
        heat = heat_pair(-3.4, -.4, .94)
        notes = VGroup(
            words(['Вода испаряется', 'с поверхности кожи'], [3.0, 1.55, 0], 26, CYAN),
            words(['Испарение забирает тепло'], [3.0, .47, 0], 23, CYAN),
            words(['Пар конденсируется', 'на поверхности кожи'], [3.0, -.62, 0], 26, ROSE),
            words(['Конденсация отдаёт тепло'], [3.0, -1.72, 0], 23, ROSE),
        )
        self.show(walls, door, human, room_name, vapor, run_time=1.3)
        self.show(heat, notes, run_time=1.0)
        particle_paths(self, [
            ([-3.9, -.72, 0], [-4.35, -.1, 0], [-5.05, .02, 0], CYAN),
            ([-1.8, .36, 0], [-2.1, .15, 0], [-2.9, -.35, 0], ROSE),
        ], 6.0)

        self.beat(1, 'Приток сухого воздуха уменьшает конденсацию и усиливает охлаждение')
        replacement = VGroup(
            words(['Открываем дверь'], [3.0, 1.7, 0], 28, GOLD),
            words(['Приходит более сухой воздух'], [3.0, .78, 0], 23),
            words(['Меньше конденсации', 'на поверхности кожи'], [3.0, -.35, 0], 25, ROSE),
            words(['Испарение эффективнее', 'отводит тепло'], [3.0, -1.67, 0], 25, CYAN),
        )
        new_name = words(['Приток более сухого воздуха'], [-3.4, 2.45, 0], 22, GOLD, 5.2)
        self.play(FadeOut(notes), Transform(room_name, new_name),
                  Rotate(door, -PI/4, about_point=np.array([left, -1.9, 0])), run_time=1.7)
        self.show(replacement, run_time=.8)
        particle_paths(self, [
            ([-4.65, -.55, 0], [-5.45, -.3, 0], [-6.15, -.45, 0], LAVENDER),
            ([-4.45, -1.45, 0], [-5.45, -1.05, 0], [-6.15, -1.25, 0], LAVENDER),
        ], 4.7)
        # Removing this arrow is a qualitative reduction, not a claim that no
        # condensation occurs or that the two initial heat rates were equal.
        reduced = VGroup(heat[0].copy(), heat[1].copy(),
                         heat[2].copy().set_opacity(.22), heat[3].copy().set_opacity(.22))
        self.play(Transform(heat, reduced), FadeOut(vapor[0]), FadeOut(vapor[1]),
                  FadeOut(vapor[4]), FadeOut(vapor[5]), run_time=1.2)
        particle_paths(self, [
            ([-3.95, -.8, 0], [-4.4, -.3, 0], [-5.1, -.1, 0], CYAN),
        ], 4.0)

        self.beat(2, 'При высокой влажности испарительное охлаждение затруднено')
        self.clear_stage()
        wet = bath_panel(-3.12, True)
        explanation = VGroup(
            words(['Вода на горячих камнях', 'увеличивает влажность'], [3.1, 1.2, 0], 26, GOLD),
            words(['Испаряющаяся вода', 'забирает тепло у кожи'], [3.1, -.1, 0], 25, CYAN),
            words(['Высокая влажность', 'затрудняет испарение'], [3.1, -1.6, 0], 25, ROSE),
        )
        self.show(wet, explanation, run_time=1.5)
        particle_paths(self, [
            ([-3.55, -.65, 0], [-4.0, -.2, 0], [-4.5, -.05, 0], CYAN),
            ([-1.55, .15, 0], [-2.0, -.1, 0], [-2.6, -.3, 0], ROSE),
        ], 6.0)

        self.beat(3, 'В сухом воздухе испарение пота облегчено')
        self.clear_stage(keep=(wet,))
        dry = bath_panel(3.12, False)
        self.show(dry, run_time=1.5)
        particle_paths(self, [
            ([2.7, -.65, 0], [2.1, -.2, 0], [1.5, -.05, 0], CYAN),
            ([3.65, -.9, 0], [4.25, -.8, 0], [4.9, -.25, 0], CYAN),
        ], 6.0)

        self.beat(4, 'Сравнение завершено: влажность влияет на испарительное охлаждение')
        # Each tracer reaches its endpoint; neither panel is cut off mid-flow.
        particle_paths(self, [
            ([-3.55, -.65, 0], [-4.0, -.2, 0], [-4.5, -.05, 0], CYAN),
            ([-1.55, .15, 0], [-2.0, -.1, 0], [-2.6, -.3, 0], ROSE),
            ([2.7, -.65, 0], [2.1, -.2, 0], [1.5, -.05, 0], CYAN),
        ], 6.0)
        scheme = words(['Учебная схема теплообмена'], [0, -2.74, 0], 18, MUTED, 11)
        self.show(scheme, run_time=.8)


class DewPoint(ChapterScene):
    chapter_id = 11

    def chapter(self):
        self.beat(0, 'Без добавления влаги нагрев при неизменном объёме уменьшает φ')
        box = Rectangle(width=4.45, height=3.05, color=GRID,
                        stroke_width=2).move_to([-3.45, -.2, 0])
        fixed = formula(r'm=\mathrm{const},\quad V=\mathrm{const}',
                        [-3.45, 2.05, 0], 29, GOLD, 5)
        coordinates = [(-4.95, .65), (-3.8, .7), (-2.4, .62),
                       (-4.6, -.35), (-3.25, -.4), (-1.9, -.55),
                       (-4.9, -1.12), (-3.7, -1.2), (-2.5, -1.05)]
        molecules = VGroup(*[Dot([x, y, 0], radius=.065, color=CYAN)
                             for x, y in coordinates])
        notes = VGroup(
            words(['Влагу не добавляем'], [3.0, 1.8, 0], 26, GOLD),
            formula(r'\rho=\frac{m}{V}=\mathrm{const}', [3.0, .8, 0], 36),
            formula(r'T\uparrow\quad\Rightarrow\quad\rho_{\mathrm{н}}\uparrow',
                    [3.0, -.35, 0], 36, ROSE),
            formula(r'\varphi=\frac{\rho}{\rho_{\mathrm{н}}}\,100\%\quad\downarrow',
                    [3.0, -1.67, 0], 37, CYAN),
        )
        heat = arrow([-3.45, -2.63, 0], [0, .56, 0], ROSE)
        heat_name = words(['Нагрев'], [-4.65, -2.35, 0], 22, ROSE, 1.55)
        self.show(box, fixed, molecules, notes, heat, heat_name, run_time=1.4)
        # Closed little loops preserve both particle count and volume.
        paths = [Circle(radius=.17).move_to(p.get_center()+LEFT*.17)
                 for p in molecules]
        self.play(*[MoveAlongPath(p, path) for p, path in zip(molecules, paths)],
                  run_time=5.5, rate_func=linear)
        self.play(molecules.animate.set_color(GOLD), run_time=1.2)

        self.beat(1, 'При постоянных температуре и массе пара сжатие повышает φ')
        self.clear_stage()
        left, initial_right, final_right = -5.7, -1.2, -3.9
        top, bottom = 1.35, -1.6
        piston = Line([initial_right, bottom, 0], [initial_right, top, 0],
                      color=GOLD, stroke_width=5)
        walls = VGroup(Line([left, bottom, 0], [initial_right, bottom, 0], color=GRID),
                       Line([left, top, 0], [initial_right, top, 0], color=GRID),
                       Line([left, bottom, 0], [left, top, 0], color=GRID))
        particles = VGroup(*[Dot([x, y, 0], radius=.065, color=CYAN)
                             for x, y in [(-5.15, .8), (-4.0, .8), (-2.5, .8),
                                          (-4.85, -.1), (-3.6, -.15), (-1.8, -.1),
                                          (-5.2, -1.0), (-3.95, -1.0), (-2.4, -1.0)]])
        fixed = formula(r'T=\mathrm{const},\quad m=\mathrm{const}',
                        [-3.45, 2.05, 0], 29, GOLD, 5.2)
        notes = VGroup(
            formula(r'V\downarrow', [3.0, 1.45, 0], 40, GOLD),
            formula(r'\rho=\frac{m}{V}\uparrow', [3.0, .35, 0], 40),
            formula(r'\varphi=\frac{\rho}{\rho_{\mathrm{н}}}\,100\%\uparrow',
                    [3.0, -.93, 0], 37, CYAN),
        )
        state = words(['Ненасыщенный пар'], [-3.45, -2.32, 0], 23, MUTED, 5.1)
        self.show(walls, piston, particles, fixed, notes, state, run_time=1.3)
        ratio = (final_right-left)/(initial_right-left)
        self.play(piston.animate.shift(LEFT*(initial_right-final_right)),
                  *[p.animate.move_to([left+(p.get_x()-left)*ratio, p.get_y(), 0])
                    for p in particles], run_time=6.0, rate_func=smooth)
        saturated = words(['Достигнуто насыщение'], [-3.45, -2.32, 0], 23, CYAN, 5.1)
        self.play(Transform(state, saturated), run_time=.7)
        self.show(formula(r'\varphi=100\%', [3.0, -2.17, 0], 35, CYAN), run_time=.8)

        self.beat(2, 'На холодной бутылке конденсат появляется при Tповерхности ниже точки росы')
        self.clear_stage()
        bottle_outline = VMobject(color=CYAN, stroke_width=2.5)
        bottle_outline.set_points_as_corners([
            [-4.23, -1.68, 0], [-4.23, .35, 0], [-3.85, .85, 0],
            [-3.85, 1.25, 0], [-3.2, 1.25, 0], [-3.2, .85, 0],
            [-2.82, .35, 0], [-2.82, -1.68, 0], [-4.23, -1.68, 0],
        ])
        water = Rectangle(width=1.32, height=1.6, color=CYAN,
                          fill_color=CYAN, fill_opacity=.14, stroke_opacity=0).move_to([-3.525, -.83, 0])
        cap = Line([-3.91, 1.31, 0], [-3.14, 1.31, 0], color=GOLD, stroke_width=4)
        temperatures = VGroup(
            formula(r'T_{\mathrm{комн}}=25^\circ\mathrm{C}', [-3.5, 2.15, 0], 31, GOLD, 5.0),
            formula(r'T_{\mathrm{бут}}=5^\circ\mathrm{C}', [-3.5, -2.3, 0], 31, CYAN, 5.0),
        )
        condition = VGroup(
            words(['Конденсат появляется, если'], [3.0, 1.65, 0], 25, GOLD),
            formula(r'5^\circ\mathrm{C}<T_{\mathrm{росы}}', [3.0, .62, 0], 38, CYAN),
            words(['Поверхность холоднее', 'точки росы окружающего воздуха'],
                  [3.0, -.63, 0], 24, INK),
            words(['Вода собирается снаружи бутылки'], [3.0, -1.85, 0], 22, MUTED),
        )
        self.show(bottle_outline, water, cap, temperatures, condition, run_time=1.4)
        starts = [np.array([-5.55, .15, 0]), np.array([-1.15, -.7, 0]),
                  np.array([-5.25, -1.3, 0]), np.array([-1.35, .55, 0])]
        ends = [np.array([-4.27, .1, 0]), np.array([-2.78, -.67, 0]),
                np.array([-4.27, -1.15, 0]), np.array([-2.83, .3, 0])]
        arriving = VGroup(*[Dot(p, radius=.065, color=LAVENDER) for p in starts])
        self.show(arriving, run_time=.35)
        self.play(*[p.animate.move_to(end) for p, end in zip(arriving, ends)],
                  run_time=5.5, rate_func=smooth)
        drops = VGroup(*[Ellipse(width=.09, height=.19, color=CYAN,
                                fill_color=CYAN, fill_opacity=.85, stroke_width=1).move_to(p)
                         for p in ends])
        self.play(Transform(arriving, drops), run_time=.8)

        self.beat(3, 'Точка росы — температура насыщения при неизменном парциальном давлении')
        self.clear_stage()
        ax = axes(x_range=(0, 5.2, 1), y_range=(0, 5.2, 1), width=5.05,
                  height=3.4, center=np.array([-3.6, -.35, 0]))
        ax.x_axis.ticks.set_opacity(0); ax.y_axis.ticks.set_opacity(0)
        labels = VGroup(eq('T', 28, MUTED).next_to(ax.x_axis, RIGHT, buff=.15),
                        eq('p', 28, MUTED).next_to(ax.y_axis, UP, buff=.12))
        curve = ax.plot(lambda t: .15*t*t+.65, x_range=[0, 5.1], color=GOLD, stroke_width=3)
        saturation = formula(r'p_{\mathrm{н}}(T)', ax.c2p(4.15, 4.1), 25, GOLD, 1.4)
        fixed_p = Line(ax.c2p(3, 2), ax.c2p(5, 2), color=CYAN, stroke_width=3)
        guide = DashedLine(ax.c2p(3, 0), ax.c2p(3, 2), color=LAVENDER,
                           stroke_width=1.7, dash_length=.07)
        dew_name = formula(r'T_{\mathrm{росы}}', ax.c2p(3, 0)+DOWN*.4, 26, LAVENDER, 1.8)
        moving = Dot(ax.c2p(5, 2), radius=.075, color=CYAN)
        cooling = arrow(ax.c2p(4.8, 1.5), ax.c2p(3.2, 1.5)-ax.c2p(4.8, 1.5), CYAN, 2)
        cool_name = words(['Охлаждение'], [-3.6, 2.2, 0], 23, CYAN, 4.8)
        notes = VGroup(
            formula(r'p=\mathrm{const}', [3.0, 1.65, 0], 39, CYAN),
            words(['Пар становится насыщенным'], [3.0, .65, 0], 25),
            formula(r'p=p_{\mathrm{н}}(T_{\mathrm{росы}})', [3.0, -.5, 0], 36, GOLD),
            formula(r'\varphi=100\%', [3.0, -1.75, 0], 39, LAVENDER),
        )
        self.show(ax, labels, notes, run_time=1.1)
        self.show(curve, create=True, run_time=2.5)
        self.show(saturation, fixed_p, moving, cooling, cool_name, run_time=.8)
        self.play(moving.animate.move_to(ax.c2p(3, 2)), run_time=5.0, rate_func=smooth)
        self.show(guide, dew_name, run_time=.8)

        self.beat(4, 'В равновесной модели после насыщения выпадает конденсат')
        self.clear_stage()
        window = Rectangle(width=2.25, height=3.35, color=CYAN,
                           fill_color=CYAN, fill_opacity=.07, stroke_width=3).move_to([-3.5, -.25, 0])
        cross = VGroup(Line([-3.5, -1.925, 0], [-3.5, 1.425, 0], color=GRID, stroke_width=3),
                       Line([-4.625, -.25, 0], [-2.375, -.25, 0], color=GRID, stroke_width=3))
        condition = formula(r'T_{\mathrm{окна}}<T_{\mathrm{росы}}', [-3.5, 2.15, 0], 30, GOLD, 5.25)
        window_name = words(['Холодное окно'], [-3.5, -2.45, 0], 24, CYAN, 5.0)
        notes = VGroup(
            words(['Охлаждение до насыщения'], [3.0, 1.75, 0], 25, GOLD),
            formula(r'\varphi\leq100\%', [3.0, .6, 0], 43, CYAN),
            words(['В равновесной модели задач'], [3.0, -.42, 0], 23, MUTED),
            words(['Дальнейшее охлаждение:', 'выпадает конденсат'], [3.0, -1.7, 0], 25),
        )
        self.show(window, cross, condition, window_name, notes, run_time=1.3)
        destinations = [(-4.1, .85), (-2.8, .62), (-4.0, -1.1), (-2.95, -.9)]
        particles = VGroup(*[Dot([x+1.15, y+.2, 0], radius=.06, color=LAVENDER)
                             for x, y in destinations])
        self.show(particles, run_time=.35)
        self.play(*[p.animate.move_to([x, y, 0])
                    for p, (x, y) in zip(particles, destinations)],
                  run_time=5.5, rate_func=smooth)
        drops = VGroup(*[Ellipse(width=.1, height=.21, color=CYAN,
                                fill_color=CYAN, fill_opacity=.85, stroke_width=1).move_to([x, y, 0])
                         for x, y in destinations])
        self.play(Transform(particles, drops), run_time=.8)
