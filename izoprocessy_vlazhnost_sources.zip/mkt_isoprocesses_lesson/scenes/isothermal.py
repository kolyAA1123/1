"""Ideal-gas variables and isotherms, drawn only from source pp. 2–4.

All unlabelled coordinates below set the layout of qualitative diagrams. They
are not numerical physical examples. Curves and moving states stay positive.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gas_style import *


def formula(tex, center, size=35, color=INK, width=11.8):
    result = eq(tex, size, color)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result.move_to(center)


def words(lines, center, size=24, color=INK, width=5.7):
    result = VGroup(*[txt(line, size, color) for line in lines]).arrange(DOWN, buff=.18)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result.move_to(center)


def qualitative_axes(center, width=5.0, height=3.6, horizontal='V', vertical='p'):
    """No numerical ticks: the PDF supplies no numerical diagram data."""
    ax = axes(x_range=(0, 5, 1), y_range=(0, 4, 1),
              width=width, height=height, center=np.array(center))
    ax.x_axis.ticks.set_opacity(0)
    ax.y_axis.ticks.set_opacity(0)
    x_label = eq(horizontal, 28, MUTED).next_to(ax.x_axis, RIGHT, buff=.14)
    y_label = eq(vertical, 28, MUTED).next_to(ax.y_axis, UP, buff=.13)
    return ax, VGroup(ax, x_label, y_label)


def state_mark(ax, volume, pressure, index, color):
    point = ax.c2p(volume, pressure)
    dot = Dot(point, radius=.06, color=color)
    guides = VGroup(
        DashedLine(ax.c2p(volume, 0), point, color=color, stroke_width=1.5, dash_length=.06),
        DashedLine(ax.c2p(0, pressure), point, color=color, stroke_width=1.5, dash_length=.06),
    )
    name = eq(str(index), 25, color).move_to(point + UP * .27 + RIGHT * .23)
    v_label = eq(rf'V_{index}', 25, color).move_to(ax.c2p(volume, 0) + DOWN * .30)
    p_label = eq(rf'p_{index}', 25, color).move_to(ax.c2p(0, pressure) + LEFT * .35)
    return VGroup(dot, guides, name, v_label, p_label)


class GasStateVariables(ChapterScene):
    chapter_id = 1

    def chapter(self):
        self.beat(0, 'Четыре параметра связаны уравнением состояния')
        cards = VGroup()
        variables = [
            ('p', ['давление'], CYAN),
            ('V', ['объём'], GOLD),
            (r'\nu', ['количество', 'вещества'], LAVENDER),
            ('T', ['абсолютная', 'температура'], ROSE),
        ]
        for x, (symbol, definition, color) in zip((-4.5, -1.5, 1.5, 4.5), variables):
            frame = RoundedRectangle(width=2.65, height=1.9, corner_radius=.10,
                                     color=GRID, stroke_width=1.5).move_to([x, 1.1, 0])
            letter = formula(symbol, [x, 1.55, 0], 48, color, 2.2)
            label = words(definition, [x, .7, 0], 23, INK, 2.35)
            cards.add(VGroup(frame, letter, label))
        self.show(cards, run_time=1.4)
        equation = formula(r'pV=\nu RT', [0, -1.05, 0], 53)
        temperature_unit = formula(r'T\;\text{— в кельвинах}', [0, -2.15, 0], 29, MUTED)
        self.show(equation, temperature_unit, run_time=1.2)

        self.beat(1, 'Во всех трёх случаях количество вещества неизменно')
        self.clear_stage()
        fixed_amount = formula(r'\nu=\mathrm{const}', [0, 1.55, 0], 51, LAVENDER)
        definition = words(['«Изо» — величина остаётся постоянной'], [0, .25, 0], 30, INK, 11.5)
        remaining = words(['Дополнительно фиксируем одну из величин'], [0, -1.0, 0], 26, MUTED, 11.5)
        candidates = formula(r'T\qquad p\qquad V', [0, -2.0, 0], 42, GOLD)
        self.show(fixed_amount, definition, run_time=1.0)
        self.show(remaining, candidates, run_time=1.0)

        self.beat(2, 'Три изопроцесса: T, p или V постоянны')
        self.clear_stage()
        headings = VGroup(
            txt('Процесс', 19, MUTED).move_to([-3.8, 2.35, 0]),
            txt('Постоянно', 19, MUTED).move_to([.3, 2.35, 0]),
        )
        self.show(headings, run_time=.7)
        rows = VGroup()
        row_specs = [
            ('Изотермический', r'T,\nu=\mathrm{const}', CYAN),
            ('Изобарический', r'p,\nu=\mathrm{const}', GOLD),
            ('Изохорический', r'V,\nu=\mathrm{const}', ROSE),
        ]
        for y, (name, condition, color) in zip((1.45, .1, -1.25), row_specs):
            frame = RoundedRectangle(width=12, height=1.03, corner_radius=.08,
                                     color=GRID, stroke_width=1.2).move_to([0, y, 0])
            label = txt(name, 24, color).move_to([-3.8, y, 0])
            constant = formula(condition, [.3, y, 0], 31, color, 3.05)
            row = VGroup(frame, label, constant)
            rows.add(row)
            self.show(row, run_time=.9)

        self.beat(3, 'У каждого процесса изменяются два оставшихся параметра')
        changes_heading = txt('Изменяются', 19, MUTED).move_to([4.2, 2.35, 0])
        self.show(changes_heading, run_time=.7)
        varying = VGroup()
        for row, y, symbols, color in zip(rows, (1.45, .1, -1.25),
                                          (r'p,\;V', r'V,\;T', r'p,\;T'),
                                          (CYAN, GOLD, ROSE)):
            pair = formula(symbols, [4.2, y, 0], 34, color, 2.6)
            varying.add(pair)
            self.show(pair, run_time=.8)
            self.play(Indicate(row[1], color=color, scale_factor=1.04), run_time=.8)

        self.beat(4, 'Ненулевое количество идеального газа; положительная абсолютная T')
        positive = formula(r'\nu>0,\quad T>0\qquad\Rightarrow\qquad p>0,\;V>0',
                           [0, -2.45, 0], 29, MUTED)
        self.show(positive, run_time=1.2)


class IsothermalLaw(ChapterScene):
    chapter_id = 2

    def chapter(self):
        self.beat(0, 'Изотермический процесс: T и ν постоянны')
        conditions = formula(r'T=\mathrm{const}\qquad\nu=\mathrm{const}', [0, 1.65, 0], 39, GOLD)
        initial_equation = formula(r'pV=\nu RT', [0, -.05, 0], 55)
        statement = words(['Правая часть постоянна'], [0, -1.55, 0], 29, MUTED, 10)
        self.show(conditions, run_time=1.0)
        self.show(initial_equation, statement, run_time=1.2)

        self.beat(1, 'Определяем c = νRT и получаем обратную пропорциональность')
        self.clear_stage(keep=(conditions,))
        c_definition = formula(r'c=\nu RT=\mathrm{const}', [0, .45, 0], 40, GOLD)
        product = formula(r'pV=c', [0, -.6, 0], 42)
        inverse = formula(r'p=\frac{c}{V}', [0, -1.9, 0], 49, CYAN)
        self.show(c_definition, run_time=1.0)
        self.show(product, run_time=1.0)
        self.show(inverse, run_time=1.0)

        self.beat(2, 'Положительная ветвь гиперболы и первое состояние газа')
        self.clear_stage()
        ax, chart = qualitative_axes([-3.05, 0, 0], width=5.0, height=3.6)
        curve = ax.plot(lambda v: 4 / v, x_range=(1.12, 4.7), color=CYAN, stroke_width=3.2)
        state1 = state_mark(ax, 1.4, 4 / 1.4, 1, GOLD)
        rhs = VGroup(
            formula(r'p=\frac{c}{V}', [3.25, 1.3, 0], 47, CYAN, 5.2),
            formula(r'T,\nu=\mathrm{const}', [3.25, .0, 0], 33, GOLD, 5.2),
            formula(r'p>0,\quad V>0', [3.25, -1.1, 0], 31, MUTED, 5.2),
            words(['Шкалы условные'], [3.25, -2.15, 0], 23, MUTED, 5.2),
        )
        self.show(chart, create=True, run_time=1.2)
        self.show(curve, create=True, run_time=3.0)
        self.show(state1, rhs, run_time=1.2)

        self.beat(3, 'Полный переход по одной изотерме: V растёт, p уменьшается')
        self.clear_stage(keep=(chart, curve, state1))
        volume = ValueTracker(1.4)
        moving = always_redraw(lambda: Dot(ax.c2p(volume.get_value(), 4 / volume.get_value()),
                                          radius=.065, color=ROSE))
        guides = always_redraw(lambda: VGroup(
            DashedLine(ax.c2p(volume.get_value(), 0),
                       ax.c2p(volume.get_value(), 4 / volume.get_value()),
                       color=ROSE, stroke_width=1.5, dash_length=.06),
            DashedLine(ax.c2p(0, 4 / volume.get_value()),
                       ax.c2p(volume.get_value(), 4 / volume.get_value()),
                       color=ROSE, stroke_width=1.5, dash_length=.06),
        ))
        self.show(guides, moving, run_time=.8)
        self.play(volume.animate.set_value(4.0), run_time=5.8, rate_func=smooth)
        freeze(guides, moving)
        final_name = eq('2', 25, ROSE).move_to(ax.c2p(4, 1) + UP * .31 + RIGHT * .10)
        final_v = eq(r'V_2', 25, ROSE).move_to(ax.c2p(4, 0) + DOWN * .30)
        final_p = eq(r'p_2', 25, ROSE).move_to(ax.c2p(0, 1) + LEFT * .35)
        state2_labels = VGroup(final_name, final_v, final_p)
        products = VGroup(
            formula(r'p_1V_1=c', [3.25, 1.25, 0], 39, GOLD, 5.2),
            formula(r'p_2V_2=c', [3.25, .1, 0], 39, ROSE, 5.2),
            formula(r'V_2>V_1,\quad p_2<p_1', [3.25, -1.3, 0], 33, INK, 5.4),
        )
        self.show(state2_labels, products, run_time=1.0)

        self.beat(4, 'Закон Бойля — Мариотта: переход завершён')
        self.clear_stage(keep=(chart, curve, state1, guides, moving, state2_labels))
        law = VGroup(
            words(['Закон', 'Бойля — Мариотта'], [3.25, 1.45, 0], 28, INK, 5.4),
            formula(r'p_1V_1=p_2V_2', [3.25, -.05, 0], 43, CYAN, 5.4),
            formula(r'T,\nu=\mathrm{const}', [3.25, -1.25, 0], 34, GOLD, 5.4),
            words(['Оба конечных состояния отмечены'], [3.25, -2.25, 0], 22, MUTED, 5.4),
        )
        self.show(law, run_time=1.3)


class IsothermalDiagrams(ChapterScene):
    chapter_id = 3

    def chapter(self):
        self.beat(0, 'Две температуры; количество вещества одинаково')
        ax_pv, panel_pv = qualitative_axes([-4.3, -.3, 0], width=3.2, height=2.8)
        pv_title = txt('p–V', 23, INK).move_to([-4.3, 2.28, 0])
        legend = VGroup(eq(r'T_1', 28, CYAN).move_to([-4.9, 1.86, 0]),
                        eq(r'T_2', 28, GOLD).move_to([-3.7, 1.86, 0]))
        low_curve = ax_pv.plot(lambda v: 3 / v, x_range=(1.1, 4.6), color=CYAN, stroke_width=3)
        high_curve = ax_pv.plot(lambda v: 5 / v, x_range=(1.4, 4.6), color=GOLD, stroke_width=3)
        condition = VGroup(
            formula(r'T_1<T_2', [2.0, 1.2, 0], 44, INK, 6),
            formula(r'\nu=\mathrm{const}', [2.0, -.1, 0], 35, LAVENDER, 6),
            words(['Большей T соответствует', 'более высокая изотерма'], [2.0, -1.5, 0], 26, MUTED, 6),
        )
        self.show(panel_pv, pv_title, legend, create=True, run_time=1.2)
        self.show(low_curve, create=True, run_time=2.0)
        self.show(high_curve, create=True, run_time=2.0)
        self.show(condition, run_time=1.2)

        self.beat(1, 'При одном V на верхней изотерме давление больше')
        self.play(FadeOut(condition), run_time=.8)
        common_v = 2.3
        p_low, p_high = 3 / common_v, 5 / common_v
        comparison = VGroup(
            DashedLine(ax_pv.c2p(common_v, 0), ax_pv.c2p(common_v, 3.55),
                       color=MUTED, stroke_width=1.4, dash_length=.06),
            Dot(ax_pv.c2p(common_v, p_low), radius=.055, color=CYAN),
            Dot(ax_pv.c2p(common_v, p_high), radius=.055, color=GOLD),
        )
        same_volume = eq('V', 25, MUTED).move_to(ax_pv.c2p(common_v, 0) + DOWN * .31)
        comparisons = VGroup(
            formula(r'c_1=\nu RT_1<c_2=\nu RT_2', [2.0, .95, 0], 37, INK, 7.3),
            formula(r'p_2>p_1\quad\text{при одном }V', [2.0, -.35, 0], 35, GOLD, 7.3),
            words(['Сравниваем при одинаковом ν'], [2.0, -1.55, 0], 26, MUTED, 7.3),
        )
        self.show(comparison, same_volume, create=True, run_time=1.2)
        self.show(comparisons, run_time=1.3)

        self.beat(2, 'Проекции процесса на плоскости p–T вертикальны')
        self.play(FadeOut(comparisons), run_time=.8)
        ax_pt, panel_pt = qualitative_axes([0, -.3, 0], width=3.2, height=2.8,
                                         horizontal='T', vertical='p')
        pt_title = txt('p–T', 23, INK).move_to([0, 2.28, 0])
        pt_lines, pt_labels = self.vertical_projection(ax_pt)
        explanatory = VGroup(
            formula(r'T=\mathrm{const}', [4.3, 1.0, 0], 31, GOLD, 3.2),
            words(['Проекция', 'процесса'], [4.3, -.25, 0], 25, INK, 3.1),
            words(['При той же T', 'давление меняется'], [4.3, -1.6, 0], 22, MUTED, 3.1),
        )
        self.show(panel_pt, pt_title, create=True, run_time=1.0)
        self.show(pt_lines, create=True, run_time=2.0)
        self.show(pt_labels, explanatory, run_time=1.0)

        self.beat(3, 'На плоскости V–T проекции также вертикальны')
        self.play(FadeOut(explanatory), run_time=.8)
        ax_vt, panel_vt = qualitative_axes([4.3, -.3, 0], width=3.2, height=2.8,
                                         horizontal='T', vertical='V')
        vt_title = txt('V–T', 23, INK).move_to([4.3, 2.28, 0])
        vt_lines, vt_labels = self.vertical_projection(ax_vt)
        self.show(panel_vt, vt_title, create=True, run_time=1.0)
        self.show(vt_lines, create=True, run_time=2.0)
        self.show(vt_labels, run_time=1.0)

        self.beat(4, 'Один процесс представлен в трёх системах координат')
        summary = formula(r'T,\nu=\mathrm{const}\qquad pV=\nu RT\qquad p,V,T>0',
                          [0, -2.65, 0], 31, INK, 11.9)
        self.show(summary, run_time=1.2)

    @staticmethod
    def vertical_projection(ax):
        lines, labels = VGroup(), VGroup()
        for index, temperature, color in ((1, 1.7, CYAN), (2, 3.4, GOLD)):
            lines.add(
                DashedLine(ax.c2p(temperature, 0), ax.c2p(temperature, .7),
                           color=color, stroke_width=1.3, dash_length=.06),
                Line(ax.c2p(temperature, .7), ax.c2p(temperature, 3.25),
                     color=color, stroke_width=3),
            )
            labels.add(eq(rf'T_{index}', 25, color).move_to(ax.c2p(temperature, 0) + DOWN * .32))
        return lines, labels
