"""Isobaric and isochoric laws; pressure units, from source pages 4–6.

Plot coordinates are schematic layout coordinates, not new numerical examples.
Solid process segments and animated states always remain strictly positive.
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gas_style import *


def formula(tex, center, size=35, color=INK, width=6.0):
    mob = eq(tex, size, color).move_to(center)
    if mob.width > width:
        mob.scale_to_fit_width(width)
    return mob


def words(text, center, size=24, color=INK, width=6.0):
    mob = txt(text, size, color).move_to(center)
    if mob.width > width:
        mob.scale_to_fit_width(width)
    return mob


def diagram(x_tex, y_tex, center, width=4.8, height=3.35, title=None,
            label_size=27):
    """Keep axis labels outside the plot; titles have their own row above it."""
    ax = axes(x_range=(0, 3.4, 1), y_range=(0, 3.2, 1),
              width=width, height=height, center=np.array(center, dtype=float))
    # Source diagrams have no numerical tick values: these axes are schematic.
    ax.x_axis.ticks.set_opacity(0)
    ax.y_axis.ticks.set_opacity(0)
    labels = VGroup(eq(x_tex, label_size).next_to(ax.x_axis.get_end(), RIGHT, buff=.15),
                    eq(y_tex, label_size).next_to(ax.y_axis.get_end(), UP, buff=.12))
    if title:
        labels.add(words(title, [center[0], center[1] + height / 2 + .43, 0],
                         23 if width > 4 else 20, MUTED, width))
    return ax, labels


def horizontal_pair(ax, symbol, label_size=25):
    lines = VGroup(*[Line(ax.c2p(.42, y), ax.c2p(3.05, y), color=color,
                         stroke_width=3)
                    for y, color in [(1, CYAN), (2, GOLD)]])
    guides = VGroup(*[DashedLine(ax.c2p(0, y), ax.c2p(.42, y), color=color,
                                 stroke_width=1.4, dash_length=.07)
                     for y, color in [(1, CYAN), (2, GOLD)]])
    labels = VGroup(*[eq(fr'{symbol}_{i}', label_size, color)
                     .next_to(ax.c2p(0, y), LEFT, buff=.16)
                     for i, y, color in [(1, 1, CYAN), (2, 2, GOLD)]])
    return lines, guides, labels


def vertical_pair(ax, symbol, label_size=25):
    lines = VGroup(*[Line(ax.c2p(x, .42), ax.c2p(x, 2.85), color=color,
                         stroke_width=3)
                    for x, color in [(1, CYAN), (2, GOLD)]])
    guides = VGroup(*[DashedLine(ax.c2p(x, 0), ax.c2p(x, .42), color=color,
                                 stroke_width=1.4, dash_length=.07)
                     for x, color in [(1, CYAN), (2, GOLD)]])
    labels = VGroup(*[eq(fr'{symbol}_{i}', label_size, color)
                     .next_to(ax.c2p(x, 0), DOWN, buff=.15)
                     for i, x, color in [(1, 1, CYAN), (2, 2, GOLD)]])
    return lines, guides, labels


def rising_pair(ax, fixed_symbol, label_size=26):
    # The factor-of-two slopes match p1=1 atm / p2=2 atm, or V1=1 / V2=2.
    lines = VGroup(Line(ax.c2p(.5, .5), ax.c2p(2.65, 2.65), color=CYAN,
                        stroke_width=3),
                   Line(ax.c2p(.5, .25), ax.c2p(3.05, 1.525), color=GOLD,
                        stroke_width=3))
    extensions = VGroup(DashedLine(ax.c2p(0, 0), ax.c2p(.5, .5), color=CYAN,
                                   stroke_width=1.4, dash_length=.065),
                       DashedLine(ax.c2p(0, 0), ax.c2p(.5, .25), color=GOLD,
                                   stroke_width=1.4, dash_length=.065))
    labels = VGroup(eq(fr'{fixed_symbol}_1', label_size, CYAN)
                    .next_to(ax.c2p(2.65, 2.65), UP, buff=.14),
                    eq(fr'{fixed_symbol}_2', label_size, GOLD)
                    .next_to(ax.c2p(3.05, 1.525), UP, buff=.14))
    return lines, extensions, labels


def show_family(scene, ax, labels, family, run_time=2.5):
    lines, guides, curve_labels = family
    scene.show(ax, labels, create=True, run_time=1.2)
    scene.show(guides, create=True, run_time=.8)
    scene.show(lines, create=True, run_time=run_time)
    scene.show(curve_labels, run_time=.7)


def derivation(scene, fixed, denominator, dependent):
    condition = formula(fr'{fixed}=\mathrm{{const}},\qquad\nu=\mathrm{{const}}',
                        [0, 2.25, 0], 38, CYAN, 11.8)
    original = formula(r'pV=\nu RT', [0, 1.15, 0], 46, INK, 11.8)
    isolated = formula(fr'{dependent}=\frac{{\nu R}}{{{denominator}}}\,T',
                       [0, -.05, 0], 44, INK, 11.8)
    coefficient = formula(fr'c=\frac{{\nu R}}{{{denominator}}}=\mathrm{{const}}',
                          [-2.55, -1.5, 0], 36, GOLD, 5.8)
    final = formula(fr'{dependent}=cT', [3.25, -1.5, 0], 46, CYAN, 4.5)
    kelvin = words('T — абсолютная температура, К', [0, -2.55, 0], 25, MUTED, 11.8)
    scene.show(condition, run_time=.8)
    scene.show(original, run_time=1.0)
    scene.show(isolated, run_time=1.4)
    scene.show(coefficient, run_time=1.1)
    scene.show(final, kelvin, run_time=1.1)


def slope_stage(scene, fixed, dependent, denominator):
    scene.clear_stage()
    condition = formula(fr'\nu_1=\nu_2,\qquad {fixed}_1<{fixed}_2',
                        [0, 2.45, 0], 32, INK, 11.8)
    scene.show(condition, run_time=.8)
    ax, labels = diagram('T', dependent, [-3.05, -.23, 0], width=5.3,
                         height=3.55)
    family = rising_pair(ax, fixed)
    show_family(scene, ax, labels, family, 3.0)
    definitions = VGroup(formula(fr'c_1=\frac{{\nu R}}{{{denominator}_1}}',
                                [3.25, 1.35, 0], 37, CYAN, 5.3),
                         formula(fr'c_2=\frac{{\nu R}}{{{denominator}_2}}',
                                 [3.25, .1, 0], 37, GOLD, 5.3),
                         formula(r'c_1>c_2', [3.25, -1.05, 0], 39, INK, 5.3))
    scene.show(definitions, run_time=1.2)
    extrapolation = words('Пунктир — формальное', [3.25, -2.0, 0], 22, MUTED, 5.4)
    extrapolation2 = words('продолжение к нулю', [3.25, -2.4, 0], 22, MUTED, 5.4)
    scene.show(extrapolation, extrapolation2, run_time=.8)


def two_states(scene, fixed, dependent, law, law_name):
    scene.clear_stage()
    condition = formula(fr'{fixed},\nu=\mathrm{{const}}', [0, 2.4, 0],
                        33, CYAN, 11.8)
    ax, labels = diagram('T', dependent, [-3.05, -.23, 0], width=5.3,
                         height=3.55)
    segment = Line(ax.c2p(.5, .5), ax.c2p(2.8, 2.8), color=CYAN, stroke_width=3)
    scene.show(condition, run_time=.7)
    scene.show(ax, labels, create=True, run_time=1.1)
    scene.show(segment, create=True, run_time=2.4)
    first = Dot(ax.c2p(.9, .9), color=GOLD, radius=.067)
    moving = Dot(ax.c2p(.9, .9), color=GOLD, radius=.067)
    scene.show(first, moving, run_time=.7)
    projections = VGroup()
    state_labels = VGroup()
    for i, value in [(1, .9), (2, 2.4)]:
        projections.add(DashedLine(ax.c2p(value, 0), ax.c2p(value, value),
                                   color=MUTED, stroke_width=1.4, dash_length=.08),
                        DashedLine(ax.c2p(0, value), ax.c2p(value, value),
                                   color=MUTED, stroke_width=1.4, dash_length=.08))
        state_labels.add(eq(fr'T_{i}', 25, GOLD).next_to(ax.c2p(value, 0), DOWN, buff=.16),
                         eq(fr'{dependent}_{i}', 25, GOLD).next_to(ax.c2p(0, value), LEFT, buff=.16),
                         eq(str(i), 23, GOLD).next_to(ax.c2p(value, value), UL, buff=.15))
    # A complete, positive segment is traversed, then both end states stay visible.
    scene.play(moving.animate.move_to(ax.c2p(2.4, 2.4)), run_time=3.2, rate_func=linear)
    scene.show(projections, create=True, run_time=1.4)
    scene.show(state_labels, run_time=.8)
    scene.show(words(law_name, [3.15, 1.35, 0], 28, INK, 5.3), run_time=.8)
    scene.show(formula(law, [3.15, -.05, 0], 47, CYAN, 5.3), run_time=1.2)
    scene.show(words('Температуры — в кельвинах', [3.15, -1.65, 0],
                     23, MUTED, 5.5), run_time=.8)


def summary(scene, isobaric):
    scene.clear_stage()
    fixed, dependent = ('p', 'V') if isobaric else ('V', 'p')
    condition = formula(fr'{fixed},\nu=\mathrm{{const}},\qquad c=\frac{{\nu R}}{{{fixed}}}',
                        [0, 2.23, 0], 30, CYAN, 11.8)
    comparison = formula(fr'{fixed}_1<{fixed}_2\quad\Longrightarrow\quad c_1>c_2',
                         [0, 1.57, 0], 23, MUTED, 11.8)
    scene.show(condition, comparison, run_time=1.0)
    specs = ([('T', 'p', 'p(T)', 'horizontal'), ('V', 'p', 'p(V)', 'horizontal'),
              ('T', 'V', 'V(T)', 'rising')] if isobaric else
             [('T', 'V', 'V(T)', 'horizontal'), ('V', 'p', 'p(V)', 'vertical'),
              ('T', 'p', 'p(T)', 'rising')])
    all_axes, all_labels, all_lines, all_guides, all_curve_labels = [VGroup() for _ in range(5)]
    for x, (xt, yt, title, kind) in zip([-4.4, -.05, 4.3], specs):
        ax, lab = diagram(xt, yt, [x, -.45, 0], width=3.05, height=2.35,
                          title=title, label_size=23)
        family = (horizontal_pair(ax, fixed, 21) if kind == 'horizontal' else
                  vertical_pair(ax, fixed, 21) if kind == 'vertical' else
                  rising_pair(ax, fixed, 21))
        line, guide, curve_labels = family
        all_axes.add(ax)
        all_labels.add(lab)
        all_lines.add(line)
        all_guides.add(guide)
        all_curve_labels.add(curve_labels)
    scene.show(all_axes, all_labels, create=True, run_time=1.3)
    scene.show(all_guides, create=True, run_time=.8)
    scene.show(all_lines, create=True, run_time=2.3)
    scene.show(all_curve_labels, run_time=.7)
    law = (r'\frac{V_1}{T_1}=\frac{V_2}{T_2}' if isobaric else
           r'\frac{p_1}{T_1}=\frac{p_2}{T_2}')
    scene.show(formula(law, [0, -2.48, 0], 30, CYAN, 11.8), run_time=1.2)


class IsobaricLaw(ChapterScene):
    chapter_id = 4

    def chapter(self):
        self.beat(0, 'Изобарный процесс: постоянны давление и количество вещества')
        derivation(self, 'p', 'p', 'V')

        self.beat(1, 'Две изобары: p₁ = 1 атм и p₂ = 2 атм')
        self.clear_stage()
        condition = formula(r'p,\nu=\mathrm{const}', [0, 2.4, 0], 33, CYAN, 11.8)
        self.show(condition, run_time=.7)
        for center, xt, title in [([-3.3, -.25, 0], 'T', 'Давление и температура'),
                                  ([3.15, -.25, 0], 'V', 'Давление и объём')]:
            ax, labels = diagram(xt, 'p', center, title=title)
            show_family(self, ax, labels, horizontal_pair(ax, 'p'), run_time=2.3)
        self.show(formula(r'p_1=1\ \text{атм}\qquad p_2=2\ \text{атм}',
                          [0, -2.65, 0], 29, INK, 11.8), run_time=.9)

        self.beat(2, 'При одинаковом ν большее давление даёт меньший наклон')
        slope_stage(self, 'p', 'V', 'p')

        self.beat(3, 'Два состояния одной изобары: закон Гей-Люссака')
        two_states(self, 'p', 'V', r'\frac{V_1}{T_1}=\frac{V_2}{T_2}',
                   'Закон Гей-Люссака')

        self.beat(4, 'Итог: три законченных изображения изобарного процесса')
        summary(self, True)


class IsochoricLaw(ChapterScene):
    chapter_id = 5

    def chapter(self):
        self.beat(0, 'Изохорный процесс: постоянны объём и количество вещества')
        derivation(self, 'V', 'V', 'p')

        self.beat(1, 'Две изохоры: V₁ = 1 м³ и V₂ = 2 м³')
        self.clear_stage()
        condition = formula(r'V,\nu=\mathrm{const}', [0, 2.4, 0], 33, CYAN, 11.8)
        self.show(condition, run_time=.7)
        first, first_labels = diagram('T', 'V', [-3.3, -.25, 0],
                                      title='Объём и температура')
        show_family(self, first, first_labels, horizontal_pair(first, 'V'), 2.3)
        second, second_labels = diagram('V', 'p', [3.15, -.25, 0],
                                        title='Давление и объём')
        show_family(self, second, second_labels, vertical_pair(second, 'V'), 2.3)
        self.show(formula(r'V_1=1\ \text{м}^3\qquad V_2=2\ \text{м}^3',
                          [0, -2.65, 0], 29, INK, 11.8), run_time=.9)

        self.beat(2, 'При одинаковом ν больший объём даёт меньший наклон')
        slope_stage(self, 'V', 'p', 'V')

        self.beat(3, 'Два состояния одной изохоры: закон Шарля')
        two_states(self, 'V', 'p', r'\frac{p_1}{T_1}=\frac{p_2}{T_2}',
                   'Закон Шарля')

        self.beat(4, 'Итог: три законченных изображения изохорного процесса')
        summary(self, False)


def mercury_column():
    """A schematic hydrostatic column; its filling finishes before any removal."""
    wall = VMobject(color=MUTED, stroke_width=2.5)
    wall.set_points_as_corners([[-4.4, 1.55, 0], [-4.4, -1.8, 0],
                               [-2.4, -1.8, 0], [-2.4, 1.55, 0]])
    fluid = Rectangle(width=1.94, height=.01, stroke_width=0,
                      fill_color=LAVENDER, fill_opacity=.58).move_to([-3.4, -1.795, 0])
    height = DoubleArrow([-1.8, -1.8, 0], [-1.8, .7, 0], buff=0,
                         color=GOLD, stroke_width=2.2,
                         max_tip_length_to_length_ratio=.07)
    guides = VGroup(DashedLine([-4.4, .7, 0], [-1.8, .7, 0], color=MUTED,
                               stroke_width=1.2, dash_length=.08),
                    DashedLine([-2.4, -1.8, 0], [-1.8, -1.8, 0], color=MUTED,
                               stroke_width=1.2, dash_length=.08))
    labels = VGroup(eq('h', 31, GOLD).next_to(height, RIGHT, buff=.2),
                    words('Столб ртути', [-3.4, 2.15, 0], 27, INK, 4.5),
                    words('Схема, высота не в масштабе', [-3.4, -2.45, 0],
                          20, MUTED, 5.0))
    return wall, fluid, height, guides, labels


class PressureUnits(ChapterScene):
    chapter_id = 6

    def chapter(self):
        self.beat(0, 'Паскаль — единица СИ; атмосфера в файле округлена')
        left = RoundedRectangle(width=5.6, height=3.3, corner_radius=.13,
                                color=GRID, stroke_width=1.5).move_to([-3.2, .05, 0])
        right = left.copy().move_to([3.2, .05, 0])
        self.show(left, right, run_time=.9)
        self.show(words('Паскаль', [-3.2, 1.12, 0], 30, INK, 5.0),
                  formula(r'[p]=\text{Па}', [-3.2, -.02, 0], 47, CYAN, 5.0),
                  words('Единица СИ', [-3.2, -1.02, 0], 25, MUTED, 5.0), run_time=1.1)
        self.show(words('Атмосфера', [3.2, 1.12, 0], 30, INK, 5.0),
                  formula(r'1\ \text{атм}\approx10^5\ \text{Па}', [3.2, -.02, 0],
                          38, GOLD, 5.0),
                  words('Округлённо, как в PDF', [3.2, -1.02, 0], 23, MUTED, 5.0),
                  run_time=1.3)

        self.beat(1, 'Давление столба жидкости: p = ρртgh')
        self.clear_stage()
        wall, fluid, height, guides, labels = mercury_column()
        self.show(wall, create=True, run_time=1.1)
        self.show(fluid, run_time=.4)
        self.play(fluid.animate.stretch_to_fit_height(2.5).move_to([-3.4, -.55, 0]),
                  run_time=2.7, rate_func=smooth)
        self.show(height, guides, create=True, run_time=1.2)
        self.show(labels, run_time=.8)
        column = VGroup(wall, fluid, height, guides, labels)
        self.show(formula(r'p=\rho_{\text{рт}}gh', [2.8, .75, 0], 47, CYAN, 6.1),
                  words('Гидростатическое давление', [2.8, -.6, 0], 25, INK, 6.1),
                  words('на уровне основания', [2.8, -1.13, 0], 24, MUTED, 6.1),
                  run_time=1.3)

        self.beat(2, 'Данные из файла: плотность, округлённое g и высота 1 мм')
        self.clear_stage(keep=(column,))
        self.show(formula(r'\rho_{\text{рт}}=13600\ \frac{\text{кг}}{\text{м}^3}',
                          [2.8, 1.45, 0], 35, LAVENDER, 6.2), run_time=1.1)
        self.show(formula(r'g\approx10\ \frac{\text{м}}{\text{с}^2}',
                          [2.8, .03, 0], 35, GOLD, 6.2), run_time=1.1)
        self.show(formula(r'h=1\ \text{мм}=0{,}001\ \text{м}',
                          [2.8, -1.43, 0], 35, CYAN, 6.2), run_time=1.1)

        self.beat(3, 'Подстановка доведена до результата: приблизительно 136 Па')
        self.clear_stage(keep=(column,))
        self.show(formula(r'p=\rho_{\text{рт}}gh', [2.8, 1.6, 0], 35, INK, 6.2),
                  run_time=.9)
        self.show(formula(r'p\approx13600\cdot10\cdot0{,}001\ \text{Па}',
                          [2.8, .4, 0], 34, INK, 6.2), run_time=1.3)
        self.show(formula(r'p\approx136\ \text{Па}', [2.8, -.85, 0],
                          48, CYAN, 6.2), run_time=1.2)
        self.show(formula(r'\text{при }g\approx10\ \text{м}/\text{с}^2',
                          [2.8, -2.02, 0], 29, MUTED, 6.2), run_time=.9)

        self.beat(4, 'Итог: все связи единиц с указанной точностью')
        self.clear_stage()
        cards = VGroup(RoundedRectangle(width=11.8, height=1.05, corner_radius=.12,
                                         color=GRID).move_to([0, 1.9, 0]),
                       RoundedRectangle(width=11.8, height=1.25, corner_radius=.12,
                                         color=GRID).move_to([0, .33, 0]),
                       RoundedRectangle(width=11.8, height=1.55, corner_radius=.12,
                                         color=GRID).move_to([0, -1.58, 0]))
        self.show(cards, run_time=1.1)
        self.show(words('Па — единица давления в СИ', [0, 1.9, 0], 30, CYAN, 11.1),
                  run_time=.9)
        self.show(formula(r'1\ \text{атм}\approx10^5\ \text{Па}',
                          [0, .33, 0], 41, GOLD, 11.1), run_time=1.0)
        self.show(formula(r'1\ \text{мм рт. ст.}\approx136\ \text{Па}',
                          [0, -1.32, 0], 38, LAVENDER, 11.1),
                  formula(r'\text{при }g\approx10\ \text{м}/\text{с}^2',
                          [0, -2.0, 0], 27, MUTED, 11.1), run_time=1.2)
