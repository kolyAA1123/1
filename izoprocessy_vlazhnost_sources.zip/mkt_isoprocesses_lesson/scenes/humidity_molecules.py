"""Humidity PDF pages 2–5: molecular energy, saturation, humidity ratios.

All particle exchanges use finite paths and stop at visible endpoints before a
transition.  Labels occupy dedicated lanes, outside particle/arrow trajectories.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gas_style import *


def fitted(text, size=25, color=INK, width=5.6):
    item=txt(text,size,color)
    if item.width>width:item.scale_to_fit_width(width)
    return item


def lines(texts, center, size=25, color=INK, buff=.32, width=5.6):
    return VGroup(*[fitted(t,size,color,width) for t in texts]).arrange(DOWN,buff=buff).move_to(center)


def liquid_vessel(x=-3., width=3.8, top=1.55, bottom=-1.8, surface=-.58, closed=True):
    left=x-width/2;right=x+width/2
    walls=VMobject(color=MUTED,stroke_width=2).set_points_as_corners(
        [[left,top,0],[left,bottom,0],[right,bottom,0],[right,top,0]])
    if closed:
        walls=VGroup(walls,Line([left,top,0],[right,top,0],color=MUTED,stroke_width=2))
    water=Rectangle(width=width-.06,height=surface-bottom,color=CYAN,
        stroke_opacity=0,fill_color=CYAN,fill_opacity=.15).move_to([x,(surface+bottom)/2,0])
    level=Line([left+.03,surface,0],[right-.03,surface,0],color=CYAN,stroke_width=2)
    return VGroup(water,walls,level)


def exchange_particles(x, up_count, down_count):
    """Colored parcels stay at their endpoints; counts are qualitative drawings."""
    outgoing=VGroup();incoming=VGroup();motions=[]
    for i in range(up_count):
        xx=x-.95+.32*i
        start=np.array([xx,-.81-.08*(i%2),0.])
        end=np.array([xx-.08,.78+.15*(i%3),0.])
        dot=Dot(start,radius=.07,color=CYAN)
        outgoing.add(dot)
        path=ArcBetweenPoints(start,end,angle=-.13)
        motions.append(MoveAlongPath(dot,path))
    for i in range(down_count):
        xx=x+.5+.3*i
        start=np.array([xx,1.06-.16*(i%2),0.])
        end=np.array([xx+.06,-.88-.06*(i%2),0.])
        dot=Dot(start,radius=.07,color=ROSE)
        incoming.add(dot)
        path=ArcBetweenPoints(start,end,angle=.13)
        motions.append(MoveAlongPath(dot,path))
    return VGroup(outgoing,incoming),motions


def flow_keys():
    # Arrow lanes and labels remain outside both particle flight columns.
    return VGroup(
        Arrow([-5.35,-.35,0],[-5.35,1.06,0],buff=0,color=CYAN,stroke_width=2.5),
        eq('N_1',26,CYAN).move_to([-5.35,1.55,0]),
        Arrow([-.65,1.06,0],[-.65,-.35,0],buff=0,color=ROSE,stroke_width=2.5),
        eq('N_2',26,ROSE).move_to([-.65,1.55,0]))


class EvaporationEnergy(ChapterScene):
    chapter_id=7
    def chapter(self):
        self.beat(0,'При парообразовании молекулы в среднем удаляются друг от друга')
        law=eq(r'E=E_{\mathrm{к}}+E_{\mathrm{п}}',42).move_to([0,2.18,0])
        left_title=txt('Жидкость',25,CYAN).move_to([-3.6,1.28,0])
        right_title=txt('Пар',25,GOLD).move_to([3.4,1.28,0])
        compact=np.array([[-.38,.3,0],[.26,.32,0],[-.38,-.31,0],[.27,-.3,0],[0,0,0]])
        starts=compact+np.array([-3.6,-.05,0])
        ends=np.array([[2.22,.59,0],[4.28,.54,0],[2.35,-.95,0],[4.35,-1.05,0],[3.3,-.15,0]])
        ghosts=VGroup(*[Dot(p,radius=.10,color=CYAN).set_opacity(.33) for p in starts])
        moving=VGroup(*[Dot(p,radius=.10,color=CYAN) for p in starts])
        transition=Arrow([-1.9,-.1,0],[.9,-.1,0],buff=0,color=MUTED,stroke_width=2.3)
        note=fitted('Расстояния между молекулами возрастают',25,MUTED,10.8).move_to([0,-2.1,0])
        self.show(law,left_title,right_title,ghosts,moving,run_time=1.4)
        self.show(transition,create=True,run_time=1.2)
        self.play(*[dot.animate.move_to(end).set_color(GOLD) for dot,end in zip(moving,ends)],run_time=5.6,rate_func=smooth)
        self.show(note,run_time=1)

        self.beat(1,'При фиксированной температуре средняя поступательная энергия постоянна')
        self.clear_stage(run_time=1)
        condition=eq(r'T=\mathrm{const}',42,GOLD).move_to([0,1.96,0])
        mean=eq(r'\overline E_{\mathrm{к}}=\frac32 kT=\mathrm{const}',44,CYAN).move_to([0,.7,0])
        subtitle=lines(['Средняя поступательная','кинетическая энергия молекулы'],[0,-.58,0],26,INK,.24,10)
        scope=lines(['Рассматриваем переход при заданной температуре.','Для произвольного испарения это условие не обязательно.'],[0,-2.12,0],21,MUTED,.23,11.7)
        self.show(condition,run_time=1)
        self.show(mean,run_time=2)
        self.show(subtitle,run_time=1)
        self.show(scope,run_time=1.2)

        self.beat(2,'На возрастающей ветви: больше расстояние — больше потенциальная энергия')
        self.clear_stage(run_time=1)
        a=axes((0,4,1),(-1.25,1.1,.5),width=6.6,height=3.65,center=LEFT*2.55+DOWN*.18)
        xl=eq('r',28).next_to(a.x_axis.get_end(),RIGHT,buff=.15)
        yl=eq(r'E_{\mathrm{п}}',28).next_to(a.y_axis.get_end(),UP,buff=.14)
        # Lennard-Jones-shaped qualitative curve; no numerical physical scale.
        r0=1.2
        def potential(r):return (r0/r)**12-2*(r0/r)**6
        curve=a.plot(potential,x_range=[1.04,3.8,.01],color=CYAN,stroke_width=3,use_smoothing=False)
        minimum=DashedLine(a.c2p(r0,0),a.c2p(r0,-1),color=MUTED,stroke_width=1.4)
        rlabel=eq('r_0',25,MUTED).move_to(a.c2p(r0,0)+UP*.3)
        zero=eq('0',22,MUTED).move_to(a.c2p(0,0)+LEFT*.24+DOWN*.17)
        parameter=ValueTracker(r0)
        point=always_redraw(lambda:Dot(a.c2p(parameter.get_value(),potential(parameter.get_value())),radius=.075,color=GOLD))
        words=lines(['Молекулы удаляются','Потенциальная энергия','увеличивается'],[3.93,.6,0],25,GOLD,.36,4.2)
        approach=eq(r'E_{\mathrm{п}}\to0',32).move_to([3.9,-1.1,0])
        self.show(a,xl,yl,zero,create=True,run_time=1.2)
        self.show(curve,create=True,run_time=3)
        self.show(minimum,rlabel,point,run_time=.9)
        self.play(parameter.animate.set_value(3.6),run_time=4,rate_func=smooth)
        freeze(point)
        self.show(words,approach,run_time=1.2)

        self.beat(3,'Испарение происходит со свободной поверхности жидкости')
        self.clear_stage(run_time=1)
        vessel=liquid_vessel(x=-3.4,width=4.1,closed=False,top=1.75)
        surface_label=lines(['Свободная','поверхность'],[1.5,-.56,0],24,CYAN,.17,4.4)
        pointer=Arrow([.1,-.56,0],[-1.25,-.56,0],buff=0,color=CYAN,stroke_width=2)
        heading=txt('Испарение',32,GOLD).move_to([2.5,1.35,0])
        definition=lines(['Переход молекул','из жидкости в пар'],[2.6,.55,0],27,INK,.28,5.0)
        liquid=txt('Жидкость',23,MUTED).move_to([-3.4,-2.17,0])
        dots=VGroup(*[Dot([-4.65+.68*i,-.79,0],radius=.075,color=GOLD) for i in range(4)])
        endpoints=[[-4.8,1.25,0],[-3.8,.85,0],[-3,1.25,0],[-2.35,.78,0]]
        self.show(vessel,liquid,run_time=1.2)
        self.show(heading,definition,surface_label,run_time=1)
        self.show(pointer,create=True,run_time=.8)
        self.show(dots,run_time=.8)
        self.play(*[dot.animate.move_to(end) for dot,end in zip(dots,endpoints)],run_time=5.5,rate_func=smooth)

        self.beat(4,'Скорость испарения определяется условиями у поверхности')
        self.clear_stage(run_time=1)
        factors=[('Площадь поверхности',CYAN),('Температура',GOLD),('Воздушный поток',ROSE),('Вид жидкости',LAVENDER)]
        cards=VGroup()
        for i,(label,color) in enumerate(factors):
            x=-3.2 if i%2==0 else 3.2
            y=1.4 if i<2 else -.15
            box=RoundedRectangle(width=5.7,height=1.08,corner_radius=.12,color=color,stroke_width=1.6).move_to([x,y,0])
            text=fitted(label,27,color,5.15).move_to([x,y,0])
            cards.add(VGroup(box,text))
        for card in cards:self.show(card,run_time=.95)
        qualifier=lines(['При прочих равных объём жидкости сам по себе','не определяет скорость испарения.'],[0,-1.9,0],24,MUTED,.25,11.8)
        self.show(qualifier,run_time=1.4)


class SaturatedVapor(ChapterScene):
    chapter_id=8
    def _base(self):
        vessel=liquid_vessel()
        keys=flow_keys()
        condition=eq(r'T=\mathrm{const}',30,GOLD).move_to([-3,2.25,0])
        labels=VGroup(txt('Испарение',22,CYAN).move_to([3.4,.4,0]),
            txt('Конденсация',22,ROSE).move_to([3.4,-.18,0]))
        self.show(vessel,condition,run_time=1)
        self.show(keys,labels,run_time=1)
        return vessel,keys,condition,labels
    def chapter(self):
        self.beat(0,'Сравниваем испарение и конденсацию за одинаковое время')
        self._base()
        explanation=lines(['Закрытый сосуд','Жидкость остаётся','Два встречных процесса'],[3.2,1.5,0],24,INK,.27,5.3)
        definition=eq(r'N_1\;\text{и}\;N_2',31).move_to([3.1,-1.12,0])
        time_note=lines(['Количество молекул','за одинаковый интервал'],[3.2,-2.03,0],23,MUTED,.22,5.7)
        particles,motions=exchange_particles(-3,2,2)
        self.show(explanation,definition,time_note,run_time=1.2)
        self.show(particles,run_time=.9)
        self.play(*motions,run_time=5.8,rate_func=smooth)

        self.beat(1,'У ненасыщенного пара испарение преобладает над конденсацией')
        self.clear_stage(run_time=1)
        self._base()
        relation=eq(r'N_1>N_2',43,GOLD).move_to([3.3,1.55,0])
        state=lines(['Ненасыщенный пар','Масса пара возрастает','Масса жидкости убывает'],[3.25,-1.4,0],25,INK,.36,5.45)
        particles,motions=exchange_particles(-3,4,1)
        self.show(relation,state,run_time=1.3)
        self.show(particles,run_time=.8)
        self.play(*motions,run_time=6,rate_func=smooth)

        self.beat(2,'По мере накопления пара конденсация усиливается')
        self.clear_stage(run_time=1)
        self._base()
        relation=eq(r'N_1>N_2',39,GOLD).move_to([3.3,1.5,0])
        state=lines(['Разность уменьшается','Система приближается','к равновесию'],[3.25,-1.4,0],25,INK,.35,5.5)
        particles,motions=exchange_particles(-3,4,3)
        self.show(relation,state,run_time=1.2)
        self.show(particles,run_time=.8)
        self.play(*motions,run_time=6,rate_func=smooth)
        restriction=fitted('При наличии жидкой фазы',21,MUTED,7).move_to([-2.5,-2.66,0])
        self.show(restriction,run_time=.9)

        self.beat(3,'Насыщенный пар находится в динамическом равновесии с жидкостью')
        self.clear_stage(run_time=1)
        self._base()
        relation=eq(r'N_1=N_2',43,GOLD).move_to([3.3,1.5,0])
        state=lines(['Насыщенный пар','Обмен продолжается','Массы фаз постоянны'],[3.25,-1.4,0],25,INK,.36,5.45)
        particles,motions=exchange_particles(-3,3,3)
        self.show(relation,state,run_time=1.2)
        self.show(particles,run_time=.8)
        self.play(*motions,run_time=6,rate_func=smooth)
        restriction=fitted('При наличии жидкости и T = const',21,MUTED,8.5).move_to([-2.2,-2.66,0])
        self.show(restriction,run_time=.9)

        self.beat(4,'Давление насыщенного пара возрастает с температурой')
        self.clear_stage(run_time=1)
        a=axes((0,4,1),(0,4,1),width=6.3,height=3.65,center=LEFT*2.65+DOWN*.03)
        labels=VGroup(eq('T',30).next_to(a.x_axis.get_end(),RIGHT,buff=.14),
            eq(r'p_{\mathrm{нас}}',28).next_to(a.y_axis.get_end(),UP,buff=.14))
        func=lambda t:.12*(np.exp(.86*t)-1)
        curve=a.plot(func,x_range=[.22,3.85,.01],color=CYAN,stroke_width=3,use_smoothing=False)
        t=ValueTracker(.5)
        point=always_redraw(lambda:Dot(a.c2p(t.get_value(),func(t.get_value())),radius=.08,color=GOLD))
        words=lines(['Больше температура','Выше давление','насыщенного пара'],[3.8,.7,0],25,INK,.38,4.6)
        qualitative=txt('Качественная зависимость',20,MUTED).move_to([3.8,-1.58,0])
        self.show(a,labels,create=True,run_time=1.2)
        self.show(curve,create=True,run_time=4)
        self.show(point,run_time=.7)
        self.play(t.animate.set_value(3.6),run_time=4,rate_func=smooth)
        freeze(point)
        self.show(words,qualitative,run_time=1.2)


class HumidityRatios(ChapterScene):
    chapter_id=9
    def chapter(self):
        self.beat(0,'Сравниваем концентрации водяного пара при одной температуре')
        same=eq(r'T_1=T_2,\qquad V_1=V_2',35,GOLD).move_to([0,2.2,0])
        vessels=VGroup(liquid_vessel(x=-3.3,width=3.8,top=1.38,bottom=-1.73,surface=-.72),
            liquid_vessel(x=3.3,width=3.8,top=1.38,bottom=-1.73,surface=-.72))
        leftpoints=[[-4.5,.72,0],[-3.6,.32,0],[-2.2,.6,0],[-3,-.26,0]]
        rightpoints=[[2.05,.87,0],[2.92,.93,0],[3.84,.74,0],[4.52,1.02,0],
            [2.33,.03,0],[3.12,.21,0],[4.2,.02,0],[2.74,-.43,0],[3.67,-.4,0]]
        dots=VGroup(*[Dot(p,radius=.075,color=CYAN) for p in leftpoints],*[Dot(p,radius=.075,color=GOLD) for p in rightpoints])
        labels=VGroup(eq('n',31,CYAN).move_to([-3.3,-2.14,0]),eq(r'n_{\mathrm{нас}}',31,GOLD).move_to([3.3,-2.14,0]))
        states=VGroup(txt('Ненасыщенный',23,CYAN).move_to([-3.3,-2.63,0]),txt('Насыщенный',23,GOLD).move_to([3.3,-2.63,0]))
        self.show(same,vessels,run_time=1.3)
        self.show(dots,run_time=2)
        self.show(labels,states,run_time=1)

        self.beat(1,'Относительная влажность — отношение концентраций при одной температуре')
        self.clear_stage(run_time=1)
        title=txt('Относительная влажность',32,GOLD).move_to([0,1.95,0])
        definition=eq(r'\varphi=\frac{n}{n_{\mathrm{нас}}}\cdot100\%',53).move_to([0,.58,0])
        items=VGroup(
            eq(r'n=\frac NV',32,CYAN).move_to([-3.5,-1.05,0]),
            eq(r'n_{\mathrm{нас}}',32,GOLD).move_to([3.5,-1.05,0]),
            txt('Концентрация пара',23,CYAN).move_to([-3.5,-1.8,0]),
            txt('При насыщении',23,GOLD).move_to([3.5,-1.8,0]))
        condition=txt('Одна и та же температура',24,MUTED).move_to([0,-2.5,0])
        self.show(title,run_time=1)
        self.show(definition,run_time=2)
        self.show(items,condition,run_time=1.4)

        self.beat(2,'Для водяного пара p = nkT: можно сравнивать парциальные давления')
        self.clear_stage(run_time=1)
        temperature=eq(r'T=\mathrm{const}',32,GOLD).move_to([0,2.15,0])
        pair=VGroup(eq('p=nkT',35,CYAN),eq(r'p_{\mathrm{нас}}=n_{\mathrm{нас}}kT',35,GOLD)).arrange(RIGHT,buff=1.8).move_to([0,1.2,0])
        chain=eq(r'\varphi=\frac{nkT}{n_{\mathrm{нас}}kT}\cdot100\%=\frac{p}{p_{\mathrm{нас}}}\cdot100\%',43).move_to([0,-.08,0])
        if chain.width>11.7:chain.scale_to_fit_width(11.7)
        meaning=lines(['p — парциальное давление водяного пара.','Общее давление воздуха сюда не подставляют.'],[0,-1.62,0],25,MUTED,.38,11.8)
        self.show(temperature,pair,run_time=1.5)
        self.show(chain,run_time=3)
        self.show(meaning,run_time=1.2)

        self.beat(3,'Плотность и концентрация связаны массой одной молекулы')
        self.clear_stage(run_time=1)
        density=eq(r'\rho=\frac mV=\frac{m_0N}{V}=m_0n',44,CYAN).move_to([0,1.6,0])
        molecule=txt('m₀ — масса одной молекулы водяного пара',24,MUTED).move_to([0,.55,0])
        conversion=eq(r'\frac{n}{n_{\mathrm{нас}}}=\frac{m_0n}{m_0n_{\mathrm{нас}}}=\frac{\rho}{\rho_{\mathrm{нас}}}',42).move_to([0,-.55,0])
        result=eq(r'\varphi=\frac{\rho}{\rho_{\mathrm{нас}}}\cdot100\%',44,GOLD).move_to([0,-1.92,0])
        self.show(density,run_time=2)
        self.show(molecule,run_time=1)
        self.show(conversion,run_time=2.5)
        self.show(result,run_time=1.5)

        self.beat(4,'Абсолютная влажность — плотность водяного пара, единица СИ — кг/м³')
        self.clear_stage(run_time=1)
        title=txt('Относительная влажность',28,GOLD).move_to([-3.3,2.05,0])
        ratios=VGroup(
            eq(r'\varphi=\frac{n}{n_{\mathrm{нас}}}\cdot100\%',35),
            eq(r'\varphi=\frac{p}{p_{\mathrm{нас}}}\cdot100\%',35),
            eq(r'\varphi=\frac{\rho}{\rho_{\mathrm{нас}}}\cdot100\%',35)).arrange(DOWN,buff=.35).move_to([-3.3,-.05,0])
        line=Line([.05,2.22,0],[.05,-2.4,0],color=GRID,stroke_width=1.3)
        absolute_title=fitted('Абсолютная влажность',28,CYAN,5.55).move_to([3.35,2.05,0])
        absolute=eq(r'\rho=\frac mV',46,CYAN).move_to([3.35,.74,0])
        unit=eq(r'[\rho]=\frac{\mathrm{кг}}{\mathrm{м}^{3}}',35).move_to([3.35,-.43,0])
        meaning=lines(['Плотность','водяного пара'],[3.35,-1.72,0],25,INK,.27,5.25)
        condition=txt('При одной температуре',20,MUTED).move_to([-3.3,-2.45,0])
        self.show(title,line,absolute_title,run_time=1)
        for ratio in ratios:self.show(ratio,run_time=1.2)
        self.show(absolute,unit,meaning,condition,run_time=1.7)
