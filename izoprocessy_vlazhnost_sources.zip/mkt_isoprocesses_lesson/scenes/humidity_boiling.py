"""Boiling, its pressure condition, and a completed bubble ascent.

Only the examples on pp. 8–9 of ВЛАЖНОСТЬ.pdf are used. The vessel dimensions
and particle positions are qualitative drawing coordinates, not extra data.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gas_style import *


def formula(tex, center, size=35, color=INK, width=6.5):
    result = eq(tex, size, color)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result.move_to(center)


def words(lines, center, size=25, color=INK, width=6.4):
    result = VGroup(*[txt(line, size, color) for line in lines]).arrange(DOWN, buff=.17)
    if result.width > width:
        result.scale_to_fit_width(width)
    return result.move_to(center)


def vessel(left=-5.3, right=-2.3, bottom=-2.2, surface=1.15, top=1.9,
           pressure_x=-3.8):
    water = Polygon([left, bottom, 0], [right, bottom, 0],
                    [right, surface, 0], [left, surface, 0],
                    stroke_width=0, fill_color=CYAN, fill_opacity=.13)
    walls = VMobject(color=INK, stroke_width=2.2).set_points_as_corners([
        [left, top, 0], [left, bottom, 0], [right, bottom, 0], [right, top, 0]])
    level = Line([left, surface, 0], [right, surface, 0], color=CYAN, stroke_width=2)
    p0 = formula(r'p_0', [pressure_x, 2.35, 0], 32, GOLD, 1.0)
    down = arrow([pressure_x, 1.94, 0], [0, -.55, 0], GOLD, 2.5)
    return VGroup(water, walls, level, p0, down)


def depth_marker(center_y=-1.5, surface=1.15):
    dimension = DoubleArrow([-5.72, center_y, 0], [-5.72, surface, 0],
                            buff=0, color=MUTED, stroke_width=2,
                            max_tip_length_to_length_ratio=.06)
    label = formula('h', [-6.10, (center_y + surface) / 2, 0], 31, MUTED, .35)
    ticks = VGroup(*[
        Line([-5.88, y, 0], [-5.55, y, 0], color=MUTED, stroke_width=1.4)
        for y in (center_y, surface)
    ])
    return VGroup(dimension, label, ticks)


def static_pressure_diagram():
    container = vessel()
    bubble = Circle(radius=.27, color=ROSE, stroke_width=2.5,
                    fill_color=BLACK_BG, fill_opacity=.75).move_to([-4.0, -1.5, 0])
    pressure = formula('p', [-3.35, -1.5, 0], 31, ROSE, .45)
    depth = depth_marker()
    return VGroup(container, bubble, pressure, depth)


def small_vessel(center_x):
    left, right = center_x - 1.5, center_x + 1.5
    water = Polygon([left, -2.1, 0], [right, -2.1, 0],
                    [right, -.4, 0], [left, -.4, 0],
                    stroke_width=0, fill_color=CYAN, fill_opacity=.13)
    walls = VMobject(color=INK, stroke_width=2).set_points_as_corners([
        [left, .25, 0], [left, -2.1, 0], [right, -2.1, 0], [right, .25, 0]])
    level = Line([left, -.4, 0], [right, -.4, 0], color=CYAN, stroke_width=2)
    return VGroup(water, walls, level)


class BoilingCondition(ChapterScene):
    chapter_id = 12

    def chapter(self):
        self.beat(0, 'Испарение идёт с поверхности; кипение — во всём объёме')
        headings = VGroup(
            words(['Испарение'], [-3.4, 2.12, 0], 29, CYAN, 5.4),
            words(['С поверхности'], [-3.4, 1.32, 0], 24, MUTED, 5.4),
            words(['Кипение'], [3.4, 2.12, 0], 29, GOLD, 5.4),
            words(['Во всём объёме'], [3.4, 1.32, 0], 24, MUTED, 5.4),
        )
        containers = VGroup(small_vessel(-3.4), small_vessel(3.4))
        self.show(headings, containers, run_time=1.3)
        particles = VGroup(*[
            Dot([x, -.36, 0], radius=.055, color=CYAN)
            for x in (-4.15, -3.4, -2.65)
        ])
        self.show(particles, run_time=.7)
        self.play(*[particle.animate.shift(UP * .97) for particle in particles],
                  run_time=3.0, rate_func=smooth)
        bubbles = VGroup(*[
            Circle(radius=radius, color=GOLD, stroke_width=2.2).move_to([x, y, 0])
            for x, y, radius in ((2.55, -1.55, .18), (3.45, -.95, .25),
                                  (4.18, -1.64, .21))
        ])
        self.show(bubbles, create=True, run_time=2.7)
        labels = VGroup(
            words(['Молекулы покинули поверхность'], [-3.4, -2.62, 0], 20, MUTED, 5.7),
            words(['Пузырьки образовались в жидкости'], [3.4, -2.62, 0], 20, MUTED, 5.7),
        )
        self.show(labels, run_time=1.0)

        self.beat(1, 'У пузырька давление жидкости: атмосферное плюс гидростатическое')
        self.clear_stage()
        diagram = static_pressure_diagram()
        explanation = VGroup(
            formula(r'p=p_0+\rho gh', [2.75, 1.55, 0], 44, INK, 6.8),
            words(['p₀ — давление над поверхностью'], [2.75, .35, 0], 24, GOLD, 6.7),
            words(['ρgh — добавка с глубиной'], [2.75, -.6, 0], 24, MUTED, 6.7),
            words(['h — глубина пузырька'], [2.75, -1.55, 0], 24, MUTED, 6.7),
        )
        self.show(diagram, run_time=1.3)
        self.show(explanation, run_time=1.3)

        self.beat(2, 'Начало кипения: давление насыщенного пара сравнялось с внешним')
        self.clear_stage(keep=(diagram,))
        condition = VGroup(
            formula(r'p_{\mathrm{нас}}(T)=p_0+\rho gh', [2.75, 1.45, 0], 41, ROSE, 6.8),
            words(['Пар в пузырьке', 'и окружающая жидкость', 'имеют одинаковое давление'],
                  [2.75, -.25, 0], 25, INK, 6.6),
            words(['Модель без поверхностного натяжения'],
                  [2.75, -2.0, 0], 19, MUTED, 6.6),
        )
        self.show(condition, run_time=1.5)

        self.beat(3, 'Глубина 3 см добавляет 300 Па к атмосферному давлению')
        self.clear_stage()
        givens = VGroup(
            formula(r'p_0=10^5\,\text{Па}', [-3.3, 1.85, 0], 35, GOLD, 5.7),
            formula(r'\rho=1000\,\text{кг}/\text{м}^3', [3.3, 1.85, 0], 35, CYAN, 5.7),
            formula(r'g\approx10\,\text{м}/\text{с}^2', [-3.3, .55, 0], 35, MUTED, 5.7),
            formula(r'h=3\,\text{см}=0{,}03\,\text{м}', [3.3, .55, 0], 35, MUTED, 5.7),
        )
        hydrostatic = formula(r'\rho gh=1000\cdot10\cdot0{,}03=300\,\text{Па}',
                              [0, -1.0, 0], 37, CYAN, 12.1)
        total = formula(r'p_{\mathrm{нас}}=100000+300=100300\,\text{Па}',
                        [0, -2.35, 0], 38, ROSE, 12.1)
        self.show(givens, run_time=1.3)
        self.show(hydrostatic, run_time=1.4)
        self.show(total, run_time=1.4)

        self.beat(4, 'Около 100 кПа вода кипит примерно при 100 °C')
        self.clear_stage()
        final_diagram = static_pressure_diagram()
        depth_value = words(['h = 3 см'], [-3.8, -2.62, 0], 23, MUTED, 3.0)
        result = VGroup(
            formula(r'p_{\mathrm{нас}}=100300\,\text{Па}', [2.75, 1.7, 0], 38, ROSE, 6.8),
            formula(r'p_{\mathrm{нас}}\approx100\,\text{кПа}', [2.75, .45, 0], 38, GOLD, 6.8),
            formula(r'T_{\mathrm{кип}}\approx100\,{}^\circ\mathrm C',
                    [2.75, -.8, 0], 42, CYAN, 6.8),
            words(['Давление и температура', 'здесь округлены'],
                  [2.75, -2.1, 0], 23, MUTED, 6.6),
        )
        self.show(final_diagram, depth_value, run_time=1.2)
        self.show(result, run_time=1.4)


class BoilingTemperature(ChapterScene):
    chapter_id = 13

    def chapter(self):
        self.beat(0, 'Меньше внешнее давление — ниже температура кипения')
        chain = formula(r'p_0\downarrow\quad\Rightarrow\quad '
                        r'p_{\mathrm{нас}}(T_{\mathrm{кип}})\downarrow\quad\Rightarrow\quad '
                        r'T_{\mathrm{кип}}\downarrow',
                        [0, 1.8, 0], 43, INK, 12.2)
        comparison = VGroup(
            formula(r'p_0\approx100\,\text{кПа}', [-3.3, .05, 0], 38, CYAN, 5.7),
            formula(r'T_{\mathrm{кип}}\approx100\,{}^\circ\mathrm C',
                    [-3.3, -1.35, 0], 39, CYAN, 5.7),
            formula(r'p_0=70\,\text{кПа}', [3.3, .05, 0], 38, GOLD, 5.7),
            formula(r'T_{\mathrm{кип}}\approx90\,{}^\circ\mathrm C',
                    [3.3, -1.35, 0], 39, GOLD, 5.7),
        )
        self.show(chain, run_time=1.4)
        self.show(comparison, run_time=1.5)
        self.show(words(['Численные примеры для воды'], [0, -2.55, 0], 23, MUTED, 11),
                  run_time=1.0)

        self.beat(1, 'В горах вода закипает при меньшей температуре')
        self.clear_stage()
        mountain = VMobject(color=MUTED, stroke_width=2.7).set_points_as_corners([
            [-5.85, -2.12, 0], [-4.55, -.1, 0], [-3.5, 1.45, 0],
            [-2.55, -.05, 0], [-1.25, -2.12, 0]])
        snow = VMobject(color=INK, stroke_width=2.4).set_points_as_corners([
            [-4.0, .71, 0], [-3.74, .54, 0], [-3.5, .78, 0],
            [-3.27, .53, 0], [-2.99, .65, 0]])
        name = words(['Эверест'], [-3.5, 2.25, 0], 28, INK, 5.3)
        explanation = VGroup(
            formula(r'p_0\downarrow', [2.9, 1.55, 0], 43, GOLD, 6.0),
            formula(r'T_{\mathrm{кип}}\approx69\,{}^\circ\mathrm C',
                    [2.9, .2, 0], 44, CYAN, 6.0),
            words(['Округлённый пример', 'из исходного материала'],
                  [2.9, -1.3, 0], 24, MUTED, 6.0),
        )
        self.show(name, run_time=.8)
        self.show(mountain, snow, create=True, run_time=2.2)
        self.show(explanation, run_time=1.5)

        self.beat(2, 'Жидкость испаряется внутрь пузырька: масса пара растёт')
        self.clear_stage()
        container = vessel(pressure_x=-2.85)
        depth = depth_marker(center_y=-1.45)
        growth = ValueTracker(0)
        ascent = ValueTracker(0)

        def center():
            return np.array([-4.1, -1.45 + 2.10 * ascent.get_value(), 0])

        def radius():
            return .24 + .20 * growth.get_value() + .06 * ascent.get_value()

        bubble = always_redraw(lambda: Circle(
            radius=radius(), color=ROSE, stroke_width=2.5,
            fill_color=BLACK_BG, fill_opacity=.8).move_to(center()))
        pressure_template = eq('p', 30, ROSE)
        pressure = always_redraw(lambda: pressure_template.copy().move_to(
            center() + RIGHT * (radius() + .7)))
        angles = np.array([.35, 1.4, 2.45, 3.5, 4.55, 5.6])
        offsets = [np.array([np.cos(a), np.sin(a), 0]) for a in angles]
        particles = VGroup(*[
            Dot(center() + direction * .61, radius=.045, color=GOLD)
            for direction in offsets
        ])
        evaporation = VGroup(
            words(['Испарение внутрь пузырька'], [2.75, 1.4, 0], 28, INK, 6.7),
            formula(r'm\uparrow', [2.75, -.05, 0], 52, GOLD, 6.7),
            words(['В пузырьке становится', 'больше водяного пара'],
                  [2.75, -1.6, 0], 26, MUTED, 6.7),
        )
        self.show(container, depth, run_time=1.2)
        self.show(bubble, pressure, particles, evaporation, run_time=1.0)
        self.play(growth.animate.set_value(1),
                  *[particle.animate.move_to(center() + direction * .22)
                    for particle, direction in zip(particles, offsets)],
                  run_time=5.2, rate_func=smooth)
        for particle, direction in zip(particles, offsets):
            particle.add_updater(lambda mob, dt, offset=direction.copy():
                                 mob.move_to(center() + offset * .22))

        self.beat(3, 'При прочих равных увеличение массы пара увеличивает его объём')
        self.clear_stage(keep=(container, depth, bubble, pressure, particles))
        growth_equations = VGroup(
            formula(r'pV=\frac{m}{M}RT', [2.75, 1.5, 0], 47, INK, 6.7),
            formula(r'm\uparrow\quad\Rightarrow\quad V\uparrow',
                    [2.75, .05, 0], 45, GOLD, 6.7),
            words(['M — молярная масса', 'При прочих равных'],
                  [2.75, -1.0, 0], 23, MUTED, 6.7),
            formula(r'p\approx p_{\mathrm{нас}}(T)',
                    [2.75, -2.1, 0], 34, ROSE, 6.7),
        )
        self.show(growth_equations, run_time=1.5)

        self.beat(4, 'Пузырёк доходит до поверхности; пар выходит в атмосферу')
        self.clear_stage(keep=(container, bubble, pressure, particles), run_time=.9)
        ascent_notes = VGroup(
            words(['Подъём до поверхности'], [2.75, 1.6, 0], 28, INK, 6.7),
            words(['Испарение внутрь продолжается'], [2.75, .65, 0], 23, GOLD, 6.7),
            formula(r'p_{\mathrm{жидк}}=p_0+\rho gh',
                    [2.75, -.35, 0], 34, ROSE, 6.7),
            words(['С уменьшением глубины', 'давление жидкости меняется'],
                  [2.75, -1.55, 0], 23, MUTED, 6.7),
        )
        self.show(ascent_notes, run_time=1.0)
        # End at y=.65 with r=.50: the bubble actually touches y=1.15.
        self.play(ascent.animate.set_value(1), run_time=7.0, rate_func=smooth)
        freeze(bubble, pressure, particles)
        destinations = [np.array([-4.1 + .45 * np.cos(a), 2.05 + .16 * np.sin(a), 0])
                        for a in angles]
        self.play(FadeOut(bubble), FadeOut(pressure),
                  *[particle.animate.move_to(destination)
                    for particle, destination in zip(particles, destinations)],
                  run_time=2.8, rate_func=smooth)
        self.play(FadeOut(particles), run_time=1.1)
        self.show(words(['Пар вышел через поверхность'], [2.75, -2.6, 0],
                        23, CYAN, 6.7), run_time=.8)
