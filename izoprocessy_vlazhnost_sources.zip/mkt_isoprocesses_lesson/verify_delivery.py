"""Check the assembled silent film, chapter fades, background and full decode."""
from pathlib import Path
import hashlib
import json
import subprocess
import numpy as np

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT / 'plan.json').read_text())
MOVIE = ROOT / 'output/izoprocessy_vlazhnost_1080p60.mp4'


def raw_frames(path, start, duration, filters):
    return subprocess.check_output([
        'ffmpeg', '-v', 'error', '-ss', str(start), '-t', str(duration),
        '-i', str(path), '-vf', filters, '-f', 'rawvideo', 'pipe:1',
    ])


if __name__ == '__main__':
    report = json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-show_streams', '-show_format',
        '-show_chapters', '-of', 'json', str(MOVIE),
    ]))
    video = next(s for s in report['streams'] if s['codec_type'] == 'video')
    assert not any(s['codec_type'] == 'audio' for s in report['streams'])
    assert (video['width'], video['height'], video['avg_frame_rate']) == (1920, 1080, '60/1')
    assert int(video['nb_frames']) == PLAN['duration'] * 60
    assert abs(float(report['format']['duration']) - PLAN['duration']) < .05
    assert len(report['chapters']) == len(PLAN['chapters'])
    fades = []
    layouts = []
    for chapter in PLAN['chapters']:
        layout_path = ROOT / 'output/layout_checks' / f"{chapter['id']:02d}.json"
        layout = json.loads(layout_path.read_text())
        assert layout['samples'] and layout['samples'][-1]['time'] >= chapter['duration'] - 1, chapter['id']
        assert not any(sample['issues'] for sample in layout['samples']), (chapter['id'], layout_path)
        preview = ROOT / 'output/preview_chapters' / f"{chapter['id']:02d}_{chapter['class']}.mp4"
        sources = [ROOT / 'gas_style.py', ROOT / 'plan.json', ROOT / 'scenes' / chapter['module']]
        assert preview.stat().st_mtime > max(source.stat().st_mtime for source in sources), chapter['id']
        layouts.append({'chapter': chapter['id'], 'snapshots_checked': len(layout['samples']),
                        'text_overlaps': 0, 'text_outside_frame': 0})
        clip = ROOT / 'output/chapters' / f"{chapter['id']:02d}_{chapter['class']}.mp4"
        data = raw_frames(clip, chapter['duration'] - 1.2, 1.2,
                          'fps=10,scale=160:90,format=rgb24')
        frames = np.frombuffer(data, dtype=np.uint8).reshape(-1, 90, 160, 3)
        energy = frames.mean(axis=(1, 2, 3))
        assert energy[-1] / max(energy[0], .001) < .05, chapter['id']
        assert max(np.diff(energy)) < .05, chapter['id']
        corner = raw_frames(MOVIE, chapter['start'] + 3, .05,
                            'crop=16:16:0:0,format=rgb24')
        assert corner and max(corner) == 0, chapter['id']
        fades.append({'chapter': chapter['id'],
                      'end_fade_rgb_mean': [round(float(v), 4) for v in energy],
                      'black_corner': True})
    log = ROOT / 'output/decode_check.log'
    print('Technical checks passed. Decoding the complete film...', flush=True)
    with log.open('w') as errors:
        result = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(MOVIE),
                                 '-map', '0:v:0', '-f', 'null', '-'], stderr=errors)
    assert result.returncode == 0 and log.stat().st_size == 0, log
    digest = hashlib.file_digest(MOVIE.open('rb'), 'sha256').hexdigest()
    summary = {'duration_seconds': PLAN['duration'], 'resolution': [1920, 1080],
               'fps': 60, 'frames': int(video['nb_frames']), 'audio_streams': 0,
               'chapters': len(report['chapters']), 'bytes': MOVIE.stat().st_size,
               'sha256': digest, 'full_decode_passed': True, 'chapter_fades': fades,
               'label_layout_checks': layouts}
    (ROOT / 'output/quality_validation.json').write_text(
        json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"VERIFIED {MOVIE.name}: {summary['bytes']} bytes, SHA256 {digest}", flush=True)
