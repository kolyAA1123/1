"""Scene entrypoints for available isoprocesses and humidity sections."""
from scenes.isothermal import GasStateVariables as _GasStateVariables
class GasStateVariables(_GasStateVariables):
    pass

from scenes.isothermal import IsothermalLaw as _IsothermalLaw
class IsothermalLaw(_IsothermalLaw):
    pass

from scenes.isothermal import IsothermalDiagrams as _IsothermalDiagrams
class IsothermalDiagrams(_IsothermalDiagrams):
    pass

from scenes.isobaric_isochoric import IsobaricLaw as _IsobaricLaw
class IsobaricLaw(_IsobaricLaw):
    pass

from scenes.isobaric_isochoric import IsochoricLaw as _IsochoricLaw
class IsochoricLaw(_IsochoricLaw):
    pass

from scenes.isobaric_isochoric import PressureUnits as _PressureUnits
class PressureUnits(_PressureUnits):
    pass

from scenes.humidity_molecules import EvaporationEnergy as _EvaporationEnergy
class EvaporationEnergy(_EvaporationEnergy):
    pass

from scenes.humidity_molecules import SaturatedVapor as _SaturatedVapor
class SaturatedVapor(_SaturatedVapor):
    pass

from scenes.humidity_molecules import HumidityRatios as _HumidityRatios
class HumidityRatios(_HumidityRatios):
    pass

from scenes.humidity_applications import EvaporationCooling as _EvaporationCooling
class EvaporationCooling(_EvaporationCooling):
    pass

from scenes.humidity_applications import DewPoint as _DewPoint
class DewPoint(_DewPoint):
    pass

from scenes.humidity_boiling import BoilingCondition as _BoilingCondition
class BoilingCondition(_BoilingCondition):
    pass

from scenes.humidity_boiling import BoilingTemperature as _BoilingTemperature
class BoilingTemperature(_BoilingTemperature):
    pass
