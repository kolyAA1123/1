from pathlib import Path
import math
import json

import numpy as np
from manim import Axes, Circle, Create, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Функции и графики"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



def axes_view(x,y):
    return Axes(x_range=[*x,1],y_range=[*y,1],x_length=5.15,y_length=3.75,
        axis_config={"include_ticks":False,"stroke_width":1.65,"color":MUTED}).move_to([-3.70,-.19,0])


def graph(kind):
    if kind is None:
        return VGroup(),VGroup()
    limit={
        "line":((-3,3),(-3,4)),
        "shift":((-3.7,4.4),(-2.6,4.2)),
        "parabola":((-3,5),(-3.5,6.2)),
        "root":((-2.7,4.1),(-1.3,4)),
        "hyperbola":((-4,4),(-3.5,3.5)),
        "exp_log":((-2.9,4.4),(-2.9,4.4)),
        "absolute":((-3.3,3.3),(-2.3,3.6)),
        "piecewise":((-3,3),(-1.3,3.6)),
        "circle":((-3,3),(-3,3)),
        "diamond":((-3.3,3.3),(-2.25,2.25)),
        "levels":((-1.3,8.15),(-15.1,6.2)),
    }
    a=axes_view(*limit[kind])
    specs={
        "line":[(lambda x:.75*x+1,(-2.7,2.7),CYAN),(lambda x:.75*x-1,(-2.7,2.7),GOLD)],
        "shift":[(lambda x:x*x,(-2,2),MUTED),(lambda x:(x-1)**2-2,(-1.45,3.45),CYAN)],
        "parabola":[(lambda x:(x-1)**2-1,(-1.6,3.6),CYAN)],
        "root":[(math.sqrt,(0,3.95),MUTED),(lambda x:math.sqrt(x+2)+1,(-2,3.95),CYAN)],
        "hyperbola":[(lambda x:2/x,(-3.7,-.65),CYAN),(lambda x:2/x,(.65,3.7),CYAN)],
        "exp_log":[(lambda x:2**x,(-2.75,2.08),CYAN),(math.log2,(.14,4.2),GOLD)],
        "absolute":[(lambda x:x*x-1,(-2.06,2.06),MUTED),(lambda x:abs(x*x-1),(-2.06,2.06),CYAN)],
        "piecewise":[(lambda x:x+2,(-2.8,0),CYAN),(lambda x:1+x*x/4,(0,2.8),GOLD)],
        "circle":[],
        "diamond":[],
        "levels":[(lambda x:(x-4)**2-13,(-.3,8.08),MUTED),(lambda x:3-2*x,(-1.15,8.05),LAVENDER),
                  (lambda x:(x-4)**2-13,(0,6),CYAN)],
    }[kind]
    output=VGroup(*[a.plot(f,x_range=[start,end,.04],color=c,stroke_width=3.3) for f,(start,end),c in specs])
    if kind=="circle":
        output.add(Circle(radius=1.25,color=CYAN,stroke_width=3).stretch(5.15/3.75,0).move_to(a.c2p(0,0)))
    if kind=="diamond":
        points=[a.c2p(2.6,0),a.c2p(0,1.5),a.c2p(-2.6,0),a.c2p(0,-1.5)]
        output.add(*[Line(u,v,color=CYAN,stroke_width=3) for u,v in zip(points,points[1:]+points[:1])])
    if kind=="piecewise":
        output.add(Dot(a.c2p(0,2),radius=.067,color=CYAN),Dot(a.c2p(0,1),radius=.068,color=GOLD,fill_color=BLACK_BG,stroke_width=2))
    if kind=="levels":
        for x,y,closed in ((0,3,False),(4,-13,True),(6,-9,False)):
            color=GOLD if closed else ROSE
            output.add(Dot(a.c2p(x,y),radius=.066,color=color,
                       fill_color=color if closed else BLACK_BG,stroke_width=2))
        for x,y,label,shift in [(0,3,"3",[-.30,.08,0]),(4,-13,"-13",[0,-.30,0]),(6,-9,"-9",[.34,0,0])]:
            output.add(equation(label,INK,a.c2p(x,y)+shift,.25))
    return VGroup(a),output


class GraphsLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind=="levels" else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
