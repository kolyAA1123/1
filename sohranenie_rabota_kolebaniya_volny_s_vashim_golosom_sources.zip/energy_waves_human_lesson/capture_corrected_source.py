"""Contact sheets and full-size evidence for the three corrected silent chapters."""
from pathlib import Path
import json,subprocess
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parent

def main():
    timeline=json.loads((ROOT/'output/source_timeline.json').read_text())
    out=ROOT/'output/corrected_source_contacts';out.mkdir(exist_ok=True)
    items=[]
    for ch in timeline['chapters']:
        if ch['id'] not in [3,5,6,7]:continue
        video=ROOT/'visual_source/output/chapters'/f"{ch['id']:02d}_{ch['class']}.mp4"
        for beat in ch['beats']:
            key=f"{ch['id']:02d}_{beat['index']+1:02d}"
            frame=(beat['terminal_hold_start_frame']+beat['terminal_hold_end_frame']-1)//2
            seek=max(0,frame//60-1);first=frame-seek*60;dest=out/f'{key}_full.jpg'
            subprocess.run(['ffmpeg','-v','error','-threads','1','-ss',str(seek),'-i',str(video),
                '-vf',f'trim=start_frame={first}:end_frame={first+1}',
                '-frames:v','1','-q:v','2','-threads','1','-y',str(dest)],check=True)
            items.append({'key':key,'frame':frame,'file':dest.name,'video':str(video)})
    sheet=Image.new('RGB',(1920,((len(items)+4)//5)*248),'#151515');draw=ImageDraw.Draw(sheet)
    for i,item in enumerate(items):
        x=i%5*384;y=i//5*248
        im=Image.open(out/item['file']);im.thumbnail((384,216));sheet.paste(im,(x,y))
        draw.text((x+8,y+222),item['key']+' corrected',fill='white')
    sheet.save(out/'sheet.jpg',quality=96)
    (out/'manifest.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
    print(f'Captured{len(items)}correctedsourceendstates',flush=True)

if __name__=='__main__':main()
