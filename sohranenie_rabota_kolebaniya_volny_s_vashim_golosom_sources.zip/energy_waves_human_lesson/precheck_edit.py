"""Check measured audio placement and explicit frame maps before muxing.

This does not certify pronunciation or subjective scene synchronization. The
final delivery verifier still requires actual media, AAC, and complete decode.
"""
from pathlib import Path
import json
import numpy as np

from verify_delivery import (ROOT, ORIGINAL_SOURCE, RATE, FPS, CHAPTER_COUNT,
    CUES_PER_CHAPTER, CUE_COUNT, read, digest, wav, boundary_checks, mapped_frame)
from retime_video import build_segments

def main():
    out=ROOT/'output'
    plan=read(ROOT/'plan.json');mapping=read(ROOT/'frame_map.json')
    source=read(ORIGINAL_SOURCE/'plan.json')
    assert len(plan['chapters'])==len(mapping['chapters'])==len(source['chapters'])==CHAPTER_COUNT
    cuts=read(ROOT/'cuts.json')['cues'];edits=read(out/'edit_decisions.json')
    recording=read(ROOT/'recording_manifest.json');asr=read(ROOT/'asr_recording_manifest.json')
    assert recording['sha256']==asr['source_sha256']
    assert digest(ROOT/'materials/recording_16k.wav')==asr['guide_sha256']
    if recording.get('processed_wav_sha256'):
        assert digest(ROOT/'materials/recording_processed.wav')==recording['processed_wav_sha256']
    guide=wav(ROOT/'materials/recording_16k.wav',16000)
    boundary_results=boundary_checks(cuts,guide,edits)
    del guide
    processed=wav(ROOT/'materials/recording_processed.wav')
    assert len(cuts)==len(edits)==CUE_COUNT
    for cut,edit in zip(cuts,edits):
        assert cut['key']==edit['key']
        a=round(cut['source_start']*RATE)
        left=round((edit['retained_source_start']-cut['source_start'])*RATE)
        right=round((edit['retained_source_end']-cut['source_start'])*RATE)
        expected=processed[a+left:a+right].copy()
        ramp=min(240,len(expected)//2)
        expected[:ramp]=(expected[:ramp]*np.linspace(0,1,ramp)).astype('<i2')
        expected[-ramp:]=(expected[-ramp:]*np.linspace(1,0,ramp)).astype('<i2')
        part=out/'audio/parts'/f"{cut['key']}.wav"
        assert edit['sha256']==digest(part)
        assert len(expected)==edit['samples'] and np.array_equal(expected,wav(part)),cut['key']
    del processed
    master=wav(out/'audio/narration.wav')
    assert len(master)==plan['duration']*RATE
    offset=0;cue_count=0;min_guard=float('inf');partitions=[]
    for chapter,old,mp in zip(plan['chapters'],source['chapters'],mapping['chapters']):
        assert chapter['id']==old['id']==mp['id']
        assert chapter['start']==offset
        assert mp['expected_frames']==chapter['duration']*FPS
        partition=build_segments(old['duration']*FPS,mp['replacements'],mp['expected_frames'])
        assert len(chapter['cues'])==CUES_PER_CHAPTER
        track=wav(out/'audio/chapters'/f"{chapter['id']:02d}.wav")
        assert len(track)==chapter['duration']*RATE
        assert np.array_equal(master[offset*RATE:(offset+chapter['duration'])*RATE],track)
        cursor=0
        for cue in chapter['cues']:
            assert cue['chapter']==chapter['id']
            assert abs(mapped_frame(cue['speech_source_start_frame'],mp['replacements'])/FPS-cue['at'])<1e-8,cue['key']
            a=round(cue['at']*RATE);pcm=wav(ROOT/cue['file']);b=a+len(pcm)
            assert a>=cursor and b<=len(track)
            assert not np.any(track[cursor:a])
            assert np.array_equal(track[a:b],pcm),cue['key']
            assert abs(len(pcm)/RATE-cue['speech_duration'])<1/RATE
            assert abs(cue['global_at']-(offset+cue['at']))<1e-7
            hold=next(r for r in mp['replacements'] if r['label']==cue['key'])
            transition=(hold['new_start_frame']+hold['new_frame_count'])/FPS
            guard=transition-cue['at']-cue['speech_duration']
            assert guard>=.3,(cue['key'],guard)
            min_guard=min(min_guard,guard);cursor=b;cue_count+=1
        assert not np.any(track[cursor:])
        partitions.append({'chapter':chapter['id'],'source_frames':old['duration']*FPS,
            'output_frames':chapter['duration']*FPS,
            'retained_motion_frames':sum(s.frames for s in partition if s.kind=='keep'),
            'replaced_static_source_frames':sum(s.old_end_frame-s.old_start_frame for s in partition if s.kind=='freeze'),
            'valid_contiguous_partition':True})
        offset+=chapter['duration']
    assert cue_count==CUE_COUNT and offset==plan['duration']
    report={'duration_seconds':offset,'frames':offset*FPS,'chapters':CHAPTER_COUNT,'cues':CUE_COUNT,
        'recording_sha256':recording['sha256'],'exact_parts_from_processed_recording':True,
        'exact_master_pcm_placement':True,'zero_audio_between_cues':True,
        'audio_onsets_follow_frame_map':True,'minimum_transition_guard_seconds':min_guard,
        'acoustic_boundaries':boundary_results,'frame_partitions':partitions,
        'not_final_delivery_verification':True,
        'limitations':'No AAC/media/decode checks here; no listening or pronunciation certification.'}
    (out/'preassembly_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(f"PREASSEMBLY PASSED {cue_count}cues;{offset}s;{offset*FPS}frames;minGuard{min_guard:.6f}s",flush=True)

if __name__=='__main__':main()
