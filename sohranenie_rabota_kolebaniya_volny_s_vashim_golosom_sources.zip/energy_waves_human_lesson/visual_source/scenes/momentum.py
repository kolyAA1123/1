"""Momentum chapters: source pages 1–7, completed symbolic processes only."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from energy_style import *


def mass_body(label, color=CYAN, radius=.32, center=ORIGIN):
    return VGroup(Circle(radius=radius, color=color, fill_color=color,
                         fill_opacity=.14, stroke_width=2.3),
                  eq(label, 24, color)).move_to(center)


def fixed_label(tex, target, shift=UP*.6, color=INK, size=27):
    label=eq(tex, size, color)
    label.add_updater(lambda m: m.move_to(target.get_center()+shift))
    return label


def moving_arrow(target, vector, shift=ORIGIN, color=CYAN):
    get_vector=vector if callable(vector) else lambda: np.array(vector)
    result=arrow(target.get_center()+shift, get_vector(), color)
    result.add_updater(lambda m: m.become(arrow(target.get_center()+shift,
                                                get_vector(), color)))
    return result


def remove_smooth(scene, *objects, run_time=.6):
    freeze(*objects)
    scene.play(*[FadeOut(m) for m in objects], run_time=run_time)


def collision_pair():
    """Internal masses 1 and 2; v=(1.6,.2), elastic u=(-4/15,17/15)."""
    b1=mass_body('m_1', CYAN, .30, [-4.5,.4,0])
    b2=mass_body('m_2', GOLD, .40, [-1.7,.4,0])
    return b1,b2


def velocity_pair(b1,b2,post=False):
    speed1=(-4/15 if post else 1.6)
    speed2=(17/15 if post else .2)
    v1=moving_arrow(b1, RIGHT*speed1*.85, UP*.55, CYAN)
    v2=moving_arrow(b2, RIGHT*speed2*.85, UP*.7, GOLD)
    l1=fixed_label(r'\vec v\,{}^{\prime}_1' if post else r'\vec v_1', b1,
                   UP*.98, CYAN)
    l2=fixed_label(r'\vec v\,{}^{\prime}_2' if post else r'\vec v_2', b2,
                   UP*1.13, GOLD)
    return VGroup(v1,v2,l1,l2)


class MomentumImpulse(ChapterScene):
    chapter_id=1

    def chapter(self):
        self.beat(0, 'Импульс направлен так же, как скорость тела')
        b=mass_body('m', center=[-4,.2,0])
        start=DashedLine([-4,-.45,0],[-4,.7,0],color=GRID)
        end=DashedLine([.2,-.45,0],[.2,.7,0],color=GRID)
        marks=VGroup(txt('начало',19,MUTED).move_to([-4,-.85,0]),
                     txt('конец',19,MUTED).move_to([.2,-.85,0]))
        v=moving_arrow(b,RIGHT*1.1,UP*.55,CYAN)
        p=moving_arrow(b,RIGHT*1.65,DOWN*.55,GOLD)
        vl=fixed_label(r'\vec v',b,UP*.98,CYAN)
        pl=fixed_label(r'\vec p',b,DOWN*.98,GOLD)
        definition=eq(r'\vec p=m\vec v',42).move_to([3.6,1.35,0])
        unit=eq(r'[p]=\mathrm{кг}\cdot\mathrm{м}/\mathrm{с}',28,MUTED).move_to([3.6,.35,0])
        self.show(start,end,marks,b)
        self.show(v,p,vl,pl,definition,unit)
        self.play(b.animate.move_to([.2,.2,0]),run_time=4.5,rate_func=linear)

        self.beat(1, 'Граница системы определяет, какие силы внутренние')
        self.clear_stage()
        rocket=VGroup(Polygon([-.45,-.2,0],[.25,-.2,0],[.6,0,0],[.25,.2,0],[-.45,.2,0],
                              color=CYAN,fill_opacity=.12),txt('ракета',20,CYAN).shift(DOWN*.6)).move_to([-3,.65,0])
        human=VGroup(Circle(radius=.13,color=GOLD).shift(UP*.23),
                     Line([0,.1,0],[0,-.3,0],color=GOLD),
                     Line([-.22,-.05,0],[.22,-.05,0],color=GOLD),
                     Line([0,-.3,0],[-.19,-.5,0],color=GOLD),
                     Line([0,-.3,0],[.19,-.5,0],color=GOLD),
                     txt('космонавт',20,GOLD).shift(DOWN*.9)).move_to([-.8,.65,0])
        border=Ellipse(width=5.1,height=2.8,color=MUTED,stroke_width=1.5).move_to([-2,.4,0])
        ins=txt('выбранная система',22,MUTED).move_to([-2,2.25,0])
        inner=VGroup(arrow([-2.5,.7,0],[.65,0,0],ROSE),
                     arrow([-1.25,.7,0],[-.65,0,0],ROSE))
        innerlabel=txt('взаимное притяжение — внутренние силы',22).move_to([0,-1.65,0])
        outer=txt('Внешняя сила — воздействие тела\nза границей выбранной системы',22,MUTED).move_to([3.7,.6,0])
        if outer.width>4.4:outer.scale_to_fit_width(4.4)
        self.show(rocket,human,border,ins)
        self.show(inner,innerlabel)
        self.show(outer)
        self.show(txt('Здесь внешними воздействиями пренебрегаем',21,MUTED).move_to([0,-2.4,0]))

        self.beat(2, 'Постоянная равнодействующая действует весь выделенный интервал')
        self.clear_stage()
        tracker=ValueTracker(0)
        b=mass_body('m',center=[-3.8,.1,0])
        b.add_updater(lambda m:m.move_to([-3.8+.8*tracker.get_value()+2.4*tracker.get_value()**2,.1,0]))
        velocity=moving_arrow(b,lambda:RIGHT*(.6+3.6*tracker.get_value()),DOWN*.55,CYAN)
        force=moving_arrow(b,RIGHT*1.15,UP*.6,ROSE)
        fl=fixed_label(r'\vec F=\mathrm{const}',b,UP*1.02,ROSE,24)
        vl=fixed_label(r'\vec v',b,DOWN*.98,CYAN)
        timeline=Line([-4.8,-1.7,0],[4.8,-1.7,0],color=MUTED)
        ticks=VGroup(Line([-4.8,-1.83,0],[-4.8,-1.57,0],color=MUTED),
                     Line([4.8,-1.83,0],[4.8,-1.57,0],color=MUTED))
        dot=Dot([-4.8,-1.7,0],radius=.065,color=GOLD)
        dot.add_updater(lambda m:m.move_to([-4.8+9.6*tracker.get_value(),-1.7,0]))
        timewords=VGroup(eq(r't_{\mathrm{н}}',23).move_to([-4.8,-2.15,0]),
                        eq(r't_{\mathrm{к}}',23).move_to([4.8,-2.15,0]),
                        eq(r'\Delta t',28,GOLD).move_to([0,-2.15,0]))
        acceleration=eq(r'\vec a=\frac{\vec v_{\mathrm{к}}-\vec v_{\mathrm{н}}}{\Delta t}',36).move_to([2.65,1.85,0])
        self.show(b,velocity,vl,force,fl,timeline,ticks,dot,timewords,acceleration)
        self.play(tracker.animate.set_value(1),run_time=5.2,rate_func=linear)
        freeze(b,dot)
        remove_smooth(self,force,fl)
        self.show(eq(r'\vec v_{\mathrm{к}}\ne\vec v_{\mathrm{н}}',28,CYAN).move_to([2.7,.35,0]))

        self.beat(3, 'Импульс силы равен изменению импульса тела')
        self.clear_stage()
        line1=eq(r'\vec F=m\vec a=m\frac{\vec v_{\mathrm{к}}-\vec v_{\mathrm{н}}}{\Delta t}',40).move_to([0,1.7,0])
        line2=eq(r'\vec F\Delta t=m\vec v_{\mathrm{к}}-m\vec v_{\mathrm{н}}',40).move_to([0,.4,0])
        line3=eq(r'\vec F\Delta t=\Delta\vec p',46,GOLD).move_to([0,-1.0,0])
        self.show(line1)
        self.show(line2,run_time=1.2)
        self.show(line3,run_time=1.2)
        self.show(SurroundingRectangle(line3,color=GOLD,buff=.2),
                  txt('Масса постоянна; сила постоянна на интервале Δt',22,MUTED).move_to([0,-2.3,0]))

        self.beat(4, 'При нулевой равнодействующей импульс не изменяется')
        self.clear_stage()
        b=mass_body('m',center=[-4,.2,0])
        vel=moving_arrow(b,RIGHT*1.1,UP*.55,CYAN)
        momentum=moving_arrow(b,RIGHT*1.65,DOWN*.55,GOLD)
        labels=VGroup(fixed_label(r'\vec v',b,UP*.95,CYAN),
                      fixed_label(r'\vec p',b,DOWN*.95,GOLD))
        result=eq(r'\vec F=0\quad\Longrightarrow\quad\vec p_{\mathrm{к}}=\vec p_{\mathrm{н}}',37).move_to([0,2.0,0])
        self.show(b,vel,momentum,labels,result)
        self.play(b.animate.shift(RIGHT*5),run_time=4.8,rate_func=linear)
        self.show(txt('Скорость постоянна',25,CYAN).move_to([0,-2.2,0]))


class MomentumConservation(ChapterScene):
    chapter_id=2

    def chapter(self):
        self.beat(0, 'Рассматриваем суммарный импульс двух тел замкнутой системы')
        b1,b2=collision_pair()
        boundary=RoundedRectangle(width=10.8,height=2.8,corner_radius=.18,color=MUTED,
                                  stroke_width=1.4).move_to([0,.45,0])
        velocities=velocity_pair(b1,b2)
        initial=eq(r'\vec p_{\mathrm{н}1}=m_1\vec v_1,\qquad\vec p_{\mathrm{н}2}=m_2\vec v_2',33).move_to([0,-1.7,0])
        self.show(boundary,b1,b2,velocities,initial)
        self.phase_title=txt('до взаимодействия',23,MUTED).move_to([2.8,2.25,0])
        self.show(self.phase_title)

        self.beat(1, 'Внутренние силы приложены к разным телам и противоположны')
        self.play(b1.animate.shift(RIGHT*2.4),b2.animate.shift(RIGHT*.3),run_time=3.1,rate_func=linear)
        remove_smooth(self,velocities,initial)
        self.play(Transform(self.phase_title,txt('взаимодействие',23,MUTED).move_to([2.8,2.25,0])),run_time=.5)
        forces=VGroup(moving_arrow(b1,LEFT*1.1,DOWN*.05,ROSE),
                      moving_arrow(b2,RIGHT*1.1,DOWN*.05,ROSE))
        force_labels=VGroup(fixed_label(r'\vec F_{\mathrm{на}\,1}',b1,DOWN*.7,ROSE,25),
                           fixed_label(r'\vec F_{\mathrm{на}\,2}',b2,DOWN*.85,ROSE,25))
        relation=eq(r'\vec F_{\mathrm{на}\,1}=-\vec F_{\mathrm{на}\,2}',34,ROSE).move_to([2.6,-1.8,0])
        self.show(forces,force_labels,relation)
        self.wait(.8)
        remove_smooth(self,forces,force_labels)
        post=velocity_pair(b1,b2,True)
        self.show(post)
        self.play(b1.animate.shift(LEFT*.48),b2.animate.shift(RIGHT*2.04),run_time=3.72,rate_func=linear)
        self.play(Transform(self.phase_title,txt('после взаимодействия',23,MUTED).move_to([2.8,2.25,0])),run_time=.6)

        self.beat(2, 'Изменение импульса записываем отдельно для каждого тела')
        self.clear_stage()
        row1=eq(r'\vec F_{\mathrm{на}\,1}\Delta t=\vec p_{\mathrm{к}1}-\vec p_{\mathrm{н}1}',38,CYAN).move_to([0,1.25,0])
        row2=eq(r'\vec F_{\mathrm{на}\,2}\Delta t=\vec p_{\mathrm{к}2}-\vec p_{\mathrm{н}2}',38,GOLD).move_to([0,-.1,0])
        self.show(row1)
        self.show(row2)
        self.show(txt('Один и тот же интервал взаимодействия Δt',24,MUTED).move_to([0,-1.6,0]))

        self.beat(3, 'В сумме уравнений внутренние силы дают ноль')
        self.clear_stage()
        sumline=eq(r'(\vec F_{\mathrm{на}\,1}+\vec F_{\mathrm{на}\,2})\Delta t'
                   r'=\vec p_{\mathrm{к}1}-\vec p_{\mathrm{н}1}+\vec p_{\mathrm{к}2}-\vec p_{\mathrm{н}2}',31).move_to([0,1.2,0])
        if sumline.width>12:sumline.scale_to_fit_width(12)
        third=eq(r'\vec F_{\mathrm{на}\,1}+\vec F_{\mathrm{на}\,2}=0',34,ROSE).move_to([0,-.15,0])
        zero=eq(r'0=\vec p_{\mathrm{к}1}+\vec p_{\mathrm{к}2}-\vec p_{\mathrm{н}1}-\vec p_{\mathrm{н}2}',34).move_to([0,-1.65,0])
        self.show(sumline)
        self.show(third)
        self.show(zero)

        self.beat(4, 'Сумма импульсов до взаимодействия равна сумме после')
        self.clear_stage()
        two=eq(r'\vec p_{\mathrm{н}1}+\vec p_{\mathrm{н}2}=\vec p_{\mathrm{к}1}+\vec p_{\mathrm{к}2}',39,GOLD).move_to([0,1.6,0])
        many=eq(r'\vec p_{\mathrm{н}1}+\cdots+\vec p_{\mathrm{н}n}'
                r'=\vec p_{\mathrm{к}1}+\cdots+\vec p_{\mathrm{к}n}',38).move_to([0,.1,0])
        self.show(two)
        self.show(many)
        self.show(txt('Инерциальная система отсчёта · замкнутая система тел',24,MUTED).move_to([0,-1.3,0]),
                  txt('Суммарный импульс остаётся постоянным',28,GOLD).move_to([0,-2.25,0]))


class ConservationConditions(ChapterScene):
    chapter_id=3

    def chapter(self):
        self.beat(0, 'Проверяем внешние силы для выбранной системы')
        criterion=eq(r'\sum\vec F_{\mathrm{внеш}}=0\quad\Longrightarrow\quad\vec p_{\mathrm{сист}}=\mathrm{const}',38,GOLD).move_to([0,1.65,0])
        self.show(criterion)
        conditions=VGroup(txt('Компенсация внешних сил',29,CYAN),
                          txt('Короткое взаимодействие: мал внешний импульс',27,ROSE),
                          txt('Нулевая проекция внешней силы на ось',27,LAVENDER)).arrange(DOWN,buff=.7).move_to([0,-.55,0])
        for row in conditions:self.show(row,run_time=.8)

        self.beat(1, 'На горизонтали без трения внешние силы скомпенсированы')
        self.clear_stage()
        floor=Line([-5.5,-1.1,0],[5.5,-1.1,0],color=MUTED)
        bodies=VGroup(*[VGroup(Rectangle(width=.9,height=.6,color=c,fill_color=c,fill_opacity=.12),eq(f'm_{i}',25,c)).move_to([x,-.8,0])
                       for i,x,c in [(1,-2.2,CYAN),(2,2.2,GOLD)]])
        self.show(floor,bodies,txt('Горизонтальная поверхность без трения',25,MUTED).move_to([0,2.25,0]))
        forces=VGroup()
        for i,b in enumerate(bodies,1):
            x=b.get_x()
            forces.add(arrow([x,-.8,0],[0,1.2,0],CYAN),arrow([x,-.8,0],[0,-1.2,0],ROSE),
                       eq(rf'\vec N_{i}',27,CYAN).move_to([x+.55,.15,0]),
                       eq(rf'm_{i}\vec g',27,ROSE).move_to([x+.65,-1.8,0]))
        self.show(forces)
        self.show(eq(r'\vec N_i+m_i\vec g=0',34).move_to([0,1.35,0]))
        self.show(eq(r'\sum\vec F_{\mathrm{внеш}}=0',31,GOLD).move_to([0,-2.6,0]))

        self.beat(2, 'При взрыве учитываем только краткий интервал взаимодействия')
        self.clear_stage()
        whole=Rectangle(width=.8,height=.4,color=CYAN,fill_color=CYAN,fill_opacity=.15).move_to([-3.5,.8,0])
        whole_mass=fixed_label(r'm_1+m_2',whole,UP*.5,CYAN,23)
        before_t=ValueTracker(0)
        whole.add_updater(lambda m:m.move_to([-3.5+1.8*before_t.get_value(),
                                              .8-.036*before_t.get_value()-.1296*before_t.get_value()**2,0]))
        gravity=moving_arrow(whole,DOWN*.75,DOWN*.1,ROSE)
        glabel=fixed_label(r'(m_1+m_2)\vec g',whole,DOWN*1.2,ROSE,23)
        speed=moving_arrow(whole,lambda:np.array([.9,-.018-.1296*before_t.get_value(),0]),UP*.42,CYAN)
        self.show(whole,whole_mass,gravity,glabel,speed,
                  txt('Схема краткого интервала взрыва',25,MUTED).move_to([0,2.3,0]))
        self.play(before_t.animate.set_value(1),run_time=1.8,rate_func=linear)
        center=whole.get_center()
        p1=Rectangle(width=.4,height=.4,color=CYAN,fill_color=CYAN,fill_opacity=.15).move_to(center+LEFT*.2)
        p2=Rectangle(width=.4,height=.4,color=GOLD,fill_color=GOLD,fill_opacity=.15).move_to(center+RIGHT*.2)
        masses=VGroup(fixed_label('m_1',p1,UP*.95,CYAN,22),fixed_label('m_2',p2,UP*.95,GOLD,22))
        # Equal fragment masses: gravity arrows add to the original one.
        g1=moving_arrow(p1,DOWN*.375,DOWN*.15,ROSE)
        g2=moving_arrow(p2,DOWN*.375,DOWN*.15,ROSE)
        gl1=fixed_label(r'm_1\vec g',p1,DOWN*.8+LEFT*.3,ROSE,21)
        gl2=fixed_label(r'm_2\vec g',p2,DOWN*.8+RIGHT*.3,ROSE,21)
        freeze(whole,whole_mass,gravity,glabel,speed)
        self.play(FadeOut(whole),FadeOut(whole_mass),FadeOut(speed),
                  FadeIn(p1),FadeIn(p2),run_time=.7)
        self.show(g1,g2,gl1,gl2,masses,run_time=.5)
        # The combined gravity arrow remains until both fragment weights are visible.
        remove_smooth(self,gravity,glabel,run_time=.5)
        internal=VGroup(moving_arrow(p1,LEFT*1.2,UP*.15,ROSE),moving_arrow(p2,RIGHT*1.2,UP*.15,ROSE))
        self.show(internal,run_time=.5)
        self.wait(.5)
        remove_smooth(self,internal,run_time=.5)
        q=ValueTracker(0)
        c1=p1.get_center().copy();c2=p2.get_center().copy()
        p1.add_updater(lambda m:m.move_to(c1+[-.5*q.get_value(),-.246*q.get_value()-.09*q.get_value()**2,0]))
        p2.add_updater(lambda m:m.move_to(c2+[3.5*q.get_value(),-.246*q.get_value()-.09*q.get_value()**2,0]))
        fragment_v=VGroup(moving_arrow(p1,lambda:np.array([-.3,-.1476-.108*q.get_value(),0]),UP*.55,CYAN),
                         moving_arrow(p2,lambda:np.array([2.1,-.1476-.108*q.get_value(),0]),UP*.55,GOLD))
        self.show(fragment_v,run_time=.5)
        self.play(q.animate.set_value(1),run_time=1.5,rate_func=linear)
        freeze(p1,p2)
        formula=eq(r'(m_1+m_2)\vec v\ \approx\ m_1\vec v_1+m_2\vec v_2',33).move_to([0,-2.0,0])
        self.show(formula,txt('Приближённо за малое время; тяжесть продолжает действовать',21,MUTED).move_to([0,-2.65,0]))

        self.beat(3, 'Шар пойман тележкой: сохраняется горизонтальная проекция импульса')
        self.clear_stage()
        floor=Line([-5.5,-1.35,0],[5.5,-1.35,0],color=MUTED)
        cart=VGroup(VMobject(color=GOLD,stroke_width=3).set_points_as_corners([[-.8,.35,0],[-.8,-.2,0],[.8,-.2,0],[.8,.35,0]]),
                    Circle(radius=.12,color=GOLD).move_to([-.5,-.4,0]),Circle(radius=.12,color=GOLD).move_to([.5,-.4,0]))
        cart.move_to([0,-.91,0])
        cartlabel=eq('M',26,GOLD).move_to([0,-1.9,0])
        ball=Dot([-3,1.65,0],radius=.13,color=CYAN)
        bl=fixed_label('m',ball,UP*.34,CYAN,24)
        q=ValueTracker(0)
        # x is uniform, y is a complete downward parabola, ending inside the tub.
        ball.add_updater(lambda m:m.move_to([-3+3*q.get_value(),1.65-.7*q.get_value()-1.78*q.get_value()**2,0]))
        velocity=moving_arrow(ball,lambda:np.array([1.08,(-.7-3.56*q.get_value())*.36,0]),ORIGIN,CYAN)
        vx=arrow([-3,2.2,0],[1.08,0,0],CYAN)
        vxl=eq(r'v_x',24,CYAN).move_to([-2.45,2.5,0])
        xy=VGroup(arrow([3.9,-.1,0],[1.25,0,0],MUTED),arrow([3.9,-.1,0],[0,1.25,0],MUTED),
                  eq('x',23,MUTED).move_to([5.4,-.1,0]),eq('y',23,MUTED).move_to([3.9,1.45,0]))
        self.show(floor,cart,cartlabel,ball,bl)
        self.show(xy,velocity,vx,vxl)
        self.play(q.animate.set_value(1),run_time=2.5,rate_func=linear)
        freeze(ball)
        remove_smooth(self,velocity,bl,vx,vxl,run_time=.5)
        # The ball is now fully inside the cart and remains with it.
        pair=VGroup(cart,ball)
        after=arrow([.8,-.7,0],[.27,0,0],GOLD)
        after.add_updater(lambda m:m.become(arrow(cart.get_center()+[.8,.21,0],[.27,0,0],GOLD)))
        label=eq(r'\vec v',25,GOLD)
        label.add_updater(lambda m:m.move_to(cart.get_center()+[1.05,.65,0]))
        cartlabel.add_updater(lambda m:m.move_to(cart.get_center()+DOWN*.95))
        self.show(after,label,
                  eq(r'p_{x,\mathrm{до}}=p_{x,\mathrm{после}}',31).move_to([-2.7,-2.6,0]),
                  txt('По вертикали действует внешний импульс опоры',21,MUTED).move_to([1.4,2.25,0]))
        self.play(pair.animate.shift(RIGHT*1.2),run_time=4,rate_func=linear)
        self.show(eq(r'mv_x=(M+m)v',29,GOLD).move_to([2.7,-2.6,0]))

        self.beat(4, 'Различаем полный вектор, приближённое сохранение и одну проекцию')
        self.clear_stage()
        rows=[(r'\sum\vec F_{\mathrm{внеш}}=0', 'Суммарный вектор импульса постоянен', CYAN),
              (r'\Delta t\ \mathrm{мало}', 'Внешним импульсом можно пренебречь', ROSE),
              (r'\sum F_{\mathrm{внеш},x}=0', 'Сохраняется только проекция на выбранную ось', LAVENDER)]
        for i,(formula,description,color) in enumerate(rows):
            y=1.7-i*1.55
            self.show(eq(formula,33,color).move_to([-3.6,y,0]),
                      txt(description,23).move_to([1.9,y,0]),run_time=.9)


class CollisionTypes(ChapterScene):
    chapter_id=4

    def chapter(self):
        self.beat(0, 'Центральный удар: сила направлена по линии центров тел')
        b1=mass_body('m_1',CYAN,.3,[-3.8,.35,0])
        b2=mass_body('m_2',GOLD,.42,[-.8,.35,0])
        line=DashedLine([-5,.35,0],[5,.35,0],color=GRID)
        self.show(line,b1,b2,txt('Линия центров масс сталкивающихся тел',24,MUTED).move_to([0,1.9,0]))
        # A lighter incoming body and a resting heavier body: a possible rebound.
        v=moving_arrow(b1,RIGHT*1.2,UP*.65,CYAN)
        self.show(v)
        self.play(b1.animate.shift(RIGHT*2.28),run_time=2.4,rate_func=linear)
        remove_smooth(self,v,run_time=.4)
        force=VGroup(moving_arrow(b1,LEFT*1.0,ORIGIN,ROSE),moving_arrow(b2,RIGHT*1.0,ORIGIN,ROSE))
        self.show(force,run_time=.5)
        self.wait(.5)
        remove_smooth(self,force,run_time=.5)
        out=VGroup(moving_arrow(b1,LEFT*.4,UP*.65,CYAN),moving_arrow(b2,RIGHT*.8,UP*.75,GOLD))
        self.show(out,run_time=.5)
        self.play(b1.animate.shift(LEFT*.76),b2.animate.shift(RIGHT*1.52),run_time=2.4,rate_func=linear)

        self.beat(1, 'Абсолютно неупругий удар: тела сближаются до контакта')
        self.clear_stage()
        b1=mass_body('m_1',CYAN,.32,[-4,.25,0])
        b2=mass_body('m_2',GOLD,.32,[-1.5,.25,0])
        # Equal masses; initial speeds 1.5 and .5, final common speed 1.
        self.b1,self.b2=b1,b2
        before=VGroup(moving_arrow(b1,RIGHT*1.2,UP*.65,CYAN),
                      moving_arrow(b2,RIGHT*.4,UP*.65,GOLD),
                      fixed_label(r'\vec v_{01}',b1,UP*1.06,CYAN),
                      fixed_label(r'\vec v_{02}',b2,UP*1.06,GOLD))
        self.show(b1,b2,before,
                  txt('После удара тела движутся как единое целое',25,MUTED).move_to([0,-1.65,0]))
        self.play(b1.animate.shift(RIGHT*2.79),b2.animate.shift(RIGHT*.93),run_time=3.4,rate_func=linear)
        remove_smooth(self,before)
        join=SurroundingRectangle(VGroup(b1,b2),color=LAVENDER,buff=.1,corner_radius=.08)
        self.show(join,run_time=.8)
        self.join=join

        self.beat(2, 'Сцеплённая пара проходит общий участок с одной скоростью')
        b1,b2=self.b1,self.b2
        pair=VGroup(b1,b2,self.join)
        common=moving_arrow(pair,RIGHT*.8,UP*.7,GOLD)
        vl=fixed_label(r'\vec v',pair,UP*1.12,GOLD)
        mass=fixed_label(r'm_1+m_2',pair,DOWN*.9,LAVENDER,28)
        self.show(common,vl,mass)
        self.play(pair.animate.shift(RIGHT*1.86),run_time=3.4,rate_func=linear)
        result=eq(r'm_1\vec v_{01}+m_2\vec v_{02}=(m_1+m_2)\vec v',33).move_to([0,-2.45,0])
        self.show(result)

        self.beat(3, 'Абсолютно упругий удар: кинетическая энергия до и после одинакова')
        self.clear_stage()
        b1=mass_body('m_1',CYAN,.3,[-3.8,.3,0])
        b2=mass_body('m_2',GOLD,.42,[-.8,.3,0])
        initial=VGroup(moving_arrow(b1,RIGHT*1.2,UP*.65,CYAN),fixed_label(r'\vec v_1',b1,UP*1.05,CYAN))
        self.show(b1,b2,initial)
        self.play(b1.animate.shift(RIGHT*2.28),run_time=2.1,rate_func=linear)
        remove_smooth(self,initial,run_time=.4)
        contact=VGroup(moving_arrow(b1,LEFT*.9,ORIGIN,ROSE),moving_arrow(b2,RIGHT*.9,ORIGIN,ROSE))
        self.show(contact,run_time=.4)
        self.wait(.3)
        remove_smooth(self,contact,run_time=.4)
        final=VGroup(moving_arrow(b1,LEFT*.4,UP*.65,CYAN),moving_arrow(b2,RIGHT*.8,UP*.75,GOLD),
                     fixed_label(r'\vec u_1',b1,UP*1.05,CYAN),fixed_label(r'\vec u_2',b2,UP*1.15,GOLD))
        self.show(final,run_time=.5)
        self.play(b1.animate.shift(LEFT*.76),b2.animate.shift(RIGHT*1.52),run_time=2.1,rate_func=linear)
        self.show(eq(r'E_{\mathrm{к},\,\mathrm{до}}=E_{\mathrm{к},\,\mathrm{после}}',36,GOLD).move_to([0,-1.55,0]),
                  txt('Сравниваем состояния до и после взаимодействия',22,MUTED).move_to([0,-2.4,0]))

        self.beat(4, 'Центральность — геометрия; упругость характеризует итог взаимодействия')
        self.clear_stage()
        entries=[('Центральный удар','Сила — вдоль линии центров',CYAN),
                 ('Абсолютно неупругий','После удара — единое целое',LAVENDER),
                 ('Абсолютно упругий','Кинетическая энергия до и после равна',GOLD)]
        for i,(name,meaning,color) in enumerate(entries):
            y=1.9-i*1.35
            self.show(txt(name,25,color).move_to([-3.55,y,0]),
                      txt(meaning,23).move_to([2.2,y,0]),run_time=.9)
        self.show(txt('Для сохранения импульса проверяем замкнутость системы',24,MUTED).move_to([0,-2.45,0]))
