"""Mux supplied recorded speech with frame-mapped energy and waves chapters."""
from pathlib import Path
import json,subprocess,wave
ROOT=Path(__file__).resolve().parent
PREFIX='sohranenie_rabota_kolebaniya_volny_s_vashim_golosom'
# Mono80k preserves speech clarity and keeps this HD60 file under100MiB for GitHub.
def main():
 plan=json.loads((ROOT/'plan.json').read_text());out=ROOT/'output'
 clips=[out/'chapters'/f"{c['id']:02d}_{c['class']}.mp4" for c in plan['chapters']]
 assert all(p.is_file() for p in clips)
 voice=out/'audio/narration.wav'
 with wave.open(str(voice),'rb') as w:
  assert (w.getnchannels(),w.getsampwidth(),w.getframerate(),w.getnframes())==(1,2,48000,plan['duration']*48000)
 concat=out/'concat.txt';concat.write_text(''.join("file '"+str(p).replace("'","'\\''")+"'\n" for p in clips))
 meta=out/'chapters.ffmeta';lines=[';FFMETADATA1','title=Законы сохранения, работа, мощность, колебания и волны — с вашим голосом','artist=Озвучка из предоставленной пользователем записи']
 for c in plan['chapters']:
  title=c['title'].replace('=','\\=').replace(';','\\;').replace('#','\\#')
  lines+=['[CHAPTER]','TIMEBASE=1/1000',f"START={c['start']*1000}",f"END={(c['start']+c['duration'])*1000}",'title='+title]
 meta.write_text('\n'.join(lines)+'\n')
 movie=out/f'{PREFIX}_1080p60.mp4'
 subprocess.run(['ffmpeg','-hide_banner','-v','warning','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(voice),'-i',str(meta),'-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-c:v','copy','-c:a','aac','-b:a','80k','-ar','48000','-ac','1','-t',str(plan['duration']),'-movflags','+faststart',str(movie)],check=True)
 print(f'ASSEMBLED {movie.name}: {plan["duration"]}s, {movie.stat().st_size} bytes',flush=True)
if __name__=='__main__':main()
