"""Verify isolated label-position fixes and preservation of original assets."""
from pathlib import Path
import difflib,hashlib,json
from audit_source_timeline import mp4_frames,probe

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'energy_waves_lesson'
NEW=ROOT/'visual_source'
CORRECTED=[3,5,6,7]

def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def partials(ch,root):
    cls=ch['class'];module=ch['module'][:-3]
    p=root/f"output/render_cache/{ch['id']:02d}/videos/{module}/1080p60/partial_movie_files/{cls}/partial_movie_file_list.txt"
    paths=[Path(s[6:-1].removeprefix('file:')) for s in p.read_text().splitlines() if s.startswith("file '")]
    return [mp4_frames(p) for p in paths]

def main():
    before=read(ROOT/'output/visual_source_before.json');plan=read(OLD/'plan.json')
    originals=[]
    for item in before['original_chapters']:
        p=OLD/'output/chapters'/item['name'];actual=sha(p)
        assert actual==item['sha256'],p
        originals.append({'id':int(item['name'][:2]),'name':item['name'],
            'before_sha256':item['sha256'],'after_sha256':actual,'unchanged':True})
    for item in before['original_files']:
        assert sha(OLD/item['relative'])==item['sha256'],item['relative']
        if item['relative'] not in ['scenes/work_energy.py','scenes/momentum.py']:
            assert sha(NEW/item['relative'])==item['sha256'],item['relative']
    old=(OLD/'scenes/work_energy.py').read_text()
    expected=old.replace("txt('1', 20, MUTED).move_to([-4.8, -1.3, 0])", "txt('1', 20, MUTED).move_to([-4.8, -2.45, 0])")
    expected=expected.replace("txt('2', 20, MUTED).move_to([-1.35, -1.3, 0])", "txt('2', 20, MUTED).move_to([-1.35, -2.45, 0])")
    expected=expected.replace('def extension_force(body, extension, vector, tex, color, label_side=UP):',
                              'def extension_force(body, extension, vector, tex, color, label_side=UP, label_buff=.1):')
    expected=expected.replace('label.next_to(shaft, label_side, buff=.1)',
                              'label.next_to(shaft, label_side, buff=label_buff)')
    line="elastic = extension_force(block, p, LEFT * .9, r'\\vec F_{\\text{упр}}', GOLD, DOWN)"
    expected=expected.replace(line,line[:-1]+', label_buff=.3)')
    current=(NEW/'scenes/work_energy.py').read_text()
    assert current==expected,'Unexpected visual source edit'
    diff=list(difflib.unified_diff(old.splitlines(),current.splitlines(),
              fromfile='original/scenes/work_energy.py',tofile='visual_source/scenes/work_energy.py',n=2))
    old_momentum=(OLD/'scenes/momentum.py').read_text()
    expected_momentum=old_momentum.replace(
        "gl1=fixed_label(r'm_1\\vec g',p1,DOWN*.8,ROSE,21)",
        "gl1=fixed_label(r'm_1\\vec g',p1,DOWN*.8+LEFT*.3,ROSE,21)")
    expected_momentum=expected_momentum.replace(
        "gl2=fixed_label(r'm_2\\vec g',p2,DOWN*.8,ROSE,21)",
        "gl2=fixed_label(r'm_2\\vec g',p2,DOWN*.8+RIGHT*.3,ROSE,21)")
    new_momentum=(NEW/'scenes/momentum.py').read_text()
    assert new_momentum==expected_momentum,'Unexpected momentum source edit'
    diff+=list(difflib.unified_diff(old_momentum.splitlines(),new_momentum.splitlines(),
               fromfile='original/scenes/momentum.py',tofile='visual_source/scenes/momentum.py',n=2))
    corrections=[]
    descriptions={3:'Adjacent fragment-weight labels moved outboard by0.3world units each, retaining gravity arrow geometry and timing.',
                  5:'State labels1/2 moved below displacement arrow at original endpoint x values; clear of the full moving weight-shaft range.',
                  6:'Elastic-force label moved0.2world units below floor in spring-work scenes.',
                  7:'Elastic-force label moved0.2world units below floor in spring-energy scene.'}
    for ch in plan['chapters']:
        name=f"{ch['id']:02d}_{ch['class']}.mp4";p=NEW/'output/chapters'/name
        if ch['id'] not in CORRECTED:
            assert p.is_symlink() and p.resolve()==OLD/'output/chapters'/name
            continue
        assert p.is_file() and not p.is_symlink(),p
        old_frames=partials(ch,OLD);new_frames=partials(ch,NEW)
        assert old_frames==new_frames,(ch['id'],old_frames,new_frames)
        v=probe(p)
        assert (int(v['width']),int(v['height']),v['r_frame_rate'])==(1920,1080,'60/1')
        assert int(v['nb_frames'])==mp4_frames(p)==ch['duration']*60==sum(old_frames)
        corrections.append({'id':ch['id'],'class':ch['class'],
            'original_sha256':sha(OLD/'output/chapters'/name),'new_sha256':sha(p),
            'source_frames':int(v['nb_frames']),'same_frame_count':True,
            'partial_frame_counts_unchanged':True,'partial_frame_counts':new_frames,
            'event_timing_unchanged':True,'label_changes':descriptions[ch['id']]})
    result={'new_source_root':str(NEW),'original_sources_unchanged':True,
            'original_source_files_checked':len(before['original_files']),
            'original_chapters_before_after':originals,'all23_original_chapters_unchanged':True,
            'only_label_positions_changed':True,'source_diff':diff,
            'corrected_chapter_ids':CORRECTED,'chapters':corrections}
    (ROOT/'visual_corrections.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('Verified4 isolated label corrections;23 original clips and all original source files unchanged.',flush=True)

if __name__=='__main__':main()
