"""Capture115 source states and five reviewed intermediate states, read-only."""
from pathlib import Path
import json,subprocess,math
from concurrent.futures import ThreadPoolExecutor
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/source_contacts';OUT.mkdir(parents=True,exist_ok=True)
SOURCE=ROOT/'visual_source/output/chapters'
anchors=json.loads((ROOT/'narration_anchors.json').read_text())
FPS=anchors['fps'];FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
DETAILS={'01_03':2313,'02_02':1310,'12_03':1783,'21_03':2085,'23_01':326}

def capture_frame(source,frame,destination,thumbnail=False):
    seek=max(0,frame//FPS-1);local=frame-seek*FPS
    vf=f'trim=start_frame={local}:end_frame={local+1}'
    if thumbnail:vf+=',scale=384:216'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-threads','1',
                    '-ss',str(seek),'-i',str(source),'-an','-vf',vf,
                    '-frames:v','1','-threads','1','-q:v','2','-y',str(destination)],check=True)

def capture(cue):
    key=cue['key'];sources=list(SOURCE.glob(f"{cue['chapter']:02d}_*.mp4"))
    assert len(sources)==1,(key,sources)
    frame=(cue['hold_start_frame']+cue['hold_end_frame']-1)//2
    capture_frame(sources[0],frame,OUT/f'{key}.jpg',True)
    result={'key':key,'source_file':sources[0].name,'source_frame':frame,
            'source_time_seconds':frame/FPS,'thumbnail':f'{key}.jpg'}
    if key in DETAILS:
        capture_frame(sources[0],DETAILS[key],OUT/f'{key}_intermediate_full.jpg')
        result['intermediate_detail']={'frame':DETAILS[key],'file':f'{key}_intermediate_full.jpg'}
    return result

with ThreadPoolExecutor(max_workers=1) as pool:items=list(pool.map(capture,anchors['cues']))
sheet_count=math.ceil(len(items)/25)
for k in range(sheet_count):
    group=items[k*25:(k+1)*25]
    height=math.ceil(len(group)/5)*248
    canvas=Image.new('RGB',(1920,height),'#161616');draw=ImageDraw.Draw(canvas)
    for i,item in enumerate(group):
        x=(i%5)*384;y=(i//5)*248
        with Image.open(OUT/item['thumbnail']) as im:canvas.paste(im,(x,y))
        draw.text((x+10,y+221),f"{item['key']}  source {item['source_time_seconds']:.2f}s",font=FONT,fill='white')
    canvas.save(OUT/f'sheet_{k+1:02d}.jpg',quality=95)
manifest={'fps':FPS,'capture':'Midpoint of each terminal static hold,115cues; five intermediate exact sourceframes. Original source files unchanged; isolated visual corrections in chapters3/5/6/7.',
          'items':items,'sheets':[f'sheet_{i:02d}.jpg' for i in range(1,sheet_count+1)],
          'intermediate_details':{k:{'frame':v,'file':f'{k}_intermediate_full.jpg'} for k,v in DETAILS.items()}}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('Created',len(items),'cue frames and',sheet_count,'sheets at',OUT)
