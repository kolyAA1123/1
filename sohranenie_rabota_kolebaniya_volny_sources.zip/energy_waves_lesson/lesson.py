"""Manim entry points for individual source-bound chapters."""
from scenes import momentum as _momentum
from scenes import work_energy as _work_energy
from scenes import oscillations as _oscillations
from scenes import waves as _waves

class MomentumImpulse(_momentum.MomentumImpulse):
    pass

class MomentumConservation(_momentum.MomentumConservation):
    pass

class ConservationConditions(_momentum.ConservationConditions):
    pass

class CollisionTypes(_momentum.CollisionTypes):
    pass

class ConstantWork(_work_energy.ConstantWork):
    pass

class VariableWork(_work_energy.VariableWork):
    pass

class PotentialEnergy(_work_energy.PotentialEnergy):
    pass

class KineticWork(_work_energy.KineticWork):
    pass

class MechanicalEnergy(_work_energy.MechanicalEnergy):
    pass

class Power(_work_energy.Power):
    pass

class Efficiency(_work_energy.Efficiency):
    pass

class OscillationTypes(_oscillations.OscillationTypes):
    pass

class PeriodFrequencyAmplitude(_oscillations.PeriodFrequencyAmplitude):
    pass

class HarmonicDerivatives(_oscillations.HarmonicDerivatives):
    pass

class SpringCycle(_oscillations.SpringCycle):
    pass

class SpringPeriod(_oscillations.SpringPeriod):
    pass

class SimplePendulum(_oscillations.SimplePendulum):
    pass

class PendulumEnergy(_waves.PendulumEnergy):
    pass

class EnergyPeriodPhase(_waves.EnergyPeriodPhase):
    pass

class Resonance(_waves.Resonance):
    pass

class MechanicalWaves(_waves.MechanicalWaves):
    pass

class SoundProperties(_waves.SoundProperties):
    pass

class SoundResonanceWavelength(_waves.SoundResonanceWavelength):
    pass
