"""Pure-black visual system with controlled, completed transitions."""
from pathlib import Path
import json
import re
import numpy as np
from manim import *

ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'plan.json').read_text())
BLACK_BG='#000000'
INK='#EDF2FA'
MUTED='#9AAAC0'
CYAN='#58DCE6'
GOLD='#FFD071'
ROSE='#F17C95'
LAVENDER='#A394FA'
GRID='#28354A'
FONT='DejaVu Sans'
CYRILLIC_TEX=TexTemplate(tex_compiler='xelatex',output_format='.xdv',
    preamble=r'\usepackage{amsmath}\usepackage{amssymb}\usepackage{fontspec}\setmainfont{DejaVu Sans}')

def txt(text,size=25,color=INK,**kwargs):
    return Text(text,font=FONT,font_size=size,color=color,**kwargs)

def eq(tex,size=35,color=INK,**kwargs):
    if re.search('[А-Яа-яЁё]',tex):
        tex=re.sub(r'\\mathrm\{([^{}]*[А-Яа-яЁё][^{}]*)\}',r'\\text{\1}',tex)
        kwargs.setdefault('tex_template',CYRILLIC_TEX)
    return MathTex(tex,font_size=size,color=color,**kwargs)

def axes(x_range=(0,5,1),y_range=(0,4,1),width=5.8,height=3.7,center=LEFT*2.8+DOWN*.15):
    a=Axes(x_range=x_range,y_range=y_range,x_length=width,y_length=height,
        axis_config={'color':MUTED,'stroke_width':1.4,'include_tip':True,
                     'tip_width':.1,'tip_height':.11},tips=True)
    return a.move_to(center)

def arrow(start,vector,color=CYAN,width=3):
    start=np.asarray(start,dtype=float);vector=np.asarray(vector,dtype=float)
    norm=np.linalg.norm(vector)
    if norm<1e-6:
        return Arrow(start,start+RIGHT*.001,buff=0,color=color,stroke_width=width).set_opacity(0)
    result=Arrow(start,start+vector,buff=0,color=color,stroke_width=width,
                 max_tip_length_to_length_ratio=.22)
    if norm<.08:result.set_opacity(norm/.08)
    return result

def car(color=CYAN):
    body=RoundedRectangle(width=.7,height=.24,corner_radius=.05,color=color,stroke_width=2)
    roof=VMobject(color=color,stroke_width=2).set_points_as_corners([[-.24,.12,0],[-.12,.28,0],[.13,.28,0],[.25,.12,0]])
    wheels=VGroup(*[Circle(radius=.065,color=INK,stroke_width=1.7).move_to([x,-.15,0]) for x in [-.22,.22]])
    return VGroup(body,roof,wheels)

def freeze(*objects):
    for obj in objects:obj.clear_updaters(recursive=True)

def _suspend(objects):
    saved=[];seen=set()
    for obj in objects:
        obj.update(0)
        for mob in obj.get_family():
            if id(mob) not in seen:
                seen.add(id(mob));saved.append((mob,list(mob.updaters)))
                mob.clear_updaters(recursive=False)
    return saved

def _resume(saved):
    for obj,updaters in saved:
        for updater in updaters:obj.add_updater(updater)

class ChapterScene(MovingCameraScene):
    chapter_id=1

    def construct(self):
        self.camera.background_color=BLACK_BG
        self.meta=PLAN['chapters'][self.chapter_id-1]
        self.chapter_duration=self.meta['duration']
        self.started=self.time
        title=txt(self.meta['title'],27).to_edge(LEFT,buff=.55).to_edge(UP,buff=.28)
        if title.width>8.6:title.scale_to_fit_width(8.6).to_edge(LEFT,buff=.55)
        cite=txt(f"{self.meta['short']} · с. {self.meta['pages']}",15,MUTED).to_edge(RIGHT,buff=.5).to_edge(UP,buff=.29)
        count=txt(f"{self.chapter_id:02d} / {len(PLAN['chapters'])}",14,MUTED).to_edge(RIGHT,buff=.52).move_to([6.15,3.04,0])
        rule=Line([-6.55,2.91,0],[6.55,2.91,0],color=GRID,stroke_width=1)
        self.header=VGroup(title,cite,count,rule)
        self.caption=None
        self.play(FadeIn(self.header),run_time=.8)
        self.chapter()
        elapsed=self.time-self.started
        remaining=self.chapter_duration-elapsed
        if remaining<1.97:
            raise RuntimeError(f"Chapter {self.chapter_id}: no closing pause: {remaining:.3f}s")
        self.wait(remaining-1.2)
        freeze(*self.mobjects)
        self.play(*[FadeOut(m) for m in list(self.mobjects)],run_time=1.2)

    def beat(self,index,note=None):
        target=self.meta['beats'][index]
        elapsed=self.time-self.started
        if elapsed>target+.16:
            raise RuntimeError(f"Chapter {self.chapter_id}, beat {index}: late {elapsed:.3f}>{target}")
        if target-elapsed>1e-6:self.wait(target-elapsed)
        if note:
            new=txt(note,23,MUTED).move_to([0,-3.36,0])
            if new.width>12.4:new.scale_to_fit_width(12.4)
            anim=[FadeIn(new)]
            if self.caption is not None:anim.append(FadeOut(self.caption))
            self.play(*anim,run_time=.5)
            self.caption=new

    def show(self,*objects,run_time=1.0,create=False):
        """Do not let always_redraw override FadeIn/Create opacity."""
        saved=_suspend(objects)
        try:
            self.play(*[(Create(m) if create else FadeIn(m)) for m in objects],run_time=run_time)
        finally:_resume(saved)

    def clear_stage(self,keep=(),run_time=1.0):
        protected=[self.header,self.caption,*keep]
        protected_ids={id(m) for p in protected if p is not None for m in p.get_family()}
        stage=[m for m in list(self.mobjects)
               if not any(id(member) in protected_ids for member in m.get_family())]
        freeze(*stage)
        if stage:self.play(*[FadeOut(m) for m in stage],run_time=run_time)

    def chapter(self):raise NotImplementedError
