"""Work, energy, power and efficiency, redrawn from source pp. 8–16.

All distances below are layout coordinates, never numerical physical data.
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from energy_style import *


def formula(tex, center, size=32, color=INK, width=6.5):
    mob = eq(tex, size, color).move_to(center)
    if mob.width > width:
        mob.scale_to_fit_width(width)
    return mob


def words(lines, center, size=24, color=INK, width=6.1):
    mob = VGroup(*[txt(s, size, color) for s in lines]).arrange(DOWN, buff=.18)
    if mob.width > width:
        mob.scale_to_fit_width(width)
    return mob.move_to(center)


def attached_force(body, vector, tex, color, label_side=UP, label_buff=.1):
    """A force and its precompiled label follow a body without recreating text."""
    origin = body.get_center()
    shaft = arrow(origin, vector, color)
    label = eq(tex, 25, color).next_to(shaft, label_side, buff=label_buff)
    anchor = Dot(origin, radius=.001).set_opacity(0)
    group = VGroup(shaft, label, anchor)
    group.add_updater(lambda m: m.shift(body.get_center() - m[2].get_center()))
    return group


def extension_force(body, extension, vector, tex, color, label_side=UP):
    """Hooke-law arrow with length proportional to displayed extension.

    The one precompiled label is repositioned; no text is created per frame.
    """
    vector = np.asarray(vector, dtype=float)
    shaft = arrow(body.get_center(), vector * extension.get_value(), color)
    label = eq(tex, 25, color)
    group = VGroup(shaft, label)
    def update_force(m):
        proportion = extension.get_value()
        shaft.become(arrow(body.get_center(), vector * proportion, color))
        label.next_to(shaft, label_side, buff=.1)
        label.set_opacity(min(1, max(0, proportion / .12)))
    group.add_updater(update_force)
    update_force(group)
    return group


def spring_picture(center_y=.2, initial_x=-4.4, final_x=-2.6):
    """Slow extension: tracker, block and mutable polyline spring."""
    p = ValueTracker(0)
    anchor = np.array([-5.9, center_y, 0.])
    block = RoundedRectangle(width=.55, height=.52, corner_radius=.04,
                             color=CYAN, fill_color=BLACK_BG, fill_opacity=1)
    block.move_to([initial_x, center_y, 0])
    block.add_updater(lambda m: m.move_to([interpolate(initial_x, final_x, p.get_value()), center_y, 0]))
    spring = VMobject(color=GOLD, stroke_width=2.5)
    def reshape(m):
        end = block.get_left()
        coords = [anchor, anchor + RIGHT * .15]
        length = end[0] - anchor[0] - .3
        for i in range(13):
            coords.append(anchor + RIGHT * (.15 + length * i / 12) + UP * (.12 * (-1) ** i if i not in (0, 12) else 0))
        coords.append(end)
        m.set_points_as_corners(coords)
    spring.add_updater(reshape)
    reshape(spring)
    wall = VGroup(Line(anchor + UP * .55, anchor + DOWN * .55, color=MUTED),
                  *[Line(anchor + UP * y, anchor + UP * (y - .13) + LEFT * .13, color=MUTED, stroke_width=1)
                    for y in np.linspace(-.4, .5, 6)])
    floor = Line([-6.1, center_y - .29, 0], [-2.1, center_y - .29, 0], color=GRID)
    return p, block, spring, wall, floor


def two_vector_diagram(origin, first=RIGHT * 2.5, second=RIGHT * 1.9 + UP * 1.2,
                       first_tex=r'\vec S', second_tex=r'\vec F'):
    one = arrow(origin, first, CYAN)
    two = arrow(origin, second, GOLD)
    angle = Angle(Line(origin, origin + first), Line(origin, origin + second),
                  radius=.58, color=MUTED, stroke_width=1.6)
    labels = VGroup(eq(first_tex, 28, CYAN).next_to(one, DOWN, buff=.12),
                    eq(second_tex, 28, GOLD).next_to(two, UP, buff=.1),
                    eq(r'\alpha', 25, MUTED).move_to(origin + RIGHT * .82 + UP * .22))
    return VGroup(one, two, angle, labels)


class ConstantWork(ChapterScene):
    chapter_id = 5

    def chapter(self):
        self.beat(0, 'Постоянная сила и прямолинейное перемещение')
        vectors = two_vector_diagram(np.array([-5.5, -.4, 0]))
        self.show(vectors, create=True, run_time=1.8)
        definition = formula(r'A=\vec F\cdot\vec S=FS\cos\alpha', [2.8, .8, 0], 38)
        info = words(['Работа — скалярная величина', 'Единица СИ — джоуль'], [2.8, -.5, 0])
        unit = formula(r'[A]=\text{Дж}', [2.8, -1.55, 0], 32, CYAN)
        self.show(definition, info, unit, run_time=1.2)

        self.beat(1, 'Четыре силы; полный участок движения бруска')
        self.clear_stage()
        ground = Line([-5.9, -.95, 0], [-.4, -.95, 0], color=MUTED)
        body = RoundedRectangle(width=.66, height=.46, corner_radius=.03, color=CYAN,
                                fill_color=BLACK_BG, fill_opacity=1).move_to([-4.8, -.7, 0])
        forces = VGroup(attached_force(body, [1.2, .65, 0], r'\vec F', GOLD, UR),
                        attached_force(body, [0, .4, 0], r'\vec N', LAVENDER, LEFT),
                        attached_force(body, [0, -1.05, 0], r'm\vec g', ROSE, RIGHT),
                        attached_force(body, [-1.2, 0, 0], r'\vec F_{\text{тр}}', MUTED, UP))
        displacement = arrow([-4.8, -2.05, 0], RIGHT * 3.45, CYAN)
        slabel = eq(r'\vec S', 28, CYAN).next_to(displacement, DOWN, buff=.1)
        labels = VGroup(txt('1', 20, MUTED).move_to([-4.8, -1.3, 0]),
                        txt('2', 20, MUTED).move_to([-1.35, -1.3, 0]))
        work = formula(r'A_F=FS\cos\alpha', [3.1, .3, 0], 40, GOLD, 5.7)
        self.show(ground, body, forces, displacement, slabel, labels, run_time=1.2)
        self.show(work)
        self.play(body.animate.move_to([-1.35, -.7, 0]), run_time=3.3, rate_func=linear)
        arrived = words(['Состояние 2 достигнуто'], [3.1, -1.2, 0], 23, MUTED, 5.5)
        self.show(arrived, run_time=.7)

        self.beat(2, 'Тяжесть и нормальная реакция перпендикулярны перемещению')
        self.clear_stage(keep=(ground, body, displacement, slabel, labels))
        normal = attached_force(body, [0, .4, 0], r'\vec N', LAVENDER, LEFT)
        gravity = attached_force(body, [0, -1.05, 0], r'm\vec g', ROSE, RIGHT)
        self.show(normal, gravity)
        a = formula(r'A_{mg}=mgS\cos90^\circ=0', [3.15, .85, 0], 32, ROSE, 5.8)
        b = formula(r'A_N=NS\cos90^\circ=0', [3.15, -.4, 0], 32, LAVENDER, 5.8)
        angle_note = formula(r'\alpha=90^\circ', [-3.9, 1.2, 0], 31, MUTED, 4)
        self.show(a, angle_note)
        self.show(b)

        self.beat(3, 'Трение направлено против перемещения: работа отрицательна')
        self.clear_stage(keep=(ground, body, displacement, slabel, labels))
        friction = attached_force(body, [-1.2, 0, 0], r'\vec F_{\text{тр}}', ROSE, UP)
        self.show(friction)
        half = Arc(radius=.72, start_angle=0, angle=PI, color=MUTED,
                   arc_center=np.array([-4.1, .5, 0]))
        opposite = VGroup(arrow([-4.1, .5, 0], RIGHT * 1.3, CYAN),
                          arrow([-4.1, .5, 0], LEFT * 1.3, ROSE))
        degree = eq(r'180^\circ', 26, MUTED).move_to([-4.1, 1.5, 0])
        self.show(opposite, half, degree, create=True, run_time=1.4)
        f1 = formula(r'A_{\text{тр}}=F_{\text{тр}}S\cos180^\circ', [3.1, .8, 0], 33, ROSE, 5.9)
        f2 = formula(r'A_{\text{тр}}=-F_{\text{тр}}S', [3.1, -.65, 0], 38, ROSE, 5.9)
        self.show(f1)
        self.show(f2)

        self.beat(4, 'Итог: каждая сила имеет собственную работу')
        self.clear_stage()
        entries = [(r'A_F=FS\cos\alpha', GOLD), (r'A_{mg}=0', ROSE),
                   (r'A_N=0', LAVENDER), (r'A_{\text{тр}}=-F_{\text{тр}}S', CYAN)]
        cards = VGroup()
        for i, (tex, color) in enumerate(entries):
            x, y = (-3.25 if i % 2 == 0 else 3.25), (1.25 if i < 2 else -.9)
            frame = RoundedRectangle(width=5.9, height=1.55, corner_radius=.12,
                                     color=GRID, stroke_width=1.5).move_to([x, y, 0])
            cards.add(VGroup(frame, formula(tex, [x, y, 0], 37, color, 5.45)))
        self.show(cards, run_time=1.5)


class VariableWork(ChapterScene):
    chapter_id = 6

    def chapter(self):
        self.beat(0, 'На малом участке перемещения сила приблизительно постоянна')
        ax = axes(x_range=(0, 4.5, 1), y_range=(0, 3.5, 1), width=5.5, height=3.8,
                  center=LEFT * 3.05 + DOWN * .1)
        labels = VGroup(eq(r'F_x', 27, GOLD).next_to(ax.y_axis, UP, buff=.1),
                        eq(r'S_x', 27, CYAN).next_to(ax.x_axis, RIGHT, buff=.1))
        fun = lambda x: 1.1 + .35 * x + .24 * np.sin(1.5 * x)
        graph = ax.plot(fun, x_range=(0, 4), color=GOLD, stroke_width=3)
        strip = Polygon(ax.c2p(.5, 0), ax.c2p(1, 0), ax.c2p(1, fun(.75)), ax.c2p(.5, fun(.75)),
                        color=CYAN, stroke_width=1, fill_color=CYAN, fill_opacity=.35)
        self.show(ax, labels, create=True)
        self.show(graph, create=True, run_time=2.1)
        self.show(strip, run_time=.8)
        local = formula(r'\Delta A\approx F_x\Delta S_x', [3.3, .65, 0], 36, CYAN, 5.9)
        hint = words(['Малый участок перемещения', 'Площадь узкого прямоугольника'], [3.3, -.65, 0], 23, MUTED, 5.6)
        self.show(local, hint)

        self.beat(1, 'Суммируем работы всех малых участков')
        self.clear_stage(keep=(ax, labels, graph))
        strips = VGroup()
        for x in np.arange(0, 4, .5):
            strips.add(Polygon(ax.c2p(x, 0), ax.c2p(x + .5, 0), ax.c2p(x + .5, fun(x + .25)), ax.c2p(x, fun(x + .25)),
                               color=BLACK_BG, stroke_width=1.2, fill_color=CYAN, fill_opacity=.42))
        self.play(LaggedStart(*[FadeIn(s) for s in strips], lag_ratio=.15), run_time=2.5)
        summation = formula(r'A\approx\Delta A_1+\Delta A_2+\ldots', [3.3, .55, 0], 34, CYAN, 5.9)
        interval = words(['Все участки выбранного интервала', 'учтены последовательно'], [3.3, -.75, 0], 23, MUTED, 5.6)
        self.show(summation, interval)

        self.beat(2, 'Полная работа равна площади под графиком')
        self.clear_stage(keep=(ax, labels, graph, strips))
        area = ax.get_area(graph, x_range=(0, 4), color=CYAN, opacity=.4)
        self.play(ReplacementTransform(strips, area), run_time=1.7)
        result = words(['Работа переменной силы', 'Площадь под графиком'], [3.3, .55, 0], 27, INK, 5.7)
        area_a = formula(r'A', [3.3, -1.05, 0], 57, CYAN)
        self.show(result, area_a)
        self.play(Indicate(area, color=CYAN, scale_factor=1.025), run_time=1.2)

        self.beat(3, 'Медленное растяжение пружины: равные модули сил')
        self.clear_stage()
        p, block, spring, wall, floor = spring_picture()
        external = extension_force(block, p, RIGHT * .9, r'\vec F', CYAN, UP)
        elastic = extension_force(block, p, LEFT * .9, r'\vec F_{\text{упр}}', GOLD, DOWN)
        ax2 = axes(x_range=(0, 3.5, 1), y_range=(0, 3.2, 1), width=4.6, height=3.5,
                   center=RIGHT * 3.35 + UP * .1)
        labels2 = VGroup(eq(r'x', 25).next_to(ax2.x_axis, RIGHT, buff=.1),
                         eq(r'F=kx', 27, GOLD).next_to(ax2.y_axis, UP, buff=.1))
        line = ax2.plot(lambda x: .85 * x, x_range=(0, 3), color=GOLD, stroke_width=3)
        ends = VGroup(DashedLine(ax2.c2p(3, 0), ax2.c2p(3, 2.55), color=MUTED),
                      DashedLine(ax2.c2p(0, 2.55), ax2.c2p(3, 2.55), color=MUTED),
                      eq(r'x_0', 25).next_to(ax2.c2p(3, 0), DOWN, buff=.12),
                      eq(r'kx_0', 25).next_to(ax2.c2p(0, 2.55), LEFT, buff=.12))
        self.show(wall, floor, block, spring, external, elastic, ax2, labels2, run_time=1.1)
        self.play(p.animate.set_value(1), Create(line), run_time=3.2, rate_func=smooth)
        freeze(block, spring, external, elastic)
        self.show(ends)
        extension = VGroup(arrow([-4.4, -1, 0], RIGHT * 1.8, CYAN), eq(r'x_0', 26, CYAN).move_to([-3.5, -1.4, 0]))
        self.show(extension)

        self.beat(4, 'Работа внешней силы — полная площадь треугольника')
        self.clear_stage(keep=(block, spring, wall, floor, external, elastic, ax2, labels2, line, ends, extension))
        triangle = Polygon(ax2.c2p(0, 0), ax2.c2p(3, 0), ax2.c2p(3, 2.55),
                           color=CYAN, stroke_width=0, fill_color=CYAN, fill_opacity=.32)
        self.show(triangle, run_time=1.6)
        conclusion = formula(r'A_F=\frac12\,kx_0\cdot x_0=\frac{kx_0^2}{2}', [0, -2.45, 0], 38, CYAN, 11.8)
        self.show(conclusion, run_time=1.2)


class PotentialEnergy(ChapterScene):
    chapter_id = 7

    def chapter(self):
        self.beat(0, 'Одинаковые начальное и конечное положения; два полных пути')
        b = np.array([-4.9, 1.55, 0]); c = np.array([-4.9, -1.5, 0]); d = np.array([-1.4, -1.5, 0])
        direct = Line(b, c, color=CYAN, stroke_width=2.7)
        diagonal = Line(b, d, color=GOLD, stroke_width=2.7)
        horizontal = Line(d, c, color=GOLD, stroke_width=2.7)
        route_labels = VGroup(eq('B', 27).next_to(b, UP, buff=.1), eq('C', 27).next_to(c, DOWN, buff=.12),
                             eq('h', 26, CYAN).move_to([-5.45, .05, 0]),
                             eq('S', 26, GOLD).move_to([-2.8, .45, 0]),
                             eq('L', 26, GOLD).move_to([-3.1, -1.95, 0]))
        alpha = Angle(Line(d, b), Line(d, c), radius=.6, color=MUTED)
        alpha_label = eq(r'\alpha', 24, MUTED).move_to([-2.3, -1.2, 0])
        self.show(direct, diagonal, horizontal, route_labels, alpha, alpha_label, create=True, run_time=1.5)
        bead1 = Dot(b, radius=.13, color=CYAN)
        bead2 = Circle(radius=.18, color=GOLD, stroke_width=3).move_to(b)
        self.show(bead1, bead2, run_time=.6)
        self.play(bead1.animate.move_to(c), run_time=2.0, rate_func=linear)
        self.play(bead2.animate.move_to(d), run_time=2.3, rate_func=linear)
        self.play(bead2.animate.move_to(c), run_time=1.7, rate_func=linear)
        complete = words(['Оба пути завершены в C'], [3.2, .5, 0], 28, INK, 5.7)
        self.show(complete, run_time=.7)

        self.beat(1, 'Работа тяжести зависит от конечных положений')
        self.clear_stage(keep=(direct, diagonal, horizontal, route_labels, alpha, alpha_label, bead1, bead2))
        lines = VGroup(formula(r'A_1=mgh\cos0^\circ=mgh', [3.15, 1.6, 0], 29, CYAN, 6.05),
                       formula(r'A_2=mgS\cos(90^\circ-\alpha)+mgL\cos90^\circ', [3.15, .65, 0], 25, GOLD, 6.05),
                       formula(r'A_2=mgS\sin\alpha=mgh', [3.15, -.25, 0], 29, GOLD, 6.05),
                       formula(r'S\sin\alpha=h\quad\Longrightarrow\quad A_1=A_2', [3.15, -1.2, 0], 29, INK, 6.05))
        for line in lines:
            self.show(line, run_time=.75)
        definition = words(['Потенциальная сила: работа', 'не зависит от траектории'], [0, -2.55, 0], 24, MUTED, 12)
        self.show(definition)

        self.beat(2, 'Потенциальная энергия в однородном поле тяжести')
        self.clear_stage()
        base = Line([-5.6, -1.9, 0], [-.8, -1.9, 0], color=MUTED)
        zero = eq(r'E_{\text{п}}=0', 25, MUTED).next_to(base, DOWN, buff=.18)
        body = Circle(radius=.22, color=CYAN, fill_color=CYAN, fill_opacity=.25).move_to([-3.3, 1.55, 0])
        height = DoubleArrow([-4.55, -1.9, 0], [-4.55, 1.55, 0], buff=0, color=GOLD, stroke_width=2)
        hlabel = eq('h', 29, GOLD).next_to(height, LEFT, buff=.15)
        self.show(base, zero, body, height, hlabel)
        potential = formula(r'E_{\text{п}}=mgh', [3.15, 1.4, 0], 43, CYAN, 5.8)
        info = words(['Энергия — скалярная величина', 'Взаимное положение тел', 'Нулевой уровень выбирают произвольно'], [3.15, -.2, 0], 23, INK, 6.0)
        unit = formula(r'[E]=\text{Дж}', [3.15, -1.85, 0], 30, MUTED)
        self.show(potential, info, unit)

        self.beat(3, 'При спуске потенциальная энергия уменьшается, работа тяжести положительна')
        self.clear_stage(keep=(base, zero, body))
        heights = VGroup(DashedLine([-4.7, 1.55, 0], [-2.4, 1.55, 0], color=MUTED),
                         DoubleArrow([-4.55, -1.9, 0], [-4.55, 1.55, 0], buff=0, color=GOLD, stroke_width=2),
                         DoubleArrow([-2.1, -1.9, 0], [-2.1, -.35, 0], buff=0, color=CYAN, stroke_width=2),
                         eq(r'h_1', 26, GOLD).move_to([-5.0, -.1, 0]),
                         eq(r'h_2', 26, CYAN).move_to([-1.65, -1.15, 0]),
                         txt('1', 21, MUTED).move_to([-2.85, 1.55, 0]),
                         txt('2', 21, MUTED).move_to([-2.85, -.35, 0]))
        self.show(heights)
        self.play(body.animate.move_to([-3.3, -.35, 0]), run_time=2.5, rate_func=smooth)
        d1 = formula(r'\Delta E_{\text{п}}=E_{\text{п}2}-E_{\text{п}1}', [3.0, 1.65, 0], 31, INK, 6.2)
        d2 = formula(r'\Delta E_{\text{п}}=mgh_2-mgh_1<0', [3.0, .6, 0], 30, CYAN, 6.2)
        a1 = formula(r'A_{mg}=mg(h_1-h_2)=mgh_1-mgh_2', [3.0, -.5, 0], 29, GOLD, 6.2)
        a2 = formula(r'A_{mg}=-\Delta E_{\text{п}}>0', [3.0, -1.65, 0], 35, GOLD, 6.2)
        for obj in (d1, d2, a1, a2):
            self.show(obj, run_time=.7)

        self.beat(4, 'Потенциальная энергия пружины и примеры потенциальных сил из конспекта')
        self.clear_stage()
        p, block, spring, wall, floor = spring_picture(center_y=.65)
        external = extension_force(block, p, RIGHT * .9, r'\vec F', CYAN, UP)
        elastic = extension_force(block, p, LEFT * .9, r'\vec F_{\text{упр}}', GOLD, DOWN)
        self.show(block, spring, wall, floor, external, elastic)
        self.play(p.animate.set_value(1), run_time=2.8, rate_func=smooth)
        freeze(block, spring, external, elastic)
        extension = VGroup(arrow([-4.4, -.25, 0], RIGHT * 1.8, CYAN), eq('x', 27, CYAN).move_to([-3.5, -.65, 0]))
        self.show(extension)
        energy = formula(r'E_{\text{пр}}=\frac{kx^2}{2}', [3.1, .85, 0], 44, GOLD, 5.8)
        gravity = formula(r'E_{\text{п}}=mgh', [3.1, -.6, 0], 39, CYAN, 5.8)
        examples = words(['В конспекте рассмотрены:', 'сила тяжести, тяготение, сила упругости'], [0, -2.3, 0], 24, MUTED, 12)
        self.show(energy, gravity, examples)


class KineticWork(ChapterScene):
    chapter_id = 8

    def chapter(self):
        self.beat(0, 'Кинетическая энергия определяется массой и скоростью')
        track = arrow([-5.9, -.8, 0], RIGHT * 5.6, MUTED, 2)
        marks = VGroup(txt('1', 23, MUTED).move_to([-5.2, -1.35, 0]),
                       txt('2', 23, MUTED).move_to([-1.25, -1.35, 0]),
                       eq('OX', 25, MUTED).move_to([-.55, -1.3, 0]))
        body = car().scale(.85).move_to([-5.2, -.58, 0])
        v = ValueTracker(0)
        velocity = attached_force(body, RIGHT * .28, r'\vec v_1', CYAN, UP)
        self.show(track, marks, body, velocity)
        energy = formula(r'E_{\text{к}}=\frac{mv^2}{2}', [3.0, .8, 0], 46, CYAN, 6.0)
        info = words(['Кинетическая энергия', 'Скалярная величина'], [3.0, -.8, 0], 25, INK, 5.9)
        self.show(energy, info)

        self.beat(1, 'В показанном разгоне сила — результирующая')
        self.clear_stage(keep=(track, marks, body))
        origin = body.get_center().copy()
        body.add_updater(lambda m: m.move_to(origin + RIGHT * 3.95 * (.35 * v.get_value() + .65 * v.get_value() ** 2)))
        moving_v = arrow(body.get_center() + UP * .45, RIGHT * .28, CYAN)
        moving_v.add_updater(lambda m: m.put_start_and_end_on(body.get_center() + UP * .45,
                                                            body.get_center() + UP * .45 + RIGHT * (.28 + 1.04 * v.get_value())))
        vlabel = eq(r'\vec v', 26, CYAN)
        vlabel.add_updater(lambda m: m.next_to(moving_v, UP, buff=.1))
        force = attached_force(body, RIGHT * .85, r'\vec F', GOLD, DOWN)
        law = formula(r'F_x=ma_x', [3.1, 1.25, 0], 39, GOLD, 5.7)
        accel = formula(r'a_x=\frac{v_{2x}^2-v_{1x}^2}{2S_x}', [3.1, -.15, 0], 38, INK, 5.7)
        displacement = VGroup(arrow([-5.2, -2.1, 0], RIGHT * 3.95, CYAN), eq(r'S_x\ne0', 25, CYAN).move_to([-3.2, -2.5, 0]))
        self.show(moving_v, vlabel, force, law, accel, displacement)
        self.play(v.animate.set_value(1), run_time=3.2, rate_func=linear)
        freeze(body, moving_v, vlabel, force)
        endpoint = txt('Состояние 2', 22, MUTED).move_to([-2.1, 1.3, 0])
        self.show(endpoint, run_time=.6)

        self.beat(2, 'Подстановка приводит к разности двух кинетических энергий')
        self.clear_stage(keep=(track, marks, body, moving_v, vlabel, force, displacement, endpoint))
        line1 = formula(r'F_xS_x=\frac{m(v_{2x}^2-v_{1x}^2)}{2}', [3.1, 1.25, 0], 35, INK, 5.9)
        line2 = formula(r'F_xS_x=\frac{mv_{2x}^2}{2}-\frac{mv_{1x}^2}{2}', [3.1, -.25, 0], 35, CYAN, 5.9)
        self.show(line1)
        self.show(line2, run_time=1.1)
        read = words(['Работа результирующей силы', 'равна изменению энергии движения'], [3.1, -1.8, 0], 22, MUTED, 5.8)
        self.show(read)

        self.beat(3, 'Теорема относится к сумме работ всех сил')
        self.clear_stage()
        theorem = formula(r'A_{\text{всех}}=E_{\text{к}2}-E_{\text{к}1}=\Delta E_{\text{к}}', [0, .85, 0], 47, CYAN, 12)
        text = words(['Теорема об изменении кинетической энергии', 'Применяется и к пространственному движению'], [0, -.85, 0], 27, INK, 12)
        self.show(theorem, text, run_time=1.4)
        box = SurroundingRectangle(theorem, color=CYAN, buff=.28, stroke_width=1.7)
        self.show(box, create=True)

        self.beat(4, 'Разделим работы на потенциальные и непотенциальные')
        self.clear_stage()
        total = formula(r'A_{\text{всех}}=A_{\text{потенц}}+A_{\text{непотенц}}', [0, 1.35, 0], 40, INK, 12)
        energy = formula(r'A_{\text{потенц}}+A_{\text{непотенц}}=\Delta E_{\text{к}}', [0, -.2, 0], 40, CYAN, 12)
        self.show(total)
        self.show(energy)
        meaning = words(['Сумма работ меняет кинетическую энергию'], [0, -1.8, 0], 27, MUTED, 12)
        self.show(meaning)


class MechanicalEnergy(ChapterScene):
    chapter_id = 9

    def chapter(self):
        self.beat(0, 'Соединим теорему о кинетической энергии и работу потенциальных сил')
        first = formula(r'A_{\text{потенц}}=-\Delta E_{\text{п}}', [-3.15, 1.6, 0], 33, GOLD, 6)
        second = formula(r'A_{\text{всех}}=\Delta E_{\text{к}}', [3.15, 1.6, 0], 33, CYAN, 6)
        step = formula(r'-(E_{\text{п}2}-E_{\text{п}1})+A_{\text{непотенц}}=E_{\text{к}2}-E_{\text{к}1}', [0, .1, 0], 35, INK, 12)
        result = formula(r'A_{\text{непотенц}}=(E_{\text{к}2}+E_{\text{п}2})-(E_{\text{к}1}+E_{\text{п}1})', [0, -1.65, 0], 37, CYAN, 12)
        self.show(first, second)
        self.show(step)
        self.show(result)

        self.beat(1, 'Полная механическая энергия — сумма кинетической и потенциальной')
        self.clear_stage()
        definition = formula(r'E_{\text{мех}}=E_{\text{к}}+E_{\text{п}}', [0, 1.55, 0], 45, GOLD, 12)
        balance = formula(r'A_{\text{непотенц}}=E_{\text{мех}2}-E_{\text{мех}1}', [0, .05, 0], 40, INK, 12)
        short = formula(r'A_{\text{непотенц}}=\Delta E_{\text{мех}}', [0, -1.5, 0], 46, CYAN, 12)
        self.show(definition)
        self.show(balance)
        self.show(short)

        self.beat(2, 'Гладкий склон: трения нет, нормальная реакция работы не совершает')
        self.clear_stage()
        start = np.array([-5.5, 1.5, 0]); end = np.array([-1.2, -1.5, 0])
        tangent = (end - start) / np.linalg.norm(end - start)
        normal = np.array([-tangent[1], tangent[0], 0])
        slope = Line(start, end, color=MUTED, stroke_width=2.7)
        base = Line(end, [-5.5, -1.5, 0], color=GRID, stroke_width=1.3)
        body = RoundedRectangle(width=.6, height=.42, corner_radius=.025, color=CYAN,
                                fill_color=BLACK_BG, fill_opacity=1).rotate(np.arctan2(tangent[1], tangent[0]))
        body.move_to(start + normal * .23)
        state = VGroup(txt('1', 22, MUTED).move_to(start + LEFT * .35 + UP * .4),
                       txt('2', 22, MUTED).move_to(end + DOWN * .42))
        p = ValueTracker(0)
        body.add_updater(lambda m: m.move_to(interpolate(start, end, p.get_value() ** 2) + normal * .23))
        gravity = attached_force(body, DOWN * .9, r'm\vec g', ROSE, LEFT)
        reaction = attached_force(body, normal * (.9 * abs(tangent[0])), r'\vec N', LAVENDER, RIGHT)
        self.show(slope, base, body, state, gravity, reaction)
        no_friction = formula(r'A_{\text{тр}}=0', [3.1, 1.45, 0], 36, INK, 5.8)
        no_normal = formula(r'A_N=NS\cos90^\circ=0', [3.1, .2, 0], 32, LAVENDER, 5.8)
        no_non = formula(r'A_{\text{непотенц}}=0', [3.1, -1.2, 0], 37, CYAN, 5.8)
        self.show(no_friction, no_normal)
        self.play(p.animate.set_value(1), run_time=3.1, rate_func=linear)
        freeze(body, gravity, reaction)
        self.show(no_non)

        self.beat(3, 'Обмен энергиями при неизменной полной сумме')
        self.clear_stage()
        p2 = ValueTracker(0)
        frame = Rectangle(width=1.2, height=3.8, color=MUTED, stroke_width=1.5).move_to([-4.25, .2, 0])
        kinetic = Rectangle(width=1.14, height=.01, fill_color=CYAN, fill_opacity=.85, stroke_width=0)
        potential = Rectangle(width=1.14, height=3.8, fill_color=GOLD, fill_opacity=.85, stroke_width=0)
        bottom = -1.7
        def set_kinetic(m):
            h = 3.8 * p2.get_value()
            m.stretch_to_fit_height(max(h, .001)).move_to([-4.25, bottom + h / 2, 0]).set_opacity(0 if h < .001 else .85)
        def set_potential(m):
            h = 3.8 * (1 - p2.get_value())
            m.stretch_to_fit_height(max(h, .001)).move_to([-4.25, bottom + 3.8 * p2.get_value() + h / 2, 0]).set_opacity(0 if h < .001 else .85)
        kinetic.add_updater(set_kinetic); potential.add_updater(set_potential)
        bars_labels = VGroup(eq(r'E_{\text{п}}', 30, GOLD).move_to([-2.8, 1.2, 0]),
                             eq(r'E_{\text{к}}', 30, CYAN).move_to([-2.8, -.5, 0]),
                             txt('Качественная схема', 18, MUTED).move_to([-4.05, -2.25, 0]))
        statements = VGroup(formula(r'A_{\text{непотенц}}=0\ \Longrightarrow\ \Delta E_{\text{мех}}=0', [2.8, 1.5, 0], 32, INK, 6.7),
                             formula(r'E_{\text{к}1}+E_{\text{п}1}=E_{\text{к}2}+E_{\text{п}2}', [2.8, .1, 0], 37, CYAN, 6.7),
                             formula(r'E_{\text{мех}}=\mathrm{const}', [2.8, -1.35, 0], 38, GOLD, 6.7))
        self.show(frame, kinetic, potential, bars_labels, statements)
        self.play(p2.animate.set_value(1), run_time=4.0, rate_func=smooth)
        freeze(kinetic, potential)

        self.beat(4, 'Общий энергетический баланс учитывает работу непотенциальных сил')
        self.clear_stage()
        general = formula(r'E_{\text{мех}1}+A_{\text{непотенц}}=E_{\text{мех}2}', [0, 1.55, 0], 45, CYAN, 12)
        expanded = formula(r'E_{\text{к}1}+E_{\text{п}1}+A_{\text{непотенц}}=E_{\text{к}2}+E_{\text{п}2}', [0, .05, 0], 38, INK, 12)
        condition = words(['Сохранение механической энергии:', 'работа непотенциальных сил равна нулю'], [0, -1.65, 0], 27, GOLD, 12)
        self.show(general)
        self.show(expanded)
        self.show(condition)


class Power(ChapterScene):
    chapter_id = 10

    def chapter(self):
        self.beat(0, 'Средняя мощность: работа за завершённый интервал времени')
        line = Line([-5.6, .1, 0], [-.6, .1, 0], color=MUTED)
        endpoints = VGroup(Line([-5.6, -.05, 0], [-5.6, .25, 0], color=MUTED),
                           Line([-.6, -.05, 0], [-.6, .25, 0], color=MUTED),
                           txt('начало', 22, MUTED).move_to([-5.6, -.5, 0]),
                           txt('конец', 22, MUTED).move_to([-.6, -.5, 0]))
        bracket = Brace(line, DOWN, color=CYAN, buff=.75)
        interval = eq('t', 30, CYAN).next_to(bracket, DOWN, buff=.1)
        dot = Dot([-5.6, .1, 0], color=CYAN, radius=.11)
        self.show(line, endpoints, bracket, interval, dot)
        self.play(dot.animate.move_to([-.6, .1, 0]), run_time=2.8, rate_func=linear)
        complete = formula(r'A', [-3.1, .85, 0], 44, GOLD, 4.5)
        mean = formula(r'P_{\text{ср}}=\frac{A}{t}', [3.1, .7, 0], 48, CYAN, 5.7)
        self.show(complete, mean)

        self.beat(1, 'Мощность измеряется в ваттах')
        self.clear_stage(keep=(line, endpoints, bracket, interval, dot, complete))
        unit = formula(r'[P]=\text{Вт}=\frac{\text{Дж}}{\text{с}}', [3.1, 1.2, 0], 39, GOLD, 5.8)
        meanings = words(['A — выполненная работа', 't — весь интервал времени', 'P — работа за единицу времени'], [3.1, -.65, 0], 24, INK, 5.8)
        self.show(unit, meanings)

        self.beat(2, 'Подставим работу постоянной силы')
        self.clear_stage()
        vectors = two_vector_diagram(np.array([-5.4, -.4, 0]))
        self.show(vectors, create=True, run_time=1.5)
        p0 = formula(r'P=\frac{A}{t}', [3.1, 1.3, 0], 43, INK, 5.8)
        work = formula(r'A=FS\cos\alpha', [3.1, -.1, 0], 37, GOLD, 5.8)
        substituted = formula(r'P=\frac{FS\cos\alpha}{t}', [3.1, -1.65, 0], 43, CYAN, 5.8)
        self.show(p0, work)
        self.show(substituted)

        self.beat(3, 'При равномерном прямолинейном движении S/t равно скорости')
        self.clear_stage()
        route = arrow([-5.7, -.8, 0], RIGHT * 5.1, MUTED, 2)
        body = car().move_to([-5.15, -.58, 0])
        velocity = attached_force(body, RIGHT * .95, r'\vec v', CYAN, UP)
        s = VGroup(arrow([-5.15, -1.75, 0], RIGHT * 3.45, CYAN), eq('S', 28, CYAN).move_to([-3.4, -2.17, 0]))
        self.show(route, body, velocity, s)
        relation = formula(r'v=\frac{S}{t}', [3.1, 1.1, 0], 44, INK, 5.7)
        rewrite = formula(r'P=F\,\frac{S}{t}\cos\alpha', [3.1, -.75, 0], 42, CYAN, 5.7)
        self.show(relation, rewrite)
        self.play(body.animate.move_to([-1.7, -.58, 0]), run_time=3.1, rate_func=linear)
        freeze(velocity)

        self.beat(4, 'Мощность через силу и скорость в выбранный момент')
        self.clear_stage()
        vectors = two_vector_diagram(np.array([-5.3, -.5, 0]), first_tex=r'\vec v')
        self.show(vectors, create=True, run_time=1.6)
        result = formula(r'P=Fv\cos\alpha', [3.1, .95, 0], 46, CYAN, 5.9)
        info = words(['Угол между силой и скоростью', 'Для мгновенной мощности:', 'F и v берут в один момент'], [3.1, -.85, 0], 24, INK, 5.8)
        self.show(result, info)


class Efficiency(ChapterScene):
    chapter_id = 11

    def chapter(self):
        self.beat(0, 'Два способа доставить блок на одну и ту же вершину')
        low = np.array([-1.3, -1.2, 0]); foot = np.array([-5.3, -1.2, 0]); high = np.array([-1.3, 1.65, 0])
        ground = Line([-5.8, -1.5, 0], [-.7, -1.5, 0], color=MUTED)
        vertical = DashedLine(low, high, color=CYAN, stroke_width=2.3)
        horiz = Line(low, foot, color=GOLD, stroke_width=2.3)
        incline = Line(foot, high, color=GOLD, stroke_width=2.3)
        h = DoubleArrow([-.75, -1.2, 0], [-.75, 1.65, 0], buff=0, color=CYAN, stroke_width=1.8)
        dims = VGroup(h, eq('H', 27, CYAN).next_to(h, RIGHT, buff=.12),
                      eq(r'S_1', 27, GOLD).move_to([-3.3, -1.85, 0]),
                      eq(r'S_2', 27, GOLD).move_to([-3.8, .7, 0]))
        direct = RoundedRectangle(width=.56, height=.5, corner_radius=.035, color=CYAN,
                                  stroke_width=2.2, fill_color=BLACK_BG, fill_opacity=1).move_to(low)
        indirect = RoundedRectangle(width=.64, height=.58, corner_radius=.035, color=GOLD,
                                    stroke_width=2, fill_color=BLACK_BG, fill_opacity=0).move_to(low)
        explanation = words(['КПД — характеристика эффективности', 'Полезная и затраченная работа', 'Одинаковая конечная высота'], [3.25, .3, 0], 24, INK, 5.7)
        self.show(ground, vertical, horiz, incline, dims, direct, indirect, explanation, run_time=1.6)

        self.beat(1, 'Первый способ: полный вертикальный подъём')
        self.clear_stage(keep=(ground, vertical, horiz, incline, dims, direct, indirect))
        lift = attached_force(direct, UP * .75, r'\vec F_1', CYAN, LEFT)
        self.show(lift)
        self.play(direct.animate.move_to(high), run_time=3.4, rate_func=linear)
        freeze(lift)
        self.play(FadeOut(lift), run_time=.7)
        useful = formula(r'A_{\text{полезн}}=F_1H\cos0^\circ=F_1H', [3.2, .8, 0], 34, CYAN, 5.9)
        completed = words(['Вертикальный маршрут завершён', 'Блок находится на вершине'], [3.2, -.8, 0], 24, MUTED, 5.7)
        self.show(useful, completed)

        self.beat(2, 'Второй способ: горизонтальный участок и полный подъём по склону')
        self.clear_stage(keep=(ground, vertical, horiz, incline, dims, direct, indirect))
        push_h = attached_force(indirect, LEFT * .9, r'\vec F_2', GOLD, UP)
        friction_h = attached_force(indirect, RIGHT * .9, r'\vec F_{\text{тр}}', ROSE, DOWN)
        self.show(push_h, friction_h)
        self.play(indirect.animate.move_to(foot), run_time=2.2, rate_func=linear)
        freeze(push_h, friction_h)
        self.play(FadeOut(push_h), FadeOut(friction_h), run_time=.5)
        direction = (high - foot) / np.linalg.norm(high - foot)
        push_s = attached_force(indirect, direction * .85, r'\vec F_3', GOLD, UL)
        friction_s = attached_force(indirect, -direction * .65, r'\vec F_{\text{тр}}', ROSE, DOWN)
        self.show(push_s, friction_s, run_time=.6)
        self.play(indirect.animate.move_to(high), run_time=2.8, rate_func=linear)
        freeze(push_s, friction_s)
        self.play(FadeOut(push_s), FadeOut(friction_s), run_time=.5)
        expended = formula(r'A_{\text{затрач}}=F_2S_1+F_3S_2', [3.2, .7, 0], 36, GOLD, 5.9)
        arrived = words(['Оба участка завершены', 'Конечная точка общая'], [3.2, -.85, 0], 24, MUTED, 5.7)
        self.show(expended, arrived, run_time=.8)

        self.beat(3, 'Отношение полезной работы к затраченной: доля и проценты')
        self.clear_stage(keep=(ground, vertical, horiz, incline, dims, direct, indirect))
        fraction = formula(r'\eta=\frac{A_{\text{полезн}}}{A_{\text{затрач}}}', [3.1, 1.1, 0], 42, CYAN, 5.9)
        percent = formula(r'\eta=\frac{A_{\text{полезн}}}{A_{\text{затрач}}}\cdot100\%', [3.1, -.85, 0], 38, GOLD, 5.9)
        self.show(fraction, run_time=1.1)
        self.show(percent, run_time=1.1)
        markers = VGroup(Circle(radius=.43, color=CYAN, stroke_width=1.5).move_to(high),
                          txt('Одна вершина', 21, MUTED).move_to([-3.7, 2.3, 0]))
        self.show(markers)

        self.beat(4, 'Выигрыш в силе сопровождается проигрышем в перемещении')
        self.clear_stage(keep=(ground, vertical, horiz, incline, dims, direct, indirect))
        rule = words(['Золотое правило механики', 'Выигрыш в силе сопровождается', 'проигрышем в перемещении'], [3.2, 1.0, 0], 26, INK, 5.9)
        useful = formula(r'A_{\text{полезн}}=F_1H', [3.2, -.55, 0], 34, CYAN, 5.9)
        expended = formula(r'A_{\text{затрач}}=F_2S_1+F_3S_2', [3.2, -1.8, 0], 31, GOLD, 5.9)
        self.show(rule, useful, expended, run_time=1.2)
        self.play(Indicate(vertical, color=CYAN, scale_factor=1.01),
                  Indicate(incline, color=GOLD, scale_factor=1.01), run_time=1.2)
