"""PDF chapters 18–23: completed energy cycles and silent wave illustrations."""
import sys
from pathlib import Path
from scipy.special import ellipj, ellipk
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from energy_style import *


def period_axis(center, width=5.05, height=1.45, positive=False):
    """Normalized time; labels are created once, never inside an updater."""
    a=axes((0,1,.25),(0,1,.5) if positive else (-1,1,1),
           width=width,height=height,center=np.array(center))
    labels=VGroup()
    for x,tex in [(0,'0'),(.25,r'T/4'),(.5,r'T/2'),(.75,r'3T/4'),(1,'T')]:
        labels.add(eq(tex,18,MUTED).move_to(a.c2p(x,0 if positive else -1)+DOWN*.24))
    return a,labels


def trace(a, func, color=CYAN, width=3):
    return a.plot(func,x_range=[0,1,.005],color=color,stroke_width=width,
                  use_smoothing=False)


def spring_points(start,end,turns=9,amp=.13):
    start=np.array(start,dtype=float);end=np.array(end,dtype=float)
    d=end-start;length=np.linalg.norm(d);u=d/length
    perp=np.array([-u[1],u[0],0.])
    points=[start,start+d*.08]
    for i in range(1,turns*2):
        points.append(start+d*(.08+.84*i/(turns*2))+perp*(amp if i%2 else -amp))
    points.extend([start+d*.92,end])
    return VMobject(color=CYAN,stroke_width=2).set_points_as_corners(points)


def bar_fraction(fraction,color,x,base=-1.65,height=2.1):
    h=max(.005,height*np.clip(fraction,0,1))
    return Rectangle(width=.47,height=h,color=color,fill_color=color,
                     fill_opacity=.7,stroke_width=1).move_to([x,base+h/2,0])


def fork_shape(color=CYAN):
    # U shaped vibrating body with a stem and base, centered at its foot.
    return VGroup(
        Line([-.28,1.2,0],[-.28,.42,0],color=color,stroke_width=4),
        Arc(radius=.28,start_angle=PI,angle=PI,color=color,stroke_width=4).move_arc_center_to([0,.42,0]),
        Line([.28,.42,0],[.28,1.2,0],color=color,stroke_width=4),
        Line([0,.14,0],[0,-.4,0],color=color,stroke_width=3),
        Line([-.52,-.4,0],[.52,-.4,0],color=MUTED,stroke_width=3))


def longitudinal_row(y,phase,xmin=-4.7,xmax=4.7,count=39,amp=.14,
                     wave_length=2.35,color=CYAN):
    """Each particle oscillates about its immutable equilibrium x."""
    xs=np.linspace(xmin,xmax,count)
    dots=VGroup(*[Dot([x,y,0],radius=.047,color=color) for x in xs])
    for dot,x in zip(dots,xs):
        dot.add_updater(lambda m,dt=0,x=x:m.move_to(
            [x+amp*np.sin(TAU*(x-xmin)/wave_length-phase.get_value()),y,0]))
    return dots,xs


class PendulumEnergy(ChapterScene):
    chapter_id=18
    def chapter(self):
        self.beat(0,'Нулевой уровень потенциальной энергии — нижнее положение')
        pivot=np.array([-3.4,2.12,0.]);length=3.3;alpha=.64
        def pos(theta):return pivot+length*np.array([np.sin(theta),-np.cos(theta),0])
        ground=pos(0)[1]
        support=Line(pivot+LEFT*.48,pivot+RIGHT*.48,color=MUTED,stroke_width=3)
        level=DashedLine([-5.9,ground,0],[-.75,ground,0],color=MUTED)
        silhouettes=VGroup()
        for th,c in [(0,INK),(.35,CYAN),(alpha,GOLD)]:
            p=pos(th)
            silhouettes.add(Line(pivot,p,color=c,stroke_width=1.5),Dot(p,radius=.09,color=c))
        heights=VGroup(
            DoubleArrow([-.6,ground,0],[-.6,pos(alpha)[1],0],buff=0,color=GOLD,tip_length=.1),
            eq('h',27,GOLD).move_to([-.24,(ground+pos(alpha)[1])/2,0]),
            DoubleArrow([-1.35,ground,0],[-1.35,pos(.35)[1],0],buff=0,color=CYAN,tip_length=.07),
            eq('y',25,CYAN).move_to([-1.64,ground+.24,0]))
        labels=VGroup(txt('Нижнее',21).move_to([-3.4,-1.7,0]),
            txt('Промежуточное',19,CYAN).move_to([-2.7,-2.12,0]),
            txt('Крайнее',21,GOLD).move_to([-1.5,-1.75,0]))
        law=VGroup(eq(r'E_{\mathrm{к}}+E_{\mathrm{п}}=E',38).move_to([3.05,1.2,0]),
            eq(r'E=\mathrm{const}',38,GOLD).move_to([3.05,.3,0]),
            txt('Без потерь энергии',25,MUTED).move_to([3.05,-.7,0]))
        self.show(support,level,create=True,run_time=.8)
        self.show(silhouettes,heights,labels,run_time=1.2)
        self.show(law,run_time=1)

        self.beat(1,'За полный цикл энергии обмениваются, а их сумма сохраняется')
        self.play(FadeOut(silhouettes),FadeOut(heights),FadeOut(labels),FadeOut(law),run_time=.8)
        p=ValueTracker(0)
        # Exact ideal-pendulum timing: the geometry used in these energy bars
        # does not borrow the small-angle sinusoidal trajectory of later graphs.
        modulus=np.sin(alpha/2)
        quarter=ellipk(modulus**2)
        def th():
            sn=ellipj(quarter-2*quarter*p.get_value()/PI,modulus**2)[0]
            return 2*np.arcsin(np.clip(modulus*sn,-1,1))
        def potential():return (1-np.cos(th()))/(1-np.cos(alpha))
        bob=Dot(pos(alpha),radius=.13,color=GOLD)
        bob.add_updater(lambda m:m.move_to(pos(th())))
        thread=always_redraw(lambda:Line(pivot,pos(th()),color=INK,stroke_width=2))
        ep=always_redraw(lambda:bar_fraction(potential(),GOLD,1.7))
        ek=always_redraw(lambda:bar_fraction(1-potential(),CYAN,3.1))
        total=bar_fraction(1,LAVENDER,4.5)
        bars=VGroup(Line([1.2,-1.65,0],[5,-1.65,0],color=MUTED),
            eq(r'E_{\mathrm{п}}',27,GOLD).move_to([1.7,-2.05,0]),
            eq(r'E_{\mathrm{к}}',27,CYAN).move_to([3.1,-2.05,0]),
            eq('E',27,LAVENDER).move_to([4.5,-2.05,0]),
            txt('Сумма неизменна',25,LAVENDER).move_to([3.1,1.3,0]))
        self.show(thread,bob,ep,ek,total,bars,run_time=1)
        self.play(p.animate.set_value(TAU),run_time=10,rate_func=linear)
        freeze(bob,thread,ep,ek)

        self.beat(2,'Внизу максимальна кинетическая энергия, в крайней точке — потенциальная')
        self.clear_stage(run_time=.8)
        chain=VGroup(eq(r'\frac{mv^2}{2}+mgy=E',43),
            eq(r'E=mgh=\frac{mv_m^2}{2}',43,GOLD),
            eq(r'E_{\mathrm{п,max}}=mgh',34,GOLD),
            eq(r'E_{\mathrm{к,max}}=\frac{mv_m^2}{2}',34,CYAN)).arrange(DOWN,buff=.45).move_to([0,.1,0])
        for formula in chain:self.show(formula,run_time=.85)

        self.beat(3,'Малые колебания: координата и скорость проходят полный период T')
        self.clear_stage(run_time=.8)
        ax,lx=period_axis([-3.25,1.05,0]);av,lv=period_axis([-3.25,-1.32,0])
        fx=trace(ax,lambda t:np.sin(TAU*t),CYAN)
        fv=trace(av,lambda t:np.cos(TAU*t),GOLD)
        forms=VGroup(eq(r'x=A\sin\omega t',35,CYAN).move_to([3.1,1.1,0]),
            eq(r'v_x=v_m\cos\omega t',35,GOLD).move_to([3.1,-1.15,0]),
            txt('Модель малых колебаний',23,MUTED).move_to([3.1,2.13,0]))
        self.show(ax,av,lx,lv,forms,run_time=1)
        self.play(Create(fx),Create(fv),run_time=8,rate_func=linear)
        self.show(Dot(ax.c2p(1,0),color=CYAN),Dot(av.c2p(1,1),color=GOLD),run_time=.5)

        self.beat(4,'Кинетическая и потенциальная энергии дополняют друг друга до E')
        self.clear_stage(run_time=.8)
        ae,le=period_axis([-3.2,.2,0],width=5.6,height=2.6,positive=True)
        fc=trace(ae,lambda t:np.cos(TAU*t)**2,CYAN)
        fp=trace(ae,lambda t:np.sin(TAU*t)**2,GOLD)
        e0=DashedLine(ae.c2p(0,1),ae.c2p(1,1),color=LAVENDER)
        forms=VGroup(eq(r'E=\frac{mv_m^2}{2}',34,LAVENDER),
            eq(r'E_{\mathrm{к}}=E\cos^2\omega t',34,CYAN),
            eq(r'E_{\mathrm{п}}=E\sin^2\omega t',34,GOLD),
            eq(r'E_{\mathrm{к}}+E_{\mathrm{п}}=E',34)).arrange(DOWN,buff=.5).move_to([3.15,.1,0])
        self.show(ae,le,e0,forms,run_time=1)
        self.play(Create(fc),Create(fp),run_time=8,rate_func=linear)
        self.show(Dot(ae.c2p(1,1),color=CYAN),Dot(ae.c2p(1,0),color=GOLD),run_time=.5)


class EnergyPeriodPhase(ChapterScene):
    chapter_id=19
    def chapter(self):
        self.beat(0,'За один период движения каждая энергия повторяется дважды')
        a,l=period_axis([-2.9,.4,0],width=6.4,height=2.3,positive=True)
        c=trace(a,lambda t:np.cos(TAU*t)**2,CYAN)
        s=trace(a,lambda t:np.sin(TAU*t)**2,GOLD)
        self.show(a,l,run_time=.8)
        self.play(Create(c),Create(s),run_time=4,rate_func=linear)
        b1=BraceBetweenPoints(a.c2p(0,0)+DOWN*.55,a.c2p(.5,0)+DOWN*.55,DOWN,color=CYAN)
        b2=BraceBetweenPoints(a.c2p(.5,0)+DOWN*.55,a.c2p(1,0)+DOWN*.55,DOWN,color=CYAN)
        labels=VGroup(eq('T/2',26,CYAN).next_to(b1,DOWN,buff=.1),eq('T/2',26,CYAN).next_to(b2,DOWN,buff=.1),
            eq(r'T_E=\frac{T}{2}',42).move_to([3.95,.5,0]))
        self.show(b1,b2,labels,run_time=1)

        self.beat(1,'Старт из равновесия: синус возвращается к исходному состоянию за T')
        self.clear_stage(run_time=.8)
        a,l=period_axis([-2.9,.1,0],width=6,height=2.6)
        curve=trace(a,lambda t:np.sin(TAU*t),CYAN)
        p=ValueTracker(0)
        point=Dot(a.c2p(0,0),color=CYAN)
        point.add_updater(lambda m:m.move_to(a.c2p(p.get_value(),np.sin(TAU*p.get_value()))))
        forms=VGroup(eq(r'x=A\sin\omega t',37,CYAN),eq(r'x(0)=0,\quad v_x(0)=v_m',30),
            txt('Начало в равновесии',23,MUTED)).arrange(DOWN,buff=.6).move_to([3.5,.2,0])
        self.show(a,l,point,forms,run_time=1)
        self.play(Create(curve),p.animate.set_value(1),run_time=7,rate_func=linear)
        freeze(point)

        self.beat(2,'Старт из малого отклонения без скорости: удобна косинусоида')
        self.clear_stage(run_time=.8)
        a,l=period_axis([-2.9,.1,0],width=6,height=2.6)
        curve=trace(a,lambda t:np.cos(TAU*t),GOLD)
        p=ValueTracker(0)
        point=Dot(a.c2p(0,1),color=GOLD)
        point.add_updater(lambda m:m.move_to(a.c2p(p.get_value(),np.cos(TAU*p.get_value()))))
        forms=VGroup(eq(r'x=A\cos\omega t',37,GOLD),eq(r'x(0)=A,\quad v_x(0)=0',30),
            txt('Малый угол',24,MUTED),txt('В конспекте: менее 10°',21,MUTED)).arrange(DOWN,buff=.45).move_to([3.5,.2,0])
        self.show(a,l,point,forms,run_time=1)
        self.play(Create(curve),p.animate.set_value(1),run_time=7,rate_func=linear)
        freeze(point)

        self.beat(3,'Начальная фаза меняет запись закона, но не период колебаний')
        self.clear_stage(run_time=.8)
        a,l=period_axis([-2.6,.2,0],width=6.7,height=2.8)
        si=trace(a,lambda t:np.sin(TAU*t),CYAN)
        co=trace(a,lambda t:np.cos(TAU*t),GOLD)
        form=VGroup(eq(r'x=A\sin\omega t',32,CYAN),eq(r'x=A\cos\omega t',32,GOLD),
            eq(r'T=\frac{2\pi}{\omega}',36),txt('Одинаковый период',23,MUTED)).arrange(DOWN,buff=.5).move_to([3.8,.1,0])
        self.show(a,l,form,run_time=.9)
        self.play(Create(si),Create(co),run_time=6,rate_func=linear)

        self.beat(4,'У пружины потенциальная энергия равна kx²/2 относительно равновесия')
        self.clear_stage(run_time=.8)
        p=ValueTracker(0)
        def x():return -2.3+1.1*np.cos(p.get_value())
        wall=Line([-5.6,-.9,0],[-5.6,.5,0],color=MUTED,stroke_width=3)
        floor=Line([-5.6,-.9,0],[.1,-.9,0],color=GRID)
        block=Square(.55,color=CYAN,fill_opacity=.15).move_to([x(),-.6,0])
        block.add_updater(lambda m:m.move_to([x(),-.6,0]))
        coil=always_redraw(lambda:spring_points([-5.6,-.6,0],[x()-.275,-.6,0]))
        zero=DashedLine([-2.3,-1.2,0],[-2.3,.5,0],color=MUTED)
        ep=always_redraw(lambda:bar_fraction(np.cos(p.get_value())**2,GOLD,2.6,base=-1.15,height=1.8))
        ek=always_redraw(lambda:bar_fraction(np.sin(p.get_value())**2,CYAN,4.2,base=-1.15,height=1.8))
        label=VGroup(eq(r'E_{\mathrm{п}}',26,GOLD).move_to([2.6,-1.55,0]),
            eq(r'E_{\mathrm{к}}',26,CYAN).move_to([4.2,-1.55,0]),
            txt('x от равновесия',22,MUTED).move_to([-2.7,-1.65,0]))
        chain=eq(r'\frac{mv^2}{2}+\frac{kx^2}{2}=\frac{mv_m^2}{2}=\frac{kx_m^2}{2}',38).move_to([0,1.85,0])
        self.show(wall,floor,zero,block,coil,ep,ek,label,chain,run_time=1)
        self.play(p.animate.set_value(TAU),run_time=8,rate_func=linear)
        freeze(block,coil,ep,ek)


class Resonance(ChapterScene):
    chapter_id=20
    def chapter(self):
        self.beat(0,'Вынужденные колебания возникают под действием периодической силы')
        phase=ValueTracker(0);amplitude=ValueTracker(.18)
        def by():return -.4+amplitude.get_value()*np.sin(phase.get_value())
        support=Line([-3.8,2.15,0],[-1.8,2.15,0],color=MUTED,stroke_width=3)
        mass=Square(.6,color=CYAN,fill_opacity=.2).move_to([-2.8,by(),0])
        mass.add_updater(lambda m:m.move_to([-2.8,by(),0]))
        coil=always_redraw(lambda:spring_points([-2.8,2.15,0],[-2.8,by()+.3,0],amp=.16))
        force=always_redraw(lambda:arrow([-2.8,by()-.35,0],UP*.7*np.cos(phase.get_value()),GOLD))
        form=VGroup(txt('Периодическая внешняя сила',25,GOLD),
            txt('Вынужденные колебания',27),eq(r'\nu_{\mathrm{вынужд}}',35,GOLD)).arrange(DOWN,buff=.7).move_to([2.65,.4,0])
        self.show(support,mass,coil,form,run_time=1)
        self.show(force,run_time=.7)
        self.play(phase.animate.set_value(TAU),run_time=5,rate_func=linear)

        self.beat(1,'Согласованное воздействие постепенно увеличивает амплитуду')
        self.play(phase.animate.set_value(4*TAU),amplitude.animate.set_value(.8),run_time=10,rate_func=linear)
        freeze(mass,coil,force)
        result=txt('Последний цикл завершён',23,MUTED).move_to([2.65,-1.8,0])
        self.show(result,run_time=.7)

        self.beat(2,'Резонанс: частота воздействия совпадает с собственной частотой')
        self.clear_stage(run_time=.8)
        condition=eq(r'\nu_{\mathrm{вынужд}}=\nu_0',55,GOLD).move_to([0,1.35,0])
        definition=VGroup(txt('Резкое увеличение амплитуды',31),
            txt('вынужденных колебаний',31),
            txt('при совпадении частот',28,MUTED)).arrange(DOWN,buff=.45).move_to([0,-.35,0])
        self.show(condition,run_time=1);self.show(definition,run_time=1.2)

        self.beat(3,'Схематический график доводим через резонансный пик до правого края')
        self.clear_stage(run_time=.8)
        a=axes((0,5,1),(0,3,1),width=7.7,height=3.7,center=LEFT*.9+DOWN*.1)
        # A qualitative shape only; no scale or response-law assertion.
        points=[a.c2p(x,y) for x,y in [(0,.18),(.7,.26),(1.35,.55),(1.9,1.45),
            (2.35,2.65),(2.8,1.45),(3.4,.55),(4.2,.25),(5,.18)]]
        curve=VMobject(color=GOLD,stroke_width=3).set_points_smoothly(points)
        dashed=DashedLine(a.c2p(2.35,0),a.c2p(2.35,2.65),color=MUTED)
        labels=VGroup(eq('A',29).next_to(a.y_axis,UP,buff=.1),
            eq(r'\nu',30).next_to(a.x_axis,RIGHT,buff=.1),
            eq(r'\nu_0',28,GOLD).move_to(a.c2p(2.35,0)+DOWN*.3),
            txt('Схематично',21,MUTED).move_to([4.6,1.65,0]),
            txt('Собственная',23,GOLD).move_to([4.6,.35,0]),
            txt('частота',23,GOLD).move_to([4.6,-.1,0]))
        self.show(a,labels,run_time=1)
        self.play(Create(curve),run_time=7,rate_func=linear)
        self.show(dashed,create=True,run_time=.7)

        self.beat(4,'Линейка, бокал и здание имеют собственные частоты колебаний')
        self.clear_stage(run_time=.8)
        ruler=VGroup(Rectangle(width=.28,height=2,color=CYAN),Line([-.6,-1,0],[.6,-1,0],color=MUTED)).move_to([-4,0,0])
        glass=VGroup(Arc(radius=.65,start_angle=PI,angle=PI,color=GOLD),
            Line([0,-.65,0],[0,-1.5,0],color=GOLD),Line([-.5,-1.5,0],[.5,-1.5,0],color=GOLD)).move_to([0,.1,0])
        building=VGroup(Rectangle(width=1.2,height=2.2,color=LAVENDER),
            *[Rectangle(width=.2,height=.25,color=MUTED).move_to([xx,yy,0]) for xx in [-.3,.3] for yy in [-.6,0,.6]])
        building.move_to([4,0,0]);ground=Line([2.8,-1.2,0],[5.2,-1.2,0],color=MUTED)
        names=VGroup(txt('Линейка',23,CYAN).move_to([-4,1.7,0]),txt('Бокал',23,GOLD).move_to([0,1.7,0]),
            txt('Здание',23,LAVENDER).move_to([4,1.7,0]),
            txt('Большой отклик при совпадении частот',27).move_to([0,-2.1,0]))
        self.show(ruler,glass,building,ground,names,run_time=1.2)
        q=ValueTracker(0)
        originals=[m.copy() for m in [ruler,glass,building]]
        for mob,original,ang in zip([ruler,glass,building],originals,[.07,.04,.04]):
            origin=original.get_bottom()
            mob.add_updater(lambda m,dt=0,original=original,ang=ang,origin=origin:
                m.become(original.copy().rotate(ang*np.sin(q.get_value()),about_point=origin)))
        self.play(q.animate.set_value(2*TAU),run_time=6,rate_func=linear)
        freeze(ruler,glass,building)


class MechanicalWaves(ChapterScene):
    chapter_id=21
    def chapter(self):
        self.beat(0,'Волна — распространение колебаний в пространстве')
        water=Circle(radius=1.9,color=GRID,stroke_width=1.5).move_to([-3.3,-.1,0])
        stone=Dot([-3.3,1.9,0],radius=.1,color=GOLD)
        definition=VGroup(txt('Возмущение распространяется',28),txt('от места воздействия',26,MUTED)).arrange(DOWN,buff=.55).move_to([2.6,.5,0])
        self.show(water,stone,definition,run_time=.9)
        self.play(stone.animate.move_to([-3.3,-.1,0]),run_time=.8,rate_func=linear)
        self.play(FadeOut(stone),run_time=.3)
        for i in range(2):
            radius=ValueTracker(.02)
            ring=always_redraw(lambda:Circle(radius=max(.02,radius.get_value()),color=CYAN,stroke_width=2).move_to([-3.3,-.1,0]))
            self.show(ring,run_time=.3)
            self.play(radius.animate.set_value(1.86),run_time=2.2,rate_func=linear)
            freeze(ring);self.play(FadeOut(ring),run_time=.7)

        self.beat(1,'Поперечная волна: частица колеблется поперёк распространения')
        self.clear_stage(run_time=.8)
        p=ValueTracker(0);xs=np.linspace(-5.1,5.1,57)
        def yy(x):return .65*np.sin(TAU*(x+5.1)/3.4-p.get_value())
        line=always_redraw(lambda:VMobject(color=CYAN,stroke_width=2).set_points_smoothly([[x,yy(x),0] for x in xs]))
        marked_x=0.
        marked=Dot([marked_x,yy(marked_x),0],radius=.1,color=GOLD)
        marked.add_updater(lambda m:m.move_to([marked_x,yy(marked_x),0]))
        equilibrium=DashedLine([-5.2,0,0],[5.2,0,0],color=GRID)
        guide=DoubleArrow([0,-.95,0],[0,.95,0],buff=0,color=GOLD,stroke_width=2)
        spread=arrow([-1.2,1.7,0],RIGHT*2.4,CYAN)
        labels=VGroup(txt('Распространение',23,CYAN).move_to([0,2.2,0]),
            txt('Частица ↕',24,GOLD).move_to([2.5,-1.7,0]),
            txt('Схема поперечной волны',25).move_to([-2.4,-1.7,0]))
        self.show(equilibrium,line,marked,guide,spread,labels,run_time=1)
        self.play(p.animate.set_value(TAU),run_time=7,rate_func=linear)
        freeze(line,marked)

        self.beat(2,'Гребень и впадина проходят вправо, а частица остаётся около своего места')
        crest=Dot([-4.25,.65,0],radius=.07,color=CYAN)
        trough=Dot([-2.55,-.65,0],radius=.07,color=ROSE)
        words=VGroup(txt('Гребень',24,CYAN).move_to([-4.25,1.17,0]),
            txt('Впадина',24,ROSE).move_to([-2.55,-1.18,0]),
            txt('Примеры: морская волна, удар хлыстом',24,MUTED).move_to([0,-2.45,0]))
        self.show(crest,trough,words,run_time=1)
        # One full spatial wavelength, ending in the same visible profile.
        line.add_updater(lambda m:m.become(VMobject(color=CYAN,stroke_width=2).set_points_smoothly([[x,yy(x),0] for x in xs])))
        marked.add_updater(lambda m:m.move_to([marked_x,yy(marked_x),0]))
        self.play(FadeOut(crest),FadeOut(trough),FadeOut(words[0]),FadeOut(words[1]),run_time=.6)
        self.play(p.animate.set_value(2*TAU),run_time=6,rate_func=linear)
        freeze(line,marked)

        self.beat(3,'Продольная волна: уплотнения перемещаются, частицы колеблются вдоль оси')
        self.clear_stage(run_time=.8)
        p=ValueTracker(0)
        row,xs=longitudinal_row(0,p,xmin=-5,xmax=5,count=51,amp=.15,wave_length=2.5)
        marked_x=0.;mark=Dot([0,0,0],radius=.09,color=GOLD)
        mark.add_updater(lambda m:m.move_to([marked_x+.15*np.sin(TAU*(marked_x+5)/2.5-p.get_value()),0,0]))
        equilibrium=Line([0,-.45,0],[0,.45,0],color=GRID)
        wave_arrow=arrow([-1.25,1.3,0],RIGHT*2.5,CYAN)
        particle_arrow=DoubleArrow([-.45,-.9,0],[.45,-.9,0],buff=0,color=GOLD)
        names=VGroup(txt('Волна →',25,CYAN).move_to([0,1.85,0]),
            txt('Частица ↔ около равновесия',25,GOLD).move_to([0,-1.65,0]),
            txt('Уплотнение и разрежение проходят вправо',24,MUTED).move_to([0,2.4,0]))
        self.show(row,mark,equilibrium,wave_arrow,particle_arrow,names,run_time=1)
        self.play(p.animate.set_value(TAU),run_time=8,rate_func=linear)
        freeze(row,mark)

        self.beat(4,'Направление колебаний частиц определяет тип волны')
        self.clear_stage(run_time=.8)
        p=ValueTracker(0)
        rows=VGroup()
        for x in np.linspace(-4.9,4.9,45):
            d=Dot([x,1,0],radius=.045,color=CYAN)
            d.add_updater(lambda m,dt=0,x=x:m.move_to([x,1+.35*np.sin(TAU*(x+4.9)/2.45-p.get_value()),0]))
            rows.add(d)
        lower,_=longitudinal_row(-1.05,p,xmin=-4.9,xmax=4.9,count=45,amp=.12,wave_length=2.45,color=GOLD)
        labels=VGroup(txt('Поперечная: частицы ↕, волна →',25,CYAN).move_to([0,2.1,0]),
            txt('Продольная: частицы ↔, волна →',25,GOLD).move_to([0,-2.15,0]))
        self.show(rows,lower,labels,run_time=1)
        self.play(p.animate.set_value(TAU),run_time=7,rate_func=linear)
        freeze(rows,lower)


class SoundProperties(ChapterScene):
    chapter_id=22
    def chapter(self):
        self.beat(0,'Колеблющееся тело передаёт возмущение соседним частицам среды')
        source=Rectangle(width=.25,height=1.3,color=GOLD,fill_opacity=.3).move_to([-5.5,0,0])
        phase=ValueTracker(0)
        source.add_updater(lambda m:m.move_to([-5.5+.08*np.sin(phase.get_value()),0,0]))
        pulse=ValueTracker(-6)
        xs=np.linspace(-4.8,5,42)
        particles=VGroup(*[Dot([x,0,0],radius=.055,color=CYAN) for x in xs])
        def displacement(x):
            d=x-pulse.get_value()
            return .16*np.cos(PI*d/1.6)**2*np.sin(6*d) if abs(d)<.8 else 0.
        for dot,x in zip(particles,xs):
            dot.add_updater(lambda m,dt=0,x=x:m.move_to([x+displacement(x),0,0]))
        labels=VGroup(txt('Источник',23,GOLD).move_to([-5.2,-1.15,0]),
            txt('Материальная среда',28,CYAN).move_to([.2,1.5,0]),
            arrow([-1.1,.8,0],RIGHT*2.2,CYAN))
        self.show(source,particles,labels,run_time=1)
        self.play(pulse.animate.set_value(6.6),phase.animate.set_value(3*TAU),run_time=8,rate_func=linear)
        freeze(source,particles)

        self.beat(1,'Звук распространяется и в твёрдых телах; скорость зависит от среды')
        self.clear_stage(run_time=.8)
        rail=VGroup(Line([-5.4,.3,0],[5.4,.3,0],color=MUTED,stroke_width=5),
            Line([-5.4,-.3,0],[5.4,-.3,0],color=MUTED,stroke_width=5),
            *[Line([x,-.6,0],[x,.6,0],color=GRID,stroke_width=3) for x in np.linspace(-5,5,12)])
        signal=Dot([-5,0,0],radius=.12,color=GOLD)
        names=VGroup(txt('Схема передачи колебаний по рельсу',28).move_to([0,1.6,0]),
            txt('Возмущение →',22,GOLD).move_to([0,.9,0]),
            txt('Скорость звука зависит от свойств среды',27,CYAN).move_to([0,-1.6,0]))
        self.show(rail,signal,names,run_time=1)
        self.play(signal.animate.move_to([5,0,0]),run_time=6,rate_func=linear)
        self.play(FadeOut(signal),run_time=.7)

        self.beat(2,'В вакууме источник колеблется, но звук не передаётся')
        self.clear_stage(run_time=.8)
        phase=ValueTracker(0)
        source=Rectangle(width=.25,height=1.4,color=GOLD,fill_opacity=.3).move_to([-4,0,0])
        source.add_updater(lambda m:m.move_to([-4+.13*np.sin(phase.get_value()),0,0]))
        medium=VGroup(*[Dot([x,y,0],radius=.04,color=CYAN) for x in np.linspace(-2.8,4.7,17) for y in [-.35,.35]])
        frame=RoundedRectangle(width=11,height=2.8,corner_radius=.15,color=GRID)
        self.show(source,medium,frame,run_time=.8)
        self.play(FadeOut(medium),run_time=1.2)
        names=VGroup(txt('Вакуум: среды нет',30).move_to([1.2,.8,0]),
            txt('Звук не распространяется',30,CYAN).move_to([1.2,-.4,0]))
        self.show(names,run_time=.8)
        self.play(phase.animate.set_value(2*TAU),run_time=6,rate_func=linear)
        freeze(source)

        self.beat(3,'При одинаковой частоте большая амплитуда соответствует более громкому звуку')
        self.clear_stage(run_time=.8)
        a,l=period_axis([-3.1,1.1,0],width=5.7,height=1.3)
        b,m=period_axis([-3.1,-1.25,0],width=5.7,height=1.3)
        c=trace(a,lambda t:.45*np.sin(2*TAU*t),CYAN)
        d=trace(b,lambda t:np.sin(2*TAU*t),GOLD)
        labels=VGroup(txt('Меньше амплитуда',25,CYAN).move_to([3.25,1.1,0]),
            txt('Больше амплитуда',25,GOLD).move_to([3.25,-.8,0]),
            txt('Громче при прочих равных',22,MUTED).move_to([3.25,-1.45,0]),
            txt('Частоты одинаковы',23,MUTED).move_to([3.25,2.05,0]))
        # These comparison axes cover the same observation interval, not one T.
        for group in [l,m]:
            for label in list(group):group.remove(label)
        endpoint=VGroup(txt('Одинаковое время',21,MUTED).move_to([-3.1,2.2,0]),
            eq('t',23,MUTED).next_to(a.x_axis,RIGHT,buff=.08),
            eq('t',23,MUTED).next_to(b.x_axis,RIGHT,buff=.08))
        self.show(a,b,labels,endpoint,run_time=.9)
        self.play(Create(c),Create(d),run_time=7,rate_func=linear)

        self.beat(4,'При одинаковой амплитуде более высокая частота даёт более высокий звук')
        self.clear_stage(run_time=.8)
        a,_=period_axis([-3.2,1.15,0],width=5.4,height=1.15)
        b,_=period_axis([-3.2,-1.1,0],width=5.4,height=1.15)
        c=trace(a,lambda t:np.sin(TAU*t),CYAN)
        d=trace(b,lambda t:np.sin(2*TAU*t),GOLD)
        labels=VGroup(txt('Ниже частота',23,CYAN).move_to([2.35,1.3,0]),
            txt('Выше частота — выше звук',23,GOLD).move_to([2.35,-.9,0]),
            txt('Одинаковое время и амплитуда',21,MUTED).move_to([-2.6,2.25,0]),
            eq('t',23,MUTED).next_to(a.x_axis,RIGHT,buff=.08),
            eq('t',23,MUTED).next_to(b.x_axis,RIGHT,buff=.08))
        fork=fork_shape().scale(.7).move_to([4.8,1.4,0])
        name=txt('Камертон',22,MUTED).move_to([4.75,.25,0])
        self.show(a,b,labels,run_time=.9)
        self.play(Create(c),Create(d),run_time=6,rate_func=linear)
        self.show(fork,name,run_time=.8)


class SoundResonanceWavelength(ChapterScene):
    chapter_id=23
    def fork_demo(self,same=True):
        first=fork_shape(CYAN).move_to([-4,-.05,0])
        second=fork_shape(GOLD).scale(1 if same else .78).move_to([4,-.05,0])
        base1=first.copy();base2=second.copy()
        phase=ValueTracker(0);response=ValueTracker(0)
        first.add_updater(lambda m:m.become(base1.copy().rotate(.035*np.sin(phase.get_value()),about_point=base1.get_bottom())))
        second.add_updater(lambda m:m.become(base2.copy().rotate((.035 if same else .006)*np.sin(response.get_value()),about_point=base2.get_bottom())))
        condition=eq(r'\nu_1=\nu_2' if same else r'\nu_1\ne\nu_2',36,GOLD).move_to([0,2.1,0])
        mallet=VGroup(Line([-.35,0,0],[.35,0,0],color=MUTED,stroke_width=3),Dot([.35,0,0],radius=.13,color=INK)).move_to([-5.3,.75,0])
        self.show(first,second,condition,mallet,run_time=.8)
        self.play(mallet.animate.shift(RIGHT*.8),run_time=.55,rate_func=linear)
        self.play(mallet.animate.shift(LEFT*.8),run_time=.55,rate_func=linear)
        self.play(FadeOut(mallet),run_time=.4)
        # First body moves before the travelling perturbation reaches the second.
        self.play(phase.animate.set_value(TAU),run_time=1.5,rate_func=linear)
        packet=VGroup(*[Arc(radius=.25+.19*i,start_angle=-.55,angle=1.1,color=CYAN).move_to([-3,.5,0]) for i in range(3)])
        self.show(packet,run_time=.35)
        self.play(packet.animate.shift(RIGHT*7),phase.animate.set_value(3*TAU),run_time=3,rate_func=linear)
        self.play(FadeOut(packet),run_time=.4)
        self.play(phase.animate.set_value(5*TAU),response.animate.set_value(2*TAU),run_time=3,rate_func=linear)
        freeze(first,second)
        note=txt('Резонансный отклик' if same else 'Сильного резонансного усиления нет',25,MUTED).move_to([0,-1.8,0])
        self.show(note,run_time=.7)

    def chapter(self):
        self.beat(0,'Удар, передача колебаний через среду и ответ одинакового камертона')
        self.fork_demo(True)

        self.beat(1,'Другая собственная частота: сильного резонансного отклика нет')
        self.clear_stage(run_time=.8)
        self.fork_demo(False)

        self.beat(2,'У струны могут совпасть частота возбуждения и одна из собственных мод')
        self.clear_stage(run_time=.8)
        title=txt('Ряд Ля из конспекта',30).move_to([0,2.1,0])
        freqs=VGroup(*[txt(str(n)+' Гц',28,CYAN if i%2==0 else GOLD) for i,n in enumerate([55,110,220,440,880])]).arrange(RIGHT,buff=.55).move_to([0,1.15,0])
        modes=VGroup()
        for i,n in enumerate([1,2,4]):
            y=.15-i*.72
            curve=VMobject(color=[CYAN,GOLD,LAVENDER][i],stroke_width=2).set_points_smoothly(
                [[x,y+.2*np.sin(n*PI*(x+4.5)/9),0] for x in np.linspace(-4.5,4.5,181)])
            modes.add(curve,Dot([-4.5,y,0],radius=.045,color=MUTED),Dot([4.5,y,0],radius=.045,color=MUTED))
        explanation=VGroup(txt('Собственные моды струны',24,MUTED).move_to([0,-2.13,0]),
            txt('Резонанс требует совпадения с подходящей модой',24).move_to([0,-2.65,0]))
        self.show(title,freqs,run_time=1)
        self.show(modes,create=True,run_time=3)
        self.show(explanation,run_time=1)

        self.beat(3,'За один период отмеченный гребень проходит одну длину волны')
        self.clear_stage(run_time=.8)
        p=ValueTracker(0);wavelength=3.2;start=-3.8
        curve=always_redraw(lambda:VMobject(color=CYAN,stroke_width=2).set_points_smoothly(
            [[x,.55*np.cos(TAU*(x-start)/wavelength-p.get_value()),0] for x in np.linspace(-5.5,5.5,181)]))
        marked=Dot([start,.55,0],radius=.1,color=GOLD)
        marked.add_updater(lambda m:m.move_to([start+wavelength*p.get_value()/TAU,.55,0]))
        initial=DashedLine([start,-1.1,0],[start,1.05,0],color=MUTED)
        final=DashedLine([start+wavelength,-1.1,0],[start+wavelength,1.05,0],color=MUTED)
        top=VGroup(txt('Начало периода',21,MUTED).move_to([start,1.65,0]),
            txt('Конец периода T',21,MUTED).move_to([start+wavelength,1.65,0]),
            arrow([2,1.4,0],RIGHT*2,CYAN),txt('Скорость v',24,CYAN).move_to([3,2,0]))
        self.show(curve,marked,initial,top,run_time=1)
        self.play(p.animate.set_value(TAU),run_time=6,rate_func=linear)
        freeze(curve,marked)
        bracket=BraceBetweenPoints([start,-1.1,0],[start+wavelength,-1.1,0],DOWN,color=GOLD)
        distance=eq(r'\lambda',34,GOLD).next_to(bracket,DOWN,buff=.1)
        form=eq(r'\lambda=vT',44,GOLD).move_to([2.8,-1.5,0])
        self.show(final,bracket,distance,form,run_time=1)

        self.beat(4,'Подставляем T = 1/ν и получаем окончательную формулу длины волны')
        self.clear_stage(run_time=.8)
        first=eq(r'\lambda=vT',48,CYAN).move_to([-3.6,1.3,0])
        period=eq(r'T=\frac{1}{\nu}',45).move_to([2.6,1.3,0])
        self.show(first,period,run_time=1)
        result=eq(r'\lambda=\frac{v}{\nu}',64,GOLD).move_to([0,-.1,0])
        self.show(result,run_time=1.3)
        legend=VGroup(txt('λ — длина волны',26,GOLD),txt('v — скорость распространения',26,CYAN),
            txt('ν — частота колебаний',26)).arrange(DOWN,buff=.35).move_to([0,-1.9,0])
        self.show(legend,run_time=1)
