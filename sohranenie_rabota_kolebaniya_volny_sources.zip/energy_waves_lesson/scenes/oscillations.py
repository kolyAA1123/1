"""Chapters 12–17: the supplied oscillations PDF, pp. 1–10 (upper part).

All dimensions below are drawing coordinates, never additional physical data.
Every moving tracker has a finite target; no time-step based loops are used.
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from energy_style import *


def fit_formula(tex, where, size=35, color=INK, width=6.1):
    mob = eq(tex, size, color)
    if mob.width > width:
        mob.scale_to_fit_width(width)
    return mob.move_to(where)


def formula_stack(rows, where=(0, 0, 0), size=35, buff=.42, width=11.7):
    group = VGroup(*[fit_formula(tex, ORIGIN, size, color, width)
                     for tex, color in rows]).arrange(DOWN, buff=buff)
    return group.move_to(where)


def rail(where=(-2.8, .25, 0), amplitude=1.55):
    center = np.array(where, dtype=float)
    baseline = Line(center-2.15*RIGHT, center+2.15*RIGHT,
                    color=MUTED, stroke_width=1.5)
    ticks = VGroup(*[Line(center+x*RIGHT+DOWN*.09,
                         center+x*RIGHT+UP*.09, color=MUTED)
                    for x in [-amplitude, 0, amplitude]])
    zero = eq('0', 24, MUTED).move_to(center+DOWN*.38)
    return VGroup(baseline, ticks, zero)


def rail_body(phase, where=(-2.8, .25, 0), amplitude=1.55,
              envelope=lambda _: 1., show_velocity=True, cycles=1):
    origin = np.array(where, dtype=float)

    def location():
        p = phase.get_value()
        return origin + amplitude*envelope(p)*np.sin(TAU*cycles*p)*RIGHT

    body = Dot(location(), radius=.11, color=CYAN)
    body.add_updater(lambda m: m.move_to(location()))
    group = VGroup(body)
    if show_velocity:
        velocity = always_redraw(lambda: arrow(
            location()+UP*.43,
            RIGHT*.92*np.cos(TAU*cycles*phase.get_value()), GOLD))
        group.add(velocity)
    return group


def sine_axes(center=(0, -.3, 0), width=9.2, height=2.5):
    a = axes((0, 1.04, .25), (-1.25, 1.25, 1), width, height,
             np.array(center, dtype=float))
    labels = VGroup(eq('0', 22, MUTED).next_to(a.c2p(0, 0), DOWN, buff=.13),
                    eq('T', 25, MUTED).next_to(a.c2p(1, 0), DOWN, buff=.13),
                    eq('t', 24, MUTED).next_to(a.x_axis.get_end(), RIGHT, buff=.1))
    return a, labels


def progressive_curve(a, fn, phase, color=CYAN):
    """Reuse one cached path; the updater creates no text or TeX objects."""
    full = a.plot(fn, x_range=[0, 1, .004], color=color, stroke_width=3)
    visible = full.copy()
    visible.add_updater(lambda m: m.pointwise_become_partial(
        full, 0, max(1e-7, min(1., phase.get_value()))))
    dot = Dot(a.c2p(0, fn(0)), radius=.055, color=color)
    dot.add_updater(lambda m: m.move_to(a.c2p(
        phase.get_value(), fn(phase.get_value()))))
    return visible, dot


def spring_path(start, end, color=CYAN):
    start, end = np.array(start), np.array(end)
    span = end-start
    points = [start, start+.09*span]
    for index in range(1, 17):
        f = .09+.82*index/17
        points.append(start+f*span+UP*(.13 if index % 2 else -.13))
    points.extend([start+.91*span, end])
    return VMobject(color=color, stroke_width=2.5).set_points_as_corners(points)


class SpringRig(VGroup):
    def __init__(self, phase, origin=(-2.55, .05, 0), amplitude=1.08,
                 velocity=True, restoring=False):
        super().__init__()
        self.phase = phase
        self.origin = np.array(origin, dtype=float)
        self.amplitude = amplitude
        wall_x = -5.72
        y = self.origin[1]
        self.fixed = VGroup(
            Line([wall_x, y-.55, 0], [wall_x, y+.8, 0], color=MUTED),
            Line([wall_x, y-.28, 0], [.05, y-.28, 0], color=MUTED),
            *[Line([wall_x-.15, y-.4+.2*i, 0],
                   [wall_x, y-.26+.2*i, 0], color=GRID) for i in range(6)],
            DashedLine(self.origin+DOWN*.7, self.origin+UP*.8,
                       color=GRID, stroke_width=1.4),
            eq('x=0', 24, MUTED).move_to(self.origin+DOWN*.95))
        self.block = RoundedRectangle(width=.64, height=.56,
                                       corner_radius=.06, color=CYAN,
                                       fill_color=GRID, fill_opacity=.65)
        self.block.move_to(self.position())
        self.block.add_updater(lambda m: m.move_to(self.position()))
        self.spring = always_redraw(lambda: spring_path(
            np.array([wall_x, y, 0]), self.position()+LEFT*.32))
        self.add(self.fixed, self.spring, self.block)
        if velocity:
            self.v = always_redraw(lambda: arrow(
                self.position()+UP*.67,
                RIGHT*.92*np.cos(TAU*phase.get_value()), GOLD))
            self.add(self.v)
        if restoring:
            self.force = always_redraw(lambda: arrow(
                self.position()+DOWN*.65,
                -RIGHT*1.02*np.sin(TAU*phase.get_value()), ROSE))
            self.add(self.force)

    def position(self):
        return self.origin + RIGHT*self.amplitude*np.sin(TAU*self.phase.get_value())


class OscillationTypes(ChapterScene):
    chapter_id = 12

    def chapter(self):
        self.beat(0, 'Колебание повторяется и возвращает систему в исходное состояние')
        phase = ValueTracker(0)
        body = SpringRig(phase)
        definition = VGroup(txt('Механические колебания', 27),
                            txt('Точное или приближённое', 23, MUTED),
                            txt('повторение движения', 23, MUTED)).arrange(DOWN, buff=.32)
        definition.move_to([2.95, .25, 0])
        self.show(body, definition, run_time=1.1)
        self.play(phase.animate.set_value(1), run_time=5.4, rate_func=linear)
        complete = txt('Исходное состояние повторилось', 22, CYAN).move_to([0, -1.6, 0])
        self.show(complete, run_time=.7)

        self.beat(1, 'Свободные: после вывода из равновесия система предоставлена себе')
        self.clear_stage(run_time=.8)
        phase = ValueTracker(0)
        body = SpringRig(phase)
        label = VGroup(txt('Свободные колебания', 28, CYAN),
                       txt('После начального воздействия', 22, MUTED),
                       txt('под действием внутренних сил', 22, MUTED),
                       txt('колебательной системы', 22, MUTED)).arrange(DOWN, buff=.3)
        label.move_to([2.8, .3, 0])
        initiating = arrow([-3.6, 1.45, 0], RIGHT*1.6, GOLD)
        self.show(body, label, initiating, run_time=.9)
        self.play(FadeOut(initiating), run_time=.65)
        self.play(phase.animate.set_value(1), run_time=5.2, rate_func=linear)

        self.beat(2, 'Вынужденные: на систему действует внешняя периодическая сила')
        self.clear_stage(run_time=.8)
        phase = ValueTracker(0)
        body = SpringRig(phase, velocity=False)
        force = always_redraw(lambda: arrow(
            body.position()+UP*.75,
            RIGHT*1.1*np.sin(TAU*phase.get_value()), ROSE))
        force_label = eq(r'\vec F_{\text{внеш}}(t)', 29, ROSE).move_to([-2.8, 1.95, 0])
        label = VGroup(txt('Вынужденные колебания', 27, ROSE),
                       txt('Внешнее периодическое', 23, MUTED),
                       txt('воздействие продолжается', 23, MUTED)).arrange(DOWN, buff=.34)
        label.move_to([2.8, .25, 0])
        self.show(body, force, force_label, label, run_time=.9)
        self.play(phase.animate.set_value(1), run_time=5.8, rate_func=linear)

        self.beat(3, 'При потерях энергии размах постепенно уменьшается')
        self.clear_stage(run_time=.8)
        phase = ValueTracker(0)
        track = rail()
        body = rail_body(phase, envelope=lambda p: (1-p)**2,
                         show_velocity=False, cycles=3)
        label = VGroup(txt('Затухающие колебания', 27, GOLD),
                       txt('Амплитуда уменьшается', 23, MUTED),
                       txt('из-за потерь энергии', 23, MUTED)).arrange(DOWN, buff=.34)
        label.move_to([2.8, .3, 0])
        self.show(track, body, label, run_time=.9)
        self.play(phase.animate.set_value(1), run_time=7, rate_func=linear)
        stopped = txt('Покой вблизи равновесия', 22, GOLD).move_to([0, -1.65, 0])
        self.show(stopped, run_time=.6)

        self.beat(4, 'Различаем причину колебаний и изменение их амплитуды')
        self.clear_stage(run_time=.9)
        rows = VGroup(
            txt('Свободные — после начального воздействия', 26, CYAN),
            txt('Вынужденные — внешняя периодическая сила', 26, ROSE),
            txt('Затухающие — амплитуда уменьшается', 26, GOLD),
            txt('Повторение движения — общий признак колебаний', 23, MUTED)
        ).arrange(DOWN, aligned_edge=LEFT, buff=.62).move_to([0, .15, 0])
        self.show(rows, run_time=1.5)


class PeriodFrequencyAmplitude(ChapterScene):
    chapter_id = 13

    def chapter(self):
        self.beat(0, 'Полный период возвращает и координату, и направление скорости')
        phase = ValueTracker(0)
        track, body = rail(), rail_body(phase)
        title = formula_stack([(r't=0:\quad x=0,\quad v_x>0', GOLD),
                               (r't=T:\quad x=0,\quad v_x>0', CYAN)],
                              [2.8, .25, 0], 31, width=5.8)
        self.show(track, body, title, run_time=1.1)
        self.play(phase.animate.set_value(1), run_time=6, rate_func=linear)
        result = eq(r'\text{Одно полное колебание}\quad\longleftrightarrow\quad T', 31)
        result.move_to([0, -1.7, 0])
        self.show(result, run_time=.8)

        self.beat(1, 'За время t система совершает N полных колебаний')
        self.clear_stage(run_time=.9)
        count = txt('N полных колебаний за время t', 29, MUTED).move_to([0, 1.9, 0])
        period = formula_stack([(r'T=\frac{t}{N}', CYAN), (r'[T]=\text{с}', MUTED)],
                               [-3.05, .1, 0], 44, .6, 4.5)
        frequency = formula_stack([(r'\nu=\frac{N}{t}', GOLD),
                                  (r'[\nu]=\text{Гц}', MUTED)],
                                 [3.05, .1, 0], 44, .6, 4.5)
        self.show(count, run_time=.7)
        self.show(period, run_time=1.1)
        self.show(frequency, run_time=1.1)
        meaning = txt('Частота — число колебаний за единицу времени', 25, MUTED)
        meaning.move_to([0, -1.9, 0])
        self.show(meaning, run_time=.8)

        self.beat(2, 'Период и частота взаимно обратны; ω — циклическая частота')
        self.clear_stage(run_time=.9)
        derivation = formula_stack([
            (r'T\nu=\frac{t}{N}\cdot\frac{N}{t}=1', MUTED),
            (r'T=\frac1\nu', CYAN),
            (r'\omega=\frac{2\pi}{T}', GOLD)], [0, .25, 0], 43, .55)
        self.show(derivation[0], run_time=1)
        self.show(derivation[1], run_time=1)
        self.show(derivation[2], run_time=1)

        self.beat(3, 'Амплитуда — максимальное отклонение от равновесия')
        self.clear_stage(run_time=.9)
        track = rail((0, .35, 0), 2)
        marks = VGroup(eq('-A', 30, GOLD).move_to([-2, -.35, 0]),
                       eq('+A', 30, GOLD).move_to([2, -.35, 0]))
        left_span = DoubleArrow([0, .95, 0], [-2, .95, 0], color=CYAN,
                                buff=0, stroke_width=2)
        right_span = DoubleArrow([0, .95, 0], [2, .95, 0], color=CYAN,
                                 buff=0, stroke_width=2)
        summary = eq(r'A=x_0', 44, GOLD).move_to([0, -1.45, 0])
        self.show(track, marks, run_time=1)
        self.show(left_span, right_span, create=True, run_time=1.3)
        self.show(summary, run_time=.8)

        self.beat(4, 'Гармонический закон: тело движется по прямой, график показывает x(t)')
        self.clear_stage(run_time=.9)
        phase = ValueTracker(0)
        track = rail((0, 1.8, 0), 1.55)
        body = rail_body(phase, (0, 1.8, 0), 1.55, show_velocity=False)
        a, labels = sine_axes((0, -.8, 0), 9.6, 2.5)
        law = eq(r'x=x_0\sin(\omega t)', 35, CYAN).move_to([4.25, 1.8, 0])
        ordinate = eq(r'\frac{x}{x_0}', 27, CYAN).next_to(a.y_axis.get_end(), UP, buff=.08)
        curve, marker = progressive_curve(a, lambda t: np.sin(TAU*t), phase)
        self.show(track, body, a, labels, law, ordinate, curve, marker, run_time=1)
        self.play(phase.animate.set_value(1), run_time=6.8, rate_func=linear)
        freeze(curve, marker, body)


class HarmonicDerivatives(ChapterScene):
    chapter_id = 14

    def chapter(self):
        self.beat(0, 'Производная сложной функции включает производную её аргумента')
        rows = formula_stack([
            (r'(\cos t)^{\prime}=-\sin t\qquad (\sin t)^{\prime}=\cos t', CYAN),
            (r'(\sin(t^2))^{\prime}=\cos(t^2)\cdot2t=2t\cos(t^2)', INK),
            (r'(5\sin(7t+3))^{\prime}=5\cos(7t+3)\cdot7', INK),
            (r'\phantom{(5\sin(7t+3))^{\prime}}{}=35\cos(7t+3)', GOLD)],
            [0, .15, 0], 34, .5)
        for row in rows:
            self.show(row, run_time=1.1)

        self.beat(1, 'Производная координаты даёт проекцию скорости')
        self.clear_stage(run_time=.9)
        rows = formula_stack([
            (r'x=x_0\sin(\omega t)', CYAN),
            (r'v_x=x^{\prime}=x_0\cos(\omega t)\cdot\omega', INK),
            (r'v_x=\omega x_0\cos(\omega t)', GOLD)], [0, .25, 0], 42, .6)
        for row in rows:
            self.show(row, run_time=1.2)

        self.beat(2, 'Максимальный модуль скорости равен ωA; проекция меняет знак')
        self.clear_stage(run_time=.9)
        rows = formula_stack([
            (r'v_x=v_m\cos(\omega t)', INK),
            (r'v_x=\omega x_0\cos(\omega t)', GOLD),
            (r'v_m=\omega x_0=\omega A', CYAN)], [0, .25, 0], 42, .57)
        for row in rows:
            self.show(row, run_time=1)
        maximum = txt('vₘ — максимальный модуль скорости', 24, MUTED).move_to([0, -2.05, 0])
        self.show(maximum, run_time=.8)

        self.beat(3, 'Ускорение направлено к равновесию: знак противоположен координате')
        self.clear_stage(run_time=.9)
        rows = formula_stack([
            (r'a_x=v_x^{\prime}=(\omega x_0\cos(\omega t))^{\prime}', INK),
            (r'a_x=-\omega^2x_0\sin(\omega t)', ROSE),
            (r'x=x_0\sin(\omega t)\quad\Longrightarrow\quad a_x=-\omega^2x', CYAN)],
            [0, .25, 0], 38, .6)
        for row in rows:
            self.show(row, run_time=1.2)

        self.beat(4, 'В крайних точках vₓ=0; в равновесии aₓ=0 и |vₓ| максимально')
        self.clear_stage(run_time=.9)
        phase = ValueTracker(0)
        charts = VGroup()
        moving = VGroup()
        for y, fn, label, color in [
                (1.55, lambda t: np.sin(TAU*t), r'x/x_0', CYAN),
                (.05, lambda t: np.cos(TAU*t), r'v_x/v_m', GOLD),
                (-1.45, lambda t: -np.sin(TAU*t), r'a_x/a_m', ROSE)]:
            a, labels = sine_axes((.8, y, 0), 8.6, 1.1)
            name = eq(label, 27, color).move_to([-5.1, y, 0])
            curve, marker = progressive_curve(a, fn, phase, color)
            charts.add(a, labels, name)
            moving.add(curve, marker)
        equations = VGroup(eq(r'a_x+\omega^2x=0', 29, CYAN),
                           eq(r'a_m=\omega^2A', 29, ROSE)).arrange(RIGHT, buff=1.4)
        equations.move_to([0, -2.55, 0])
        amplitude_note = txt('максимальный\nмодуль', 15, ROSE).move_to([4.85, -2.55, 0])
        self.show(charts, moving, equations, amplitude_note, run_time=1)
        self.play(phase.animate.set_value(1), run_time=8, rate_func=linear)
        freeze(moving)


class SpringCycle(ChapterScene):
    chapter_id = 15

    def chapter(self):
        self.beat(0, 'Без трения: старт из равновесия со скоростью вправо')
        phase = ValueTracker(0)
        rig = SpringRig(phase)
        friction = txt('Трения нет', 25, MUTED).move_to([-2.8, 1.8, 0])
        time = eq('t=0', 39, CYAN).move_to([3.15, 1.1, 0])
        state = formula_stack([(r'x=0', INK), (r'v_x=+v_m', GOLD)],
                              [3.15, -.25, 0], 37, .45, 4.6)
        law = eq(r'x=x_0\sin(\omega t)', 31, MUTED).move_to([-2.8, -1.8, 0])
        self.show(rig, friction, time, state, law, run_time=1.2)

        self.beat(1, 'Первая четверть: растяжение пружины и остановка справа')
        self.play(phase.animate.set_value(.25), run_time=5.6, rate_func=linear)
        new_time = eq(r't=T/4', 39, CYAN).move_to(time)
        new_state = formula_stack([(r'x=+x_0', INK), (r'v_x=0', GOLD)],
                                  [3.15, -.25, 0], 37, .45, 4.6)
        self.play(Transform(time, new_time), Transform(state, new_state), run_time=.8)

        self.beat(2, 'Вторая четверть: возврат в равновесие со скоростью влево')
        self.play(phase.animate.set_value(.5), run_time=5.6, rate_func=linear)
        new_time = eq(r't=2T/4', 39, CYAN).move_to(time)
        new_state = formula_stack([(r'x=0', INK), (r'v_x=-v_m', GOLD)],
                                  [3.15, -.25, 0], 37, .45, 4.6)
        self.play(Transform(time, new_time), Transform(state, new_state), run_time=.8)

        self.beat(3, 'Третья четверть: максимальное сжатие и остановка слева')
        self.play(phase.animate.set_value(.75), run_time=5.6, rate_func=linear)
        new_time = eq(r't=3T/4', 39, CYAN).move_to(time)
        new_state = formula_stack([(r'x=-x_0', INK), (r'v_x=0', GOLD)],
                                  [3.15, -.25, 0], 37, .45, 4.6)
        self.play(Transform(time, new_time), Transform(state, new_state), run_time=.8)

        self.beat(4, 'В конце периода повторяются исходная координата и скорость')
        self.play(phase.animate.set_value(1), run_time=5.6, rate_func=linear)
        new_time = eq(r't=T', 39, CYAN).move_to(time)
        new_state = formula_stack([(r'x=0', INK), (r'v_x=+v_m', GOLD)],
                                  [3.15, -.25, 0], 37, .45, 4.6)
        self.play(Transform(time, new_time), Transform(state, new_state), run_time=.8)
        timeline = VGroup(*[eq(tex, 27, GOLD if i in [0, 4] else MUTED)
                            for i, tex in enumerate([
                                '0', r'\frac T4', r'\frac{2T}4',
                                r'\frac{3T}4', 'T'])]).arrange(RIGHT, buff=1)
        timeline.move_to([0, -2.6, 0])
        self.show(timeline, run_time=.8)
        freeze(rig)


class SpringPeriod(ChapterScene):
    chapter_id = 16

    def chapter(self):
        self.beat(0, 'Синус и косинус соответствуют разным начальным состояниям')
        phase = ValueTracker(0)
        stage = VGroup()
        moving = VGroup()
        for y, fn, label, description, color in [
                (1.05, lambda t: np.sin(TAU*t), r'x=x_0\sin(\omega t)',
                 'Из равновесия вправо', CYAN),
                (-1.15, lambda t: np.cos(TAU*t), r'x=x_0\cos(\omega t)',
                 'Из крайнего правого положения', GOLD)]:
            a, labels = sine_axes((1.5, y, 0), 7.4, 1.55)
            law = fit_formula(label, [-4.5, y+.37, 0], 28, color, 3.1)
            note = txt(description, 17, MUTED).move_to([-4.5, y-.45, 0])
            if note.width > 3.3:
                note.scale_to_fit_width(3.3)
            curve, marker = progressive_curve(a, fn, phase, color)
            stage.add(a, labels, law, note)
            moving.add(curve, marker)
        self.show(stage, moving, run_time=1)
        self.play(phase.animate.set_value(1), run_time=6.5, rate_func=linear)
        freeze(moving)

        self.beat(1, 'При x>0 сила упругости направлена к равновесию, влево')
        self.clear_stage(run_time=.9)
        phase = ValueTracker(.25)
        rig = SpringRig(phase, velocity=False, restoring=True)
        force_label = eq(r'\vec F_{\text{упр}}', 29, ROSE).move_to([-2.5, -1.3, 0])
        positive = eq('x>0', 32, CYAN).move_to([-2.55, 1.55, 0])
        steps = formula_stack([(r'F_{\text{упр},x}=-kx', ROSE),
                               (r'ma_x=-kx', INK)], [3.1, .4, 0], 38, .6, 5.6)
        self.show(rig, force_label, positive, steps, run_time=1.1)

        self.beat(2, 'Перенесём силу влево и разделим всё уравнение на массу')
        new_steps = formula_stack([(r'ma_x+kx=0', INK),
                                   (r'a_x+\frac{k}{m}x=0', CYAN)],
                                  [3.1, .4, 0], 40, .7, 5.6)
        self.play(Transform(steps, new_steps), run_time=1.5)

        self.beat(3, 'Сравнение с гармоническим уравнением определяет частоту')
        new_steps = formula_stack([(r'a_x+\frac{k}{m}x=0', INK),
                                   (r'a_x+\omega^2x=0', MUTED),
                                   (r'\omega^2=\frac{k}{m}', GOLD),
                                   (r'\omega=\sqrt{\frac{k}{m}}', CYAN)],
                                  [3.1, .1, 0], 35, .35, 5.6)
        self.play(Transform(steps, new_steps), run_time=1.6)

        self.beat(4, 'Вывод завершается формулой периода пружинного маятника')
        self.clear_stage(run_time=1)
        rows = formula_stack([(r'\omega=\frac{2\pi}{T}=\sqrt{\frac{k}{m}}', INK),
                              (r'T=2\pi\sqrt{\frac{m}{k}}', CYAN)],
                             [0, .3, 0], 48, .8)
        self.show(rows[0], run_time=1.2)
        self.show(rows[1], run_time=1.3)
        border = SurroundingRectangle(rows[1], color=CYAN, buff=.23, stroke_width=1.6)
        self.show(border, create=True, run_time=.9)


class SimplePendulum(ChapterScene):
    chapter_id = 17

    def chapter(self):
        self.beat(0, 'Малый груз на длинной нити: отклонение по модулю меньше 10°')
        phase = ValueTracker(0)
        pivot = np.array([-3.15, 2.25, 0])
        length = 3.3
        angle_amplitude = .14  # Drawing angle < 10 degrees, no new physical datum.

        def angle():
            return angle_amplitude*np.cos(TAU*phase.get_value())

        def position():
            a = angle()
            return pivot+length*np.array([np.sin(a), -np.cos(a), 0])

        equilibrium = pivot+DOWN*length
        support = VGroup(Line(pivot+LEFT*.5, pivot+RIGHT*.5, color=MUTED),
                         Dot(pivot, radius=.045, color=INK))
        vertical = DashedLine(pivot, equilibrium+DOWN*.35,
                              color=GRID, stroke_width=1.4)
        string = Line(pivot, position(), color=INK, stroke_width=2.2)
        string.add_updater(lambda m: m.put_start_and_end_on(pivot, position()))
        bob = Dot(position(), radius=.13, color=CYAN)
        bob.add_updater(lambda m: m.move_to(position()))
        length_label = eq('l', 30, INK).move_to(pivot+DOWN*1.6+LEFT*.34)
        angle_label = eq(r'\alpha', 27, GOLD).move_to(pivot+DOWN*.77+RIGHT*.23)
        angle_arc = always_redraw(lambda: Arc(
            radius=.75, start_angle=-PI/2, angle=angle(), arc_center=pivot,
            color=GOLD, stroke_width=2))
        model = VGroup(support, vertical, string, bob, length_label, angle_arc, angle_label)
        condition = formula_stack([(r'|\alpha|<10^\circ', GOLD),
                                   (r'\text{Малые отклонения}', MUTED)],
                                  [2.8, .6, 0], 35, .5, 5.9)
        self.show(model, condition, run_time=1.1)
        self.play(phase.animate.set_value(1), run_time=7, rate_func=linear)
        freeze(model)

        self.beat(1, 'Используем приближение малых углов; α в радианах')
        new_condition = formula_stack([
            (r'\cos\alpha\approx1', INK),
            (r'\sin\alpha\approx\tan\alpha\approx\alpha', GOLD),
            (r'T_{\text{н}}\cos\alpha\approx mg', CYAN)],
            [2.8, .55, 0], 34, .53, 6.4)
        self.play(Transform(condition, new_condition), run_time=1.3)
        gravity = arrow(position(), DOWN*.88, GOLD)
        tension = arrow(position(), (pivot-position())/length*.88/np.cos(angle()), ROSE)
        force_names = VGroup(eq('mg', 27, GOLD).move_to(position()+DOWN*.65+RIGHT*.4),
                             eq(r'T_{\text{н}}', 27, ROSE).move_to(position()+UP*.65+LEFT*.3))
        self.show(gravity, tension, force_names, create=False, run_time=.9)
        approximation = txt('Вертикальное движение мало', 22, MUTED).move_to([2.8, -1.65, 0])
        self.show(approximation, run_time=.8)

        self.beat(2, 'Горизонтальная составляющая натяжения возвращает груз к равновесию')
        self.play(FadeOut(approximation), run_time=.6)
        new_condition = formula_stack([
            (r'ma_x=-T_{\text{н}}\sin\alpha', ROSE),
            (r'ma_x\approx-\frac{mg}{\cos\alpha}\sin\alpha', INK),
            (r'a_x+g\tan\alpha\approx0', CYAN)],
            [2.8, .35, 0], 34, .65, 6.3)
        self.play(Transform(condition, new_condition), run_time=1.6)

        self.beat(3, 'Из геометрии sin α=x/l; при малых углах получаем гармоническое уравнение')
        xline = Line(equilibrium, [position()[0], equilibrium[1], 0],
                     color=CYAN, stroke_width=3)
        projection = DashedLine(position(), [position()[0], equilibrium[1]-.15, 0],
                                color=MUTED, stroke_width=1.3)
        xlabel = eq('x', 26, CYAN).move_to((equilibrium+position())/2+DOWN*.4)
        self.show(xline, projection, xlabel, create=False, run_time=.8)
        new_condition = formula_stack([
            (r'\sin\alpha=\frac{x}{l},\qquad\tan\alpha\approx\sin\alpha', INK),
            (r'a_x+\frac{g}{l}x\approx0', CYAN),
            (r'\omega^2=\frac{g}{l},\qquad\omega=\sqrt{\frac{g}{l}}', GOLD)],
            [2.8, .35, 0], 33, .65, 6.4)
        self.play(Transform(condition, new_condition), run_time=1.6)

        self.beat(4, 'В принятой модели период зависит от длины и g, а от массы не зависит')
        new_condition = formula_stack([
            (r'\omega=\frac{2\pi}{T}=\sqrt{\frac{g}{l}}', INK),
            (r'T=2\pi\sqrt{\frac{l}{g}}', CYAN)],
            [2.8, .6, 0], 42, .8, 6.1)
        self.play(Transform(condition, new_condition), run_time=1.5)
        independent = VGroup(txt('Массы в формуле нет', 26, GOLD),
                             txt('При малых углах отклонения', 23, MUTED)).arrange(DOWN, buff=.4)
        independent.move_to([2.8, -1.9, 0])
        self.show(independent, run_time=1)
