"""Resistor connections, source energy, complete circuit and Joule heating."""
from current_style import *


def resistor(center=(-3.1,0,0),label='R',vertical=False,color=INK):
    x,y,_=center
    body=Rectangle(width=.48 if vertical else 1.05,height=.65 if vertical else .48,
                   color=color,stroke_width=2,fill_color=color,fill_opacity=.05).move_to(center)
    if vertical:
        leads=VGroup(Line([x,y-.6,0],[x,y-.325,0],color=MUTED),Line([x,y+.325,0],[x,y+.6,0],color=MUTED))
        name=formula(label,[x-.58,y,0],29,color,width=.7)
    else:
        leads=VGroup(Line([x-.85,y,0],[x-.525,y,0],color=MUTED),Line([x+.525,y,0],[x+.85,y,0],color=MUTED))
        name=formula(label,[x,y+.65,0],29,color,width=1.2)
    return VGroup(body,leads,name)


def series_network():
    resistors=VGroup(resistor((-4.2,0,0),'R_1'),resistor((-1.8,0,0),'R_2'))
    wires=VGroup(Line([-5.7,0,0],[-5.05,0,0],color=MUTED),
                 Line([-3.35,0,0],[-2.65,0,0],color=MUTED),
                 Line([-.95,0,0],[-.55,0,0],color=MUTED))
    names=VGroup(*[formula(s,[x,.35,0],26,MUTED,width=.6) for x,s in [(-5.55,'A'),(-3.0,'B'),(-.65,'C')]])
    return VGroup(resistors,wires,names)


def parallel_network():
    resistors=VGroup(resistor((-3.1,.85,0),'R_1'),resistor((-3.1,-.85,0),'R_2'))
    wires=VGroup(*[Line(a,b,color=MUTED) for a,b in [
        ([-5.3,.85,0],[-3.95,.85,0]),([-2.25,.85,0],[-.9,.85,0]),
        ([-5.3,-.85,0],[-3.95,-.85,0]),([-2.25,-.85,0],[-.9,-.85,0]),
        ([-5.3,-.85,0],[-5.3,.85,0]),([-.9,-.85,0],[-.9,.85,0]),
        ([-5.85,0,0],[-5.3,0,0]),([-.9,0,0],[-.35,0,0])]])
    nodes=VGroup(Dot([-5.3,0,0],radius=.05,color=GOLD),Dot([-.9,0,0],radius=.05,color=GOLD),
                 formula('A',[-5.3,.4,0],25,GOLD,width=.6),formula('B',[-.9,.4,0],25,GOLD,width=.6))
    return resistors,wires,nodes


def source_circuit():
    external=resistor((-2.7,1.5,0),'R')
    internal=resistor((-5.1,.75,0),'r',vertical=True,color=LAVENDER)
    battery=VGroup(Line([-5.5,-.25,0],[-4.7,-.25,0],color=ROSE,stroke_width=3),
                   Line([-5.35,-.65,0],[-4.85,-.65,0],color=CYAN,stroke_width=3),
                   formula('+',[-4.45,-.25,0],24,ROSE,width=.5),
                   formula('-',[-4.45,-.65,0],24,CYAN,width=.5),
                   formula(r'\varepsilon',[-5.7,-.45,0],29,GOLD,width=.5))
    wires=VGroup(*[Line(a,b,color=MUTED) for a,b in [
        ([-5.1,-.25,0],[-5.1,.15,0]),([-5.1,1.35,0],[-5.1,1.5,0]),
        ([-5.1,1.5,0],[-3.55,1.5,0]),([-1.85,1.5,0],[-.8,1.5,0]),
        ([-.8,1.5,0],[-.8,-1.5,0]),([-.8,-1.5,0],[-5.1,-1.5,0]),
        ([-5.1,-1.5,0],[-5.1,-.65,0])]])
    outline=RoundedRectangle(width=1.5,height=3.35,corner_radius=.15,color=GRID,stroke_width=1).move_to([-5.1,0,0])
    label=words('Источник',[-5.1,-2.0,0],20,MUTED,width=2)
    current=VGroup(arrow([-3.1,.65,0],[.9,0,0],CYAN),formula('I',[-2.65,.25,0],27,CYAN,width=.8))
    return VGroup(external,internal,battery,wires,outline,label,current),external,internal


class SeriesResistors(CurrentScene):
    chapter_id=7
    def chapter(self):
        self.beat(0)
        net=series_network()
        given=words(['Нет ответвлений','Стационарный ток'],[3.1,1.3,0],26)
        flow=VGroup(*[VGroup(arrow([x,-.8,0],[.65,0,0],CYAN),formula('I',[x+.325,-1.3,0],27,CYAN,width=.7)) for x in [-5.45,-3.35,-1.3]])
        relation=formula('I=I_1=I_2',[3.1,-.15,0],43,CYAN)
        self.show(net,given,run_time=1.2);self.intro(0)
        self.act(0,LaggedStart(*[FadeIn(m) for m in flow],lag_ratio=.3),Write(relation))
        self.show(words(['Заряд не накапливается','и не расходуется в резисторах'],[3.1,-1.65,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        net=series_network()
        definition=formula(r'U_{AC}=\varphi_A-\varphi_C',[3.1,1.3,0],39)
        spans=VGroup(DoubleArrow([-4.9,-.85,0],[-3.5,-.85,0],buff=0,color=GOLD),
                     DoubleArrow([-2.5,-.85,0],[-1.1,-.85,0],buff=0,color=GOLD),
                     formula('U_1',[-4.2,-1.3,0],29,GOLD,width=1),formula('U_2',[-1.8,-1.3,0],29,GOLD,width=1),
                     DoubleArrow([-5.55,-2.05,0],[-.65,-2.05,0],buff=0,color=CYAN),formula('U',[-3.1,-2.45,0],29,CYAN,width=1))
        relation=formula('U=U_1+U_2',[3.1,-.15,0],43,GOLD)
        self.show(net,definition,run_time=1.2);self.intro(1)
        self.act(1,LaggedStart(*[FadeIn(m) for m in spans],lag_ratio=.15),Write(relation))
        self.show(words(['Общая работа на единицу заряда','складывается из двух частей'],[3.1,-1.65,0],23,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        initial=formula(r'IR=IR_1+IR_2',[0,1.25,0],48,width=11.5)
        condition=words('Сокращаем общий ненулевой ток I',[0,0,0],26,MUTED,width=11.5)
        result=formula(r'R=R_1+R_2',[0,-1.3,0],52,GOLD,width=11.5)
        self.show(initial,condition,run_time=1.2);self.intro(2)
        self.act(2,Write(result))
        self.show(words('Последовательное соединение: один путь тока',[0,-2.5,0],25,MUTED,width=11.5),run_time=1.2);self.result(2)


class ParallelResistors(CurrentScene):
    chapter_id=8
    def chapter(self):
        self.beat(0)
        resistors,wires,nodes=parallel_network()
        given=words(['Одна и та же пара узлов','Две параллельные ветви'],[3.1,1.3,0],25)
        relation=formula('U=U_1=U_2',[3.1,-.2,0],43,GOLD)
        self.show(resistors,given,run_time=1.2);self.intro(0)
        self.act(0,Create(wires),FadeIn(nodes),Write(relation))
        self.show(words('Концы обеих ветвей имеют общие потенциалы',[3.1,-1.7,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        parts=parallel_network()
        incoming=VGroup(arrow([-5.95,0,0],[.65,0,0],CYAN),formula('I',[-5.8,.55,0],26,CYAN,width=.6))
        branches=VGroup(*[VGroup(arrow([-4.8,y,0],[.75,0,0],CYAN),formula(s,[-4.45,y+.45,0],26,CYAN,width=.7)) for y,s in [(.85,'I_1'),(-.85,'I_2')]])
        relation=formula('I=I_1+I_2',[3.1,.8,0],43,CYAN)
        self.show(*parts,incoming,words('Сохранение заряда в узле',[3.1,2.0,0],24),run_time=1.2);self.intro(1)
        self.act(1,FadeIn(branches),Write(relation))
        self.show(formula(r'I_1=\frac U{R_1},\qquad I_2=\frac U{R_2}',[3.1,-1.1,0],34),
                  words('Токи ветвей могут различаться',[3.1,-2.3,0],23,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        initial=formula(r'\frac UR=\frac U{R_1}+\frac U{R_2}',[0,1.25,0],48,width=11.5)
        condition=words('Сокращаем общее ненулевое напряжение U',[0,0,0],25,MUTED,width=11.5)
        result=formula(r'\frac1R=\frac1{R_1}+\frac1{R_2}',[0,-1.3,0],50,GOLD,width=11.5)
        self.show(initial,condition,run_time=1.2);self.intro(2)
        self.act(2,Write(result))
        self.show(words('Общее сопротивление определяют обе ветви',[0,-2.5,0],25,MUTED,width=11.5),run_time=1.2);self.result(2)

        self.beat(3)
        heading=words('Два параллельных резистора',[0,2.15,0],28,width=11.5)
        initial=formula(r'\frac1R=\frac{R_1+R_2}{R_1R_2}',[0,.8,0],49)
        result=formula(r'R=\frac{R_1R_2}{R_1+R_2}',[0,-.8,0],51,GOLD)
        self.show(heading,initial,run_time=1.2);self.intro(3)
        self.act(3,Write(result))
        self.show(words('Формула произведения и суммы — именно для двух резисторов',[0,-2.3,0],24,MUTED,width=11.5),run_time=1.2);self.result(3)


class EmfInternalResistance(CurrentScene):
    chapter_id=9
    def chapter(self):
        self.beat(0)
        outline=RoundedRectangle(width=2.4,height=3.3,corner_radius=.15,color=GRID).move_to([-3.1,0,0])
        signs=VGroup(formula('+',[-1.55,1.2,0],34,ROSE,width=.6),formula('-',[-1.55,-1.2,0],34,CYAN,width=.6))
        particle=charge('+',[-3.1,-1.15,0],.2)
        lift=arrow([-4.65,-.9,0],[0,1.8,0],GOLD)
        definition=formula(r'\varepsilon=\frac{A_{\mathrm{ст}}}{q}',[3.1,1.3,0],47,GOLD)
        self.show(outline,signs,particle,lift,definition,
                  words('Сторонние силы',[-3.1,2.2,0],24),
                  words('Условный положительный заряд',[-3.1,-2.3,0],21,MUTED),
                  words('ЭДС — энергия на единицу заряда',[3.1,-.15,0],24),run_time=1.2);self.intro(0)
        self.act(0,particle.animate.move_to([-3.1,1.15,0]))
        self.show(formula(r'1\ \mathrm{V}=1\ \mathrm{J/C}',[3.1,-1.55,0],37),
                  words('ЭДС не является механической силой',[3.1,-2.4,0],22,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        net,external,internal=source_circuit()
        given=words(['Реальный источник','Внутреннее сопротивление r'],[3.1,1.3,0],25)
        frame=SurroundingRectangle(internal[0],color=GOLD,buff=.12)
        self.show(net,given,run_time=1.2);self.intro(1)
        self.act(1,Create(frame),internal[0].animate.set_fill(GOLD,opacity=.3).set_stroke(GOLD))
        self.show(words(['Часть энергии преобразуется','в тепло внутри источника'],[3.1,-.4,0],24,GOLD),
                  words('r — внутреннее; R — внешнее',[3.1,-1.9,0],23,MUTED),run_time=1.2);self.result(1)

        self.beat(2)
        points=[[-4.8,-1.5,0],[-4.8,1.5,0],[-3.0,1.5,0],[-3.0,.65,0],[-1.3,.65,0],[-1.3,-1.5,0],[-4.8,-1.5,0]]
        path=VMobject(color=MUTED,stroke_width=2).set_points_as_corners(points)
        labels=VGroup(formula(r'\varepsilon',[-5.35,0,0],32,GOLD,width=.7),
                      formula('Ir',[-2.55,1.1,0],29,LAVENDER,width=.8),
                      formula('IR',[-.7,-.4,0],29,CYAN,width=.8))
        particle=charge('+',points[0],.16)
        relation=formula(r'\varepsilon=Ir+IR',[3.1,.65,0],44,GOLD)
        self.show(path,labels,particle,words('Энергия на единицу заряда',[-3.1,2.25,0],23),
                  words('Условная энергетическая схема',[-3.1,-2.35,0],21,MUTED),run_time=1.2);self.intro(2)
        self.act(2,MoveAlongPath(particle,path),Write(relation),rate_func=linear)
        self.show(words(['Источник даёт энергию','Она выделяется на r и R'],[3.1,-1.2,0],24,MUTED),run_time=1.2);self.result(2)


class CompleteCircuit(CurrentScene):
    chapter_id=10
    def chapter(self):
        self.beat(0)
        net,external,internal=source_circuit()
        balance=formula(r'\varepsilon=IR+Ir',[3.1,1.2,0],43,GOLD)
        law=formula(r'\varepsilon=I(R+r)',[3.1,-.2,0],43)
        self.show(net,balance,run_time=1.2);self.intro(0)
        self.act(0,Write(law))
        self.show(words(['Через R и r проходит один ток','Цепь замкнута, режим установился'],[3.1,-1.7,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        initial=formula(r'\varepsilon=I(R+r)',[0,1.2,0],48,width=11.5)
        condition=words(['Внешнее сопротивление R','Внутреннее сопротивление r'],[0,-.05,0],26,MUTED,width=11.5)
        final=formula(r'I=\frac{\varepsilon}{R+r}',[0,-1.55,0],53,CYAN,width=11.5)
        self.show(initial,condition,run_time=1.2);self.intro(1)
        self.act(1,Write(final))
        self.show(words('Закон Ома для полной цепи',[0,-2.6,0],25,GOLD,width=11.5),run_time=1.2);self.result(1)

        self.beat(2)
        net,external,internal=source_circuit()
        condition=words(['Короткое замыкание','R → 0; r > 0'],[3.1,1.6,0],26)
        initial=formula(r'I=\frac{\varepsilon}{r+R}',[3.1,.15,0],45)
        final=formula(r'I_{\mathrm{к.з.}}=\frac{\varepsilon}{r}',[3.1,.15,0],45,ROSE)
        bridge=Line([-3.55,1.5,0],[-1.85,1.5,0],color=ROSE,stroke_width=3)
        self.show(net,condition,initial,run_time=1.2);self.intro(2)
        self.act(2,FadeOut(external),Create(bridge),Succession(FadeOut(initial),FadeIn(final)))
        self.show(words(['Ток ограничен внутренним r','Внешний участок почти не сопротивляется'],[3.1,-1.7,0],23,MUTED),run_time=1.2);self.result(2)


class JouleLenz(CurrentScene):
    chapter_id=11
    def chapter(self):
        self.beat(0)
        heater=resistor([-3.1,.4,0],'R')
        wires=VGroup(Line([-5.7,.4,0],[-3.95,.4,0],color=MUTED),Line([-2.25,.4,0],[-.55,.4,0],color=MUTED))
        flow=VGroup(arrow([-5.4,-.65,0],[1.0,0,0],CYAN),formula('I',[-4.9,-1.15,0],29,CYAN,width=.8))
        bar=Rectangle(width=.4,height=.05,color=GOLD,fill_color=GOLD,fill_opacity=.45).move_to([-1.2,-1.675,0])
        target=Rectangle(width=.4,height=2,color=GOLD,fill_color=GOLD,fill_opacity=.45).move_to([-1.2,-.7,0])
        law=formula(r'Q=I^2Rt',[3.1,1.25,0],48,GOLD)
        self.show(heater,wires,flow,bar,law,words('I и R постоянны в течение t',[3.1,-.1,0],24),
                  words('Накопленная теплота',[-3.1,-2.2,0],22,MUTED),run_time=1.2);self.intro(0)
        self.act(0,heater[0].animate.set_fill(ROSE,opacity=.5).set_stroke(ROSE),Transform(bar,target))
        self.show(formula('Q',[-1.2,.8,0],31,GOLD,width=.8),formula(r'[Q]=\mathrm{J}',[3.1,-1.45,0],37),
                  words('Q — теплота; q — заряд',[3.1,-2.45,0],23,MUTED),run_time=1.2);self.result(0)

        self.beat(1)
        ohm=formula(r'I=\frac UR',[-3.1,1.25,0],47,CYAN)
        heat=formula(r'Q=I^2Rt',[3.1,1.25,0],47)
        middle=formula(r'Q=\frac{U^2}{R^2}Rt',[0,-.25,0],47,width=11.5)
        final=formula(r'Q=\frac{U^2}{R}t',[0,-1.85,0],49,GOLD,width=11.5)
        self.show(ohm,heat,run_time=1.2);self.intro(1)
        self.act(1,Write(middle))
        self.show(final,words('Омический участок с постоянными U и R',[0,-2.7,0],23,MUTED,width=11.5),run_time=1.2);self.result(1)

        self.beat(2)
        ohm=formula(r'R=\frac UI',[-3.1,1.25,0],47,CYAN)
        heat=formula(r'Q=I^2Rt',[3.1,1.25,0],47)
        middle=formula(r'Q=I^2\frac UI t',[0,-.25,0],47,width=11.5)
        final=formula(r'Q=I^2Rt=\frac{U^2}{R}t=UIt',[0,-1.85,0],43,GOLD,width=11.5)
        self.show(ohm,heat,run_time=1.2);self.intro(2)
        self.act(2,Write(middle))
        self.show(final,words('Одна и та же теплота резистивного участка',[0,-2.7,0],23,MUTED,width=11.5),run_time=1.2);self.result(2)
