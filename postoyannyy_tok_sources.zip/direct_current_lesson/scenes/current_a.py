"""Current, resistance, Ohm's law and meters: source PDF pages 2–5."""
from current_style import *


def resistor(center=(-3.1,0,0),width=1.5,label='R'):
    x,y,_=center
    body=Rectangle(width=width,height=.55,color=INK,stroke_width=2).move_to(center)
    leads=VGroup(Line([x-width/2-.75,y,0],[x-width/2,y,0],color=MUTED),
                 Line([x+width/2,y,0],[x+width/2+.75,y,0],color=MUTED))
    name=formula(label,[x,y+.68,0],29,width=2)
    return VGroup(body,leads,name)


def instrument(letter,center,radius=.35):
    return VGroup(Circle(radius=radius,color=CYAN,stroke_width=2).move_to(center),
                  formula(letter,center,28,CYAN,width=.65))


def wire_model():
    body=RoundedRectangle(width=5.0,height=1.6,corner_radius=.12,color=MUTED).move_to([-3.1,0,0])
    ions=VGroup(*[Dot([x,.48,0],radius=.07,color=ROSE) for x in [-5,-4.1,-3.2,-2.3]])
    electrons=VGroup(*[charge('−',[x,-.35,0],.14) for x in [-5.0,-4.1,-3.2,-2.3]])
    return body,ions,electrons


class CurrentAndDirection(CurrentScene):
    chapter_id=1
    def chapter(self):
        self.beat(0)
        body,ions,electrons=wire_model()
        e_arrow=arrow([-1.0,1.5,0],[-4.2,0,0],GOLD)
        e_name=formula(r'\vec E',[-3.1,2.03,0],30,GOLD,width=1.5)
        given=words(['Электрический ток','Упорядоченное движение зарядов'],[3.1,1.0,0],25)
        self.show(body,ions,electrons,e_arrow,e_name,given,run_time=1.2)
        self.intro(0)
        self.act(0,electrons.animate.shift(RIGHT*.8))
        self.show(words(['В металле носители — электроны','Ионы остаются в узлах решётки'],[3.1,-.55,0],23,CYAN),
                  words('Показана направленная составляющая движения',[-3.1,-1.55,0],20,MUTED,width=5.5),run_time=1.2)
        self.result(0)

        self.beat(1)
        given=words(['Условное направление тока','По движению положительного заряда'],[3.1,1.1,0],25)
        electron=charge('−',[-5.0,-.65,0],.21)
        electron_arrow=arrow([-4.5,-.65,0],[3.1,0,0],CYAN)
        electron_name=words('Электроны',[-3.1,-1.3,0],23,CYAN)
        i_arrow=arrow([-.9,.85,0],[-4.4,0,0],GOLD)
        i_name=formula('I',[-3.1,1.5,0],34,GOLD,width=1)
        self.show(given,electron,electron_name,run_time=1.2)
        self.intro(1)
        self.act(1,Create(electron_arrow),Create(i_arrow),FadeIn(i_name))
        self.show(words(['В металле I направлен','против дрейфа электронов'],[3.1,-.6,0],25,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        boxes=VGroup(*[Rectangle(width=1.5,height=1.45,color=GRID).move_to([x,.2,0]) for x in [-4.9,-3.1,-1.3]])
        times=VGroup(*[formula(r'\Delta t',[x,-1.05,0],28,MUTED,width=1.3) for x in [-4.9,-3.1,-1.3]])
        equal=VGroup(*[words('q',[x,.2,0],34,CYAN,width=1.2) for x in [-4.9,-3.1,-1.3]])
        given=words(['Постоянный ток','Равные промежутки времени'],[3.1,1.0,0],27)
        self.show(boxes,times,given,run_time=1.2)
        self.intro(2)
        self.act(2,LaggedStart(*[FadeIn(q) for q in equal],lag_ratio=.3))
        self.show(formula(r'I=\mathrm{const}',[3.1,-.35,0],41,GOLD),
                  words('Переносится одинаковый заряд',[3.1,-1.65,0],23,MUTED),run_time=1.2)
        self.result(2)


class CurrentChargeGraphs(CurrentScene):
    chapter_id=2
    def chapter(self):
        self.beat(0)
        body=RoundedRectangle(width=5,height=1.45,corner_radius=.12,color=MUTED).move_to([-3.1,.2,0])
        section=Line([-2.9,-.7,0],[-2.9,1.1,0],color=GOLD,stroke_width=3)
        electrons=VGroup(*[charge('−',[x,y,0],.13) for x,y in [(-5.1,.6),(-4.75,-.15),(-4.4,.3),(-4.0,-.15)]])
        label=words('Поперечное сечение',[-3.1,-1.35,0],23,GOLD)
        e=formula(r'e\approx1.6\cdot10^{-19}\ \mathrm{C}',[3.1,1.2,0],35,CYAN)
        law=formula(r'q=Ne',[3.1,-.15,0],45)
        self.show(body,section,electrons,label,e,run_time=1.2)
        self.intro(0)
        self.act(0,electrons.animate.shift(RIGHT*2.5),Write(law))
        self.show(words(['N — число прошедших электронов','q — модуль перенесённого заряда'],[3.1,-1.65,0],22,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        q=formula(r'q=Ne',[-3.1,.75,0],44,CYAN)
        given=words(['За время t через сечение','переносится заряд q'],[-3.1,-.8,0],25)
        initial=formula(r'I=\frac qt',[3.1,1.0,0],48)
        derived=formula(r'I=\frac{Ne}{t}',[3.1,-.3,0],44,GOLD)
        self.show(q,given,initial,run_time=1.2)
        self.intro(1)
        self.act(1,Write(derived))
        self.show(formula(r'1\ \mathrm{A}=1\ \mathrm{C/s}',[3.1,-1.85,0],33),run_time=1.2)
        self.result(1)

        self.beat(2)
        ax,frame=chart(center=(-3.1,.15,0),width=4.7,height=3.0,x_range=(0,5,1),y_range=(0,4,1),x_label='t',y_label='I')
        points=[ax.c2p(0,0),ax.c2p(1.3,3),ax.c2p(3.4,3),ax.c2p(4.7,0)]
        graph=VMobject(color=CYAN,stroke_width=3).set_points_as_corners(points)
        area=Polygon(*points,stroke_width=0,fill_color=CYAN,fill_opacity=.23)
        given=words(['График силы тока I(t)','Ток меняется со временем'],[3.1,1.2,0],26)
        self.show(frame,given,run_time=1.2)
        self.intro(2)
        self.act(2,Create(graph))
        self.show(area,words(['Заряд численно равен','площади под графиком'],[3.1,-.35,0],27,GOLD),
                  words('А · с = Кл',[3.1,-1.85,0],25,MUTED),run_time=1.2)
        self.result(2)

        self.beat(3)
        ax,frame=chart(center=(-3.1,.15,0),width=4.7,height=3.0,x_range=(0,5,1),y_range=(0,4,1),x_label='t',y_label='I')
        origin=ax.c2p(0,0);end=ax.c2p(4,3);base=ax.c2p(4,0)
        graph=Line(origin,end,color=CYAN,stroke_width=3)
        area=Polygon(origin,end,base,stroke_width=0,fill_color=CYAN,fill_opacity=.23)
        bounds=DashedLine(end,base,color=MUTED)
        tags=VGroup(formula('t_1',base+DOWN*.35,24,MUTED,width=.7),
                    formula('I_1',ax.c2p(0,3)+LEFT*.35,24,MUTED,width=.7))
        given=words(['Линейный рост от нуля','Выбран интервал от 0 до t₁'],[3.1,1.1,0],25)
        self.show(frame,given,run_time=1.2)
        self.intro(3)
        self.act(3,Create(graph),Create(bounds),FadeIn(tags))
        self.show(area,formula(r'q=\frac{I_1t_1}{2}',[3.1,-.35,0],43,GOLD),
                  words('Площадь треугольника',[3.1,-1.85,0],24,MUTED),run_time=1.2)
        self.result(3)


class ResistanceGeometry(CurrentScene):
    chapter_id=3
    def chapter(self):
        self.beat(0)
        r=resistor()
        given=words(['Сопротивление проводника','Материал и геометрия'],[3.1,1.25,0],26)
        law=formula(r'R=\frac{\rho l}{S}',[3.1,-.1,0],47)
        self.show(r,given,run_time=1.2)
        self.intro(0)
        self.act(0,Write(law))
        self.show(words(['R — Ом; ρ — Ом · м','l — м; S — м²'],[3.1,-1.65,0],24,MUTED),
                  words('Однородный проводник, постоянное сечение',[-3.1,-1.65,0],21,MUTED,width=5.5),run_time=1.2)
        self.result(0)

        self.beat(1)
        body=Rectangle(width=3.0,height=.8,color=CYAN,stroke_width=3).move_to([-3.95,.3,0])
        longer=Rectangle(width=4.7,height=.8,color=CYAN,stroke_width=3).move_to([-3.1,.3,0])
        length=DoubleArrow([-5.45,-.6,0],[-2.45,-.6,0],buff=0,color=GOLD)
        length_end=DoubleArrow([-5.45,-.6,0],[-.75,-.6,0],buff=0,color=GOLD)
        tag=formula('l',[-3.1,-1.15,0],31,GOLD,width=1)
        law=formula(r'R=\frac{\rho l}{S}',[3.1,1.05,0],45)
        given=words(['Один материал','Площадь сечения S постоянна'],[3.1,-.2,0],24,MUTED)
        self.show(body,length,tag,law,given,run_time=1.2)
        self.intro(1)
        self.act(1,Transform(body,longer),Transform(length,length_end))
        self.show(words('l ↑  ⇒  R ↑',[3.1,-1.75,0],30,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        body=Rectangle(width=4.7,height=.65,color=CYAN,stroke_width=3).move_to([-3.1,.3,0])
        wider=Rectangle(width=4.7,height=1.4,color=CYAN,stroke_width=3).move_to([-3.1,.3,0])
        section=Ellipse(width=.35,height=.65,color=GOLD,stroke_width=2).move_to([-5.45,.3,0])
        wider_section=Ellipse(width=.35,height=1.4,color=GOLD,stroke_width=2).move_to([-5.45,.3,0])
        s=formula('S',[-3.1,-1.15,0],32,GOLD,width=1)
        law=formula(r'R=\frac{\rho l}{S}',[3.1,1.05,0],45)
        given=words(['Один материал','Длина l постоянна'],[3.1,-.2,0],24,MUTED)
        self.show(body,section,s,law,given,run_time=1.2)
        self.intro(2)
        self.act(2,Transform(body,wider),Transform(section,wider_section))
        self.show(words('S ↑  ⇒  R ↓',[3.1,-1.75,0],30,GOLD),run_time=1.2)
        self.result(2)


class TemperatureResistance(CurrentScene):
    chapter_id=4
    def chapter(self):
        self.beat(0)
        ions=VGroup(*[Dot([x,y,0],radius=.065,color=ROSE) for x in [-4.7,-3.1,-1.5] for y in [-.65,.75]])
        motion=VGroup(*[Circle(radius=.12,color=GOLD,stroke_width=1.4).move_to(p.get_center()) for p in ions])
        frame=Rectangle(width=4.7,height=2.6,color=GRID).move_to([-3.1,.05,0])
        given=words(['Нагрев обычного металла','Колебания решётки усиливаются'],[3.1,1.05,0],25)
        self.show(frame,ions,motion,given,run_time=1.2)
        self.intro(0)
        self.act(0,*[c.animate.scale(2.1) for c in motion])
        self.show(words('T ↑  ⇒  R ↑',[3.1,-.45,0],31,GOLD),
                  words('При неизменных размерах проводника',[3.1,-1.8,0],22,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        base=Line([-4.5,-1.25,0],[-1.7,-1.25,0],color=MUTED)
        bar=Rectangle(width=1.25,height=2.25,color=CYAN,fill_color=CYAN,fill_opacity=.35).move_to([-3.1,-.125,0])
        small=Rectangle(width=1.25,height=.85,color=CYAN,fill_color=CYAN,fill_opacity=.35).move_to([-3.1,-.825,0])
        label=formula('R',[-3.1,1.6,0],34,CYAN,width=1)
        given=words(['Охлаждение обычного металла','Сопротивление уменьшается'],[3.1,1.05,0],25)
        self.show(base,bar,label,given,run_time=1.2)
        self.intro(1)
        self.act(1,Transform(bar,small))
        self.show(words(['Малое сопротивление','может оставаться ненулевым'],[3.1,-.5,0],25,CYAN),
                  words('Сверхпроводимость возникает не у всех материалов',[0,-2.35,0],22,MUTED,width=11.5),run_time=1.2)
        self.result(1)

        self.beat(2)
        initial=formula(r'T>T_c:\quad R>0',[-3.1,.8,0],43)
        zero=formula(r'T<T_c:\quad R=0',[-3.1,.8,0],43,CYAN)
        given=words(['Некоторые материалы','Критическая температура Tс'],[3.1,1.1,0],26)
        name=words('Сверхпроводящее состояние',[-3.1,-.65,0],25,CYAN)
        self.show(initial,given,run_time=1.2)
        self.intro(2)
        self.act(2,Succession(FadeOut(initial),FadeIn(zero)),FadeIn(name))
        self.show(words(['Нулевое сопротивление','Отдельное состояние материала'],[3.1,-.65,0],24,MUTED),run_time=1.2)
        self.result(2)


class OhmRheostat(CurrentScene):
    chapter_id=5
    def chapter(self):
        self.beat(0)
        r=resistor()
        u=DoubleArrow([-5.3,-1.2,0],[-.9,-1.2,0],buff=0,color=CYAN)
        u_label=formula('U',[-3.1,-1.8,0],32,CYAN,width=1)
        i=arrow([-5.2,1.25,0],[4.1,0,0],GOLD)
        i_label=formula('I',[-3.1,1.85,0],32,GOLD,width=1)
        given=words(['Омический участок','Температура и R постоянны'],[3.1,1.2,0],25)
        law=formula(r'I=\frac UR',[3.1,-.15,0],49)
        self.show(r,u,u_label,i,i_label,given,run_time=1.2)
        self.intro(0)
        self.act(0,Write(law))
        self.show(words('При постоянном R: U ↑  ⇒  I ↑',[3.1,-1.75,0],24,GOLD),run_time=1.2)
        self.result(0)

        self.beat(1)
        r=resistor(label='R_1')
        old_label=r[-1]
        new_label=formula('R_2',old_label.get_center(),29,width=2)
        current=arrow([-5.2,1.3,0],[4.1,0,0],GOLD)
        shorter=arrow([-5.2,1.3,0],[2.3,0,0],GOLD)
        i=formula('I',[-3.1,1.95,0],33,GOLD,width=1)
        law=formula(r'I=\frac UR',[3.1,1.1,0],45)
        given=words(['Напряжение U постоянно','Сопротивление увеличивается'],[3.1,-.15,0],24)
        self.show(r,current,i,law,given,run_time=1.2)
        self.intro(1)
        self.act(1,Transform(current,shorter),Succession(FadeOut(old_label),FadeIn(new_label)))
        self.show(formula(r'R_2>R_1\quad\Rightarrow\quad I_2<I_1',[3.1,-1.6,0],33,CYAN),run_time=1.2)
        self.result(1)

        self.beat(2)
        body=Rectangle(width=3.8,height=.45,color=INK).move_to([-3.1,0,0])
        input_wire=Line([-5.8,0,0],[-5.0,0,0],color=MUTED)
        active=Line([-5.0,0,0],[-3.8,0,0],color=CYAN,stroke_width=6)
        active_end=Line([-5.0,0,0],[-1.8,0,0],color=CYAN,stroke_width=6)
        contact=arrow([-3.8,1.15,0],[0,-.95,0],GOLD)
        contact_end=arrow([-1.8,1.15,0],[0,-.95,0],GOLD)
        output_wire=Line([-3.8,1.15,0],[-.65,1.15,0],color=MUTED)
        output_end=Line([-1.8,1.15,0],[-.65,1.15,0],color=MUTED)
        tag=words('Включённый участок',[-3.1,-1.1,0],23,CYAN)
        given=words(['Реостат','Подключены левый вывод и ползунок'],[3.1,1.0,0],24)
        self.show(body,input_wire,active,contact,output_wire,tag,given,run_time=1.2)
        self.intro(2)
        self.act(2,Transform(active,active_end),Transform(contact,contact_end),Transform(output_wire,output_end))
        self.show(words(['Ползунок вправо: l ↑','Следовательно, R ↑'],[3.1,-.7,0],27,GOLD),run_time=1.2)
        self.result(2)


class MeasuringInstruments(CurrentScene):
    chapter_id=6
    def chapter(self):
        self.beat(0)
        r=resistor([-3.1,-.65,0])
        leads=VGroup(Line([-5.5,-.65,0],[-4.6,-.65,0],color=MUTED),
                     Line([-1.6,-.65,0],[-.7,-.65,0],color=MUTED))
        nodes=VGroup(Dot([-5.1,-.65,0],radius=.055,color=GOLD),Dot([-1.1,-.65,0],radius=.055,color=GOLD))
        branch=VGroup(VMobject(color=MUTED).set_points_as_corners([[-5.1,-.65,0],[-5.1,1.05,0],[-3.45,1.05,0]]),
                      VMobject(color=MUTED).set_points_as_corners([[-2.75,1.05,0],[-1.1,1.05,0],[-1.1,-.65,0]]))
        meter=instrument('V',[-3.1,1.05,0])
        given=words(['Вольтметр измеряет напряжение','Подключается параллельно'],[3.1,1.0,0],24)
        self.show(r,leads,nodes,given,run_time=1.2)
        self.intro(0)
        self.act(0,Create(branch),FadeIn(meter))
        self.show(formula(r'R_V\to\infty,\quad I_V=0',[3.1,-.35,0],35,CYAN),
                  words('Идеальный прибор не нагружает участок',[3.1,-1.75,0],21,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        r=resistor([-2.1,-.2,0],width=1.35)
        leads=VGroup(Line([-5.7,-.2,0],[-5.0,-.2,0],color=MUTED),
                     Line([-4.3,-.2,0],[-3.525,-.2,0],color=MUTED),
                     Line([-.675,-.2,0],[-.5,-.2,0],color=MUTED))
        meter=instrument('A',[-4.65,-.2,0])
        i=arrow([-5.35,1.2,0],[4.2,0,0],GOLD)
        i_name=formula('I',[-3.1,1.85,0],32,GOLD,width=1)
        given=words(['Амперметр измеряет силу тока','Включается последовательно'],[3.1,1.0,0],24)
        self.show(r,leads,given,run_time=1.2)
        self.intro(1)
        self.act(1,FadeIn(meter),Create(i),FadeIn(i_name))
        self.show(formula(r'R_A=0,\quad U_A=0',[3.1,-.35,0],36,CYAN),
                  words('Идеальный прибор не добавляет сопротивления',[3.1,-1.75,0],21,MUTED),run_time=1.2)
        self.result(1)

        self.beat(2)
        r=resistor([-2.7,-.45,0],width=1.4)
        ammeter=instrument('A',[-5.15,-.45,0],.3)
        main=VGroup(Line([-5.8,-.45,0],[-5.45,-.45,0],color=MUTED),
                    Line([-4.85,-.45,0],[-4.15,-.45,0],color=MUTED),
                    Line([-1.25,-.45,0],[-.6,-.45,0],color=MUTED))
        branch=VGroup(VMobject(color=MUTED).set_points_as_corners([[-4.0,-.45,0],[-4.0,1.2,0],[-3.05,1.2,0]]),
                      VMobject(color=MUTED).set_points_as_corners([[-2.35,1.2,0],[-1.35,1.2,0],[-1.35,-.45,0]]))
        voltmeter=instrument('V',[-2.7,1.2,0])
        given=words(['Совместное измерение','Приборы считаем идеальными'],[3.1,1.0,0],25)
        self.show(r,ammeter,main,given,run_time=1.2)
        self.intro(2)
        self.act(2,Create(branch),FadeIn(voltmeter))
        self.show(formula(r'U_V=U_R,\quad I_A=I_R',[3.1,-.35,0],34,GOLD),
                  words('Ток через идеальный вольтметр равен нулю',[0,-2.1,0],22,MUTED,width=11.5),run_time=1.2)
        self.result(2)
