"""Power, electrolytes, doped semiconductors and ideal diode: source pp11–14."""
from current_style import *


def c_resistor(center=(-3.1,.4,0)):
    x,y,_=center
    body=Rectangle(width=2.6,height=.8,color=INK,stroke_width=2).move_to(center)
    leads=VGroup(Line([x-2,y,0],[x-1.3,y,0],color=MUTED),Line([x+1.3,y,0],[x+2,y,0],color=MUTED))
    name=formula('R',(x,y+.85,0),31,MUTED,width=1)
    return VGroup(body,leads,name),body


def c_ion(name,pos,color):
    ring=Circle(radius=.24,color=color,fill_color=color,fill_opacity=.14).move_to(pos)
    label=formula(name,pos,20,color,width=.43)
    return VGroup(ring,label)


def c_bath(labels=False):
    vessel=VMobject(color=MUTED,stroke_width=2).set_points_as_corners([[-5.1,.5,0],[-5.1,-1.75,0],[-1.3,-1.75,0],[-1.3,.5,0]])
    liquid=Rectangle(width=3.65,height=1.55,stroke_width=0,fill_color=CYAN,fill_opacity=.1).move_to([-3.2,-.9,0])
    rods=VGroup(Line([-4.45,-1.25,0],[-4.45,.6,0],color=ROSE,stroke_width=7),Line([-1.95,-1.25,0],[-1.95,.6,0],color=CYAN,stroke_width=7))
    wire=VGroup(VMobject(color=MUTED).set_points_as_corners([[-4.45,.6,0],[-4.45,2.1,0],[-3.45,2.1,0]]),
                VMobject(color=MUTED).set_points_as_corners([[-2.95,2.1,0],[-.85,2.1,0],[-.85,1.18,0]]),
                VMobject(color=MUTED).set_points_as_corners([[-.85,.62,0],[-.85,.6,0],[-1.95,.6,0]]))
    source=VGroup(Line([-3.45,1.8,0],[-3.45,2.4,0],color=ROSE,stroke_width=3),Line([-2.95,1.92,0],[-2.95,2.28,0],color=CYAN,stroke_width=3))
    meter=Circle(radius=.28,color=INK,stroke_width=2).move_to([-.85,.9,0])
    meter_name=txt('A',18).move_to([-1.35,.9,0])
    needle=Line([-.85,.79,0],[-1.0,1.02,0],color=GOLD,stroke_width=2)
    diagram=VGroup(vessel,liquid,rods,wire,source,meter,meter_name)
    if labels:
        diagram.add(words('Анод (+)',(-5.1,1.1,0),17,ROSE,width=1.1),words('Катод (−)',(-2.65,1.1,0),17,CYAN,width=1.1))
    return diagram,needle


def c_lattice(element='Si',missing=False):
    center=np.array([-3.2,0,0]);neighbors=[center+v for v in (LEFT*1.6,RIGHT*1.6,UP*1.6,DOWN*1.6)]
    atoms=VGroup(*[VGroup(Circle(radius=.33,color=CYAN,fill_color=CYAN,fill_opacity=.08).move_to(p),formula('Si',p,23,CYAN,width=.55)) for p in neighbors])
    color=INK if element=='Si' else GOLD
    atom=VGroup(Circle(radius=.36,color=color,fill_color=color,fill_opacity=.1).move_to(center),formula(element,center,25,color,width=.58))
    bonds=VGroup();electrons=VGroup();vacancy=None
    for i,p in enumerate(neighbors):
        v=p-center;u=v/np.linalg.norm(v);mid=center+v/2;perp=np.array([-u[1],u[0],0])
        line=Line(center+u*.39,p-u*.36,color=MUTED,stroke_width=2)
        bonds.add(line)
        for j in (-1,1):
            pos=mid+perp*.12*j
            if missing and i==1 and j==1:
                vacancy=Circle(radius=.13,color=ROSE,stroke_width=2).move_to(pos)
            else:electrons.add(Dot(pos,radius=.05,color=CYAN))
    return atoms,atom,bonds,electrons,vacancy


def c_diode(center=(-3.2,.2,0),names=True):
    x,y,_=center
    triangle=Polygon([x-.55,y-.46,0],[x-.55,y+.46,0],[x+.2,y,0],color=INK,stroke_width=2,fill_opacity=0)
    bar=Line([x+.25,y-.52,0],[x+.25,y+.52,0],color=GOLD,stroke_width=3)
    leads=VGroup(Line([x-2,y,0],[x-.55,y,0],color=MUTED),Line([x+.25,y,0],[x+2,y,0],color=MUTED))
    result=VGroup(triangle,bar,leads)
    if names:
        result.add(words('Анод (p)',(x-1.45,y+.88,0),23,ROSE,width=2),words('Катод (n)',(x+1.35,y+.88,0),23,CYAN,width=2))
    return result


class ThermalPower(CurrentScene):
    chapter_id=12
    def chapter(self):
        self.beat(0)
        circuit,body=c_resistor()
        q=formula('Q',(-3.1,-.55,0),34,ROSE,width=1)
        definition=formula(r'P=\frac Qt',(3.1,1.0,0),52,GOLD)
        clock=words('За время t',(-3.1,-1.65,0),25,MUTED)
        heat=VGroup(*[Arc(radius=.2,start_angle=0,angle=PI,color=ROSE).rotate(PI/2).move_to([x,1.8,0]) for x in (-4,-3.1,-2.2)])
        self.show(circuit,q,clock,definition,run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(*[Create(h) for h in heat],lag_ratio=.3))
        self.show(formula(r'1\ \mathrm W=1\ \mathrm{J/s}',(3.1,-.35,0),37),words('Мощность: теплота за единицу времени',(3.1,-1.65,0),23,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        heat=formula(r'Q=I^2Rt',(-3.1,1.1,0),47,ROSE)
        time=words('Делим количество теплоты на время',(-3.1,-.3,0),24,MUTED)
        definition=formula(r'P=\frac Qt',(3.1,1.1,0),43)
        power=formula(r'P=I^2R',(3.1,-.35,0),47,GOLD)
        self.show(heat,time,definition,words('Постоянные I и R',(0,-2.45,0),23,MUTED,width=11.5),run_time=1.2)
        self.intro(1)
        self.act(1,Write(power))
        self.show(words('При одном R: мощность пропорциональна I²',(0,-1.6,0),25,CYAN,width=11.5),run_time=1.2)
        self.result(1)

        self.beat(2)
        initial=formula(r'P=I^2R',(-3.1,1.2,0),47)
        ohm=formula(r'U=IR',(-3.1,-.15,0),43,CYAN)
        by_u=formula(r'P=\frac{U^2}{R}',(3.1,1.2,0),44,GOLD)
        by_ui=formula(r'P=UI',(3.1,-.3,0),45,GOLD)
        self.show(initial,ohm,words(['Омический участок','Электрическая работа переходит в тепло'],(0,-2.15,0),23,MUTED,width=11.5),run_time=1.2)
        self.intro(2)
        self.act(2,Succession(Write(by_u),Write(by_ui)))
        self.show(words('Три записи одной тепловой мощности',(0,-1.25,0),26,INK,width=11.5),run_time=1.2)
        self.result(2)


class ElectrolyteCurrent(CurrentScene):
    chapter_id=13
    def chapter(self):
        self.beat(0)
        bath,needle=c_bath()
        water=words('Дистиллированная вода',(-3.2,-2.2,0),24,CYAN,width=5.3)
        definition=words(['Электролит проводит ток','благодаря подвижным ионам'],(3.1,1.15,0),26)
        result=formula(r'I\approx0',(3.1,-.3,0),47,GOLD)
        self.show(bath,needle,water,definition,run_time=1.2)
        self.intro(0)
        self.act(0,Write(result))
        self.show(words(['В опыте заметного тока нет','Это не абсолютный нуль проводимости'],(3.1,-1.65,0),22,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        bath,needle=c_bath()
        salt=VGroup(*[Dot([x,y,0],radius=.055,color=INK) for x,y in [(-3.4,.65),(-3.2,.7),(-3.0,.65),(-3.3,.5),(-3.1,.5)]])
        ions=VGroup(c_ion(r'Na^+',[-3.9,-.6,0],ROSE),c_ion(r'Cl^-',[-2.75,-.65,0],CYAN),c_ion(r'Na^+',[-2.9,-1.3,0],ROSE),c_ion(r'Cl^-',[-3.9,-1.35,0],CYAN))
        dissolved=formula(r'NaCl\longrightarrow Na^++Cl^-',(3.1,.1,0),34)
        self.show(bath,needle,salt,words('NaCl: растворяем соль',(3.1,1.55,0),27),words('Дожидаемся полного растворения',(-3.2,-2.2,0),22,MUTED,width=5.3),run_time=1.2)
        self.intro(1)
        tilted=Line([-.85,.79,0],[-.7,1.04,0],color=GOLD,stroke_width=2)
        self.act(1,Succession(salt.animate.shift(DOWN*1.3),AnimationGroup(FadeOut(salt),FadeIn(ions),Transform(needle,tilted),lag_ratio=0)))
        self.show(dissolved,words(['Ионы появились в растворе','При подключении цепи I > 0'],(3.1,-1.4,0),24,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        bath,needle=c_bath(labels=True)
        needle.put_start_and_end_on([-.85,.79,0],[-.7,1.04,0])
        # Separate horizontal lanes keep both species and labels distinct throughout.
        na=c_ion(r'Na^+',[-3.9,-.45,0],ROSE)
        cl=c_ion(r'Cl^-',[-2.7,-1.2,0],CYAN)
        direction=arrow([-4.05,-.1,0],[1.65,0,0],GOLD)
        self.show(bath,needle,na,cl,direction,words(['Na⁺ → катод (−)','Cl⁻ → анод (+)'],(3.1,1.0,0),28),run_time=1.2)
        self.intro(2)
        self.act(2,na.animate.move_to([-2.22,-.45,0]),cl.animate.move_to([-4.18,-1.2,0]))
        self.show(words(['Положительные и отрицательные ионы','вместе переносят электрический заряд'],(3.1,-1.05,0),23,GOLD),words('Показано движение к электродам',(-3.2,-2.3,0),22,MUTED,width=5.3),run_time=1.2)
        self.result(2)


class DonorConduction(CurrentScene):
    chapter_id=14
    def chapter(self):
        self.beat(0)
        atoms,atom,bonds,electrons,_=c_lattice()
        self.show(atoms,atom,words(['Кремний Si','Четыре валентных электрона'],(3.1,1.1,0),27),run_time=1.2)
        self.intro(0)
        self.act(0,LaggedStart(Create(bonds),FadeIn(electrons),lag_ratio=.3))
        self.show(words(['В модели показаны четыре связи','с соседними атомами'],(3.1,-.75,0),24,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        atoms,atom,bonds,electrons,_=c_lattice('P')
        extra=charge('−',[-2.63,.65,0],.15)
        route=ArcBetweenPoints(extra.get_center(),[-.9,1.95,0],angle=-PI/5)
        self.show(atoms,atom,bonds,electrons,extra,words(['Примесь фосфора P','Пять валентных электронов','Четыре участвуют в связях'],(3.1,1.0,0),25),run_time=1.2)
        self.intro(1)
        self.act(1,MoveAlongPath(extra,route))
        self.show(words(['Пятый электрон может стать подвижным','P — донорная примесь'],(3.1,-1.25,0),23,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        block=Rectangle(width=4.9,height=2.25,color=MUTED,stroke_width=2).move_to([-3.2,0,0])
        carriers=VGroup(*[charge('−',[x,y,0],.16) for x,y in [(-4.25,.55),(-3.25,0),(-2.25,-.55)]])
        field=arrow([-5.1,1.6,0],[3.8,0,0],GOLD)
        e=formula('E',(-3.2,2.05,0),29,GOLD,width=1)
        current=arrow([-5.1,-1.6,0],[3.8,0,0],ROSE)
        self.show(block,carriers,field,e,words(['n-тип','Основные носители — электроны'],(3.1,1.0,0),27),run_time=1.2)
        self.intro(2)
        self.act(2,carriers.animate.shift(LEFT*.85),GrowArrow(current))
        self.show(formula('I',(-3.2,-2.05,0),29,ROSE,width=1),words(['Дрейф электронов — против E','Условный ток — вдоль E','Образец в целом нейтрален'],(3.1,-1.0,0),23,MUTED),run_time=1.2)
        self.result(2)


class HoleConduction(CurrentScene):
    chapter_id=15
    def chapter(self):
        self.beat(0)
        atoms,atom,bonds,electrons,vacancy=c_lattice('Al',missing=True)
        self.show(atoms,atom,bonds,electrons,words(['Примесь алюминия Al','Три валентных электрона'],(3.1,1.2,0),27),run_time=1.2)
        self.intro(0)
        self.act(0,Create(vacancy))
        self.show(words(['В одной связи не хватает электрона','Дырка — вакантное состояние'],(3.1,-.65,0),24,ROSE),words('Атомные узлы остаются на месте',(-3.2,-2.3,0),22,MUTED,width=5.3),run_time=1.2)
        self.result(0)

        self.beat(1)
        positions=[np.array([x,0,0]) for x in (-4.9,-3.75,-2.6,-1.45)]
        sites=VGroup(*[Circle(radius=.28,color=MUTED,stroke_width=1.6).move_to(p) for p in positions])
        electrons=VGroup(*[Dot(p,radius=.09,color=CYAN) for p in positions[1:]])
        vacancy=Circle(radius=.34,color=ROSE,stroke_width=3).move_to(positions[0])
        self.show(sites,electrons,vacancy,words('Места электронов в связях',(-3.2,1.3,0),25,MUTED,width=5.3),words(['Электрон занимает пустое место','Новое пустое место — там, откуда он ушёл'],(3.1,1.05,0),24),run_time=1.2)
        self.intro(1)
        steps=[]
        for i in range(3):
            steps.append(AnimationGroup(electrons[i].animate.move_to(positions[i]),vacancy.animate.move_to(positions[i+1]),lag_ratio=0))
        self.act(1,Succession(*steps))
        self.show(words(['Электроны переместились влево','Дырка переместилась вправо'],(3.1,-1.0,0),25,GOLD),words('Дырка — не перемещающийся положительный атом',(-3.2,-1.7,0),21,MUTED,width=5.4),run_time=1.2)
        self.result(1)

        self.beat(2)
        block=Rectangle(width=4.9,height=2.25,color=MUTED,stroke_width=2).move_to([-3.2,0,0])
        holes=VGroup(*[Circle(radius=.17,color=ROSE,stroke_width=3).move_to([x,y,0]) for x,y in [(-4.9,.55),(-3.9,0),(-2.9,-.55)]])
        field=arrow([-5.1,1.6,0],[3.8,0,0],GOLD)
        current=arrow([-5.1,-1.6,0],[3.8,0,0],ROSE)
        self.show(block,holes,field,formula('E',(-3.2,2.05,0),29,GOLD,width=1),words(['p-тип','Основные носители — дырки'],(3.1,1.05,0),27),run_time=1.2)
        self.intro(2)
        self.act(2,holes.animate.shift(RIGHT*.85),GrowArrow(current))
        self.show(formula('I',(-3.2,-2.05,0),29,ROSE,width=1),words(['Дырки перемещаются вдоль E','Так же направлен условный ток','p-тип не означает заряд всего образца'],(3.1,-1.0,0),23,MUTED),run_time=1.2)
        self.result(2)


class DiodeDirection(CurrentScene):
    chapter_id=16
    def chapter(self):
        self.beat(0)
        p=Rectangle(width=2,height=2.05,color=ROSE,fill_color=ROSE,fill_opacity=.12).move_to([-4.2,0,0])
        n=Rectangle(width=2,height=2.05,color=CYAN,fill_color=CYAN,fill_opacity=.12).move_to([-2.2,0,0])
        names=VGroup(formula('p',(-4.2,1.5,0),35,ROSE,width=1),formula('n',(-2.2,1.5,0),35,CYAN,width=1))
        boundary=Line([-3.2,-1.05,0],[-3.2,1.05,0],color=GOLD,stroke_width=4)
        symbol=c_diode((3.1,-.35,0))
        self.show(p,n,names,words(['Области с разными','основными носителями'],(3.1,1.8,0),25),words('Тип носителей, не заряд всего образца',(-3.2,-1.8,0),21,MUTED,width=5.2),run_time=1.2)
        self.intro(0)
        self.act(0,Create(boundary),FadeIn(symbol))
        self.show(words('p–n-переход',(-3.2,-2.4,0),25,GOLD),words('Катод обозначен чертой',(3.1,-1.95,0),23,MUTED),run_time=1.2)
        self.result(0)

        self.beat(1)
        symbol=c_diode()
        polarity=VGroup(formula('+',(-5.2,-.65,0),39,ROSE,width=1),formula('-',(-1.2,-.65,0),39,CYAN,width=1))
        flow=arrow([-4.15,2.05,0],[1.8,0,0],ROSE)
        self.show(symbol,polarity,words('Идеальная модель',(3.1,1.7,0),28,GOLD),words('Прямое смещение',(3.1,.6,0),27),words('Диод включён в цепь с нагрузкой',(-3.2,-2.2,0),22,MUTED,width=5.3),run_time=1.2)
        self.intro(1)
        self.act(1,GrowArrow(flow),Write(formula('I',(-3.25,2.48,0),28,ROSE,width=1)))
        self.show(words(['Анод подключён к «+»','Катод подключён к «−»','Идеальный диод открыт'],(3.1,-.75,0),24),formula(r'U_{\mathrm D}=0,\quad R_{\mathrm D}=0',(3.1,-2.15,0),30,GOLD),run_time=1.2)
        self.result(1)

        self.beat(2)
        symbol=c_diode()
        polarity=VGroup(formula('-',(-5.2,-.65,0),39,CYAN,width=1),formula('+',(-1.2,-.65,0),39,ROSE,width=1))
        zero=formula(r'I=0',(3.1,.2,0),47,GOLD)
        self.show(symbol,polarity,words(['Идеальная модель','Обратное смещение'],(3.1,1.55,0),27),words('Анод и катод сохраняют свои названия',(-3.2,-1.65,0),22,MUTED,width=5.3),run_time=1.2)
        self.intro(2)
        self.act(2,Write(zero))
        self.show(formula(r'R_{\mathrm D}\longrightarrow\infty',(3.1,-.85,0),35,GOLD),words(['Идеальный диод закрыт','Пробой здесь не рассматривается'],(3.1,-1.95,0),23,MUTED),run_time=1.2)
        self.result(2)
