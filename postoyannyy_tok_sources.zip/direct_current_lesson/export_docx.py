"""Export a comfortable recording copy with visual cue times (system Python)."""
from pathlib import Path
import json
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from prepare_lesson import stamp
ROOT=Path(__file__).resolve().parent
PREFIX='postoyannyy_tok'

def export():
    plan=json.loads((ROOT/'plan.json').read_text());n=json.loads((ROOT/'narration.json').read_text())
    doc=Document();sec=doc.sections[0];sec.top_margin=sec.bottom_margin=Cm(1.8)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(12)
    normal.paragraph_format.space_after=Pt(8)
    doc.add_heading(plan['title'],0)
    doc.add_paragraph('Текст для самостоятельной озвучки')
    doc.add_paragraph('Названия глав, подписи «Теория»/«Объяснение результата» и время читать не нужно. Между двумя частями каждого эпизода есть пауза для действия. Времена совпадают с визуальным планом; длительности рассчитаны ориентировочно. Читайте естественно — после записи удержания кадров можно подстроить под голос.')
    for c in plan['chapters']:
        doc.add_heading(f"{c['id']:02d}. {c['title']}",1)
        doc.add_paragraph(f"{stamp(c['start'])}–{stamp(c['start']+c['duration'])}. Источник: {c['source']}, с. {c['pages']}.",style='Caption')
        for p in [x for x in n['passages'] if x['chapter']==c['id']]:
            phase='Теория' if p['phase']=='intro' else 'Объяснение результата'
            doc.add_paragraph(f"{stamp(p['start'])}–{stamp(p['end'])} · {phase}",style='Heading 3')
            doc.add_paragraph(p['text'])
    path=ROOT/f'{PREFIX}_tekst.docx';doc.save(path);print(path)
    return path
if __name__=='__main__':export()
