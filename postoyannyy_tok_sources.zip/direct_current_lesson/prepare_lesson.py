"""Derive one silent visual clock and narration cues from the reviewed text."""
from pathlib import Path
import hashlib,json,math,re
ROOT=Path(__file__).resolve().parent

def stamp(t):
    n=int(round(t));h,n=divmod(n,3600);m,s=divmod(n,60)
    return f'{h:02d}:{m:02d}:{s:02d}' if h else f'{m:02d}:{s:02d}'

def words(text):return len(re.findall(r"[\wёЁ]+(?:[-–][\wёЁ]+)*",text))

def prepare():
    chapters=[]
    for name in ('current_a','current_b','current_c'):
        chapters.extend(json.loads((ROOT/'scenes'/f'{name}_beats.json').read_text()))
    assert len(chapters)==16
    assert [c['id'] for c in chapters]==list(range(1,len(chapters)+1))
    elapsed=0;passages=[];total_words=0
    for c in chapters:
        c['start']=elapsed;t=.8
        for i,b in enumerate(c['beats']):
            assert b['intro'].strip() and b['result'].strip()
            b.update(index=i,start=round(t,3))
            b['intro_at']=round(t+3.2,3)
            b['intro_duration']=max(8,math.ceil(words(b['intro'])*60/125+1.5))
            b['action_at']=round(b['intro_at']+b['intro_duration']+.8,3)
            b['action_seconds']=b.get('action_seconds',5)
            b['result_at']=round(b['action_at']+b['action_seconds']+1.6,3)
            b['result_duration']=max(8,math.ceil(words(b['result'])*60/125+1.5))
            t=b['result_at']+b['result_duration']+1.4
            for phase in ('intro','result'):
                start=elapsed+b[phase+'_at'];end=start+b[phase+'_duration']
                passages.append({'chapter':c['id'],'beat':i+1,'phase':phase,'start':round(start,3),'end':round(end,3),'text':b[phase]})
                total_words+=words(b[phase])
        c['duration']=math.ceil(t+1.6);elapsed+=c['duration']
    plan={'title':'Постоянный ток','fps':60,'duration':elapsed,'audio':False,'reading_rate_wpm':125,'chapters':chapters}
    (ROOT/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'narration.json').write_text(json.dumps({'title':plan['title'],'words':total_words,'passages':passages},ensure_ascii=False,indent=2)+'\n')
    text=[plan['title'].upper(),'Текст для самостоятельной озвучки','',
          'В фильме нет звуковой дорожки. Названия глав и отметки времени читать не нужно.',
          'Текст разделён на вступление и объяснение результата. Между ними оставлена пауза для завершения действия на экране.',
          'Времена соответствуют визуальному плану; темп рассчитан ориентировочно. Читайте естественно: после получения записи длительность удержаний можно подстроить под голос.','']
    for c in chapters:
        text.extend([f"{c['id']:02d}. {c['title']} · {stamp(c['start'])}–{stamp(c['start']+c['duration'])}",f"Источник: {c['source']}, с. {c['pages']}.",''])
        for p in (p for p in passages if p['chapter']==c['id']):
            phase='Теория' if p['phase']=='intro' else 'Объяснение результата'
            text.extend([f"[{stamp(p['start'])}–{stamp(p['end'])}] {phase}",p['text'],''])
    (ROOT/'tekst_ozvuchki.txt').write_text('\n'.join(text),encoding='utf-8-sig')
    (ROOT/'narration.md').write_text('\n'.join(text),encoding='utf-8')
    board=['# Раскадровка и соответствие текста сценам','',f"Длительность: {stamp(elapsed)}. Глав: {len(chapters)}. Фрагментов текста: {len(passages)}.",'','| № | Начало | Тема | Источник, страницы |','|---|---|---|---|']
    for c in chapters:board.append(f"| {c['id']} | {stamp(c['start'])} | {c['title']} | {c['source']}, {c['pages']} |")
    for c in chapters:
        board.extend(['',f"## {c['id']:02d}. {c['title']}",'','| Эпизод | Смысл | Теория | Действие | Объяснение результата |','|---|---|---|---|---|'])
        for b in c['beats']:
            t=c['start']
            board.append(f"| {b['index']+1} | {b['caption']} | {stamp(t+b['intro_at'])}–{stamp(t+b['intro_at']+b['intro_duration'])} | {stamp(t+b['action_at'])}–{stamp(t+b['action_at']+b['action_seconds'])} | {stamp(t+b['result_at'])}–{stamp(t+b['result_at']+b['result_duration'])} |")
    (ROOT/'storyboard.md').write_text('\n'.join(board)+'\n')
    print(f"{len(chapters)} chapters, {len(passages)} passages, {total_words} words, {stamp(elapsed)}")
    return plan

if __name__=='__main__':prepare()
