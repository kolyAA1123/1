"""Render source-based silent direct-current chapters on the narration clock."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import subprocess
import sys
from frame_alignment import pad_black_copy

ROOT = Path(__file__).resolve().parent
PREFIX = "postoyannyy_tok"


def load_plan():
    plan = json.loads((ROOT / "plan.json").read_text(encoding="utf-8"))
    assert plan["fps"] == 60
    assert [c["id"] for c in plan["chapters"]] == list(range(1, len(plan["chapters"])+1))
    elapsed = 0
    for chapter in plan["chapters"]:
        assert chapter["start"] == elapsed, chapter["id"]
        assert isinstance(chapter["duration"], int) and chapter["duration"] > 0
        assert [b["index"] for b in chapter["beats"]] == list(range(len(chapter["beats"])))
        elapsed += chapter["duration"]
    assert elapsed == plan["duration"]
    return plan


def probe(path):
    return json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_streams", "-show_format",
        "-show_chapters", "-of", "json", str(path),
    ]))


def chapter_sources(chapter):
    return [ROOT / "current_style.py",
            ROOT / "plan.json", ROOT / "scenes" / chapter["module"]]


def render_chapter(chapter, preview=False, force=False):
    width, height, fps = (854, 480, 15) if preview else (1920, 1080, 60)
    destination = ROOT / "output" / ("preview_chapters" if preview else "chapters")
    destination.mkdir(parents=True, exist_ok=True)
    path = destination / f"{chapter['id']:02d}_{chapter['class']}.mp4"
    log = path.with_suffix(".log")
    sources = chapter_sources(chapter)
    fresh = path.exists() and path.stat().st_mtime > max(p.stat().st_mtime for p in sources)
    if preview:
        # A clip without the accompanying current audit is not a reusable preview.
        audit = ROOT / "output/layout_checks" / f"{chapter['id']:02d}.json"
        fresh = fresh and audit.exists() and audit.stat().st_mtime > max(p.stat().st_mtime for p in sources)
    if force or not fresh:
        print(f"Rendering {chapter['id']:02d} {chapter['class']} ({width}x{height}@{fps})", flush=True)
        cache = ROOT / "output/render_cache" / ("preview" if preview else "final") / f"{chapter['id']:02d}"
        command = [
            sys.executable, "-m", "manim", str(ROOT / "scenes" / chapter["module"]),
            chapter["class"], "-r", f"{width},{height}", "--fps", str(fps),
            "--format", "mp4", "--media_dir", str(cache), "--output_file", str(path),
            "--verbosity", "WARNING", "--progress_bar", "none",
        ]
        env = os.environ.copy()
        env["LESSON_RENDER_PROFILE"] = "preview" if preview else "final"
        if preview:
            env["LESSON_LAYOUT_AUDIT"] = "1"
        else:
            env.pop("LESSON_LAYOUT_AUDIT", None)
        with log.open("w", encoding="utf-8") as output:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"Chapter {chapter['id']}: exit {result.returncode}\n{log.read_text()[-7000:]}")
    report = probe(path)
    # Manim can round fractional holds down by a few frames. Complete the black
    # tail to the exact shared clock; never shift or shorten a spoken segment.
    if not preview:
        stream = next(s for s in report['streams'] if s['codec_type'] == 'video')
        expected = chapter['duration'] * fps
        actual = int(stream['nb_frames'])
        if actual != expected:
            assert abs(actual - expected) <= int(.085 * fps), (path, actual, expected)
            tail = subprocess.check_output([
                'ffmpeg', '-v', 'error', '-sseof', '-0.05', '-i', str(path),
                '-frames:v', '1', '-vf', 'scale=160:90,format=rgb24',
                '-f', 'rawvideo', 'pipe:1',
            ])
            assert tail and sum(tail) / len(tail) < .2, 'Alignment requires an already black ending'
            normalized = path.with_name(path.stem + '.aligned.mp4')
            alignment = None
            if 0 < expected - actual <= 5:
                try:
                    alignment = pad_black_copy(path, normalized, expected - actual)
                except (ValueError, AssertionError, subprocess.SubprocessError, KeyError) as error:
                    print(f'Copy padding unavailable for {chapter["id"]:02d}: {error}', flush=True)
            if alignment is None:
                subprocess.run([
                    'ffmpeg', '-v', 'error', '-y', '-i', str(path), '-an',
                    '-vf', 'tpad=stop_mode=clone:stop_duration=1',
                    '-frames:v', str(expected), '-r', str(fps),
                    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-threads', '2',
                    '-pix_fmt', 'yuv420p', str(normalized),
                ], check=True)
                alignment = {'method': 'black_tail_reencode', 'frames_added': expected - actual}
            else:
                alignment['method'] = 'black_tail_packet_copy'
            audit_path = ROOT / 'output/frame_alignment' / f'{chapter["id"]:02d}.json'
            audit_path.parent.mkdir(parents=True, exist_ok=True)
            audit_path.write_text(json.dumps(alignment, indent=2) + '\n')
            normalized.replace(path)
            report = probe(path)
            print(f'Aligned {chapter["id"]:02d} black tail: {actual} → {expected} frames', flush=True)
    videos = [s for s in report["streams"] if s["codec_type"] == "video"]
    assert len(videos) == 1 and not any(s["codec_type"] == "audio" for s in report["streams"]), path
    video = videos[0]
    numerator, denominator = map(int, video["avg_frame_rate"].split("/"))
    duration = float(report["format"]["duration"])
    tolerance = 1.2 if preview else .15
    assert (video["width"], video["height"]) == (width, height), path
    assert abs(numerator / denominator - fps) < .005, path
    assert abs(duration - chapter["duration"]) <= tolerance, (path, duration, chapter["duration"])
    if not preview:
        assert int(video["nb_frames"]) == chapter["duration"] * fps, (path, video["nb_frames"])
    print(f"Verified {chapter['id']:02d}: {duration:.3f}s", flush=True)
    return chapter["id"], path


def metadata_text(value):
    return str(value).replace("\\", "\\\\").replace("=", "\\=").replace(";", "\\;").replace("#", "\\#").replace("\n", " ")


def assemble(plan, paths):
    output = ROOT / "output"
    concat = output / "concat.txt"
    concat.write_text("".join("file '" + str(p).replace("'", "'\\''") + "'\n" for p in paths), encoding="utf-8")
    metadata = output / "chapters.ffmeta"
    lines = [";FFMETADATA1", "title=" + metadata_text(plan["title"]),
             "artist=Учебная анимация по конспектам пользователя"]
    for chapter in plan["chapters"]:
        lines.extend(["[CHAPTER]", "TIMEBASE=1/1000", f"START={chapter['start'] * 1000}",
                      f"END={(chapter['start'] + chapter['duration']) * 1000}",
                      "title=" + metadata_text(chapter["title"])])
    metadata.write_text("\n".join(lines) + "\n", encoding="utf-8")
    movie = output / f"{PREFIX}_1080p60.mp4"
    subprocess.run([
        "ffmpeg", "-hide_banner", "-loglevel", "warning", "-y",
        "-f", "concat", "-safe", "0", "-i", str(concat),
        "-i", str(metadata),
        "-map", "0:v:0", "-map_metadata", "1", "-map_chapters", "1",
        "-c:v", "copy", "-an",
        "-t", str(plan["duration"]), "-movflags", "+faststart", str(movie),
    ], check=True)
    report = probe(movie)
    videos = [s for s in report["streams"] if s["codec_type"] == "video"]
    audios = [s for s in report["streams"] if s["codec_type"] == "audio"]
    assert len(videos) == 1 and not audios
    video = videos[0]
    assert (video["width"], video["height"], video["avg_frame_rate"]) == (1920, 1080, "60/1")
    assert int(video["nb_frames"]) == plan["duration"] * 60
    assert abs(float(report["format"]["duration"]) - plan["duration"]) <= .06
    assert len(report["chapters"]) == len(plan["chapters"])
    (output / "validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"COMPLETE {movie} ({movie.stat().st_size / 1024**2:.1f} MiB)", flush=True)
    return movie


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preview", action="store_true", help="Render audited draft chapters.")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--jobs", type=int, default=3)
    parser.add_argument("--chapters", nargs="*", type=int)
    parser.add_argument("--no-assemble", action="store_true")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    plan = load_plan()
    valid_ids = {c["id"] for c in plan["chapters"]}
    if args.chapters and set(args.chapters) - valid_ids:
        parser.error("Unknown chapter ID")
    chapters = [c for c in plan["chapters"] if not args.chapters or c["id"] in args.chapters]
    results = {}
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = [pool.submit(render_chapter, chapter, args.preview, args.force) for chapter in chapters]
        for future in as_completed(futures):
            number, path = future.result()
            results[number] = path
    if args.preview:
        print("Draft chapters and layout audits ready. Final assembly uses the exact 60 fps timeline.", flush=True)
    elif len(results) == len(plan["chapters"]) and not args.no_assemble:
        assemble(plan, [results[c["id"]] for c in plan["chapters"]])


if __name__ == "__main__":
    main()
