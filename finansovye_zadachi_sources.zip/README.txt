Откройте терминал в распакованной папке. Установите Python, DejaVu Sans и системные зависимости Manim.

python -m pip install manim==0.20.1 matplotlib
python -m manim -qh --fps 60 finance_lesson.py FinanceLesson

По окончании сценарий с таймкодами окажется рядом с исходниками.
