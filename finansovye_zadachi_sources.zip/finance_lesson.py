import math
from pathlib import Path

from manim import *
from lesson_data import BEATS

from visual_style import equation, BLACK_BG, INK, MUTED, CYAN, GOLD, ROSE, LAVENDER, GRID, txt

config.background_color = BLACK_BG
config.pixel_width,config.pixel_height,config.frame_rate = 1920,1080,60

def sequence(kind):
    if kind in ("annuity","debt","table","official","deposit"):
        levels = {
            "annuity": [210,110,0],
            "debt": [120,80,40,0],
            "table": [100,70,50,10,0],
            "official": [800,680,560,440,320,200,160,120,80,40,0],
            "deposit": [100,130,143],
        }[kind]
        title="Остаток после платежа" if kind!="deposit" else "Сумма после операций"
        left,base,w,h=-6.15,-1.80,5.30,3.38
        upper=max(levels)*1.07
        positions=[np.array([left+w*i/(len(levels)-1),base+h*val/upper,0])
                   for i,val in enumerate(levels)]
        scaffold=VGroup(
            txt(title,23,MUTED).move_to([-3.50,2.03,0]),
            Line([left,base,0],[left+w+.1,base,0],stroke_width=2,color=GRID),
            txt("Периоды",18,MUTED).move_to([-3.5,-2.28,0]),
        )
        line=VMobject(color=CYAN,stroke_width=3.4).set_points_as_corners(positions)
        dots=VGroup(*[Dot(p,radius=.046,color=GOLD) for p in positions])
        indexes=[0,len(levels)//2,len(levels)-1] if len(levels)>3 else list(range(len(levels)))
        values=VGroup(*[txt(str(levels[i]),17,MUTED).next_to(positions[i],UP,buff=.12) for i in indexes])
        return scaffold, [line,dots,values]
    xs=[-6.03,-3.5,-.99]
    headings=("Исходная","Процент","Новая") if kind=="percent" else ("Остаток","Начисление","Платёж")
    labels=[txt(word,20,color).move_to([x,.7,0]) for x,word,color in zip(xs,headings,(INK,GOLD,CYAN))]
    arrows=[Arrow([x+.33,.08,0],[y-.34,.08,0],buff=0,stroke_width=3,color=LAVENDER)
            for x,y in zip(xs,xs[1:])]
    dots=VGroup(*[Dot([x,.08,0],radius=.08,color=c) for x,c in zip(xs,(INK,GOLD,CYAN))])
    return VGroup(*labels), [dots,VGroup(*arrows),VGroup()]

class FinanceLesson(Scene):
    def construct(self):
        title="Финансовые задачи"
        script=[title,"Сценарий для озвучки"]
        heading=txt(title,27).to_edge(LEFT,buff=.55).to_edge(UP,buff=.28)
        rule=Line([-6.55,2.79,0],[6.55,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.3)
        clock=lambda t:f"{round(t)//60:02d}:{round(t)%60:02d}"
        for ch,(name,kind,steps) in enumerate(BEATS,1):
            sub=txt(name,23,MUTED).move_to([0,2.42,0])
            count=txt(f"{ch:02d} / {len(BEATS):02d}",16,MUTED).move_to([6.1,3.55,0])
            base,builds=sequence(kind)
            self.play(FadeIn(sub),FadeIn(count),FadeIn(base),run_time=1.2,rate_func=smootherstep)
            current=[sub,count,base]
            script.extend(["",name])
            for i,(formula,speech) in enumerate(steps):
                height=.78 if ch in (5,7) and i==1 else .46
                visual=equation(formula,(INK,CYAN,GOLD)[i],[3.31,(1.24,.17,-1.08)[i],0],height)
                if visual.width>6.28:
                    visual.scale_to_fit_width(6.28)
                anim=[FadeIn(visual,shift=UP*.08)]
                current.append(visual)
                if builds[i].width>.001:
                    anim.append(Create(builds[i]) if type(builds[i]) is VMobject else FadeIn(builds[i]))
                    current.append(builds[i])
                self.play(*anim,run_time=.85,rate_func=smootherstep)
                start=clock(self.time)
                self.wait(math.ceil(len(speech.split())/2.0)+1)
                script.extend([f"[{start}–{clock(self.time)}]",speech])
            self.play(*[FadeOut(m) for m in current],run_time=.85,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1)
        Path("finance_narration.txt").write_text("\n".join(script)+"\n",encoding="utf-8-sig")
