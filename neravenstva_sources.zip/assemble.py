from pathlib import Path
import argparse
from concurrent.futures import ThreadPoolExecutor
import itertools
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
BASE_MEDIA = ROOT / "media"

def run(args):
    return subprocess.check_output(args)


def clock(frame):
    seconds=round(frame/60)
    return f"{seconds//3600}:{(seconds//60)%60:02d}:{seconds%60:02d}"


def build_media(render_ranges, output, script_path):
    holds = []
    sections = []
    files = []
    for range_ in render_ranges:
        first,last=map(int,range_.split("-"))
        name=f"{first:02d}_{last:02d}"
        result=json.loads((ROOT/f"timing_{name}.json").read_text())
        offset=len(files)
        hold_offset={int(index)+offset:frames for index,frames in result["holds"].items()}
        holds.append(hold_offset)
        for section in result["data"]:
            for point in section["points"]:
                point["clip"]+=offset
            sections.append(section)
        part_dir=BASE_MEDIA/name/"videos"/"inequalities_lesson"/"1080p60"/"partial_movie_files"/"InequalitiesLesson"
        files.extend(part_dir/f"uncached_{index:05d}.mp4" for index in range(result["clips"]))
    holds={k:v for record in holds for k,v in record.items()}
    def frames(path):
        args=["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=nb_frames,has_b_frames",
              "-of","json",str(path)]
        stream=json.loads(run(args))["streams"][0]
        assert int(stream["has_b_frames"])==0, path
        return int(stream["nb_frames"])
    with ThreadPoolExecutor(max_workers=5) as pool:
        nominal=list(pool.map(frames,files))
    for index in holds:
        assert nominal[index]==1, (index,nominal[index],files[index])
    sizes=[holds.get(index,n) for index,n in enumerate(nominal)]
    offsets=list(itertools.accumulate(sizes,initial=0))
    # The next sample timestamp controls the presentation time of the static picture.
    # PTS follow the integer frame grid even though stills use just one video sample.
    def seconds(frame):
        return round(frame*1_000_000/60)
    lines=["ffconcat version 1.0"]
    for i,path in enumerate(files):
        duration=(seconds(offsets[i+1])-seconds(offsets[i]))/1_000_000
        lines.extend([f"file '{path}'",f"duration {duration:.6f}"])
    timeline=output.with_suffix(".ffconcat")
    timeline.write_text("\n".join(lines)+"\n")
    subprocess.run(["ffmpeg","-n","-nostdin","-v","error","-xerror","-f","concat","-safe","0","-i",str(timeline),
                    "-map","0:v:0","-c:v","copy","-movflags","+faststart",str(output)],check=True)
    info=json.loads(run(["ffprobe","-v","error","-show_streams","-of","json",str(output)]))["streams"]
    assert len(info)==1 and info[0]["codec_type"]=="video"
    assert info[0]["width"]==1920 and info[0]["height"]==1080
    assert abs(float(info[0]["duration"])-offsets[-1]/60)<.035, (info[0]["duration"],offsets[-1]/60)
    assert int(info[0]["nb_frames"])==sum(nominal)
    lines=["Неравенства","Сценарий для озвучки"]
    group=""
    for section in sections:
        if group!=section["group"]:
            group=section["group"]
            lines.extend(["",group])
        lines.extend(["",section["heading"]])
        for point in section["points"]:
            clip=point["clip"]
            lines.extend([f"[{clock(offsets[clip])}–{clock(offsets[clip+1])}]",point["text"]])
    text="\n".join(lines)+"\n"
    assert not re.search(r"(?i)ЕГЭ|профильн|https?://|черновик|после монтажа",text)
    script_path.write_text(text,encoding="utf-8-sig")
    print(f"{output.name}: {offsets[-1]/60:.3f} s, {len(sections)} sections, {sum(nominal)} encoded frames")


if __name__=="__main__":
    cli=argparse.ArgumentParser()
    cli.add_argument("ranges", nargs="+")
    cli.add_argument("--output",default="inequalities_1080p.mp4")
    cli.add_argument("--script",default="inequalities_narration.txt")
    args=cli.parse_args()
    build_media(args.ranges,ROOT/args.output,ROOT/args.script)
