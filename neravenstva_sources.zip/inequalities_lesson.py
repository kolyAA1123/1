from pathlib import Path
import math
import json

import numpy as np
from manim import Axes, Create, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Неравенства"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()



def graph(kind):
    if kind=="parabola":
        axes=Axes(x_range=[-3.1,3.1,1],y_range=[-5,3,1],x_length=5.16,y_length=3.78,
                  axis_config={"stroke_width":1.5,"include_ticks":False,"color":MUTED}).move_to([-3.65,-.18,0])
        curve=axes.plot(lambda x:x*x-4,x_range=[-2.53,2.53],color=CYAN,stroke_width=3.2)
        selected=Line(axes.c2p(-2,0),axes.c2p(2,0),color=GOLD,stroke_width=4)
        dots=VGroup(*[Dot(axes.c2p(x,0),radius=.072,color=GOLD) for x in (-2,2)])
        labels=VGroup(*[equation(str(x),INK,axes.c2p(x,0)+[0,-.24,0],.23) for x in (-2,2)])
        return VGroup(axes,curve),VGroup(selected,dots,labels)
    if kind=="log_domain":
        def p(x):
            return np.array([-5.87+2.25*(x+1),-.17,0])
        axis=Line(p(-1.14),p(1.02),color=MUTED,stroke_width=1.8)
        marks=VGroup(Line(p(-1),p(.5),color=CYAN,stroke_width=4.0),Dot(p(.5),radius=.069,color=GOLD))
        for x in (-1,-math.sqrt(.5),0):
            marks.add(Dot(p(x),radius=.065,color=ROSE,fill_color=BLACK_BG,stroke_width=2))
        for x,t,y in [(-1,"-1",-.38),(-math.sqrt(.5),r"-\sqrt{2}/2",.32),(0,"0",-.38),(.5,"1/2",.32)]:
            marks.add(equation(t,INK,p(x)+[0,y,0],.24))
        return VGroup(axis),marks
    return VGroup(),VGroup()


class InequalitiesLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind=="log_domain" else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
