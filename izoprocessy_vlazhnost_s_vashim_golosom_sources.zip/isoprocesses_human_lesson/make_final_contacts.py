"""Capture readable states from the delivered MP4, using measured edit points."""
from pathlib import Path
import json,subprocess
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parent
PREFIX='izoprocessy_vlazhnost_s_vashim_golosom'

def main():
    plan=json.loads((ROOT/'plan.json').read_text())
    mapping=json.loads((ROOT/'frame_map.json').read_text())
    movie=ROOT/'output'/f'{PREFIX}_1080p60.mp4'
    out=ROOT/'output/final_contacts';out.mkdir(exist_ok=True)
    cases=[('01_01','speech'),('02_03','speech'),
           ('02_04','initial_explanation'),('02_04','result'),
           ('04_04','speech'),('05_04','speech'),('06_02','speech'),
           ('07_01','initial_explanation'),('07_01','result'),
           ('07_04','initial_explanation'),('07_04','result'),
           ('08_04','speech'),('09_02','speech'),('10_02','speech'),
           ('11_02','initial_explanation'),('11_02','result'),
           ('11_04','speech'),('12_03','speech'),('13_03','speech'),('13_04','speech'),
           ('13_05','surface_pressure_explanation'),('13_05','result')]
    captured=[]
    for key,phase in cases:
        ident,beat=map(int,key.split('_'));ch=plan['chapters'][ident-1]
        cue=next(c for c in ch['cues'] if c['key']==key)
        if phase=='speech':local=cue['at']+cue['speech_duration']/2
        else:
            label=key if phase=='result' else key+'_'+phase
            hold=next(r for r in mapping['chapters'][ident-1]['replacements'] if r['label']==label)
            local=(hold['new_start_frame']+hold['new_frame_count']/2)/60
        at=ch['start']+local;dest=out/f'{key}_{phase}.png'
        subprocess.run(['ffmpeg','-v','error','-threads','1','-ss',str(at),'-i',str(movie),
                        '-frames:v','1','-threads','1','-y',str(dest)],check=True)
        captured.append({'key':key,'phase':phase,'time':at,'file':dest.name,
                         'speech_active':cue['at']<=local<=cue['at']+cue['speech_duration']})
    for sheet_i,start in enumerate(range(0,len(captured),6),1):
        items=captured[start:start+6];sheet=Image.new('RGB',(1920,776),'#151515');draw=ImageDraw.Draw(sheet)
        for i,c in enumerate(items):
            x=i%3*640;y=i//3*388
            im=Image.open(out/c['file']);im.thumbnail((640,360));sheet.paste(im,(x,y))
            draw.text((x+8,y+364),f"{c['key']} / {c['phase']} / final {c['time']:.2f}s",fill='white')
        sheet.save(out/f'sheet_{sheet_i:02d}.jpg',quality=95)
    (out/'manifest.json').write_text(json.dumps(captured,ensure_ascii=False,indent=2)+'\n')
    print(f'Captured {len(captured)} delivered frames',flush=True)

if __name__=='__main__':main()
