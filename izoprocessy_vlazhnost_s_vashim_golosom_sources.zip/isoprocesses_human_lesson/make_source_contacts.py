"""Read-only source-state and in-action captures for the recorded gas lesson."""
from pathlib import Path
import argparse,json,math,subprocess
from concurrent.futures import ThreadPoolExecutor
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'mkt_isoprocesses_lesson/output/chapters'
OUT=ROOT/'output/source_contacts'
FPS=60

def frame(source,n,dest):
    seek=max(0,n//FPS-1);local=n-seek*FPS
    subprocess.run(['ffmpeg','-v','error','-y','-threads','1','-ss',str(seek),'-i',str(source),
                    '-an','-vf',f'trim=start_frame={local}:end_frame={local+1}',
                    '-frames:v','1','-threads','1','-q:v','2',str(dest)],check=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--jobs',type=int,default=1);args=p.parse_args()
    timeline=json.loads((ROOT/'output/source_timeline.json').read_text())
    assert len(timeline['chapters'])==13
    OUT.mkdir(parents=True,exist_ok=True)
    jobs=[]
    targets={(2,4),(4,4),(5,4),(6,2),(7,1),(7,3),(7,4),(8,1),(8,2),(8,3),(8,4),
             (10,2),(10,3),(10,4),(11,2),(11,3),(11,4),(13,3),(13,4),(13,5)}
    for ch in timeline['chapters']:
        clip=SOURCE/f"{ch['id']:02d}_{ch['class']}.mp4"
        for b in ch['beats']:
            k=f"{ch['id']:02d}_{b['index']+1:02d}"
            n=(b['terminal_hold_start_frame']+b['terminal_hold_end_frame']-1)//2
            jobs.append({'key':k,'phase':'terminal','source_frame':n,'clip':str(clip),'file':f'{k}_full.jpg'})
            if (ch['id'],b['index']+1) in targets:
                acts=[e for e in ch['events'] if b['source_start_frame']<=e['source_start_frame']<b['end_frame']
                      and e['kind']=='play' and e['frames']>=150]
                # Longest substantive move; investigate stages on either side
                # separately if semantic review identifies an additional risk.
                if acts:
                    e=max(acts,key=lambda x:x['frames'])
                    for q in (.25,.5,.75):
                        n=e['source_start_frame']+round((e['frames']-1)*q)
                        label=f"action_{round(q*100):02d}"
                        jobs.append({'key':k,'phase':label,'source_frame':n,'clip':str(clip),
                                     'event_line':e.get('source_code_line'),'file':f'{k}_{label}_full.jpg'})
    def run(j):
        frame(Path(j['clip']),j['source_frame'],OUT/j['file'])
        if j['phase']=='terminal':
            im=Image.open(OUT/j['file']);im.thumbnail((384,216));im.save(OUT/(j['key']+'.jpg'),quality=95)
        return j
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:items=list(pool.map(run,jobs))
    terms=[j for j in items if j['phase']=='terminal'];assert len(terms)==65
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
    sheets=[]
    for s,start in enumerate(range(0,65,25),1):
        group=terms[start:start+25];canvas=Image.new('RGB',(1920,math.ceil(len(group)/5)*248),'#161616');d=ImageDraw.Draw(canvas)
        for i,j in enumerate(group):
            x=i%5*384;y=i//5*248;canvas.paste(Image.open(OUT/(j['key']+'.jpg')),(x,y))
            d.text((x+10,y+221),f"{j['key']} / source {j['source_frame']/FPS:.2f}s",font=font,fill='white')
        f=f'sheet_{s:02d}.jpg';canvas.save(OUT/f,quality=95);sheets.append(f)
    (OUT/'manifest.json').write_text(json.dumps({'fps':FPS,'source_immutable':True,'items':items,'sheets':sheets},ensure_ascii=False,indent=2)+'\n')
    print(f'Captured65terminalstates and{len(items)-65}in-actionstates;{len(sheets)}sheets',flush=True)

if __name__=='__main__':main()
