"""Apply documented acoustic-boundary decisions to the complete recording.

This preserves the entire source partition. ASR confidence is not pronunciation
verification; native sentence times are exposed only as broad source markers.
"""
from pathlib import Path
import argparse,json,wave

ROOT=Path(__file__).resolve().parent

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def dump(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--decisions',type=Path,default=ROOT/'boundary_decisions.json')
    args=parser.parse_args()
    cuts=read(ROOT/'cuts_proposed.json')['cues']
    proposal=read(ROOT/'output/alignment_proposals.json')
    reviews=read(ROOT/'output/boundary_review.json')
    transcript=read(ROOT/'output/transcription.json')
    decisions=read(args.decisions) if args.decisions.exists() else {}
    assert len(cuts)==len(proposal['cues'])==65
    assert all(r['before'] in decisions for r in reviews if r['needs_review']), 'Document every flagged boundary decision before finalizing.'
    with wave.open(str(ROOT/'materials/recording_processed.wav')) as w:
        total=w.getnframes()/w.getframerate()
    cuts[0]['source_start']=0.;cuts[-1]['source_end']=total
    decisions_log=[]
    for i,(left,right) in enumerate(zip(cuts,cuts[1:])):
        if left['key'] in decisions:
            decision=decisions[left['key']]
            cut=float(decision['time'])
            assert left['source_start']<cut<right['source_end'],decision
            left['source_end']=right['source_start']=cut
            decisions_log.append({'before':left['key'],'after':right['key'],**decision})
        assert left['source_end']==right['source_start']
    assert all(0<=c['source_start']<c['source_end']<=total+1e-8 for c in cuts)
    for c in cuts:c['review']='Reviewed source partition; all source content retained. Only quiet edge handles may be trimmed later.'
    dump(ROOT/'cuts.json',{'source':'provided recording4.MP3','cues':cuts})
    markers=[]
    for c in cuts:
        native=[]
        for chunk in transcript:
            for segment in chunk.get('segments',[]):
                if float(segment['end'])>c['source_start'] and float(segment['start'])<c['source_end']:
                    native.append({'chunk':chunk['index'],**segment})
        markers.append({'key':c['key'],'source_start':c['source_start'],
                        'source_end':c['source_end'],'expected_text':c['expected_text'],
                        'native_segments':native})
    dump(ROOT/'output/cue_native_segments.json',markers)
    extras=[e for e in proposal['extras'] if len(e['text'].split())>=5]
    report={'summary':proposal['summary'],'source_partition_cues':65,
            'source_partition_end_seconds':total,'source_content_preserved':True,
            'confirmed_narrator_mistakes':None,'not_listening_verified':True,
            'boundary_decisions':decisions_log,
            'flagged_boundary_reviews':[{k:v for k,v in r.items() if k!='candidate_pauses'}
                                        for r in reviews if r['needs_review']],
            'recognized_extra_runs_at_least5words':extras,
            'unmatched_cue_keys':[c['key'] for c in proposal['cues'] if not c['matched_word_pairs']],
            'full_cue_omissions_detected':False if all(c['matched_word_pairs'] for c in proposal['cues']) else None,
            'limitations':'ASR phonetics/formulas may differ from the recording; recognized extras and low confidence are not verified narrator errors. Native segment times are not word timings.'}
    dump(ROOT/'output/alignment_review.json',report)
    print('Finalized65continuouscues; source end',total,flush=True)

if __name__=='__main__':main()
