"""Prepare ASR guide and a levelled recording while preserving timing/pitch."""
from pathlib import Path
import argparse,hashlib,json,subprocess,wave,re
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('recording',type=Path);args=p.parse_args()
 with args.recording.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 material=ROOT/'materials';material.mkdir(exist_ok=True);(ROOT/'output').mkdir(exist_ok=True)
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(args.recording),'-ac','1','-ar','16000','-c:a','pcm_s16le',str(material/'recording_16k.wav')],check=True)
 with (ROOT/'output/audio_processing.log').open('w') as log:
  subprocess.run(['ffmpeg','-hide_banner','-nostats','-y','-i',str(args.recording),'-af','aformat=channel_layouts=mono,highpass=f=65,loudnorm=I=-19:TP=-1.5:LRA=11:print_format=json','-ar','48000','-ac','1','-c:a','pcm_s16le',str(material/'recording_processed.wav')],check=True,stdout=log,stderr=log)
 write_manifests(args.recording)

def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def wave_info(p):
 with wave.open(str(p)) as w:return {'samples':w.getnframes(),'sample_rate':w.getframerate(),'channels':w.getnchannels(),'decoded_seconds':w.getnframes()/w.getframerate()}
def write_manifests(recording):
 recording=Path(recording);material=ROOT/'materials'
 source_sha=digest(recording);guide=wave_info(material/'recording_16k.wav');processed=wave_info(material/'recording_processed.wav')
 log=(ROOT/'output/audio_processing.log').read_text()
 measurements=json.loads(re.findall(r'\{[^{}]*"input_i"[^{}]*\}',log,re.S)[-1])
 manifest={'sha256':source_sha,'original_bytes':recording.stat().st_size,'original_not_bundled':True,
  'processing':'mono; highpass65Hz; loudnormI=-19:TP=-1.5:LRA=11; 48kPCM16; no speed or pitch changes',
  **processed,'processed_wav_sha256':digest(material/'recording_processed.wav'),'loudnorm_measurements':measurements}
 (ROOT/'recording_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 reference=ROOT.parent/'mkt_isoprocesses_lesson/narration.json';script=json.loads(reference.read_text())
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(recording)]))
 asr={'source_file':recording.name,'source_sediment_id':'file_000000007f7482469f7d7721cc59af29','source_sha256':source_sha,
  'source_bytes':recording.stat().st_size,'duration_seconds':float(probe['format']['duration']),
  'guide_sha256':digest(material/'recording_16k.wav'),'guide_processing':'FFmpeg decode, mono, 16000Hz, PCM16. No filters.',
  'engine':'sherpa-onnx1.13.8','language':'ru','model':'Whisper-small int8 ONNX','workers':4,'threads_per_worker':2,
  'timestamp_precision':'ASR segment/chunk bounds; not verified word timing','weights_not_bundled':True,'recording_not_bundled':True,
  'guide_frames':guide['samples'],'guide_duration_seconds':guide['decoded_seconds'],
  'transcribe_script_sha256':digest(ROOT/'transcribe_recording.py'),
  'ffmpeg_version':subprocess.check_output(['ffmpeg','-version'],text=True).splitlines()[0],
  'reference_script_sha256':digest(reference),'reference_script':'mkt_isoprocesses_lesson/narration.json',
  'reference_chapters':len(script['chapters']),'reference_cues':sum(len(c['cues']) for c in script['chapters'])}
 (ROOT/'asr_recording_manifest.json').write_text(json.dumps(asr,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
