"""Capture all one-hundred source readable states without changing source media."""
from pathlib import Path
import json,subprocess
from concurrent.futures import ThreadPoolExecutor
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/source_contacts';OUT.mkdir(parents=True,exist_ok=True)
anchors=json.loads((ROOT/'narration_anchors.json').read_text())
FPS=anchors['fps']
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)

def capture(cue):
 key=cue['key'];src=list((ROOT.parent/'pdf_lesson/output/chapters').glob(f"{cue['chapter']:02d}_*.mp4"))
 assert len(src)==1,(key,src)
 frame=(cue['hold_start_frame']+cue['hold_end_frame']-1)//2
 at=frame/FPS
 dest=OUT/f'{key}.jpg'
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-threads','2','-ss',f'{at:.6f}','-i',str(src[0]),'-frames:v','1','-vf','scale=384:216','-q:v','2','-y',str(dest)]
 subprocess.run(cmd,check=True)
 if key in ('08_01','17_02','20_02'):
  subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-threads','2','-ss',f'{at:.6f}','-i',str(src[0]),'-frames:v','1','-q:v','2','-y',str(OUT/f'{key}_full.jpg')],check=True)
 return {'key':key,'source_file':src[0].name,'source_frame':frame,'source_time_seconds':at,'thumbnail':dest.name}

with ThreadPoolExecutor(max_workers=2) as pool:items=list(pool.map(capture,anchors['cues']))
for sheet_index in range(4):
 group=items[sheet_index*25:(sheet_index+1)*25]
 canvas=Image.new('RGB',(1920,1240),'#161616');draw=ImageDraw.Draw(canvas)
 for i,item in enumerate(group):
  x=(i%5)*384;y=(i//5)*248
  with Image.open(OUT/item['thumbnail']) as im:canvas.paste(im,(x,y))
  draw.text((x+10,y+221),f"{item['key']}  source {item['source_time_seconds']:.2f}s",font=font,fill='white')
 canvas.save(OUT/f'sheet_{sheet_index+1:02d}.jpg',quality=95)
manifest={'fps':FPS,'capture':'Midpoint of each final static hold, all100 cues; source frames unchanged.','items':items,'sheets':[f'sheet_{i:02d}.jpg' for i in range(1,5)],'full_resolution_details':['08_01_full.jpg','17_02_full.jpg','20_02_full.jpg']}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('Created',len(items),'cue frames and4sheets at',OUT)
