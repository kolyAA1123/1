"""Propose safe audio cuts between the100 script cues using acoustic pauses.

Native ASR segment bounds locate a search region. Within shared segments the
relative token position is a search hint only, never claimed as word timing.
Cuts partition the entire recording without deleting any source interval.
Ambiguous boundaries are exported for review, not silently called verified.
"""
from pathlib import Path
import json, wave, argparse
import numpy as np
ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--alignment',type=Path,default=ROOT/'output/alignment_proposals.json')
    args=parser.parse_args()
    data=json.loads(args.alignment.read_text());cues=data['cues']
    chunks={r['index']:r for r in json.loads((ROOT/'output/transcription.json').read_text())}
    units={u['id']:u for u in data['source_units']}
    with wave.open(str(ROOT/'materials/recording_16k.wav')) as w:
        assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,16000)
        audio=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
    hop=160;n=len(audio)//hop
    rms=np.sqrt((audio[:n*hop].reshape(n,hop)**2).mean(axis=1))
    # Threshold used only for locating candidate pauses, never trimming words.
    quiet=rms<10**(-43/20)
    changes=np.diff(np.r_[False,quiet,False].astype(int))
    pauses=[(int(s)/100,int(e)/100) for s,e in zip(np.flatnonzero(changes==1),np.flatnonzero(changes==-1)) if e-s>=6]
    boundaries=[0.];reviews=[]
    for prev,nxt in zip(cues,cues[1:]):
        if not prev['segment_ids'] or not nxt['segment_ids']:
            raise ValueError(f'No matched text around {prev["key"]}->{nxt["key"]}')
        last=max(prev['chunk_ids']);first=min(nxt['chunk_ids'])
        u=units[prev['segment_ids'][-1]];v=units[nxt['segment_ids'][0]]
        shared=set(prev['segment_ids'])&set(nxt['segment_ids'])
        if last<first:
            target=(chunks[last]['end']+chunks[first]['start'])/2
            method='long_pause_chunk_boundary';window=1.25
        elif u['id']!=v['id']:
            target=(u['end']+v['start'])/2
            method='native_segment_boundary';window=1.3
        else:
            # Search hint only: units are NOT word-timestamped.
            left=prev['matched_word_pairs'][-1]['observed_index']
            right=nxt['matched_word_pairs'][0]['observed_index']
            fraction=((left+right+1)/2-u['word_start'])/max(1,u['word_end']-u['word_start'])
            target=u['start']+fraction*(u['end']-u['start'])
            method='shared_segment_token_fraction_search_hint';window=max(1.5,(u['end']-u['start'])*.35)
        candidates=[]
        for s,e in pauses:
            mid=(s+e)/2
            if mid<=boundaries[-1]+.35:continue
            if abs(mid-target)>window and not s<=target<=e:continue
            # Avoid grabbing a pause beyond the first recognized next phrase.
            if mid>max(v['end'],target+window):continue
            distance=0 if s<=target<=e else min(abs(s-target),abs(e-target))
            score=distance-.18*min(e-s,1.5)
            candidates.append({'time':round(mid,4),'pause':[s,e],'duration':round(e-s,4),'distance':round(distance,4),'score':round(score,4)})
        candidates.sort(key=lambda c:c['score'])
        if not candidates:raise ValueError(f'No safe pause around {prev["key"]}->{nxt["key"]}: {target:.3f}')
        best=candidates[0];cut=best['time'];boundaries.append(cut)
        ambiguous=method.startswith('shared') or abs(cut-target)>.7 or best['duration']<.12 or (len(candidates)>1 and candidates[1]['score']-best['score']<.12)
        reviews.append({'before':prev['key'],'after':nxt['key'],'time':cut,'pause':best['pause'],
                        'pause_duration':best['duration'],'target':round(target,4),'adjustment':round(cut-target,4),
                        'method':method,'needs_review':ambiguous,'shared_segments':sorted(shared),
                        'candidate_pauses':candidates[:6]})
    boundaries.append(len(audio)/16000)
    out=[]
    for i,c in enumerate(cues):
        out.append({'key':c['key'],'chapter':c['chapter'],'beat':c['beat'],
                    'source_start':boundaries[i],'source_end':boundaries[i+1],
                    'expected_text':c['expected_text'],'recognized_text':c['source_text'],
                    'confidence':c['confidence'],'review':'Proposed acoustic pause partition; all source content retained.'})
    (ROOT/'cuts_proposed.json').write_text(json.dumps({'source':'new provided1.mp3','cues':out},ensure_ascii=False,indent=2)+'\n')
    (ROOT/'output/boundary_review.json').write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n')
    print(f'{len(out)} cues; {sum(r["needs_review"] for r in reviews)} boundary review flags')
    for r in reviews:
        if r['needs_review']:print(r['before'],r['after'],r['time'],r['method'],r['candidate_pauses'][:3])
if __name__=='__main__':main()
