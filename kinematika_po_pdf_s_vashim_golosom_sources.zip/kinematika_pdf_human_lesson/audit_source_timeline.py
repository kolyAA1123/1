"""Recover exact source play/wait intervals from immutable Manim chapter caches.

Instrumentation executes geometry with skipped animations; source partial clips
supply exact60fps frame counts, so quantized waits are not guessed. Existing
source files and rendered clips are never modified. New scratch cache is isolated.
"""
from __future__ import annotations
import argparse, importlib, inspect, json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'pdf_lesson'
FPS=60

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames,width,height,r_frame_rate','-of','json',str(path)]))['streams'][0]

def main():
    p=argparse.ArgumentParser();p.add_argument('--chapters',type=int,nargs='*');args=p.parse_args()
    sys.path.insert(0,str(SOURCE));sys.path.insert(0,str(SOURCE/'scenes'))
    from manim import tempconfig, Wait
    from pdf_style import ChapterScene
    plan=json.loads((SOURCE/'plan.json').read_text())
    chapters=[]
    for meta in plan['chapters']:
        if args.chapters and meta['id'] not in args.chapters:continue
        ident=meta['id'];clsname=meta['class'];module=meta['module'][:-3]
        chapter_clip=SOURCE/'output/chapters'/f'{ident:02d}_{clsname}.mp4'
        chapter_video=probe(chapter_clip)
        partial_list=SOURCE/f'output/render_cache/{ident:02d}/videos/{module}/1080p60/partial_movie_files/{clsname}/partial_movie_file_list.txt'
        paths=[Path(s[6:-1].removeprefix('file:')) for s in partial_list.read_text().splitlines() if s.startswith("file '")]
        counts=[int(probe(s)['nb_frames']) for s in paths]
        events=[];beats=[]
        original_play=ChapterScene.play;original_beat=ChapterScene.beat
        def visible_texts(scene):
            found=[];seen=set()
            for root in scene.mobjects:
                for mob in root.get_family():
                    value=getattr(mob,'tex_string',None) or getattr(mob,'text',None)
                    if value and value not in seen:found.append(value);seen.add(value)
            return found
        def play(self,*animations,**kwargs):
            idx=len(events)
            if idx>=len(paths):raise ValueError(f'Unexpected extra play {ident}:{idx}')
            source_start=sum(counts[:idx]);start=self.time
            caller=next((f for f in inspect.stack() if str(SOURCE/'scenes') in f.filename),None)
            before_text=visible_texts(self)
            result=original_play(self,*animations,**kwargs)
            after_text=visible_texts(self)
            end=self.time
            is_wait=len(animations)==1 and isinstance(animations[0],Wait)
            frozen=bool(self.is_current_animation_frozen_frame()) if is_wait else False
            events.append({'index':idx,'kind':'wait' if is_wait else 'play','animation_types':[type(a).__name__ for a in animations],
                           'source_start_frame':source_start,'source_end_frame':source_start+counts[idx],
                           'frames':counts[idx],'source_start':source_start/FPS,'source_end':(source_start+counts[idx])/FPS,
                           'requested_seconds':end-start,'frozen_wait':frozen,'source_partial':str(paths[idx]),
                           'source_code_line':caller.lineno if caller else None,'visible_texts_after':after_text,
                           'new_texts':[t for t in after_text if t not in before_text]})
            self.renderer.time=(source_start+counts[idx])/FPS
            return result
        def beat(self,index,note=None):
            first=len(events);original_beat(self,index,note)
            caption=[e for e in events[first:] if e['kind']=='play']
            if not caption:raise ValueError('Expected caption reveal')
            beats.append({'index':index,'nominal_start':meta['beats'][index],
                          'caption_event_index':caption[-1]['index'],'source_start_frame':caption[-1]['source_start_frame']})
        ChapterScene.play=play;ChapterScene.beat=beat
        try:
            # Isolate any generated tex/text cache and never write source movies.
            with tempconfig({'dry_run':True,'frame_rate':FPS,'pixel_width':1920,'pixel_height':1080,
                             'media_dir':str(ROOT/'output/timeline_scratch'),'tex_dir':str(ROOT/'output/timeline_scratch/Tex'),
                             'text_dir':str(ROOT/'output/timeline_scratch/texts'),
                             'progress_bar':'none','verbosity':'ERROR','disable_caching':True}):
                cls=getattr(importlib.import_module(module),clsname)
                scene=cls(skip_animations=True);scene.construct()
        finally:
            ChapterScene.play=original_play;ChapterScene.beat=original_beat
        if len(events)!=len(paths):raise ValueError(f'Play count mismatch {ident}: {len(events)} vs {len(paths)}')
        if sum(counts)!=int(chapter_video['nb_frames']):raise ValueError(f'Partial sum differs from chapter framecount {ident}')
        for n,b in enumerate(beats):
            end=beats[n+1]['caption_event_index'] if n+1<len(beats) else len(events)-1
            # The last wait before the next beat/closing fade follows all action.
            candidates=[e for e in events[b['caption_event_index']:end] if e['kind']=='wait']
            if not candidates:raise ValueError(f'No terminal wait {ident}:{n}')
            tail=candidates[-1]
            if tail['index']!=end-1:raise ValueError(f'Last wait is not terminal {ident}:{n}')
            b['end_frame']=events[end]['source_start_frame']
            b['terminal_hold_start_frame']=tail['source_start_frame']
            b['terminal_hold_end_frame']=tail['source_end_frame']
            b['terminal_hold_frozen']=tail['frozen_wait']
            b['fixed_action_frames']=tail['source_start_frame']-b['source_start_frame']
        chapters.append({'id':ident,'class':clsname,'source':str(chapter_clip),'source_frames':int(chapter_video['nb_frames']),
                         'duration':int(chapter_video['nb_frames'])/FPS,'partial_files':len(paths),'events':events,'beats':beats})
        print(f"{ident:02d} {clsname}: {len(events)}events, {sum(counts)}frames, holds="+','.join(str(b['terminal_hold_end_frame']-b['terminal_hold_start_frame']) for b in beats),flush=True)
    out={'fps':FPS,'method':'Skipped geometry execution indexed against exact existing partial-movie frame counts; all chapter sums verified','chapters':chapters}
    target=ROOT/'output/source_timeline.json'
    if args.chapters:target=target.with_name('source_timeline_'+('_'.join(str(i) for i in args.chapters))+'.json')
    target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(target)
if __name__=='__main__':main()
