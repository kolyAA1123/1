"""Propose monotonic script-to-recording matches without inventing word times.

The ASR input uses chunk/segment timestamps. A proposal's time range therefore
covers complete source segments; shared segments require waveform refinement.
No recording is cut or modified by this program.
"""
from __future__ import annotations

import argparse
from array import array
from difflib import SequenceMatcher
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
SMALL = ("ноль один два три четыре пять шесть семь восемь девять десять "
         "одиннадцать двенадцать тринадцать четырнадцать пятнадцать "
         "шестнадцать семнадцать восемнадцать девятнадцать").split()
TENS = "ноль десять двадцать тридцать сорок пятьдесят шестьдесят семьдесят восемьдесят девяносто".split()
HUNDREDS = "ноль сто двести триста четыреста пятьсот шестьсот семьсот восемьсот девятьсот".split()
NUMBER_FORMS = {
    "нуль": "ноль", "нуля": "ноль", "нулю": "ноль", "нулем": "ноль",
    "одна": "один", "одно": "один", "одну": "один", "одного": "один",
    "одной": "один", "одному": "один", "две": "два", "двух": "два",
    "двум": "два", "двумя": "два", "трех": "три", "трем": "три",
    "тремя": "три", "четырех": "четыре", "четырем": "четыре",
    "двадцати": "двадцать", "сорока": "сорок",
}


def number_words(value: str) -> str:
    number = int(value)
    if number >= 1000:
        return value
    words = []
    if number >= 100:
        words.append(HUNDREDS[number // 100])
        number %= 100
    if number >= 20:
        words.append(TENS[number // 10])
        number %= 10
        if number:
            words.append(SMALL[number])
    elif number or not words:
        words.append(SMALL[number])
    return " ".join(words)


def normalize(text: str) -> list[str]:
    text = text.lower().replace("ё", "е")
    text = re.sub(r"\d+", lambda m: " " + number_words(m.group()) + " ", text)
    return [NUMBER_FORMS.get(word, word) for word in re.findall(r"[а-яa-z0-9]+", text)]


def near_word(left: str, right: str) -> bool:
    # Russian case/number endings are frequent ASR differences. This is only
    # a weak alignment aid; exact coverage and differences remain in reports.
    return (len(left) >= 5 and len(right) >= 5 and left[:4] == right[:4]
            and abs(len(left) - len(right)) <= 3)


def token_alignment(expected: list[str], observed: list[str]):
    """Global edit alignment, with linear score memory and byte traceback."""
    n, m = len(expected), len(observed)
    gap = 13
    previous = array("i", (j * gap for j in range(m + 1)))
    trace = [bytearray([2]) * (m + 1)]
    for i, word in enumerate(expected, 1):
        current = array("i", [i * gap])
        row = bytearray(m + 1)
        row[0] = 1
        for j, heard in enumerate(observed, 1):
            substitution = 0 if word == heard else 10 if near_word(word, heard) else 24
            diagonal = previous[j - 1] + substitution
            delete = previous[j] + gap
            insert = current[j - 1] + gap
            if diagonal <= delete and diagonal <= insert:
                current.append(diagonal)
                row[j] = 0
            elif delete <= insert:
                current.append(delete)
                row[j] = 1
            else:
                current.append(insert)
                row[j] = 2
        previous = current
        trace.append(row)
    pairs = []
    i, j = n, m
    while i or j:
        action = trace[i][j]
        if i and j and action == 0:
            i -= 1
            j -= 1
            exact = expected[i] == observed[j]
            pairs.append((i, j, "exact" if exact else "near" if near_word(expected[i], observed[j]) else "mismatch"))
        elif i and (not j or action == 1):
            i -= 1
        else:
            j -= 1
    return list(reversed(pairs)), previous[m]


def expected_cues(script):
    """Flatten the100 single-beat cues of the combined four-PDF film."""
    cues, words = [], []
    for chapter in script["chapters"]:
        for cue in chapter["cues"]:
            normalized = normalize(cue["text"])
            cues.append({
                "key": f"{chapter['id']:02d}_{cue['beat']:02d}",
                "chapter": chapter["id"], "beat": cue["beat"],
                "expected_text": cue["text"],
                "visual": cue["visual"], "completion": cue["completion"],
                "word_start": len(words), "word_end": len(words) + len(normalized),
                "normalized_words": normalized,
            })
            words.extend(normalized)
    return cues, words


def observed_units(transcript):
    units, tokens, owners, warnings = [], [], [], []
    for chunk in sorted(transcript, key=lambda item: (item["start"], item["index"])):
        segments = chunk.get("segments") or []
        combined = normalize(" ".join(segment.get("text", "") for segment in segments))
        canonical = normalize(chunk.get("text", ""))
        if not combined or SequenceMatcher(None, canonical, combined, autojunk=False).ratio() < .75:
            segments = [{"start": chunk["start"], "end": chunk["end"], "text": chunk["text"]}]
            kind = "chunk"
        else:
            kind = "asr_segment"
        for index, segment in enumerate(segments):
            normalized = normalize(segment.get("text", ""))
            if not normalized:
                continue
            start = max(float(chunk["start"]), float(segment["start"]))
            end = min(float(chunk["end"]), float(segment["end"]))
            if end <= start:
                start, end, timing = float(chunk["start"]), float(chunk["end"]), "chunk_invalid_segment_timing"
            else:
                timing = kind
            if start != float(segment["start"]) or end != float(segment["end"]):
                warnings.append(f"Clipped segment {chunk['index']}:{index} to its source chunk.")
            unit = {
                "id": f"{chunk['index']:03d}:{index}", "chunk_id": chunk["index"],
                "segment_index": index, "start": start, "end": end,
                "text": segment["text"], "timing_source": timing,
                "word_start": len(tokens), "word_end": len(tokens) + len(normalized),
            }
            owners.extend([len(units)] * len(normalized))
            tokens.extend(normalized)
            units.append(unit)
    return units, tokens, owners, warnings


def propose(script, transcript):
    cues, expected = expected_cues(script)
    units, observed, owners, input_warnings = observed_units(transcript)
    if not observed:
        raise ValueError("ASR input contains no recognized words")
    pairs, total_cost = token_alignment(expected, observed)
    by_expected = {left: (right, kind) for left, right, kind in pairs}
    strong_observed = {right for _, right, kind in pairs if kind != "mismatch"}
    unit_cues = {}
    for cue in cues:
        begin, end = cue["word_start"], cue["word_end"]
        aligned = [(i, *by_expected[i]) for i in range(begin, end) if i in by_expected]
        strong = [(i, j, kind) for i, j, kind in aligned if kind != "mismatch"]
        exact = sum(kind == "exact" for _, _, kind in strong)
        exact_coverage = exact / max(1, end - begin)
        aligned_coverage = len(strong) / max(1, end - begin)
        indices = [j for _, j, _ in strong]
        selected = sorted({owners[j] for j in indices})
        heard = observed[min(indices):max(indices) + 1] if indices else []
        similarity = SequenceMatcher(None, cue["normalized_words"], heard, autojunk=False).ratio()
        warnings = []
        if not strong:
            warnings.append("No reliable script words found; do not cut automatically.")
        if aligned_coverage < .75:
            warnings.append("Substantial expected material is missing or unrecognized.")
        if exact_coverage < .65 or similarity < .65:
            warnings.append("Low text confidence: inspect recording and ASR.")
        elif exact_coverage < .85 or similarity < .85:
            warnings.append("Text differences require review.")
        if selected and any(units[u]["timing_source"] != "asr_segment" for u in selected):
            warnings.append("Boundary uses source chunk bounds rather than native ASR segment bounds.")
        for unit_id in selected:
            unit_cues.setdefault(unit_id, []).append(cue["key"])
        cue.update({
            "observed_text": " ".join(heard),
            "source_text": " ".join(units[u]["text"].strip() for u in selected),
            "exact_coverage": round(exact_coverage, 4),
            "aligned_coverage": round(aligned_coverage, 4),
            "token_similarity": round(similarity, 4),
            "estimated_start": min(units[u]["start"] for u in selected) if selected else None,
            "estimated_end": max(units[u]["end"] for u in selected) if selected else None,
            "chunk_ids": sorted({units[u]["chunk_id"] for u in selected}),
            "segment_ids": [units[u]["id"] for u in selected],
            "observed_word_range": [min(indices), max(indices) + 1] if indices else None,
            "matched_word_pairs": [{"expected_offset": i - begin, "observed_index": j,
                                    "match": kind, "unit": units[owners[j]]["id"]}
                                   for i, j, kind in strong],
            "unmatched_expected_words": [expected[i] for i in range(begin, end)
                                         if i not in by_expected or by_expected[i][1] == "mismatch"],
            "warnings": warnings,
        })
    shared = [{"segment_id": units[u]["id"], "chunk_id": units[u]["chunk_id"],
               "start": units[u]["start"], "end": units[u]["end"], "cue_keys": keys}
              for u, keys in unit_cues.items() if len(keys) > 1]
    shared_keys = {key for entry in shared for key in entry["cue_keys"]}
    for cue in cues:
        if cue["key"] in shared_keys:
            cue["warnings"].append("Shared ASR segment: cue boundary is ambiguous; refine using audio pauses.")
        cue["confidence"] = ("high" if cue["exact_coverage"] >= .85 and cue["token_similarity"] >= .85
                             else "medium" if cue["aligned_coverage"] >= .75 and cue["token_similarity"] >= .65
                             else "low")
        cue["boundary_confidence"] = "shared_segment_needs_refinement" if cue["key"] in shared_keys else "segment_or_chunk_bounds_only"
    # Report every unused run of recognized words, including headings and retakes.
    unused = [i for i in range(len(observed)) if i not in strong_observed]
    runs = []
    for index in unused:
        if not runs or index != runs[-1][-1] + 1:
            runs.append([index])
        else:
            runs[-1].append(index)
    extras = []
    for run in runs:
        selected = sorted({owners[i] for i in run})
        heard = [observed[i] for i in run]
        candidates = []
        if len(heard) >= 5:
            for cue in cues:
                score = SequenceMatcher(None, heard, cue["normalized_words"], autojunk=False).ratio()
                if score >= .6:
                    candidates.append({"cue_key": cue["key"], "text_similarity": round(score, 4)})
        extras.append({
            "text": " ".join(heard), "word_range": [run[0], run[-1] + 1],
            "estimated_start": min(units[u]["start"] for u in selected),
            "estimated_end": max(units[u]["end"] for u in selected),
            "chunk_ids": sorted({units[u]["chunk_id"] for u in selected}),
            "segment_ids": [units[u]["id"] for u in selected],
            "possible_retake_of": sorted(candidates, key=lambda c: -c["text_similarity"])[:3],
        })
    return {
        "schema_version": 1, "method": "global_monotonic_token_edit_alignment",
        "timing_precision": "ASR segment/chunk bounds only; no word timing was inferred",
        "summary": {
            "expected_cues": len(cues), "expected_words": len(expected),
            "observed_words": len(observed), "observed_units": len(units),
            "edit_cost": total_cost, "high_confidence": sum(c["confidence"] == "high" for c in cues),
            "medium_confidence": sum(c["confidence"] == "medium" for c in cues),
            "low_confidence": sum(c["confidence"] == "low" for c in cues),
            "shared_segments": len(shared), "unused_recognized_words": len(unused),
        },
        "input_warnings": input_warnings, "cues": cues, "shared_boundaries": shared,
        "extras": extras, "source_units": units, "observed_tokens": observed,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--script", type=Path, default=ROOT.parent / "pdf_lesson/narration.json")
    parser.add_argument("--transcript", type=Path, default=ROOT / "output/transcription.json")
    parser.add_argument("--output", type=Path, default=ROOT / "output/alignment_proposals.json")
    parser.add_argument("--allow-partial", action="store_true", help="Allow an unfinished ASR prefix for review only.")
    args = parser.parse_args()
    if not args.transcript.exists():
        parser.error(f"Full ASR transcription is not ready: {args.transcript}")
    script = json.loads(args.script.read_text(encoding="utf-8"))
    transcript = json.loads(args.transcript.read_text(encoding="utf-8"))
    chunk_plan = args.transcript.parent / "asr_chunks_plan.json"
    if chunk_plan.exists() and not args.allow_partial:
        planned = json.loads(chunk_plan.read_text(encoding="utf-8"))
        if len(transcript) < len(planned):
            parser.error(f"ASR is incomplete: {len(transcript)} of {len(planned)} chunks; use --allow-partial only for review.")
    proposals = propose(script, transcript)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(proposals, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(proposals["summary"], ensure_ascii=False))
    print(args.output)


if __name__ == "__main__":
    main()
