"""Publish only the reviewed film, timed script and reproducible source archive."""
from pathlib import Path
import hashlib,json,shutil,zipfile

ROOT=Path(__file__).resolve().parent
PREFIX='kinematika_po_pdf_s_vashim_golosom'

def main():
    quality=json.loads((ROOT/'output/quality_validation.json').read_text())
    assert quality['complete'] and quality['full_decode_passed']
    movie=ROOT/'output'/f'{PREFIX}_1080p60.mp4'
    with movie.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==quality['sha256']
    shutil.copy2(movie,ROOT.parent/movie.name)
    shutil.copy2(ROOT/'tekst_ozvuchki.txt',ROOT.parent/f'{PREFIX}_tekst.txt')
    archive=ROOT.parent/f'{PREFIX}_sources.zip'
    selected=[*ROOT.glob('*.py'),*ROOT.glob('*.json'),*ROOT.glob('*.md'),ROOT/'tekst_ozvuchki.txt']
    reports=['quality_validation.json','source_timeline.json','edit_decisions.json',
             'boundary_review.json','alignment_proposals.json','alignment_review.json','transcription.json',
             'asr_validation.json','audio_processing.log','visual_review.json']
    selected.extend(ROOT/'output'/p for p in reports if (ROOT/'output'/p).exists())
    selected.extend((ROOT/'output/retime_reports').glob('*.json'))
    selected.extend((ROOT/'output').glob('anchor_choices_*.json'))
    selected.extend((ROOT/'output').glob('*static_validation.json'))
    selected.extend((ROOT/'output/source_contacts').glob('sheet_*.jpg'))
    selected.extend((ROOT/'output/final_contacts').glob('sheet.jpg'))
    selected.extend((ROOT/'output/final_contacts').glob('manifest.json'))
    selected=sorted(set(p for p in selected if p.is_file()))
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in selected:z.write(p,'kinematika_pdf_human_lesson/'+str(p.relative_to(ROOT)))
        # Existing source films and full geometry are available separately; bundle
        # compact scene code/plan so the archive is independently understandable.
        source=ROOT.parent/'pdf_lesson'
        for p in [*source.glob('*.py'),source/'plan.json',source/'narration.json',
                  source/'README.md',source/'SOURCE_NOTES.md',source/'manim.cfg',*source.glob('scenes/*.py')]:
            z.write(p,'pdf_lesson/'+str(p.relative_to(source)))
        z.write(ROOT.parent/'setup_env.sh','setup_env.sh')
        z.write(ROOT.parent/'requirements.lock','requirements.lock')
    print('Packaged',movie.name,archive.name,flush=True)

if __name__=='__main__':main()
