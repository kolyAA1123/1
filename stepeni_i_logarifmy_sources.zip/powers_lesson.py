from pathlib import Path
import math
import json

import numpy as np
from manim import Axes, Create, Dot, FadeIn, FadeOut, Line, Scene, VGroup, config, smootherstep

from lesson_data import SECTIONS
from visual_style import BLACK_BG, CYAN, GOLD, GRID, INK, LAVENDER, MUTED, ROSE, equation, txt
from fast_video import enable

TITLE="Степени и логарифмы"
config.background_color=BLACK_BG
config.pixel_width=1920
config.pixel_height=1080
config.frame_rate=60
config.max_files_cached=500
enable()


def graph(kind):
    if kind in ("exp","log"):
        center=[-3.62,-.12,0]
        xlim=(-2.6,2.6) if kind=="exp" else (-.8,6.3)
        ylim=(-.6,4.4) if kind=="exp" else (-2.7,2.7)
        axes=Axes(x_range=[*xlim,1],y_range=[*ylim,1],x_length=5.2,y_length=3.8,
                  axis_config={"stroke_width":1.8,"color":MUTED,"include_ticks":False}).move_to(center)
        if kind=="exp":
            left=axes.plot(lambda x:2**x,x_range=[-2.45,2.08],color=CYAN,stroke_width=3.2)
            right=axes.plot(lambda x:2**(-x),x_range=[-2.08,2.45],color=GOLD,stroke_width=3.2)
            dots=VGroup(Dot(axes.c2p(0,1),color=INK),equation("1",INK,axes.c2p(0,1)+[-.22,.06,0],.25))
        else:
            left=axes.plot(math.log2,x_range=[.17,5.85,.025],color=CYAN,stroke_width=3.2)
            right=axes.plot(lambda x:-math.log2(x),x_range=[.17,5.85,.025],color=GOLD,stroke_width=3.2)
            dots=VGroup(Dot(axes.c2p(1,0),color=INK),equation("1",INK,axes.c2p(1,0)+[.05,-.28,0],.25))
        return VGroup(axes),VGroup(left,right,dots)
    if kind in ("numberline","log_answer"):
        center=-5.98
        y=-.25
        def point(x):
            return [center+.95*x,y,0]
        maximum=5 if kind=="numberline" else 4.65
        axis=Line(point(-.35),point(maximum),color=MUTED,stroke_width=2)
        values=[(1,"1"),(2,"2"),(4,"4")] if kind=="numberline" else [(1,"1"),(4,"4")]
        ticks=VGroup(*[equation(text,INK,np.array(point(value))+[0,-.32,0],.26) for value,text in values])
        if kind=="numberline":
            marks=VGroup(Line(point(.04),point(1),color=CYAN,stroke_width=5),Line(point(4),point(4.95),color=CYAN,stroke_width=5),
                         Dot(point(2),radius=.085,color=CYAN),
                         *[Dot(point(value),radius=.078,color=ROSE,fill_color=BLACK_BG,stroke_width=2)
                           for value in (1,4)])
        else:
            marks=VGroup(Line(point(1),point(4),color=CYAN,stroke_width=5),
                         Dot(point(1),radius=.075,color=ROSE,fill_color=BLACK_BG,stroke_width=2),
                         Dot(point(4),radius=.075,color=CYAN))
        return VGroup(axis,ticks),marks
    return VGroup(),VGroup()


class PowerLogLesson(Scene):
    def construct(self):
        sections=[]
        holds={}
        heading=txt(TITLE,27).to_corner(np.array([-1,1,0]),buff=.39)
        rule=Line([-6.57,2.79,0],[6.57,2.79,0],color=GRID,stroke_width=1.3)
        self.play(FadeIn(heading),Create(rule),run_time=1.05,rate_func=smootherstep)
        for number,(title,kind,beats) in enumerate(SECTIONS,1):
            subtitle=txt(title,25,MUTED).move_to([0,2.37,0])
            count=txt(f"{number:02d} / {len(SECTIONS):02d}",16,MUTED).move_to([6.06,3.51,0])
            axis,curves=graph(kind)
            active=[subtitle,count]
            if len(axis):
                active.append(axis)
            self.play(*[FadeIn(mob) for mob in active],run_time=.78,rate_func=smootherstep)
            sections.append(dict(group=TITLE,heading=title,points=[]))
            centers=np.linspace(1.21,-1.52,len(beats))
            for index,((formula,text),y) in enumerate(zip(beats,centers)):
                color=(INK,CYAN,GOLD,LAVENDER)[index]
                height=.68 if "\\frac" in formula else .53
                visual=equation(formula,color,[3.25 if kind else 0,y,0],height)
                width=6.62 if kind else 12.45
                if visual.width>width:
                    visual.scale_to_fit_width(width)
                motions=[FadeIn(visual,shift=np.array([0,.07,0]))]
                active.append(visual)
                if index==(len(beats)-1 if kind in ("numberline","log_answer") else 0) and len(curves):
                    motions.append(Create(curves))
                    active.append(curves)
                self.play(*motions,run_time=.61,rate_func=smootherstep)
                self.wait(1/60)
                clip=self.renderer.num_plays-1
                holds[clip]=60*(math.ceil(len(text.split())/2.15)+1)
                sections[-1]["points"].append(dict(clip=clip,text=text))
            self.play(*[FadeOut(mob) for mob in active],run_time=.68,rate_func=smootherstep)
        self.play(FadeOut(heading),FadeOut(rule),run_time=1,rate_func=smootherstep)
        record=dict(holds=holds,data=sections,clips=self.renderer.num_plays)
        Path("timing_01_01.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
