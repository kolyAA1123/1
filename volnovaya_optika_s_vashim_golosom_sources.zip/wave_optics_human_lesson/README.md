# Волновая оптика — монтаж с авторской озвучкой

Исходные анимации и сценарий опубликованы в `volnovaya_optika_sources.zip`
и `volnovaya_optika_tekst.txt`. Этот монтаж использует исходный MP4
`volnovaya_optika_1080p60.mp4` и две части предоставленной записи.
В озвученной версии 9 глав, 58 реплик и 29 действий на экране.

Первая часть заканчивается объяснением фазового сдвига при отражении.
Вторая начинается с результата для верхней и нижней границ тонкой
плёнки. Стык находится в паузе после 49-й реплики. В монтаже сокращён
пустой участок перед началом чтения. Окна речи сверены с исходным
сценарием и сигналом. Вставки между репликами дают завершиться
исходным анимациям.

`boundaries.json` содержит уточнённые границы по объединённой записи в секундах.
`edit.json` описывает соответствие кадров и аудиоотсчётов, а `timeline.txt`
содержит сценарий с новыми таймкодами.

## Повторная сборка

Запустите из папки `wave_optics_human_lesson`. Нужны Python 3.11+
с NumPy и FFmpeg с libx264.

```sh
bash join_recording.sh "Волновая оптика.m4a" "Волновая оптика 2.m4a"
python build_edit.py /path/to/volnovaya_optika_1080p60.mp4 recording.wav
bash render_audited.sh /path/to/volnovaya_optika_1080p60.mp4 volnovaya_optika_s_vashim_golosom_1080p60.mp4
mv source-audited.gray source.gray
python check_holds.py source.gray
ffmpeg -v error -xerror -threads 2 -i volnovaya_optika_s_vashim_golosom_1080p60.mp4 \
  -map 0:v:0 -vf scale=160:90,format=gray -filter_threads 1 -f rawvideo delivered.gray \
  -map 0:a:0 -f s16le audio_decode.s16
python verify_edit.py volnovaya_optika_s_vashim_golosom_1080p60.mp4
```

Монтаж меняет длительность статичных кадров и паузы между репликами.
Внутри реплик отсчёты идут непрерывно с исходным темпом и высотой.
Для выпуска один канал закодирован в AAC. Исходные записи используются
локально. В архив включены план, сценарий, монтажные решения и проверки.
