"""Check stream format, speech placement, and the visual correspondence."""
import json
from pathlib import Path
import subprocess
import sys

import numpy as np

edit = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("edit")
plan_root = Path("wave_optics_lesson")
plan = json.loads((plan_root/"plan.json").read_text())
mapping = json.loads((edit/"edit.json").read_text())
video = Path(sys.argv[1])
total = mapping["total_frames"]
windows = mapping["windows"]
assert len(windows) == 58
probe = json.loads(subprocess.check_output([
    "ffprobe", "-v", "error", "-show_streams", "-show_chapters", "-of", "json", str(video),
]))
v, a = [stream for stream in probe["streams"] if stream["codec_type"] in ("video","audio")]
assert (v["codec_name"],v["width"],v["height"],v["r_frame_rate"],int(v["nb_frames"])) == (
    "h264",1920,1080,"60/1",total,
)
assert (a["codec_name"],int(a["sample_rate"]),a["channels"]) == ("aac",48000,1)
assert len(probe["chapters"]) == 9
assert abs(float(a["duration"])-total/60) < .03
assert video.stat().st_size < 100*1024**2
action_gaps = []
for chapter in plan["chapters"]:
    report = json.loads((plan_root/"output/sync_checks/final"/f"{chapter['id']:02}.json").read_text())
    for beat in chapter["beats"]:
        i = beat["index"] + 1
        intro, result = [window for window in windows if window["chapter"] == chapter["id"] and window["beat"] == i]
        times = {item["event"]: item["time"] for item in report["events"] if item["beat"] == i}
        delta = (intro["output_hold"][1]-intro["source_hold"][1])/60
        intro_before = (intro["output_hold"][0]-intro["source_hold"][0])/60
        assert chapter["start"]+times["intro_ready"]+intro_before < intro["speech"][0]
        action_start = chapter["start"]+times["action_start"]+delta
        action_end = chapter["start"]+times["action_end"]+delta
        assert intro["speech"][1] < action_start < action_end < result["speech"][0]
        assert result["source_hold"][0] > round((chapter["start"]+times["result_ready"])*60)
        action_gaps.append([intro["speech"][1],action_start,action_end,result["speech"][0]])
assert len(action_gaps) == 29

source = np.memmap("source.gray",dtype="uint8",mode="r",shape=(plan["duration"]*60,90,160))
delivered = np.memmap("delivered.gray",dtype="uint8",mode="r",shape=(total,90,160))
assert Path("delivered.gray").stat().st_size == total*90*160
frame_pairs = []
source_at = output_at = 0
for hold in windows:
    s,e = hold["source_hold"]
    u,w = hold["output_hold"]
    assert s-source_at == u-output_at
    frame_pairs.extend(zip(range(source_at,s,6),range(output_at,u,6)))
    frame_pairs.extend((s,k) for k in (u,(u+w)//2,w-1))
    source_at,output_at=e,w
frame_pairs.extend(zip(range(source_at,len(source),6),range(output_at,total,6)))
differences = [float(np.abs(source[i].astype("int16")-delivered[j]).mean()) for i,j in frame_pairs]
assert max(differences) < 1.0, max(differences)
assert int(delivered[:, :4, :4].max()) <= 6
assert float(np.abs(delivered[-1].astype("int16")-source[-1]).mean()) < .20

with open("audio_decode.s16","rb") as file:
    actual = np.fromfile(file,dtype="<i2")
import wave
with wave.open(str(edit/"narration.wav"),"rb") as file:
    master = np.frombuffer(file.readframes(file.getnframes()),dtype="<i2")
assert len(actual) >= len(master) and len(actual)-len(master) < 1024
correlations = []
for hold in windows:
    start = hold["audio_output_sample"]
    a,b = hold["audio_source_samples"]
    length = b-a
    prepared = master[start:start+length:8].astype("float64")
    decoded = actual[start:start+length:8].astype("float64")
    correlations.append(float(np.corrcoef(prepared,decoded)[0,1]))
assert min(correlations) > .97, min(correlations)
report = dict(frames=total, duration_seconds=total/60, audio_tracks=1, chapters=9, actions=29,
              narration_windows=len(windows), compared_frames=len(frame_pairs),
              maximum_visual_sample_difference=max(differences), decoded_audio_minimum_correlation=min(correlations),
              action_boundaries=action_gaps, bytes=video.stat().st_size)
(edit/"verification.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({key:value for key,value in report.items() if key!="action_boundaries"},indent=2))
