#!/usr/bin/env bash
set -euo pipefail
ffmpeg -nostdin -n -v error -i "$1" -i "$2" \
  -filter_complex '[0:a]aformat=sample_rates=48000:channel_layouts=mono[first];[1:a]aformat=sample_rates=48000:channel_layouts=mono[second];[first][second]concat=n=2:v=0:a=1[a]' \
  -map '[a]' -c:a pcm_s16le recording.wav
